﻿/*!@license
 * Infragistics.Web.ClientUI Grid Multi Headers 15.1.20151.2352
 *
 * Copyright (c) 2011-2015 Infragistics Inc.
 *
 * http://www.infragistics.com/
 *
 * Depends on:
 *	jquery-1.4.4.js
 *	jquery.ui.core.js
 *	jquery.ui.widget.js
 *	modernizr.js (Optional)
 *	infragistics.ui.grid.framework.js
 *	infragistics.ui.shared.js
 *	infragistics.dataSource.js
 *	infragistics.util.js
 */

/*global jQuery, Modernizr, MSApp, Modernizr */
/*jshint -W018 */
if (typeof jQuery !== "function") {
	throw new Error("jQuery is undefined");
}

(function ($) {
	var _aNull = function (val) { return val === null || val === undefined; };

	$.widget("ui.igGridColumnFixing", {
		/* 
		igGridColumnFixing widget 
		The widget is pluggable to the element where the grid is instantiated and the actual igGrid object doesn't know about it.
		*/
		/* property showing whether it should be rendered in feature chooser */
		renderInFeatureChooser: true,
		events: {
			/* cancel="true" Event which is fired when column fixing operation is initiated
			Function takes arguments evt and args.
			use args.columnIdentifier to get columnKey or columnIndex
			use args.isGroupHeader to get whether header cell has children(use this argument ONLY when multi-column-headers are enabled)
			use args.owner to get a reference to the widget
			*/
			columnFixing: "columnFixing",
			/* Event which is fired when column fixing operation is finished
			Function takes arguments evt and args.
			use args.columnIdentifier to get columnKey or columnIndex
			use args.isGroupHeader to get whether header cell has children(use this argument ONLY when multi-column-headers are enabled)
			use args.owner to get a reference to the widget
			*/
			columnFixed: "columnFixed",
			/* cancel="true" Event which is fired when column unfixing operation is initiated
			Function takes arguments evt and args.
			use args.columnIdentifier to get columnKey or columnIndex
			use args.isGroupHeader to get whether header cell has children(use this argument ONLY when multi-column-headers are enabled)
			use args.owner to get a reference to the widget
			*/
			columnUnfixing: "columnUnfixing",
			/* Event which is fired when column unfixing operation is done
			Function takes arguments evt and args.
			use args.columnIdentifier to get columnKey or columnIndex
			use args.isGroupHeader to get whether header cell has children(use this argument ONLY when multi-column-headers are enabled)
			use args.owner to get a reference to the widget
			*/
			columnUnfixed: "columnUnfixed",
			/* Event which is fired when column fixing operation has failed - e.g. sum of the width of the fixed columns container and width of the column to be fixed exceeds the grid width
			Function takes arguments evt and args.
			use args.columnIdentifier to get columnKey or columnIndex
			use args.isGroupHeader to get whether header cell has children(use this argument ONLY when multi-column-headers are enabled)
			use args.errorMessage to get error message describing the reason fixing has failed
			use args.owner to get a reference to the grid widget
			*/
			columnFixingRefused: "columnFixingRefused",
			/* Event which is fired when column unfixing operation has failed - e.g.: there is only one fixed visible column(and tries to unfix it) and at least one fixed hidden column
			Function takes arguments evt and args.
			use args.columnIdentifier to get columnKey or columnIndex
			use args.isGroupHeader to get whether header cell has children(use this argument ONLY when multi-column-headers are enabled)
			use args.errorMessage to get error message describing the reason unfixing has failed
			use args.owner to get a reference to the grid widget
			*/
			columnUnfixingRefused: "columnUnfixingRefused"
		},
		css: {
			/* Classes applied to the main fixed container */
			fixedContainer: 'ui-iggrid-fixedcontainer',
			/* classes applied to the container div of header button(which holds button for fixing/unfixing) */
			headerButtonIconContainer: 'ui-iggrid-fixcolumn-headerbuttoncontainer',
			/* Classes applied to the left side container */
			leftFixedContainer: 'ui-iggrid-fixedcontainer-left',
			/* Classes applied right side fixed container */
			rightFixedContainer: 'ui-iggrid-fixedcontainer-right',
			/* Classes applied to header cell button for fixing column */
			headerButtonIcon: 'ui-icon ui-corner-all ui-icon-pin-w',
			/* Classes applied to header cell button for fixing column */
			headerButtonIconHover: '',//ui-state-hover
			/* Classes applied to header cell button for unfixing column */
			headerButtonUnfixIcon: 'ui-icon ui-corner-all ui-icon-pin-s',
			/* Classes applied in feature chooser icon when column is not fixed */
			featureChooserIconClassFixed: 'ui-icon ui-iggrid-icon-unfix',
			/* Classes applied in feature chooser icon when column is fixed */
			featureChooserIconClassUnfixed: 'ui-icon ui-iggrid-icon-fix',
			/* Classes applied in unfixed table when fixing direction is left */
			unfixedTableLeft: 'ui-iggrid-unfixed-table-left',
			/* Classes applied in unfixed table when fixing direction is right */
			unfixedTableRight: 'ui-iggrid-unfixed-table-right'
		},
		internalErrors: {
			none: $.ig.ColumnFixing.locale.internalErrors.none,
			notValidIdentifier: $.ig.ColumnFixing.locale.internalErrors.notValidIdentifier,
			fixingRefused: $.ig.ColumnFixing.locale.internalErrors.fixingRefused,
			fixingRefusedMinVisibleAreaWidth: $.ig.ColumnFixing.locale.internalErrors.fixingRefusedMinVisibleAreaWidth,
			alreadyHidden: $.ig.ColumnFixing.locale.internalErrors.alreadyHidden,
			alreadyUnfixed: $.ig.ColumnFixing.locale.internalErrors.alreadyUnfixed,
			alreadyFixed: $.ig.ColumnFixing.locale.internalErrors.alreadyFixed,
			unfixingRefused: $.ig.ColumnFixing.locale.internalErrors.unfixingRefused,
			targetNotFound: $.ig.ColumnFixing.locale.internalErrors.targetNotFound
		},
		options: {
			/* type="string" Specifies altering text on column fixing header icon when column is not fixed */
			headerFixButtonText: $.ig.ColumnFixing.locale.headerFixButtonText,
			/* type="string" Specifies altering text on column fixing header icon when column is fixed */
			headerUnfixButtonText: $.ig.ColumnFixing.locale.headerUnfixButtonText,
			/* type="bool" option to show column fixing buttons in header cells/feature chooser */
			showFixButtons: true,
			/* type="bool" option enable syncing heights of rows between fixed/unfixed rows */
			syncRowHeights: true,
			/* type="number" option to configure scroll delta when scrolling with mouse wheel or keyboard in fixed columns area*/
			scrollDelta: 40,
			/* type="left|right" configure on which side to render fixed area
				left type="string" fixed column are rendered on the left side of the main grid.
				right type="string" fixed column are rendered on the right side of the main grid.
			*/
			fixingDirection: 'left',
			/* type="array" a list of column settings that specifies custom column fixing options on a per column basis */
			columnSettings: [
				{
					/* type="string" Specifies column key. Either key or index must be set in every column setting.*/
					columnKey: null,
					/* type="number" Specifies column index. Either key or index must be set in every column setting.*/
					columnIndex: null,
					/* type="bool" Specifies whether the column allows to be fixed or not.*/
					allowFixing: true,
					/* type="bool" Specifies whether the column to be fixed or not.*/
					isFixed: false
				}
			],
			/* type="string" Feature chooser text of the fixed column*/
			featureChooserTextFixedColumn: $.ig.ColumnFixing.locale.featureChooserTextFixedColumn,
			/* type="string" Feature chooser text of the unfixed column*/
			featureChooserTextUnfixedColumn: $.ig.ColumnFixing.locale.featureChooserTextUnfixedColumn,
			/* type="string|number" minimal visible area for unfixed columns. For instance if you fix a column(or columns) and the width of the fixed columns is such that the width of visible are of unfixed columns is less than this option then fixing will be canceled
				string The width can be set in pixels (px) and percentage (%).
				number The width can be set as a number.
			*/
			minimalVisibleAreaWidth: 30,
			/* type="bool" Specify initial fixing of non data columns(like specific rowSelectors columns on the left side of the grid) when fixingDirection is left*/
			fixNondataColumns: true,
			/* type="bool" If true then on column fixing when creating table rows all row attributes for the unfixed rows will be set in fixed rows too. Because of performance issue you can set this option to false */
			populateDataRowsAttributes: true
		},
		/* value to check when grid height is not set and fixed and unfixed area has different heights. When difference is more than this value then append blank div to fixed area so to compensate horizontal scrollbar */
		scrollContainerCheckValue: 2,
		_createWidget: function () {
			// feature chooser data
			this._fcData = {};
			this._tds = {};
			this._containers = {};
			this._colgroups = {};
			this._isInitFC = false;
			this._isFunctionsOverriden = false;
			$.Widget.prototype._createWidget.apply(this, arguments);
		},
		_unfixColumnInternal: function (colKey, isGroupHeader, target, after) {
			var noCancel, res, grid = this.grid;
			
			noCancel = this._trigger(this.events.columnUnfixing, null, {
				//'columnIndex' : colInd,
				'columnIdentifier': colKey,
				'isGroupHeader': isGroupHeader,
				owner: grid
			});
			if (noCancel) {
				res = this.unfixColumn(colKey, isGroupHeader, target, after);
				if (res.result === false) {
					this._trigger(this.events.columnUnfixingRefused, null, {
						'columnIdentifier': colKey,
						'isGroupHeader': isGroupHeader,
						'errorMessage': res.error,
						owner: grid
					});
				} else {
					this._trigger(this.events.columnUnfixed, null, {
						'columnIdentifier': colKey,
						'isGroupHeader': isGroupHeader,
						owner: grid
					});
				}
			}
			return res;
		},
		unfixColumn: function (colIdentifier, isGroupHeader, target, after) {
			/* Unfix column by specified column identifier - column key or column index
			paramType="number|string" An identifier of the column to be unfixed - column index or column key.
			paramType="bool" optional="true" when true indicates that the column is multi-column header.
			paramType="string" optional="true" Key of the column where the unfixed column should move to.
			paramType="bool" optional="true" Specifies where the unfixed column should be moved after or before the target column. This parameter is disregarded if there is no target column specified.
			returnType="object" Object description: { result: indicates whether unfixing is successful, error: error message describing the reason unfixing has failed, col: reference to the column object(if column identifier is not valid - then its value is null) }
			*/
			var col, self = this, res, colWidth,
				hasDataSkippedColumns = this._hasDataSkippedColumns(true), c, mchLevel,
				children, columnKeys, columnIndex, colKey, MCHchildren, key, $th,
				colIdentifierType = $.type(colIdentifier), initialFixedColsIndex,
				i, j, cols = this.grid.options.columns, colsLength = cols.length,
				grid = this.grid, childrenUnfixingAllowed = [],
				initialFixedColumnsLength = this.grid._fixedColumns.length,
				indexAt, columnIndexAt, hasTarget = false, targetRes, at,
				columnIndexes = [], gridId = grid.id(),
				visibleIndex, vI, inMCHGroup, $colgroup, $vContainer;
			
			res = {error: this.internalErrors.none, result: true, col: null};
			columnKeys = [];
			// M.H. 22 Feb 2013 Fix for bug #133770: fixColumn and unfixColumn methods should work with column index and column key.
			if (!isGroupHeader) {
				if (colIdentifierType === 'number') {
					columnIndex = colIdentifier;
				} else if (colIdentifierType === 'string') {
					columnIndex = -1;
					for (i = 0; i < colsLength; i++) {
						if (cols[i].key === colIdentifier) {
							columnIndex = i;
							break;
						}
					}
				}
				col = cols[columnIndex];
				res.col = col;
				if (col === null || col === undefined) {
					res.result = false;
					res.error = this.internalErrors.notValidIdentifier;
					return res;
				}
				colKey = col.key;
				columnKeys.push(colKey);
				visibleIndex = this._getVisibleIndex(colKey, true);
				$th = this.grid.container().find("#" + gridId + "_" + colKey);
				res.col = col;
				columnIndexes.push({ cI: columnIndex, vI: visibleIndex });
				children = [col];
				childrenUnfixingAllowed = [col];
			} else {
				c = [];
				$th = this.grid.fixedHeadersTable().find('th[data-mch-id=' + colIdentifier + ']');
				colKey = colIdentifier;
				MCHchildren = this.grid._getMultiHeaderColumnById(colIdentifier);
				res.col = MCHchildren;
				if (!MCHchildren) {
					res.result = false;
					res.error = this.internalErrors.notValidIdentifier;
					return res;
				}
				children = MCHchildren.children;
				childrenUnfixingAllowed = MCHchildren.children;
				columnKeys = [];
				for (i = 0; i < children.length; i++) {
					key = children[i].key;
					columnKeys.push(key);
					if (children[i].hidden === true) {
						vI = -1;
					} else {
						vI = this._getVisibleIndex(children[i].key, true);
						c.push(children[i]);
					}
					for (j = 0; j < colsLength; j++) {
						if (cols[j].key === key) {
							columnIndexes.push({ cI: j, vI: vI });
							break;
						}
					}
				}
				children = c;
			}
			// analyze target if specified
			if (!_aNull(target)) {
				hasTarget = true;
				targetRes = this._analyzeTargetIndexes(target, after, false);
				if (!targetRes) {
					res.result = false;
					res.error = this.internalErrors.targetNotFound.replace("{key}", res.col.key);
					return res;
				}
				indexAt = targetRes.indexAt;
				columnIndexAt = targetRes.columnIndexAt;
			}
			if (!!res.col.fixed === false) {
				res.result = false;
				res.error = this.internalErrors.alreadyUnfixed;
				return res;
			}
			if (res.col.hidden) {
				res.result = false;
				res.error = this.internalErrors.alreadyHidden;
				return res;
			}
			if (grid._isMultiColumnGrid) {
				mchLevel = $th.closest('tr').attr('data-mch-level');
				if (mchLevel && parseInt(mchLevel, 10) !== grid._maxLevel) {
					res.result = false;
					res.error = this.internalErrors.ActionNotAllowedForChildHeaderColumn;
					return res;
				}
			}
			// in case there is only 1 visible column in fixed area and we try to unfix
			if (!this.checkUnfixingAllowed(childrenUnfixingAllowed)) {
				res.result = false;
				res.error = this.internalErrors.unfixingRefused;
				return res;
			}
			if ($th.length > 0) {
				colWidth = $th.outerWidth();
			} else {
				colWidth = this.grid.container().find("#" + this.grid.id() + " tbody>tr:nth-child(1)>td:nth-child(" + (visibleIndex + 1) + ")").outerWidth();
			}
			this._populateContainers();
			this._rearrangeOldColsByColumnKey(colKey, false, target, after);
			colWidth = -colWidth;
			initialFixedColsIndex = self.grid._fixedColumns.length - 1;
			inMCHGroup = true;
			for (i = columnIndexes.length - 1, j = 0; i > -1; i--, j++) {
				if (columnIndexes[i].vI !== -1) {
					visibleIndex = columnIndexes[i].vI + 1;
					this._unfixColumnByVisibleIndex(visibleIndex, colWidth, false, 
									{ inMCHGroup: inMCHGroup, colIdentifier: colKey, isGroupHeader: isGroupHeader }, indexAt);
					inMCHGroup = false;
				}
				col = cols.splice(columnIndexes[i].cI, 1);
				col[0].fixed = false;
				
				if (!hasTarget) {
				cols.splice(initialFixedColsIndex - j, 0, col[0]);
				} else {
					at = columnIndexAt - j - 1;
					cols.splice(at, 0, col[0]);
				}
				vI = -1;
				if (columnIndexes[i].vI !== -1) {
					vI = columnIndexes[i].vI + 1;
			}
				this.grid._onColumnFixed(columnIndexes[i].cI, false, initialFixedColumnsLength - j, false, vI, at);
			}
			for (i = 0; i < columnKeys.length; i++) {
				key = columnKeys[i];
				for (j = 0; j < this.grid._fixedColumns.length; j++) {
					if (this.grid._fixedColumns[j].key === key) {
						col = self.grid._fixedColumns.splice(j, 1);
						col[0].fixed = false;
						break;
					}
				}
			}
			this.grid._visibleColumnsArray = undefined;
			if ($.ig.util.isIE10) {
				this.grid._hscrollbar().width('');
			}
			// M.H. 23 Aug 2013 Fix for bug #150279: When fixingDirection is "right" and row selectors are enabled unfixing columns breaks the grid.
			if (this.grid._fixedColumns.length === 0 &&
				(!hasDataSkippedColumns || this.options.fixingDirection === 'right' ||
				(hasDataSkippedColumns && !this.options.fixNondataColumns))) {
				this._removeFixedContainer();
			} else if (this.options.syncRowHeights) {
				// M.H. 13 Dec 2013 Fix for bug #159796: Fixing the first column causes misalignment between rows in fixed/unfixed area(in the new theme)
				this.checkAndSyncHeights();
			}
			grid._updateHeaderColumnIndexes();
			grid._columnMovingResets();
			this._updateGridColWidths();
			this.grid._hscrollbarcontent().scrollLeft(0);
			if (isGroupHeader) {
				this._changeStyleHeaderButton(colIdentifier, false, isGroupHeader);
			} else {
				this._changeStyleHeaderButton(columnKeys[0], false, isGroupHeader);
				}
			// M.H. 22 Jul 2013 Fix for bug #147064: When column is resized and the content of the cells is distributed on two rows the rows from both areas are misaligned.
			// when width is changed gridContentWidth is not taken properly on unfixing columns
			if (this.grid.element.data("igGridResizing")) {
				this.grid._updateGridContentWidth();
			}
			if (this._isVirtualGrid()) {
				grid._resetVirtualDom();
				if (grid._fixedColumns.length === 0 &&
					(!hasDataSkippedColumns || this.options.fixingDirection === 'right' ||
					(hasDataSkippedColumns && !this.options.fixNondataColumns))) {
					$vContainer = grid._virtualcontainer();
					$colgroup = $vContainer.find('colgroup:first');
					$colgroup.find('[data-fixed-col]').remove();
					$vContainer.find('tr td[data-fixed-container]').remove();
					if (this.options.fixingDirection === 'right') {
						this._adjustVirtualizationContainers(false);
						// header
						$vContainer.find('tr:first td:first').attr('colspan', 2);
						$vContainer.find('tr:last td:first').attr('colspan', 2);
					}
				}
				// M.H. 20 Aug 2014 Fix for bug #178399: When virtualization mode is "continuous" and you unfix column the records are scrolled to the top but the scrollbar is not updated.
				if (this._isContinuousVirtualization()) {
					grid._setScrollContainerScrollTop(0);
				}
				// M.H. 1 Apr 2015 Fix for bug 187416: When fixed virtualization is enabled and you call unfixColumn for unfixed column another vertical scrollbar is rendered and the result is true.
				if (this.options.fixingDirection !== 'right' || this.grid._fixedColumns.length === 0) {
					grid._adjustLastColumnWidth(true);
				}
			} else {
				// M.H. 10 Sep 2014 Fix for bug #180223: When you call commit the fixed area shrinks.
				grid._adjustLastColumnWidth(true);
			}
			this._updateHScrollbarWidth();
			this._trigger('_columnUnfixed', null, {
				'columnIdentifier': colIdentifier,
				isGroupHeader: isGroupHeader,
				columnindexAt: columnIndexAt
			});
			return res;
		},
		_removeFixedContainer: function () {
			var grid = this.grid, scrollContainer;
			if (!this._containers) {
				this._populateContainers();
			}
			scrollContainer = this._containers.body.unfixedContainer;
				// remove skipped columns
				if (this.options.fixingDirection === 'left') {
					this.unfixDataSkippedColumns();
				}
				scrollContainer.unbind('.columnFixing');
				// M.H. 12 Dec 2013 Fix for bug #159796: Fixing the first column causes misalignment between rows in fixed/unfixed area(in the new theme)
				if (this._containers && this._containers.body) {
					this._containers.body.unfixedTable
						.removeClass(this.css.unfixedTableLeft)
						.removeClass(this.css.unfixedTableRight);
				}
				// M.H. 26 Feb 2013 Fix for bug #134003: When the fixingDirection is "right" mouse wheel scroll does not work when you hover the unfixed area.
				if (this._DOMMouseScroll !== null && this._DOMMouseScroll !== undefined) {
					scrollContainer.unbind({
						DOMMouseScroll: this._DOMMouseScroll
					});
					this._DOMMouseScroll = null;
				}
				grid.fixedContainer().remove();
				if (this.options.fixingDirection === 'right' && !this._isVirtualGrid()) {
					scrollContainer.css({ 'overflow-y': 'auto' });
				}
				// M.H. 21 Feb 2013 Fix for bug #133521: When you fix and unfix a column the width of the columns changes and scrolling the grid to the right misaligns it.
				grid._hscrollbar().css({
				width: '100%',
					left: 0
				});
				// M.H. 24 Feb 2013 Fix for bug #133421: Columns and headers are misaligned on fixing a column when grid and its columns doesn't have width set
				if (grid.options.width === null && grid.container()[0].style.width === '') {
					grid.container().css('width', '');
				}
				if (grid.options.enableHoverStyles) {
					this._dettachHoverEvents();
				}
		},
		checkAndSyncHeights: function () {
			/*Check whether heights of fixed and unfixed tables are equal - if not sync them. Similar check is made for heights of table rows.
			*/
			if (!this.grid.hasFixedColumns()) {
				return;
			}
			if (!this._containers || !this._containers.body) {
				this._populateContainers();
			}
			var c = this._containers,
				hTbl = c.header || c.body,
				fTbl = c.footer || c.body;
			this._checkAndSyncHeightsForTables(hTbl.fixedTable, hTbl.unfixedTable, 'thead');
			this._checkAndSyncHeightsForTables(c.body.fixedTable, c.body.unfixedTable, 'tbody');
			this._checkAndSyncHeightsForTables(fTbl.fixedTable, fTbl.unfixedTable, 'tfoot');
		},
		_checkAndSyncHeightsForTables: function ($fTbl, $ufTbl, selector) {
			// check whether height of fixed and unfixed tables are equal and also whether offset of last <TR> of fixed and unfixed tables are equal - if not sync rows heights of fixed and unfixed table
			// use selector - to get THEAD/TBODY/TFOOT and its child TRs - performance optimization
			selector = selector || 'tbody';
			var h, fH, ufH,
				$fTrs = $fTbl.children(selector).children('tr'),
				$ufTrs = $ufTbl.children(selector).children('tr'),
				$fLastTr	= $fTrs.last(),
				$ufLastTr	= $ufTrs.last();
			if ($fLastTr.length > 0 &&
				(Math.abs($fTbl.outerHeight() - $ufTbl.outerHeight()) > 1 ||
				Math.abs($fLastTr.offset().top - $ufLastTr.offset().top) > 1)) {
				this.syncRowsHeights($fTrs, $ufTrs);
				fH = $fTbl.height();
				ufH = $ufTbl.height();
				h = ufH;
				if (fH > ufH) {
					h = fH;
				}
				$fTbl.height(h);
				$ufTbl.height(h);
			}
		},
		_getKeyByVisibleIndex: function (index, isFixed) {
			var hasDataSkippedColumns = this._hasDataSkippedColumns(), cols, col,
				dataSkippedColsLength = 0, visibleCols = this.grid._visibleColumns();

			cols = $.grep(visibleCols, function (col) {
				var f = (col.fixed === true);
				return f === isFixed;
			});
			if (hasDataSkippedColumns) {
				dataSkippedColsLength = this._getDataSkippedColumnsLength(isFixed);
				index -= dataSkippedColsLength;
			}
			// M.H. 16 June 2014 Fix for bug #173254: When ColumnFixing, RowSelectors and Tooltips are enabled hovering the row selector throws a js error.
			col = cols[index];
			if (!col) {
				return undefined;
			}
			return col.key;
		},
		_unfixColumnByVisibleIndex: function (
				visibleIndex,
				colWidth,
				isDataSkip,
				MCHParams,
				indexAt) {
			var grid = this.grid, inMCHGroup, colIdentifier, isGroupHeader,
				containerBody = this._containers.body,
				containerHeader = this._containers.header,
				containerFooter = this._containers.footer,
				isMCH = grid._isMultiColumnGrid;
			if (MCHParams) {
				inMCHGroup = MCHParams.inMCHGroup;
				colIdentifier = MCHParams.colIdentifier;
				isGroupHeader = MCHParams.isGroupHeader;
			}
			if (!containerHeader) {
				containerHeader = containerBody;
			}
			if (!containerFooter) {
				containerFooter = containerBody;
			}
			this._getElementsByDOM(visibleIndex, containerHeader.fixedTable.children('thead'), 'header', false, isDataSkip);
			this._getElementsByDOM(visibleIndex, containerBody.fixedTable.children('tbody'), 'body', false, isDataSkip);
			this._getElementsByDOM(visibleIndex, containerFooter.fixedTable.children('tfoot'), 'footer', false, isDataSkip);
			this._getColgroups(visibleIndex, true);
			if (isDataSkip) {
				if (this._tds.header.length > 0) {
					colWidth = $(this._tds.header[0]).outerWidth();
				} else if (this._tds.body.length > 0) {
					colWidth = $(this._tds.body[0]).outerWidth();
				}
				colWidth = -colWidth;
			}
			this._detachColgroups();
			// detach header/ body / footer cells
			this._tds.header.detach();
			this._tds.body.detach();
			this._tds.footer.detach();
			if (inMCHGroup || isDataSkip) {
				this._syncWidth(colWidth);
			}
			this._attachColgroups(true, indexAt);
			if (grid.options.showHeader) {
				this._unfixHeaderColumn(indexAt);
			}
			this._unfixBodyColumn(indexAt);
			this._unfixFooterColumn(indexAt);

			if (grid.options.showHeader && isMCH && inMCHGroup) {
				this._unfixMultiColumnHeader(colIdentifier, isGroupHeader, indexAt);
//				this._getElementsByDOM(visibleIndex, containerHeader.fixedTable.find('thead').eq(0), 'header');
//				this._unfixHeaderColumn();
			}
		},
		_setOption: function (key, value) {
			if (value === this.options[key]) {
				return;
			}
			$.Widget.prototype._setOption.apply(this, arguments);
			if (key === 'minimalVisibleAreaWidth') {
				this.grid._visibleAreaWidth(value);
			}
		},
		_gridSetOption: function (key, value) {
			// check whether value is properly set when there are fixed columns - e.g. setting width of the grid - check whether the new value is OK(as checking option minimalVisibleAreaWidth)
			var w = value, grid = this.grid, fcw/*fixed container width*/;
			if (!grid.hasFixedColumns()) {
				return;
			}
			if (key === 'width') {
				if (w.indexOf && w.indexOf('%') > 0) {
					throw new Error($.ig.ColumnFixing.locale.columnsWidthShouldBeSetInPixels);
				}
				w = parseInt(value, 10);
				fcw = grid.fixedContainer().outerWidth();
				if (fcw === null) {
					fcw = grid.fixedBodyContainer().outerWidth();
				}
				if (w - fcw < parseInt(this.options.minimalVisibleAreaWidth, 10)) {
					throw new Error($.ig.ColumnFixing.locale.setOptionGridWidthException);
				}
			}
		},
		unfixDataSkippedColumns: function () {
			/* Unfix data skipped columns(like row selectors) if any when fixingDirection is left
			*/
			var i, dataSkippedColsLength,
				isMCH = this.grid._isMultiColumnGrid,
				hasDataSkippedColumns = this._hasDataSkippedColumns();
			// we should fix data skipped columns if any - for now supported scenario is ONLY if fixing direction is LEFT
			if (this.options.fixingDirection === 'left' && hasDataSkippedColumns) {
				dataSkippedColsLength = this._getDataSkippedColumnsLength(true);
				if (isMCH) {
					this._unfixMultiColumnHeaderDataSkip();
				}
				this.grid._hasFixedDataSkippedColumns = false;
				for (i = dataSkippedColsLength - 1; i > -1; i--) {
					this._unfixColumnByVisibleIndex((i + 1), null, true);
					this.grid._onColumnFixed(-1, false, 0, false);
				}
			}
		},
		unfixAllColumns: function () {
			/* Unfix all columns
			*/
			// M.H. 6 Jun 2013 Fix for bug #142858: The grid's multi column headers are shuffled when you fix a few groups and then you call unfixAllColumns.
			var i, ths, self = this, colsToUnfix = [], isMCH = this.grid._isMultiColumnGrid, cols = this.grid._fixedColumns, colsLength = cols.length;
			// M.H. 5 Mar 2013 Fix for bug #134548: UnfixAllColumns method reverts the order of columns.
			if (colsLength > 0) {
				if (isMCH) {
					// get first table row in headears fixed table - it is with fixed table top lever(root) cells and get IDs - column keys, data-mch-id
					ths = this.grid.fixedHeadersTable().find('thead tr[data-mch-level]:nth-child(1) th');
					ths.each(function (index, th) {
						var $th = $(th), id, isGroupHeader = true;

						id = $th.attr('data-mch-id');
						if (id === undefined) {
							id = $th.attr('id').replace(self.grid.id() + '_', '');
							isGroupHeader = false;
						}
						colsToUnfix.push({id: id, isGroupHeader: isGroupHeader});
					});
				} else {
					for (i = 0; i < colsLength; i++) {
						colsToUnfix.push({id: cols[i].key, isGroupHeader: undefined});
					}
				}

				if (colsToUnfix.length > 0) {
					for (i = colsToUnfix.length - 1; i >= 0; i--) {
						this.unfixColumn(colsToUnfix[i].id, colsToUnfix[i].isGroupHeader);
					}
				}
			}
		},
		_unfixMultiColumnHeaderDataSkip: function () {
			var i, $th, dataSkippedColsLength, $unfixedThead, $fixedThead,
				maxLevel = this.grid._maxLevel,
				container = this._containers.header;
				
				if (!container) {
					container = this._containers.body;
				}
				$unfixedThead = container.unfixedTable.find('thead');
				$fixedThead = this.grid.container().find("#" + container.unfixedTable.attr("id") + "_fixed").find('thead');

			if (this._hasDataSkippedColumns() && this.options.fixingDirection === 'left') {
				dataSkippedColsLength = this._getDataSkippedColumnsLength(true);
				for (i = dataSkippedColsLength - 1; i > -1; i--) {
					$th = $fixedThead.find('tr[data-mch-level=' + maxLevel + '] th[data-skip]:nth-child(' + (i + 1) + ')');
					$th.detach();
					$th.prependTo($unfixedThead.find('tr[data-mch-level=' + maxLevel + ']'));
				}
			}
		},
		_unfixMultiColumnHeader: function (colId, isGroupHeader, indexAt) {
			var grid = this.grid, i, $th,
				gridId = grid.id(),
				maxLevel, cols,
				$fixedThead, $unfixedThead, fixedTable, oTable;
			
			if (this._containers.header) {
				oTable = this._containers.header.unfixedTable;
				fixedTable = this._containers.header.fixedTable;
			} else {
				oTable = this._containers.body.unfixedTable;
				fixedTable = this._containers.body.fixedTable;
			}
			$unfixedThead = oTable.find('thead');
			$fixedThead = fixedTable.find('thead');
			if (!_aNull(indexAt)) {
				this._fixUnfixMCHColumn(colId, { fixedThead: $fixedThead, unfixedThead: $unfixedThead, isToFix: false }, indexAt);
				return;
			}
			maxLevel = grid._maxLevel;
			if (isGroupHeader) {
				cols = grid._oldCols;
				for (i = 0; i < cols.length; i++) {
					if (cols[i].identifier === colId) {
						cols[i].fixed = false;
						this._unfixMCHColumn(cols[i], $fixedThead, $unfixedThead);
						break;
					}
				}
			} else {
				//$th = $('#' + gridId + '_' + colId);
				$th = this.grid.container().find("#" + gridId + "_" + colId);
				$th.detach().prependTo($unfixedThead.find('tr[data-mch-level=' + maxLevel + ']'));
			}
		},
		_updateGridColWidths: function () {
			// update grid variables for column widths - needed for adjustLastColumnWidth
			var totalColWidth = 0, lastColWidth, i, w, cols, grid = this.grid;

			if (grid._allColumnWidthsInPixels) {
				cols = grid._visibleColumns();
				for (i = 0; i < cols.length; i++) {
					if (cols[i].fixed !== true && cols[i].width) {
						w = parseInt(cols[i].width, 10);
						totalColWidth += w;
						lastColWidth = w;
					}
				}
				grid._lastColPixelWidth = lastColWidth;
				grid._totalColPixelWidth = totalColWidth;
			}
		},
		_unfixMCHColumn: function (el, $fixedHeader, $unfixedHeader) {
			var level = el.level, $th, domLevel, children, i;

			if (level === 0) {
				//$th = $('#' + this.grid.id() + '_' + el.key);
				$th = this.grid.container().find("#" + this.grid.id() + "_" + el.key);
			} else {
				$th = $fixedHeader.find('th[data-mch-id=' + el.identifier + ']');
				children = el.group;
			}
			domLevel = $th.closest('tr').attr('data-mch-level');
			$th.detach();
			$th.prependTo($unfixedHeader.find('tr[data-mch-level=' + domLevel + ']'));
			if (level > 0) {
				for (i = children.length - 1; i > -1; i--) {
					this._unfixMCHColumn(children[i], $fixedHeader, $unfixedHeader);
				}
			}
		},
		// M.H. 21 Aug 2013 Fix for bug #149676: When row selectors are enabled and you fix and unfix a column and then fix a column whose data is spanned on two rows the fixed and unfixed areas are misaligned.
		_isLastColumn: function () {
			var hasDataSkippedCols = this._hasDataSkippedColumns(),
				countFixedCols = this.grid._fixedColumns.length;
			
			return (countFixedCols === 1 && !hasDataSkippedCols) || (hasDataSkippedCols && countFixedCols === 0);
		},
		_unfixHeaderColumn: function (indexAt) {
			var $unfixedThead,
				tdsFirst, oTable;
			
			if (this._containers.header) {
				oTable = this._containers.header.unfixedTable;
			} else {
				oTable = this._containers.body.unfixedTable;
			}
			$unfixedThead = oTable.children('thead');
			tdsFirst = this._tds.header;
			this._fixUnfixDOM($unfixedThead, tdsFirst, false, indexAt);
			if (this._isLastColumn()) {
				$unfixedThead.children('tr[data-header-row]').css('height', '');
				}
		},
		_unfixBodyColumn: function (indexAt) {
			var tdsFirst, $tbody,
				oTable = this._containers.body.unfixedTable,
				scrollContainer = this._containers.body.unfixedContainer,
				oTableWidth = oTable.width();
			// M.H. 20 Mar 2013 Fix for bug #137003: If you fix a column then fix a column with smaller width unfixing the bigger one makes the smaller's width bigger and fixing breaks after that.
			tdsFirst = this._tds.body;
			$tbody = oTable.children('tbody');
			this._fixUnfixDOM($tbody, tdsFirst, false, indexAt);
			scrollContainer.scrollTop(0);
			// M.H. 21 Feb 2013 Fix for bug #133521: When you fix and unfix a column the width of the columns changes and scrolling the grid to the right misaligns it.
			this.grid._hscrollbarinner().css({
				width:  (this.grid._hasVerticalScrollbar && this.grid.options.fixedHeaders ? oTableWidth - this.grid._scrollbarWidth() : oTableWidth) + 'px',
				left: 0
			});
			// M.H. 21 Aug 2013 Fix for bug #149676: When row selectors are enabled and you fix and unfix a column and then fix a column whose data is spanned on two rows the fixed and unfixed areas are misaligned.
			if (this._isLastColumn()) {
				$tbody.children('tr').height('');
			}
			// M.H. 24 Feb 2013 Fix for bug #133421: Columns and headers are misaligned on fixing a column when grid and its columns doesn't have width set
			if (this.grid.options.width === null) {
				if (this.grid._fixedColumns.length === 1) {
					oTable[0].style.width = '';
				}
			}
		},
		_unfixFooterColumn: function (indexAt) {
			var $tfoot, container = this._containers.footer, oTable, tdsFirst;
			if (!container) {
				container = this._containers.body;
			}
			oTable = container.unfixedTable;
			tdsFirst = this._tds.footer;
			$tfoot = oTable.children('tfoot');
			this._fixUnfixDOM($tfoot, tdsFirst, false, indexAt);
			// M.H. 21 Aug 2013 Fix for bug #149676: When row selectors are enabled and you fix and unfix a column and then fix a column whose data is spanned on two rows the fixed and unfixed areas are misaligned.
			if (this._isLastColumn()) {
				$tfoot.children('tr').height('');
			}
		},
		_fixColumnInternal: function (colKey, isGroupHeader, target, after) {
			var noCancel, res, grid = this.grid;
			
			// M.H. 5 Jun 2013 Fix for bug #143728: The ui's isGroupHeader property of columnFixing and columnFixed events is undefined.
			if (isGroupHeader === undefined || isGroupHeader === null) {
				isGroupHeader = false;
			}
			noCancel = this._trigger(this.events.columnFixing, null, {
				//'columnIndex' : colInd,
				'columnIdentifier': colKey,
				'isGroupHeader': isGroupHeader,
				owner: grid
			});
			if (noCancel) {
				res = this.fixColumn(colKey, isGroupHeader, target, after);
				if (res.error === this.internalErrors.fixingRefused || res.result === false) {
					this._trigger(this.events.columnFixingRefused, null, {
						'columnIdentifier': colKey,
						'isGroupHeader': isGroupHeader,
						'errorMessage': res.error,
						owner: grid
					});
				} else {
					this._trigger(this.events.columnFixed, null, {
						'columnIdentifier': colKey,
						'isGroupHeader': isGroupHeader,
						owner: grid
					});
				}
			}
			return res;
		},
		_getVisibleIndex: function (colId, isFixed, ignoreDataSkip) {
			// get visible index in fixed/unfixed table
			if ($.type(colId) === 'number') {
				return colId;
			}
			var i, fixedCol, unfixedColsLength, unfixedCols, col,
				cols = this.grid._visibleColumns(), visibleIndex = 0,
				fixedCols = this.grid._fixedColumns, fixedColsLength = fixedCols.length;

			if (isFixed === undefined) {
				col = this.grid.columnByKey(colId);
				if (col) {
					isFixed = (col.fixed === true);
				}
			}
			if (isFixed) {
				for (i = 0; i < fixedColsLength; i++) {
					fixedCol = fixedCols[i];
					if (fixedCol.key === colId) {
						break;
					}
					if (!fixedCol.hidden) {
						visibleIndex++;
					}
				}
			} else {
				unfixedCols = [];
				unfixedColsLength = 0;
				for (i = 0; i < cols.length; i++) {
					if (!cols[i].fixed) {
						unfixedColsLength++;
						unfixedCols.push(cols[i]);
					}
				}
				for (i = 0; i < unfixedColsLength; i++) {
					if (unfixedCols[i].key === colId) {
						break;
					}
					visibleIndex++;
				}
			}
			if (ignoreDataSkip) {
				return visibleIndex;
			}
			// M.H. 23 Aug 2013 Fix for bug #150176: [RowSelectors]When fixingDirection is right and you fix column the grid breaks
			// TODO: we should take into account skip columns(for instance expanders for hierarchical grid, group by, row selectors, etc)
			if (this._hasDataSkippedColumns()) {
				if (this.options.fixingDirection === 'left') {
					if (isFixed) {
						visibleIndex += this._getDataSkippedColumnsLength(isFixed);
					}
				} else if (!isFixed) {
					// M.H. 23 Aug 2013 Fix for bug #150279: When fixingDirection is "right" and row selectors are enabled unfixing columns breaks the grid.
					visibleIndex += this._getDataSkippedColumnsLength();
				}
			}

			return visibleIndex;
		},
		checkFixingAllowed: function (columns) {
			/* Check whether fixing is allowed for the passed argument - columns. It should not be allowed if there is only one visible column in unfixed area and there are hidden unfixed columns
			paramType="array" array of columns - could be column indexes, column keys, column object or mixed
			returnType="bool" returns whether it is allowed fixing for the specified columns
			*/
			var i, visibleColumnsCount = 0;
			for (i = 0; i < columns.length; i++) {
				if (!columns[i].hidden) {
					visibleColumnsCount++;
				}
			}
			if (this.grid._visibleColumns(false).length - visibleColumnsCount < 1) {
				return false;
			}
			return this._isFixingUnfixingAllowed(columns, true);
		},
		checkUnfixingAllowed: function (columns) {
			/* Check whether unfixing is allowed for the passed argument - columns. It should not be allowed if there is only one visible column in fixed area and there are hidden fixed columns
			paramType="array" array of columns - could be column indexes, column keys, column object or mixed
			returnType="bool" returns whether it is allowed unfixing for the specified columns
			*/
			return this._isFixingUnfixingAllowed(columns, false);
		},
		_isFixingUnfixingAllowed: function (columns, isToFix) {
			// columns - array of columns - it should be columns(including hidden in case of MCH scenario) you want to fix/unfix
			// isToFix - boolean argument - check whether for the passed columns it is allowed to fix, if false then it is checked it is possible to unfix columns
			// Check whether fixing/unfixing is allowed
			// It should NOT be allowed if there is ONLY one visible column(and hidden unfixed columns) in unfixed area and trying to fix it or ONLY one visible fixed column(and there are other fixed hidden columns) and trying to unfix it
			var i, columnsLength = columns.length, j, col, columnsInArea = [],
				oCols = this.grid.options.columns, oColsLength = oCols.length;
			// first get all columns in area - e.g. if columns should be fixed get all UNfixed columns(in this area we found columns)
			for (i = 0; i < oColsLength; i++) {
				if ((!isToFix && oCols[i].fixed) || (isToFix && !oCols[i].fixed)) {
					for (j = 0; j < columnsLength; j++) {
						col = columns[j];
						if (col.key === oCols[i].key) {
							break;
						}
					}
					if (j === columnsLength) {
						columnsInArea.push(oCols[i]);
					}
				}
			}
			if (columnsInArea.length === 0) {
				return true;
			}
			for (i = 0; i < columnsInArea.length; i++) {
				if (!columnsInArea[i].hidden) {
					return true;
				}
			}
			return false;
		},
		_isVirtualGrid: function () {
			var gridOptions = this.grid.options;
			return (gridOptions.virtualization === true || gridOptions.rowVirtualization === true);
		},
		_isContinuousVirtualization: function () {
			return this._isVirtualGrid() && this.grid.options.virtualizationMode === 'continuous';
		},
		fixColumn: function (colIdentifier, isGroupHeader, target, after) {
			/* Fix column by specified column identifier - column index or column key
			paramType="number|string" An identifier of the column to be fixed - column index or column key.
			paramType="bool" optional="true" when true indicates that the column is multi-column header.
			paramType="string" optional="true" Key of the column where the fixed column should move to.
			paramType="bool" optional="true" Specifies where the fixed column should be moved after or before the target column. This parameter is disregarded if there is no target column specified.
			returnType="object" Object description: { result: indicates whether fixing is successful, error: error message describing the reason fixing has failed, col: reference to the column object(if column identifier is not valid - then its value is null) }
			*/
			var col, colWidth, columnIndex, res, i, j, children,
				colIdentifierType = $.type(colIdentifier), colKey, visibleIndex, isI,
				virtualization = this._isVirtualGrid(),
				shoulRerendedColgroups,
				grid = this.grid, gridId = grid.id(), $th, vI,
				isGridWidthPercentage = ($.type(grid.options.width) === 'string' && grid.options.width.indexOf('%') !== -1),
				MCHchildren, mchLevel,
				$mainFixedContainer,
				mainFixedContainerWidth = 0,
				gridWidth = parseInt(grid.options.width, 10),
				columnIndexes = [],
				hasTarget = false,
				hasDataSkippedColumns = false,
				initialFixedColumnsLength = grid._fixedColumns.length,
				isInit = (initialFixedColumnsLength === 0),
				indexAt, columnIndexAt, targetRes, vIndexAt, at,
				inMCHGroup,
				cols = grid.options.columns, colsLength = cols.length;
			// it is possible to be thrown error when fixing column - for instance colIdentifier is not correct, the column is already fixed, etc. Used also in client side event columnFixingRefused
			res = { error: this.internalErrors.none, result: true, col: null };
			// M.H. 22 Feb 2013 Fix for bug #133770: fixColumn and unfixColumn methods should work with column index and column key.
			if (!isGroupHeader) {
				if (colIdentifierType === 'number') {
					columnIndex = colIdentifier;
				} else if (colIdentifierType === 'string') {
					columnIndex = -1;
					for (i = 0; i < colsLength; i++) {
						if (cols[i].key === colIdentifier) {
							columnIndex = i;
							break;
						}
					}
					}
				col = cols[columnIndex];
				res.col = col;
				if (col === null || col === undefined) {
					res.result = false;
					res.error = this.internalErrors.notValidIdentifier;
					return res;
				}
				visibleIndex = this._getVisibleIndex(col.key);
				//$th = $('#' + gridId + '_' + colKey);
				res.col = col;
				colKey = col.key;
				$th = grid.container().find("#" + gridId + "_" + colKey);
				columnIndexes.push({ cI: columnIndex, vI: visibleIndex });
				children = [col];
			} else {
				$th = grid.headersTable().find('th[data-mch-id=' + colIdentifier + ']');
				colKey = colIdentifier;
				MCHchildren = this.grid._getMultiHeaderColumnById(colIdentifier);
				res.col = MCHchildren;
				if (!MCHchildren) {
					res.result = false;
					res.error = this.internalErrors.notValidIdentifier;
					return res;
				}
				children = MCHchildren.children;
			}
			if (!_aNull(target)) {
				hasTarget = true;
				targetRes = this._analyzeTargetIndexes(target, after, true);
				if (!targetRes) {
					res.result = false;
					res.error = this.internalErrors.targetNotFound.replace("{key}", res.col.key);
					return res;
				}
				indexAt = targetRes.indexAt;
				columnIndexAt = targetRes.columnIndexAt;
			}
			if (res.col.fixed) {
				res.result = false;
				res.error = this.internalErrors.alreadyFixed;
				return res;
			}
			if (res.col.hidden) {
				res.result = false;
				res.error = this.internalErrors.alreadyHidden;
				return res;
			}
			if (grid._isMultiColumnGrid) {
				mchLevel = $th.closest('tr').attr('data-mch-level');
				if (mchLevel && parseInt(mchLevel, 10) !== grid._maxLevel) {
					res.result = false;
					res.error = this.internalErrors.ActionNotAllowedForChildHeaderColumn;
					return res;
				}
			}
			// it should not be allowed fixing when there is only one visible column in fixed area and we try to fix this column
			if (!this.checkFixingAllowed(children, isGroupHeader)) {
				res.result = false;
				res.error = this.internalErrors.fixingRefused;
				return res;
			}
			// M.H. 7 Mar 2013 Fix for bug #134865: When width isn't set to the grid and the columns the user is able to fix all of the columns.
			if (isNaN(gridWidth) || isGridWidthPercentage) {
				gridWidth = grid.container().outerWidth();
			}
			if ($th.length === 1 || visibleIndex === undefined) {
				colWidth = $th.outerWidth();
			} else {
				colWidth = grid.container().find("#" + gridId + " tbody tr:nth-child(1) td:nth-child(" + (visibleIndex + 1) + ")").outerWidth();
			}
			// if last column has automatically increased width (because 1 or more of the last columns are hidden) then fixing it
			// the width of this column should be rolled back to its original width - we should get the widht not of the DOM element but the original Width
			// then we should rerender colgroups because fixing is just detaching the col from unfixed area and attaching to the fixed area
			shoulRerendedColgroups = false;
			if (col && grid.element.data('igGridHiding')) {
				if (col.oWidth !== undefined) {
					// M.H. 24 Feb 2014 Fix for bug #165231: When Hiding is enabled and resized column is fixed the fixed area occupied the whole grid.
					colWidth = parseInt(col.oWidth, 10);
					col.width = colWidth;
				} else if (col.width) {
					// M.H. 24 Feb 2014 Fix for bug #165231: When Hiding is enabled and resized column is fixed the fixed area occupied the whole grid.
					colWidth = parseInt(col.width, 10);
				}
				shoulRerendedColgroups = true;
			}
			if ((col && col.hidden) || colWidth === undefined) {
				colWidth = 0;
			}
			// when there are initially fixed data-skip columns OR there are fixed columns
			// M.H. 27 Feb 2015 Fix for bug #189710: When renderExpansionIndicatorColumn: true it is possible to fix a wide enough column to make the fixed area wider than the treegrid
			if (grid.hasFixedColumns()) {
				$mainFixedContainer = grid.fixedContainer();
				if (virtualization) {
					mainFixedContainerWidth = parseInt(grid._virtualcontainer().find('col[data-fixed-col]').attr('width'), 10);
				} else if ($mainFixedContainer.length) {
				mainFixedContainerWidth = $mainFixedContainer.outerWidth();
			}
			}
			if (isNaN(mainFixedContainerWidth)) {
				mainFixedContainerWidth = 0;
			}
			//}
			// check whether we could fix a column - if the sum of width of new fixed area and width of the column exceeds the width of the grid then do not allow column fixing
			// M.H. 22 Feb 2013 Fix for bug #133421: Columns and headers are misaligned on fixing a column when grid and its columns doesn't have width set
			if (colWidth + mainFixedContainerWidth + grid._scrollbarWidth() >= gridWidth - parseInt(this.options.minimalVisibleAreaWidth, 10)) {
				res.result = false;
				res.error = this.internalErrors.fixingRefusedMinVisibleAreaWidth;
				return res;
			}
			this._populateContainers();
			this._rearrangeOldColsByColumnKey(colKey, true, target, after);
			if (isGroupHeader) {
				visibleIndex = undefined;
				for (i = 0; i < children.length; i++) {
					if (children[i].hidden !== true) {
						if (i === 0 || visibleIndex === undefined) {
						visibleIndex = this._getVisibleIndex(children[i].key, false);
					}   
						vI = visibleIndex;
					} else {
						vI = -1;
					}
					for (j = 0; j < colsLength; j++) {
						if (cols[j].key === children[i].key) {
							columnIndexes.push({ cI: j, vI: vI });
							break;
						}
					}
					children[i].fixed = true;
					if (!hasTarget) {
						grid._fixedColumns.push(children[i]);
					} else {
						grid._fixedColumns.splice(i + columnIndexAt, 0, children[i]);
				}
				}
			} else {
				col.fixed = true;
				if (!hasTarget) {
					grid._fixedColumns.push(col);
				} else {
					grid._fixedColumns.splice(columnIndexAt, 0, col);
			}
			}
			isI = isInit;
			// we should fix data skipped columns if any
			if (isInit && this.options.fixingDirection === 'left') {
				hasDataSkippedColumns = this._hasDataSkippedColumns();
				if (hasDataSkippedColumns) {
					// M.H. 19 Feb 2015 Fix for bug #187756: When row selectors and fixed virtualization are enabled fixing a column moves the horizontal scrollbar downwards.
					if (this._getDataSkippedColumnsLength(true) === 0) {
					this.fixDataSkippedColumns();
					}
					isI = false;
				}
			}
			inMCHGroup = true;
			vIndexAt = indexAt;
			for (i = 0; i < columnIndexes.length; i++) {
				vI = -1;
				if (columnIndexes[i].vI !== -1) {
					vI = columnIndexes[i].vI + 1;
					this._fixColumnByVisibleIndex(vI, colWidth, isI, false, 
											{ inMCHGroup: inMCHGroup, colIdentifier: colKey, isGroupHeader: isGroupHeader, dataIndexAt: indexAt }, vIndexAt);
					if (hasTarget) {
						vIndexAt++;
					}
					inMCHGroup = false;
				}
				col = cols.splice(columnIndexes[i].cI, 1);
				if (!hasTarget) {
				cols.splice((initialFixedColumnsLength + i), 0, col[0]);
				} else {
					at = columnIndexAt + i;
					cols.splice(at, 0, col[0]);
				}
				grid._onColumnFixed(columnIndexes[i].cI, true, initialFixedColumnsLength + i + 1, isI, vI, at);
				if (isI && vI !== -1) {
					isI = false;
			}
			}
			if (isInit) {
				// M.H. 26 Feb 2013 Fix for bug #133862: When height is not defined and column is fixed filtering a column makes the footer too big and the grid keeps its original height.
				if (grid.options.height === null) {
					if ($.ig.util.isIE && $.ig.util.browserVersion >= 9) {
						this._syncTableHeights();
					}
				}
				// M.H. 12 Dec 2013 Fix for bug #159796: Fixing the first column causes misalignment between rows in fixed/unfixed area(in the new theme)
				if (this._containers && this._containers.body) {
					if (this.options.fixingDirection === 'left') {
						this._containers.body.unfixedTable.addClass(this.css.unfixedTableLeft);
					} else {
						this._containers.body.unfixedTable.addClass(this.css.unfixedTableRight);
					}
				}
			}
			grid._visibleColumnsArray = undefined;
			grid._updateHeaderColumnIndexes();
			// M.H. 24 Feb 2013 Fix for bug #133421: Columns and headers are misaligned on fixing a column when grid and its columns doesn't have width set
			if (grid.options.width === null && grid._fixedColumns.length === 1) {
				gridWidth = grid.container().outerWidth();//$('#' + gridId + '_mainFixedContainer').outerWidth() + $('#' + gridId).outerWidth();
				grid.container().width(gridWidth);
			}
			grid._columnMovingResets();
			this._updateGridColWidths();
			// when the dom has changed we need to throw an event to notify other features to update dom related parameters
			grid._hscrollbarcontent().scrollLeft(0);
			this._changeStyleHeaderButton(colKey, true, isGroupHeader);
			// if last column is with automatically increased width (because 1 or more of the last columns are hidden) then fixing it
			// the width of this column should be rolled back to its original width and the scrollbar should be re-calculated 
			if (shoulRerendedColgroups) {
				//this._rerenderFixedColgroups();
				grid._rerenderColgroups();
				this._updateHScrollbarWidth();
			}
			grid._adjustLastColumnWidth(true);
			if (virtualization) {
				// M.H. 19 Feb 2015 Fix for bug #187756: When row selectors and fixed virtualization are enabled fixing a column moves the horizontal scrollbar downwards.
				this._updateContinuousHScrollbar();
				grid._resetVirtualDom();
				if (isInit) {
					this._attachVirtualizationEvents();
					if (this.options.fixingDirection === 'right') {
						this._adjustVirtualizationContainers(true);
					}
				}
				if (this.options.fixingDirection === 'right') {
					this._containers.header.unfixedTable.css(grid._padding, '');
					this._containers.footer.unfixedTable.css(grid._padding, '');
				}
				// M.H. 20 Aug 2014 Fix for bug #178399: When virtualization mode is "continuous" and you unfix column the records are scrolled to the top but the scrollbar is not updated.
				if (this._isContinuousVirtualization()) {
					this._syncScrollTop();
				}
				// M.H. 20 Aug 2014 Fix for bug #178635: The scrollbar shrinks when you fix a column.
				grid._hscrollbarcontent().css('overflow-y', 'hidden');
			}
			// M.H. 20 Aug 2014 Fix for bug #176479: The fixed and unfixed rows are misaligned if you fix the last column and the column before it has value that spans on two or more lines.
			if (this.options.syncRowHeights) {
				this.checkAndSyncHeights();
			}
			// M.H. 18 Sep 2013 Fix for bug #151251: The space under the row selectors is empty when fixNondataColumns is true.
			this._checkAndRenderHScrlbarCntnr();
			this._trigger('_columnFixed', null, {
				'columnIdentifier': colIdentifier,
				isGroupHeader: isGroupHeader,
				at: columnIndexAt,
				len: children.length
			});
			return res;
		},
		_syncScrollTop: function () {
			/* sync scrollTop position between fixed and unfixed containers */
			if (!this._containers || !this._containers.body) {
				this._populateContainers();
			}
			var top, $scrollContainer = this._containers.body.unfixedContainer,
				$fixedBodyContainer = this._containers.body.fixedContainer;
			top = $scrollContainer.scrollTop();
			$fixedBodyContainer.scrollTop(top);
		},
		_attachVirtualizationEvents: function () {
			var grid = this.grid;
			grid.fixedBodyContainer().bind({
				mouseenter: function () {
					grid._isMouseOverVirtualTable = true;
				},
				mouseleave: function () {
					grid._isMouseOverVirtualTable = false;
				}
			});
		},
		fixDataSkippedColumns: function () {
			/* Fix data skipped columns(like row selectors) if any when fixing direction is left. If already fixed nothing is done
			*/
			var i, dataSkippedColsLength,
				isMCH = this.grid._isMultiColumnGrid,
				hasDataSkippedColumns = this._hasDataSkippedColumns();
			// we should fix data skipped columns if any - for now supported scenario is ONLY if fixing direction is LEFT
			if (this.options.fixingDirection === 'left' && hasDataSkippedColumns) {
				dataSkippedColsLength = this._getDataSkippedColumnsLength();
				if (dataSkippedColsLength > 0) {
					this.grid._hasFixedDataSkippedColumns = true;
				}
				for (i = 0; i < dataSkippedColsLength; i++) {
					this._fixColumnByVisibleIndex(1, null, (i === 0), true);
					this.grid._onColumnFixed(-1, true, 0, (i === 0));
				}
				if (isMCH) {
					this._fixMultiColumnHeaderDataSkip();
				}
				// M.H. 23 Sep 2013 Fix for bug #152468: The fixed and unfixed areas are misalinged when there are cells with text spanned on two rows and the grid doesn't have height in IE9.
				if (this.grid.options.height === null) {
					if ($.ig.util.isIE && $.ig.util.browserVersion >= 9) {
						this._syncTableHeights();
					}
				}
				// M.H. 5 Mar 2014 Fix for bug #165935: When Row Selectors and Column Fixing are enabled clearing the filter and scrolling the grid to the right misaligns the headers and data cells.
				this.grid._updateGridContentWidth();
				if (this.options.syncRowHeights) {
					this.checkAndSyncHeights();
			}
				// M.H. 8 Sep 2014 Fix for bug #178635: The scrollbar shrinks when you fix a column.
				if (this._isVirtualGrid()) {
					this.grid._hscrollbarcontent().css('overflow-y', 'hidden');
				}
				if (this.grid._hasFixedDataSkippedColumns) {
					this._trigger('_dataSkipColumnFixed', null);
				}
				this._checkAndRenderHScrlbarCntnr();
			}
		},
		_fixColumnByVisibleIndex: function (visibleIndex, 
				colWidth, 
				isInit, 
				isDataSkip, 
				MCHParams,
				indexAt) {
			var grid = this.grid, inMCHGroup, colIdentifier, isGroupHeader,
				isMCH = grid._isMultiColumnGrid,
				isGridWidthPercentage = ($.type(grid.options.width) === 'string' && grid.options.width.indexOf('%') !== -1),
				isToShowHeader = grid.options.showHeader,
				isToShowFooter = grid.options.showFooter,
				containerBody = this._containers.body,
				containerHeader = this._containers.header,
				containerFooter = this._containers.footer;
			if (MCHParams) {
				inMCHGroup = MCHParams.inMCHGroup;
				colIdentifier = MCHParams.colIdentifier;
				isGroupHeader = MCHParams.isGroupHeader;
			}
			if (!containerHeader) {
				containerHeader = containerBody;
			}
			if (!containerFooter) {
				containerFooter = containerBody;
			}
			
			this._getElementsByDOM(visibleIndex, containerHeader.unfixedTable.children('thead'), 'header', isInit, isDataSkip);
			this._getElementsByDOM(visibleIndex, containerBody.unfixedTable.children('tbody'), 'body', isInit, isDataSkip);
			this._getElementsByDOM(visibleIndex, containerFooter.unfixedTable.children('tfoot'), 'footer', isInit, isDataSkip);
			this._getColgroups(visibleIndex);
			if (isInit && this.options.syncRowHeights) {
				this._setRowHeightsByContainer('header');
				this._setRowHeightsByContainer('body');
				this._setRowHeightsByContainer('footer');
			}
			if (isDataSkip) {
				inMCHGroup = true;
				if (this._tds.header.length > 0) {
					colWidth = $(this._tds.header[0]).outerWidth();
				} else if (this._tds.body.length > 0) {
					colWidth = $(this._tds.body[0]).outerWidth();
				}
				// M.H. 3 June 2015 Fix for bug 200699: When MCH and Row Selectors are enabled, there are initially fixed columns and the grid is bound to an empty data source the headers are not rendered correctly.
				if (colWidth === null) {
					colWidth = containerHeader.unfixedTable.find('thead')
									.find('tr:not([data-skip]):first>th:nth-child(' + visibleIndex + ')')
									.outerWidth();
				}
			}
			if (isInit) {
				this._syncUnfixedWidth(colWidth);
				this._renderMainFixedContainer(colWidth);
			} else if (inMCHGroup) {
				this._syncWidth(colWidth);
			}
			// M.H. 22 Jul 2013 Fix for bug #147143: When the widths are in percents fixing a column in Firefox shrinks other columns' widths.
			// if we detach header cells then in FF it is not rendered properly when widht is in percentage
			if (!($.ig.util.isFF && isGridWidthPercentage)) {//!($.ig.util.isFF && isGridWidthPercentage)
				this._tds.header.detach();
			}
			this._tds.body.detach();
			this._tds.footer.detach();
			this._detachColgroups();

			this._attachColgroups(false, indexAt);
			// render header
			this._fixBodyColumn(isInit, indexAt);
			if (isToShowFooter) {
				this._fixFooterColumn(isInit, indexAt);
			}
			if (isToShowHeader) {
				if (isMCH) {
					if (inMCHGroup) {
						this._fixMultiColumnHeader(colIdentifier, isInit, isGroupHeader, indexAt);
				}
				}
				// M.H. 20 Jan 2015 Fix for bug #187636: When multi column headers and filtering are enabled fixing a column throws a js error.
				this._fixHeaderColumn(isInit, indexAt);
				if (this.options.syncRowHeights && this._heights) {
					this._syncHeights(this._heights.header, containerHeader.fixedTable.find('thead').eq(0));
				}
			}
		},
		_hasDataSkippedColumns: function (isFixed) {
			if (this._hasDataSkippedColumn !== undefined) {
				return this._hasDataSkippedColumn;
			}
			this._hasDataSkippedColumn = this._getDataSkippedColumnsLength(isFixed) > 0;
			return this._hasDataSkippedColumn;
		},
		_getDataSkippedColumnsLength: function (isFixed) {
			if (!this._containers || !this._containers.body) {
				this._populateContainers();
			}
			var $table = this._containers.body.unfixedTable;
			
			if (isFixed) {
				$table = this._containers.body.fixedTable;
			}
			return $table.find('colgroup col[data-skip]').length;
		},
		_renderVirtualFixedContainer: function (colWidth) {
			var self = this, grid = this.grid, gridId = grid.id(), $col, cssClass,
				$colgroup,
				$trHeader,
				$trBody,
				$trFooter,
				leftFixingDirection = true,
				fixingDirection = 'left',
				$vContainer = grid._virtualcontainer(),
				functionRenderContainer, fixedBodyTable, fixedHeaderContainer, fixedFooterContainer,
				fixedBodyContainer,
				scrollContainer,
				headerContainer, footerContainer,
				oTable, scrollContainerHeight;

			$colgroup = $vContainer.find('colgroup:first');
			$trHeader = this._containers.header.unfixedContainer.closest('tr');
			$trBody = this._containers.body.unfixedContainer.closest('tr');
			$trFooter = this._containers.footer.unfixedContainer.closest('tr');
			scrollContainer = this._containers.body.unfixedContainer;
			cssClass = this.css.leftFixedContainer;
			if (this.options.fixingDirection === 'right') {
				cssClass = this.css.rightFixedContainer;
				leftFixingDirection = false;
				fixingDirection = 'right';
			}
			// render containers
			// first we should render body container
			colWidth = colWidth + 'px';
			$col = $('<col width="' + colWidth + '" data-fixed-col="' + this.options.fixingDirection + '"></col>');
			if (leftFixingDirection) {
				$col.prependTo($colgroup);
			} else {
				$col.insertBefore($colgroup.find('col:last'));
			}
			functionRenderContainer = function (fixedContainerId, $container, type, $tr) {
				var $fixedContainer, $fixedTable, $td;
				oTable = $container.find('table');
				$td = $('<td data-fixed-container="true" style="border-width: 0px;"></td>');
				if (leftFixingDirection) {
					$td.prependTo($tr);
				} else {
					$tr.find('td:first').removeAttr('colspan');
					if (type === 'body') {
						$td.insertBefore($tr.find('td:last'));
					} else {
						$td.attr('colspan', 2);
						$td.appendTo($tr);
					}
				}
				$fixedContainer = $('<div id="' + fixedContainerId + '" data-scroll="true" data-fixing-direction="' + fixingDirection + '" class="' + cssClass + '" data-fixed-container="true"></div>').appendTo($td);
				$fixedTable = $('<table id="' + oTable.attr('id') + '_fixed" class="' + oTable.attr('class') + '" style="table-layout:fixed; width: ' + colWidth + ';" border=0 cellpadding=0 cellspacing=0><colgroup /></table>')
					.appendTo($fixedContainer);
				self._containers[type].fixedContainer = $fixedContainer;
				self._containers[type].fixedTable = $fixedTable;
				$fixedContainer
					.css({
						'overflow': 'hidden', 
						//'height': scrollContainerHeight, //+ $('#' + grid.element[0].id + '_hscroller').height()
						'position': 'relative'
					});
				if (!leftFixingDirection && type !== 'body') {
					$fixedTable.css(grid._padding, $colgroup.find('col:last').attr('width') + 'px');
				}
				//fixedTable.addClass(oTable.attr('class'));
				return $fixedContainer;
			};
			// render body container
			fixedBodyContainer = functionRenderContainer(gridId + '_fixedBodyContainer', this._containers.body.unfixedContainer, 'body', $trBody);
			// M.H. 18 Nov 2015 Fix for bug 209220: Setting the grid's height runtime does not change the height of the fixed area
			fixedBodyContainer
				.addClass(grid.css.gridVirtualScrollDivClass)
				.addClass(grid.css.gridScrollDivClass);
			// M.H. 14 Jun 2013 Fix for bug #144693: When you fix a column and then filter a column the records increase their height.
			// M.H. 6 Jun 2013 Fix for bug #143942: When filtering is enabled and column is fixed scrolling the grid vertically misaligns the fixed and unfixed areas.
			if (grid.options.height !== null && $.ig.util.isIE) {
				fixedBodyContainer.find('table').height(scrollContainer.find('table').height());
			}
			// M.H. 26 Feb 2013 Fix for bug #133862: When height is not defined and column is fixed filtering a column makes the footer too big and the grid keeps its original height.
			if (grid.options.height === null) {
				scrollContainerHeight = '100%';
			} else {
				scrollContainerHeight = scrollContainer.height();
				// M.H. 7 Mar 2013 Fix for bug #135253: When width and height are set to the grid, widths to the columns are not set and there is initially fixed column the fixed area has bigger height than the unfixed.
				if (this.grid._hscrollbar().is(':visible')) {
					scrollContainerHeight += this.grid._hscrollbar().outerHeight();
				}
			}
			fixedBodyContainer.height(scrollContainerHeight);
			fixedBodyTable = fixedBodyContainer.find('table');
			$('<tbody />').appendTo(fixedBodyTable);
			if (grid.options.showHeader) {
				if (grid.options.fixedHeaders && grid.options.height !== null) {
					headerContainer = this._containers.header.unfixedContainer;
					fixedHeaderContainer = functionRenderContainer(gridId + '_fixedHeaderContainer', headerContainer, 'header', $trHeader);
					$('<thead />').appendTo(fixedHeaderContainer.find('table'));
					// M.H. 22 Feb 2013 Fix for bug #133539: When the grid has vertical scrollbar and caption fixing a column makes the headers misaligned.
					grid._renderFixedCaption();
				} else {
					$('<thead />').insertBefore(fixedBodyContainer.find('tbody'));
				}
			}
			if (grid.options.showFooter) {
				if (grid.options.fixedFooters && grid.options.height !== null) {
					footerContainer = this._containers.footer.unfixedContainer;
					fixedFooterContainer = functionRenderContainer(gridId + '_fixedFooterContainer', footerContainer, 'footer', $trFooter);
					$('<tfoot />').appendTo(fixedFooterContainer.find('table'));
					// M.H. 11 Jun 2013 Fix for bug #143596: When the width of a fixed column is smaller than the width of the text in summary cell this text goes in 2 rows and it makes the summaries misaligned.
					this._containers.footer.fixedTable.css('whiteSpace', this._containers.footer.unfixedTable.css('whiteSpace'));
				} else {
					//M.K. 28 May 2015: Move TFOOT rendering after the TBODY (in order to support ARIA).
					$('<tfoot role="rowgroup"/>').insertAfter(fixedBodyContainer.find('tbody'));
				}
			}
			// only for data container
			grid._fixedTable = fixedBodyTable;
			if (this._isContinuousVirtualization()) {
				scrollContainer.bind({
					//keydown: this._onKeyDown,
					//mousewheel: this._onMouseWheelHandler,
					scroll: function () {
						var top = $(this).scrollTop();
						fixedBodyContainer.scrollTop(top);
					}
				});
			} else {
				grid._hscrollbar().detach().insertAfter(this._containers.body.unfixedContainer);
			}
		},
		_setFixedBodyCntnrHeight: function (scrollContainer, fixedBodyContainer) {
			if (!this._containers || !this._containers.body) {
				this._populateContainers();
			}
			var grid = this.grid, hScrlbar, scrollContainerHeight;
			fixedBodyContainer = fixedBodyContainer || this._containers.body.fixedContainer;
			scrollContainer = scrollContainer || this._containers.body.unfixedContainer;
			// M.H. 26 Feb 2013 Fix for bug #133862: When height is not defined and column is fixed filtering a column makes the footer too big and the grid keeps its original height.
			if (grid.options.height === null) {
				scrollContainerHeight = '100%';
			} else {
				//$mainFixedContainer.css('max-height', grid.options.height);
				scrollContainerHeight = scrollContainer.height();
				hScrlbar = grid._hscrollbar();
				// M.H. 7 Mar 2013 Fix for bug #135253: When width and height are set to the grid, widths to the columns are not set and there is initially fixed column the fixed area has bigger height than the unfixed.
				if (hScrlbar.is(':visible')) {
					scrollContainerHeight += hScrlbar.outerHeight();
				}
			}
			fixedBodyContainer.height(scrollContainerHeight);
		},
		_renderMainFixedContainer: function (colWidth) {
			if (this._isVirtualGrid()) {
				this._renderVirtualFixedContainer(colWidth);
				return;
			}
			var self = this, grid = this.grid, gridId = grid.id(), diff,
				functionRenderContainer, fixedBodyTable, fixedHeaderContainer, fixedFooterContainer,
				fixingDirection, syncScrollContainers,
				$mainFixedContainer, fixedBodyContainer,
				mainFixedContainerId = grid.id() + '_mainFixedContainer',
				scrollContainer,
				virtualization = this._isVirtualGrid(),
				headerContainer, footerContainer, oTable;
				
			// M.H. 28 Feb 2013 Fix for bug #134435: When height is set and column is fixed changing the page changes grid's height and the horizontal scrollbar is not on the correct place
			$mainFixedContainer = $('<div id="' + mainFixedContainerId + '" data-fixed-container="true"></div>');
			$mainFixedContainer
				.css({
				'overflow': 'hidden', 
				'position': 'relative'
			});
			scrollContainer = this._containers.body.unfixedContainer;
			$mainFixedContainer
				//.width(colWidth)
				//.addClass(scrollContainer.attr('class'))
				.addClass(this.css.fixedContainer);
			fixingDirection = 'left';
			if (this.options.fixingDirection === 'left') {
				fixingDirection = 'left';
				$mainFixedContainer.addClass(this.css.leftFixedContainer);
				if (this._containers.header) {
					$mainFixedContainer.insertBefore(this._containers.header.unfixedContainer);
				} else {
					$mainFixedContainer.insertBefore(scrollContainer);
				}
				$mainFixedContainer.css({'float': 'left', 'left': 0});
			} else if (this.options.fixingDirection === 'right') {
				fixingDirection = 'right';
				$mainFixedContainer.addClass(this.css.rightFixedContainer);
				if (virtualization) {
					$mainFixedContainer.insertBefore(this.grid._virtualcontainer());
				} else {
				if (this._containers.header) {
					$mainFixedContainer.insertBefore(this._containers.header.unfixedContainer);
				} else {
					$mainFixedContainer.insertBefore(scrollContainer);
				}
				}
				$mainFixedContainer.css({'float': 'right', 'right': 0});
			}
			$mainFixedContainer.attr('data-fixing-direction', fixingDirection);
			// M.H. 6 Jun 2013 Fix for bug #143586: CellClick event doesn't fire for fixed columns.
			$mainFixedContainer.bind(this.grid._mouseClickEventHandlers);
			// render containers
			// first we should render body container
			colWidth = 'width:' + colWidth + 'px';
			functionRenderContainer = function (fixedContainerId, $container, type) {
				var $fixedContainer, $fixedTable;
				oTable = $container.find('table');
				$fixedContainer = $('<div id="' + fixedContainerId + '" data-scroll="true" data-fixed-container="true"></div>').appendTo($mainFixedContainer);
				$fixedTable = $('<table id="' + oTable.attr('id') + '_fixed" class="' + oTable.attr('class') + '" style="table-layout:fixed; ' + colWidth + '" border=0 cellpadding=0 cellspacing=0><colgroup /></table>')
					.appendTo($fixedContainer);
				self._containers[type].fixedContainer = $fixedContainer;
				self._containers[type].fixedTable = $fixedTable;
				$fixedContainer
					.css({
					'overflow': 'hidden', 
					'position': 'relative'
				});
				return $fixedContainer;
			};
			// render body container
			fixedBodyContainer = functionRenderContainer(gridId + '_fixedBodyContainer', scrollContainer, 'body');
			// M.H. 10 Sep 2014 Fix for bug #179865: When you navigate the cell selection with arrow keys from fixed to unfixed area the selected cell goes to  the next row in virtual grid.
			fixedBodyContainer.attr('data-fixing-direction', fixingDirection);
			// M.H. 14 Jun 2013 Fix for bug #144693: When you fix a column and then filter a column the records increase their height.
			// M.H. 6 Jun 2013 Fix for bug #143942: When filtering is enabled and column is fixed scrolling the grid vertically misaligns the fixed and unfixed areas.
			if (grid.options.height !== null && $.ig.util.isIE) {
				fixedBodyContainer.find('table').height(scrollContainer.find('table').height());
			}
			this._setFixedBodyCntnrHeight(scrollContainer, fixedBodyContainer);
			//fixedBodyContainer.appendTo($mainFixedContainer);
			fixedBodyTable = fixedBodyContainer.find('table');
			$('<tbody />').appendTo(fixedBodyTable);
			if (grid.options.showHeader) {
				 if (grid.options.fixedHeaders && grid.options.height !== null) {
					headerContainer = this._containers.header.unfixedContainer;
					fixedHeaderContainer = functionRenderContainer(gridId + '_fixedHeaderContainer', headerContainer, 'header');
					$('<thead />').appendTo(fixedHeaderContainer.find('table'));
					//fixedHeaderContainer.height(headerContainer.height());
					fixedHeaderContainer.prependTo($mainFixedContainer);
					//headerContainer.height(headerContainer.height());
					// M.H. 22 Feb 2013 Fix for bug #133539: When the grid has vertical scrollbar and caption fixing a column makes the headers misaligned.
					grid._renderFixedCaption();
				 } else {
					// M.H. 4 Mar 2015 Fix for bug #189443: When columns are auto generated and heigth is not set fixing a column and data binding a grid causes a misalignment
					// order of TBODY/TFOOT/THEAD should be the same in both fixed/unfixed tables
					if (grid.element.find('thead').next().is('tbody')) {
						$('<thead />').insertBefore(fixedBodyContainer.find('tbody'));
					} else {
						if (grid.element.find('thead').prev().is('colgroup')) {
							$('<thead />').insertAfter(fixedBodyContainer.find('colgroup'));
						} else {
							$('<thead />').insertAfter(fixedBodyContainer.find('tbody'));
						}
					}
				}
			}
			if (grid.options.showFooter) {
				 if (grid.options.fixedFooters && grid.options.height !== null) {
					footerContainer = this._containers.footer.unfixedContainer;
					fixedFooterContainer = functionRenderContainer(gridId + '_fixedFooterContainer', footerContainer, 'footer');
					$('<tfoot role="rowgroup" />').appendTo(fixedFooterContainer.find('table'));
					// M.H. 11 Jun 2013 Fix for bug #143596: When the width of a fixed column is smaller than the width of the text in summary cell this text goes in 2 rows and it makes the summaries misaligned.
					this._containers.footer.fixedTable.css('whiteSpace', this._containers.footer.unfixedTable.css('whiteSpace'));
					fixedFooterContainer.appendTo($mainFixedContainer);
				 } else {
				 	//M.K. 28 May 2015: Move TFOOT rendering after the TBODY (in order to support ARIA).
				 	$('<tfoot role="rowgroup" />').insertAfter(fixedBodyContainer.find('tbody'));
				 }
			}
			// only for data container
			grid._fixedTable = fixedBodyTable;
			if (this.options.fixingDirection === 'right') {
				fixedBodyContainer.css({'overflow-y': 'auto'});
				scrollContainer.css({'overflow-y': 'hidden'});
			}
			// M.H. 5 Mar 2013 Fix for bug #134687: Sorted style is removed the first time you fix a sorted column.
			//this._renderFixedRecords(fixedBodyTable, undefined, undefined, true);
			syncScrollContainers = function (direction) {
				var scrollTop = fixedBodyContainer.scrollTop();
				scrollTop += -direction * self.options.scrollDelta;
				if (scrollTop <= 0) {
					scrollTop = 0;
				}
				fixedBodyContainer.scrollTop(scrollTop);
				scrollContainer.scrollTop(scrollTop);
			};
			this._onMouseWheelHandler = function (event) {
				var evt, direction, w, d, st;
				evt = event.originalEvent;
				w = evt.wheelDelta;
				d = evt.detail;
				if (d) {
					if (w) {
						direction = w/d/40*d > 0 ? 1 : -1; // Opera
					}
					else {
						direction = -d/3;// Firefox;		 TODO: do not /3 for OS X
					}
				} else {
					direction = w/120;// IE/Safari/Chrome TODO: /3 for Chrome OS X
				}
				st = fixedBodyContainer.scrollTop();
				syncScrollContainers(direction);
				// M.H. 4 Mar 2013 Fix for bug #134225: The page can't be scrolled vertically with mouse wheel when you hover the fixed column.
				// M.H. 21 Mar 2015 Fix for bug 190105: Browser’s vertical scrollbar does not move by mouse wheel if MultiColumnHeaders and ColumnFixing are enabled.
				if (grid.options.height === null ||
					st === fixedBodyContainer.scrollTop()) {
					return true;
				}
				return false;
			};
			// M.H. 26 Feb 2013 Fix for bug #134003: When the fixingDirection is "right" mouse wheel scroll does not work when you hover the unfixed area.
			this._DOMMouseScroll = function (event) { // Firefox
				var dir = -1, delta;
				//I.I. bug fix for 104505. The issue is reproducible with jquery 1.7.1 only
				delta = -event.originalEvent.detail / 3; // // determine if we are scrolling up or down
				if (delta > 0) { // scroll up 
					dir = 1;
				}  // else default => scroll down 
				syncScrollContainers(dir);
				// M.H. 4 Mar 2013 Fix for bug #134225: The page can't be scrolled vertically with mouse wheel when you hover the fixed column.
				if (grid.options.height === null) {
					return true;
				}
				event.preventDefault();
			};
			this._onKeyDown = function (event) {
				var isUp = (event.keyCode === $.ui.keyCode.UP), isDown = (event.keyCode === $.ui.keyCode.DOWN);
				if (isUp) {
					syncScrollContainers(1);
				} else if (isDown) {
					syncScrollContainers(-1);
				}
				//return false;
			};
			// M.H. 4 Jul 2014 Fix for bug #173032: Desynchronization between rows in the fixed and unfixed area on touch devices
			if (grid.element.igScroll !== undefined && 
				((typeof Modernizr === 'object' && Modernizr.touch === true) ||
					window.PointerEvent || window.navigator.msPointerEnabled)) {
				// instantiate igScroll for the fixed area
				fixedBodyContainer.igScroll({
					scrolled: function () {
						syncScrollContainers(0);
						//self._DOMMouseScroll(e);
					},
					stopped: function () {
						syncScrollContainers(0);
					}
				});
				// M.H. 17 Jul 2014 Fix for bug #175880: Cannot scroll the fixed area on Internet Explorer under touch devices
				fixedBodyContainer.css('-ms-touch-action', 'none');
			}
			// add handlers
			// M.H. 26 Feb 2013 Fix for bug #134003: When the fixingDirection is "right" mouse wheel scroll does not work when you hover the unfixed area.
			if ($.ig.util.isIE || this.options.fixingDirection === 'right') {
				scrollContainer.bind({
					'keydown.columnFixing': this._onKeyDown,
					'mousewheel.columnFixing': this._onMouseWheelHandler,
					'DOMMouseScroll.columnFixing': this._DOMMouseScroll
				});
			}
			scrollContainer.bind({
				'scroll.columnFixing': function () {
					var top = $(this).scrollTop();
					fixedBodyContainer.scrollTop(top);
				}
			});
			fixedBodyContainer.bind({
				scroll: function () {
					// first scrolling is applied for the fixed container and then is checked whether scrollTop is synced for fixed/unfixed area
					var fTop = fixedBodyContainer.scrollTop(),
						sTop = scrollContainer.scrollTop();
					if (fTop !== sTop) {
						scrollContainer.scrollTop(fTop);
					}
				},
				mousewheel: this._onMouseWheelHandler,
				// M.H. 22 Feb 2013 Fix for bug #133776: The mouse wheel scroll does not work when you hover the fixed area in Firefox.
				DOMMouseScroll: this._DOMMouseScroll
			});
			if (this.options.fixingDirection === 'right') {
				fixedBodyContainer.bind({
					keydown: this._onMouseWheelHandler
				});
			}
			// M.H. 21 May 2013 Fix for bug #141231: Column fixing breaks columns header with one normal header and other with multiple headers.
			if (grid.options.width === null) {
				diff = parseFloat($mainFixedContainer.css('borderRightWidth'));
				if (diff > 0) {
					this._syncUnfixedWidth(diff);
				}
			}
		},
		_getElementsByDOM: function (visibleIndex, $DOM, type, isInit, isDataSkipped) {
			var self = this, $TRS = $DOM.find('tr');
			
			if (isInit && this.options.syncRowHeights) {
				if (!self._heights) {
					self._heights = {};
				}
				self._heights[type] = [];
				$TRS.each(function (ind, tr) {
					self._heights[type].push({h: tr.offsetHeight, tr: tr});
				});
			}
			if (type === 'header') {
				this._tds[type] = $DOM.find('tr:not([data-mch-level],[data-skip]) th:nth-child(' + visibleIndex + '),tr:not([data-mch-level],[data-skip]) td:nth-child(' + visibleIndex + ')');
			} else if (isDataSkipped) {
				this._tds[type] = $DOM.find('th:nth-child(' + visibleIndex + '), td:nth-child(' + visibleIndex + ')');
			} else {
				this._tds[type] = $DOM.find('td:nth-child(' + visibleIndex + ')');
			}
		},
		_getColgroups: function (visibleIndex, isFixed) {
			var $bodyTable = this._containers.body.unfixedTable,
				$headerTable,
				$footerTable;

			if (isFixed) {
				$bodyTable = this._containers.body.fixedTable;
			}
			this._getColgroup(visibleIndex, $bodyTable, 'body');
			if (this._containers.header) {
				if (isFixed) {
					$headerTable = this._containers.header.fixedTable;
				} else {
					$headerTable = this._containers.header.unfixedTable;
				}
				this._getColgroup(visibleIndex, $headerTable, 'header');
			}
			if (this._containers.footer) {
				if (isFixed) {
					$footerTable = this._containers.footer.fixedTable;
				} else {
					$footerTable = this._containers.footer.unfixedTable;
				}
				this._getColgroup(visibleIndex, $footerTable, 'footer');
			}
		},
		_getColgroup: function (visibleIndex, $DOM, type) {
			var $cols = $DOM.find('colgroup col:nth-child(' + visibleIndex + ')');

			this._colgroups[type] = $cols;
		},
		_detachColgroups: function () {
			this._colgroups.body.detach();
			if (this._colgroups.header) {
				this._colgroups.header.detach();
			}
			if (this._colgroups.footer) {
				this._colgroups.footer.detach();
			}
		},
		_attachColgroups: function (isFixed, indexAt) {
			var cols = this._colgroups.body,
				$bodyTable, $headerTable, $footerTable;
			
			if (isFixed) {
				$bodyTable = this._containers.body.unfixedTable;
			} else {
				$bodyTable = this._containers.body.fixedTable;
			}
			this._attachColgroup(cols, $bodyTable, isFixed, indexAt);
			if (this._colgroups.header && this._colgroups.header.length > 0) {
				if (isFixed) {
					$headerTable = this._containers.header.unfixedTable;
				} else {
					$headerTable = this._containers.header.fixedTable;
				}
				cols = this._colgroups.header;
				this._attachColgroup(cols, $headerTable, isFixed, indexAt);
			}
			if (this._colgroups.footer && this._colgroups.footer.length > 0) {
				if (isFixed) {
					$footerTable = this._containers.footer.unfixedTable;
				} else {
					$footerTable = this._containers.footer.fixedTable;
				}
				cols = this._colgroups.footer;
				this._attachColgroup(cols, $footerTable, isFixed, indexAt);
			}
		},
		_attachColgroup: function (cols, $table, isFixed, indexAt) {
			var i, $col, dataSkippedColsLength, colsLength = cols.length, $colgroup = $table.find('colgroup'), insertAfter;
			if (!_aNull(indexAt)) {
				indexAt++;
				insertAfter = false;
				if (indexAt > $colgroup.children('col').length) {
					indexAt = $colgroup.children('col').length;
					insertAfter = true;
				}
				$col = $colgroup.children('col:nth-child(' + indexAt + ')');
				if (!$col.length) {
					return;
				}
				for (i = 0; i < colsLength; i++) {
					if (insertAfter) {
						cols.insertAfter($col);
					} else {
						cols.insertBefore($col);
					}
				}
				return;
			}
			// M.H. 23 Aug 2013 Fix for bug #150279: When fixingDirection is "right" and row selectors are enabled unfixing columns breaks the grid.
			if (isFixed && this._hasDataSkippedColumns(true) && this.options.fixingDirection === 'right') {
				dataSkippedColsLength = this._getDataSkippedColumnsLength();
				for (i = 0; i < colsLength; i++) {
					$(cols[i]).insertAfter($colgroup.find('col').eq(dataSkippedColsLength - 1));
				}
			} else {
				for (i = 0; i < colsLength; i++) {
					if (isFixed) {
						$(cols[i]).prependTo($colgroup);
					} else {
						$(cols[i]).appendTo($colgroup);
					}
				}
			}
		},
		_setRowHeightsByContainer: function (type) {
			var i, heights = this._heights[type], heightsLength = heights.length;

			for (i = 0; i < heightsLength; i++) {
				heights[i].tr.style.height = heights[i].h + 'px';
			}
		},
		_syncRowStyles: function () {
			// sync styles between fixed and unfixed table body rows
			// M.H. 12 Jun 2013 Fix for bug #144399: Deleting a row and fixing a column breaks the zebra style of the records.
			var i, fixedRow, unfixedRow,
				container = this._containers.body,
				$unfixedTable = container.unfixedTable,
				$fixedTable = container.fixedTable,
				fixedRows = $fixedTable.find('tbody tr'),
				unfixedRows = $unfixedTable.find('tbody tr'),
				rowsLength = fixedRows.length;

			for (i = 0; i < rowsLength; i++) {
				fixedRow = fixedRows[i];
				unfixedRow = unfixedRows[i];
				fixedRow.setAttribute('style', unfixedRow.getAttribute('style'));
				fixedRow.setAttribute('class', unfixedRow.getAttribute('class'));
			}
		},
		_populateContainers: function () {
			var gridId = this.grid.id(),
				grid = this.grid,
				self = this,
				virtualization = this._isVirtualGrid(),
				$unfixedHeaders = this.grid.container().find("#" + gridId + "_headers"),
				$unfixedFooters = this.grid.container().find("#" + gridId + "_footer_container"),
				$fixedBodyContainer = this.grid.container().find("#" + gridId + "_fixedBodyContainer"),
				functionPopulateContainers,
				scrollContainer;

			if (virtualization) {
				scrollContainer = this.grid._vdisplaycontainer();
			} else {
				scrollContainer = this.grid.scrollContainer();
			}
			if (scrollContainer.length === 0) {
				scrollContainer = this.grid.element;
			}
			this._containers = {};
			functionPopulateContainers = function ($unfixedContainer, $fixedContainer, type) {
				var $unfixedTable = $unfixedContainer.find('table'), $fixedTable = grid.container().find("#" + $unfixedTable.attr("id") + "_fixed");
				// M.H. 21 May 2013 Fix for bug #141231: Column fixing breaks columns header with one normal header and other with multiple headers.
				if ($unfixedTable.length === 0) {
					$unfixedTable = $unfixedContainer;
				}
				self._containers[type] = {
					fixedContainer: $fixedContainer,
					unfixedContainer: $unfixedContainer,
					fixedTable: $fixedTable,
					unfixedTable: $unfixedTable
				};
			};
			if ($unfixedHeaders.length > 0) {
				functionPopulateContainers($unfixedHeaders.parent('div'), grid.fixedHeaderContainer(), "header");
			}
			functionPopulateContainers(scrollContainer, $fixedBodyContainer, "body");
			if ($unfixedFooters.length > 0 && $unfixedFooters[0].nodeName !== 'TFOOT') {
				//$fixedFooterContainer = $fixedBodyContainer;
				functionPopulateContainers($unfixedFooters, grid.fixedFooterContainer(), "footer");
			}
		},
		_fixMultiColumnHeaderDataSkip: function () {
			var i, $th, dataSkippedColsLength, $unfixedThead, $fixedThead,
				maxLevel = this.grid._maxLevel,
				container = this._containers.header;
				
			if (!container) {
				container = this._containers.body;
			}
			$unfixedThead = container.unfixedTable.find('thead');
			$fixedThead = this.grid.container().find("#" + container.unfixedTable.attr("id") + "_fixed").find('thead');
			if (this._hasDataSkippedColumns() && this.options.fixingDirection === 'left') {
				dataSkippedColsLength = this._getDataSkippedColumnsLength(true);
				for (i = 0; i < dataSkippedColsLength; i++) {
					$th = $unfixedThead.find('tr[data-mch-level=' + maxLevel + '] th[data-skip]:nth-child(1)');
					$th.detach();
					$th.appendTo($fixedThead.find('tr[data-mch-level=' + maxLevel + ']'));
				}
			}
		},
		_fixMultiColumnHeader: function (colInd, isInit, isGroupHeader, indexAt) {
			var grid = this.grid, i, cols,
				gridId = grid.id(), $th, maxLevel,
				$fixedThead, $unfixedThead,
				fixedTable, oTable,
				//heights = [],
				container = this._containers.header;
			
			if (!container) {
				container = this._containers.body;
			}
			oTable = container.unfixedTable;
			$unfixedThead = oTable.find('thead');
			fixedTable = this.grid.container().find("#" + oTable.attr("id") + "_fixed");
			// M.H. 21 May 2013 Fix for bug #141231: Column fixing breaks columns header with one normal header and other with multiple headers.
			if (fixedTable.length === 0) {
				fixedTable = container.fixedTable;
			}
			$fixedThead = fixedTable.find('thead');
			maxLevel = grid._maxLevel;
			if (isInit) {
				$unfixedThead.find('tr[data-mch-level]').each(function (ci, tr) {
					var attr = tr.attributes, attrStr = '';
					//heights.push({h: this.offsetHeight, r: this});
					if (attr) {
						for (i = 0; i < attr.length; i++) {
							attrStr += ' ' + attr[i].name + '="' + attr[i].value + '"';
						}
					}
					$('<tr' + attrStr + '></tr>').appendTo($fixedThead);
				});
				//if (this.options.syncRowHeights && this._heights.header) {
					//this._syncHeights(this._heights.header, $fixedThead);
				//}
				// add dataskipped columns if any
//				if (this._hasDataSkippedColumns() && this.options.fixingDirection === 'left') {
//					dataSkippedColsLength = this._getDataSkippedColumnsLength(true);
//					for (i = 0; i < dataSkippedColsLength; i++) {
//						$th = $unfixedThead.find('tr[data-mch-level=' + maxLevel + '] th[data-skip]:nth-child(1)');
//						$th.detach();
//						$th.appendTo($fixedThead.find('tr[data-mch-level=' + maxLevel + ']'));
//					}
//				}
			}
			if (!_aNull(indexAt)) {
				this._fixUnfixMCHColumn(colInd, { fixedThead: $fixedThead, unfixedThead: $unfixedThead, isToFix: true });
				return;
			}
			if (isGroupHeader) {
				cols = grid._oldCols;
				for (i = 0; i < cols.length; i++) {
					if (cols[i].identifier === colInd) {
						cols[i].fixed = true;
						this._renderMCHColumn(cols[i], $fixedThead, $unfixedThead);
						break;
					}
				}
			} else {
				//$th = $('#' + gridId + '_' + colInd);
				$th = this.grid.container().find("#" + gridId + "_" + colInd);
				$th.detach();
				//tdsFirst = oTable.find('thead tr[data-mch-level=' + maxLevel + '] th:nth-child(' + visibleIndex + ')');
				// changing col into colgroup
				$th.appendTo($fixedThead.find('tr[data-mch-level=' + maxLevel + ']'));
			}
		},
		// render single header column - it could be MultiColumn or at level 0, -renders all its children
		_renderMCHColumn: function (el, $fixedHeader, $unfixedHeader) {
			var level = el.level, domLevel, children, i, $th;
			//nColArray = this.grid._buildColumnLayoutArray(jQuery.extend(true, [], this._oldCols))
			if (level === 0) {
				//$th = $('#' + this.grid.id() + '_' + el.key);
				$th = this.grid.container().find("#" + this.grid.id() + "_" + el.key);
			} else {
				$th = $unfixedHeader.find('th[data-mch-id=' + el.identifier + ']');
				children = el.group;
			}
			domLevel = $th.closest('tr').attr('data-mch-level');
			$th.detach();
			$th.appendTo($fixedHeader.find('tr[data-mch-level=' + domLevel + ']'));
			if (level > 0) {
				for (i = 0; i < children.length; i++) {
					this._renderMCHColumn(children[i], $fixedHeader, $unfixedHeader);
				}
			}
		},
		_fixUnfixMCHColumn: function (colInd, fixingParams) {
			var i, grid = this.grid, oCols = grid._oldCols, col,
				fixedThead = fixingParams.fixedThead,
				unfixedThead = fixingParams.unfixedThead,
				isToFix = fixingParams.isToFix,
				area = isToFix ? fixedThead : unfixedThead,
				mchInstance = grid.element.data('igGridMultiColumnHeaders');
			if (!mchInstance) {
				return;
			}
			for (i = 0; i < oCols.length; i++) {
				if (oCols[i].identifier === colInd || oCols[i].key === colInd) {
					col = oCols[i];
					col.fixed = isToFix;
					break;
				}
			}
			if (i === oCols.length) {
				return;
			}
			
			mchInstance._rows = {};
			mchInstance._analyzeRowspanRows(this._getColumnsByState(isToFix), 0);
			this._fixUnfixMCHColumnRecursive(col, mchInstance._rows, area, isToFix);
		},
		_fixUnfixMCHColumnRecursive: function (col, rows, area, isToFix) {
			var grid = this.grid, $th, i, j, level = col.level, id, domLevel, cells,
				$targetTh, children;
			if (level === 0) {
				id = col.key;
				$th = grid.container().find("#" + this.grid.id() + "_" + col.key);
			} else {
				id = col.identifier;
				$th = grid.container().find('th[data-mch-id=' + col.identifier + ']');
			}
			domLevel = parseInt($th.closest('tr').attr('data-mch-level'), 10);
			cells = rows[domLevel];
			if (cells) {
				for (i = 0; i < cells.length; i++) {
					if (cells[i].identifier === id || cells[i].key === id) {
						col.fixed = isToFix;
						$th.detach();
						if (!cells[i + 1]) {
							$th.appendTo(area.find('tr[data-mch-level=' + domLevel + ']'));
						} else {
							if (_aNull(cells[i + 1].key)) {
								$targetTh = area.find('th[data-mch-id=' + cells[i + 1].identifier + ']');
							} else {
								$targetTh = area.find("#" + grid.id() + "_" + cells[i + 1].key);
							}
							if (!$targetTh.length) {
								i += 2;
								for (j = i; j < cells.length; j++) {
									if (_aNull(cells[j].key)) {
										$targetTh = area.find('th[data-mch-id=' + cells[j].identifier + ']');
									} else {
										$targetTh = area.find("#" + grid.id() + "_" + cells[j].key);
									}
									if (!$targetTh.length) {
										$targetTh = null;
									} else {
										break;
									}
								}
								if ($targetTh && $targetTh.length) {
									$th.insertBefore($targetTh);
								} else {
									$th.appendTo(area.find('tr[data-mch-level=' + domLevel + ']'));
								}
							} else {
								$th.insertBefore($targetTh);
							}
						}
						break;
					}
				}
			}
			children = col.group;
			if (children) {
				for (i = 0; i < children.length; i++) {
					this._fixUnfixMCHColumnRecursive(children[i], rows, area, isToFix);
				}
			}
		},
		_fixHeaderColumn: function (isInit, indexAt) {
			var self = this,
				$fixedThead, $tr,
				syncRowHeights = (this.options.syncRowHeights === true),
				$fixedTable, tdsFirst, $unfixedThead,
				$unfixedTable, heights,
				container = this._containers.header;
			
			if (!container) {
				container = this._containers.body;
			}
			$unfixedTable = container.unfixedTable;
			$fixedTable = container.fixedTable;
			$unfixedThead = $unfixedTable.find('thead');
			$fixedThead = $fixedTable.find('thead');
			tdsFirst = this._tds.header;
			if (!isInit) {
				// setting table TDs, THs
				this._fixUnfixDOM($fixedTable.children('thead'), tdsFirst, true, indexAt);
			} else {
				if (syncRowHeights) {
					heights = self._heights.header;
				}
				$unfixedThead.find('tr:not([data-mch-level])').each(function (ci, tr) {
					var i, $td = $(tdsFirst[ci]), attr = tr.attributes, attrStr = '';
					if (attr) {
						for (i = 0; i < attr.length; i++) {
							attrStr += ' ' + attr[i].name + '="' + attr[i].value + '"';
						}
					}
					$tr = $('<tr' + attrStr + '></tr>').appendTo($fixedThead);
					$td.appendTo($tr);
					if (syncRowHeights) {
						this.style.height = heights[ci].h + 'px';
					}
				});
			}
		},
		_fixBodyColumn: function (isInit, indexAt) {
			var grid = this.grid, i, heights, $trsUnfixed,
				$trs, trsLength, tr,
				$fixedTable, tdsFirst,
				$unfixedTable, syncDataIds, dataId,
				container = this._containers.body;
			
			$unfixedTable = container.unfixedTable;
			$fixedTable = container.fixedTable;
			tdsFirst = this._tds.body;
			if (isInit) {
				// M.H. 5 Mar 2013 Fix for bug #134687: Sorted style is removed the first time you fix a sorted column.
				$trsUnfixed = $unfixedTable.find('tbody>tr');
				trsLength = $trsUnfixed.length;
				this._renderFixedRecords($fixedTable, 0, trsLength - 1, true, $trsUnfixed);
				$trs = $fixedTable.find('tbody>tr');
				//trsLength = $trs.length;
				syncDataIds = false;
				if (trsLength !== grid.dataSource.dataView().length) {
					syncDataIds = true;
					$trsUnfixed = $unfixedTable.find('tbody>tr');
				}
				for (i = 0; i < trsLength; i++) {
					tr = $trs[i];
					$(tdsFirst[i]).appendTo(tr);
					if (syncDataIds) {
						dataId = $trsUnfixed[i].getAttribute('data-id');
						if (dataId) {
							tr.setAttribute('data-id', dataId);
						}
					}
				}
				// we should first set "content" (tds inside TRs) and then set height of the rows because performance issue
				if (this.options.syncRowHeights) {
					heights = this._heights.body;
					for (i = 0; i < trsLength; i++) {
						$trs[i].style.height = heights[i].h + 'px';
					}
				}
			} else {
				this._fixUnfixDOM($fixedTable.children('tbody'), tdsFirst, true, indexAt);
			}
			this._updateHScrollbarWidth();
			// M.H. 24 Feb 2013 Fix for bug #133421: Columns and headers are misaligned on fixing a column when grid and its columns doesn't have width set
			if (grid.options.width === null && $unfixedTable[0].style.width === '') {
				$unfixedTable[0].style.width = $unfixedTable.outerWidth() + 'px';
			}
			// sync mouseover styling in fixed/unfixed table rows
			if (isInit && this.grid.options.enableHoverStyles) {
				this._attachHoverEvents();
				}
		},
		_fixUnfixDOM: function (area, tds, isToFix, indexAt) {
			var i, trs = area.children('tr:not([data-mch-level],[data-skip])'), tdsLength = tds.length, $tr0, target, skip, insertAfter = false;
			if (!tdsLength) {
				return;
			}
			if (_aNull(indexAt)) {
				if (isToFix) {
					for (i = 0; i < tdsLength; i++) {
						$(tds[i]).appendTo(trs[i]);
					}
				} else {
					if (this._hasDataSkippedColumns(true) && this.options.fixingDirection === 'right') {
						skip = this._getDataSkippedColumnsLength();
						for (i = 0; i < trs.length; i++) {
							$(tds[i]).insertAfter(trs[i].children[skip - 1]);
						}
					} else {
						trs.each(function (ind, tr) {
							$(tds[ind]).prependTo($(tr));
			});
					}
			}
			} else {
				$tr0 = $(trs[0]);
				insertAfter = false;
				indexAt++;
				if (indexAt > $tr0.children('td,th').length) {
					indexAt = $tr0.children('td,th').length;
					insertAfter = true;
			}
				target = trs.children(':nth-child(' + indexAt + ')');
				if (!target.length) {
					return;
			}
				tds.each(function (index, td) {
					if (insertAfter) {
						$(td).insertAfter(target[index]);
					} else {
						$(td).insertBefore(target[index]);
			}
				});
			}
		},
		_fixFooterColumn: function (isInit, indexAt) {
			var heights, $fixedTable, tdsFirst, $tfoot, $unfixedTable,
				syncRowHeights = (this.options.syncRowHeights === true),
				container = this._containers.footer;
			
			if (!container) {
				container = this._containers.body;
			}
			$unfixedTable = container.unfixedTable;
			$fixedTable = container.fixedTable;
			tdsFirst = this._tds.footer;
			if (!isInit) {
				// setting table TDs, THs
				this._fixUnfixDOM($fixedTable.children('tfoot'), tdsFirst, true, indexAt);
			} else {
				$tfoot = $fixedTable.find('tfoot');
				if (syncRowHeights) {
					heights = this._heights.footer;
				}
				$unfixedTable.find('tfoot tr').each(function (ci, tr) {
					var i, h, $td = $(tdsFirst[ci]), attr = tr.attributes, $tr, attrValue, attrName, attrStr = '';
					if (attr) {
						for (i = 0; i < attr.length; i++) {
							attrName = attr[i].name;
							attrValue = attr[i].value;
							// M.H. 26 Apr 2013 Fix for bug #140689: When column is fixed and summaries are enabled filtering a column makes the grid to render incorrectly.
							if (attrName.toLowerCase() === 'id') {
								attrValue += '_fixed';
							}
							attrStr += ' ' + attrName + '="' + attrValue + '"';
						}
					}
					$tr = $('<tr' + attrStr + '></tr>').appendTo($tfoot);
					// sync heights
					if (syncRowHeights) {
						// M.H. 6 Nov 2013 Fix for bug #157012: When Summaries are enabled fixing a column throws a js error in IE8.
						h = heights[ci].h;
						$tr.height(h);
						this.style.height = h + 'px';
					}
					$td.appendTo($tr);
				});
				// M.H. 5 Mar 2013 Fix for bug #134687: Sorted style is removed the first time you fix a sorted column.
				//M.K. 27 May 2015: This fix is no longer needed.
				//$fixedTable.find('tr').each(function (ind, $row) {
				//	$(tdsFirst[ind]).appendTo($row);
				//});
				// M.H. 22 Aug 2013 Fix for bug #149851: When row selectors and summaries are enabled and there is a summary row spanned on two lines the fixed area is not aligned with the unfixed area.
				if (this._hasDataSkippedColumns() && this.grid._fixedColumns.length <= 1) {
					this._syncRowsHeights(this.grid.footersTable().find('tfoot'), this.grid.fixedFootersTable().find('tfoot'));
				}
			}
		},
		_dettachHoverEvents: function () {
			this._populateContainers();
			var container = this._containers.body,
				$unfixedTable = container.unfixedTable,
				$fixedTable = container.fixedTable;
			$fixedTable.undelegate('tbody', '.hoverColumnFixing');
			$unfixedTable.undelegate('tbody', '.hoverColumnFixing');
		},
		_attachHoverEvents: function () {
			this._populateContainers();
			var container = this._containers.body,
				$unfixedTable = container.unfixedTable,
				$fixedTable = container.fixedTable;

			this._mouseOverHandler = $.proxy(this._mouseOver, this);
			this._mouseLeaveHandler = $.proxy(this._mouseLeave, this);
			//this.grid._registerAdditionalEvents();
			$fixedTable.delegate('tbody', {
				'mousemove.hoverColumnFixing': this._mouseOverHandler,
				'mouseleave.hoverColumnFixing': this._mouseLeaveHandler
			});
			$unfixedTable.delegate('tbody', {
				'mousemove.hoverColumnFixing': this._mouseOverHandler,
				'mouseleave.hoverColumnFixing': this._mouseLeaveHandler
			});
		},
		_mouseOver: function (event) {
			var css = 'ui-state-hover', $tr = $(event.target).closest('tr'), grid = this.grid;
			if (grid._isFixedElement($tr)) {
				grid._mousemoveTr(grid.element.find('tbody tr:nth-child(' + ($tr.index() + 1) + ')')[0], event);
			}
			if (this._hoverTr) {
				this._hoverTr.find('td,th').removeClass(css);
			}
			this._hoverTr = grid.fixedTable().find('tbody tr:nth-child(' + ($tr.index() + 1) + ')');
			this._hoverTr.find('td,th').addClass(css);
		},
		_mouseLeave: function (event) {
			var css = 'ui-state-hover', $tr = $(event.target).closest('tr'), grid = this.grid;
			if (grid._isFixedElement($tr)) {
				grid._mouseleaveTr(grid.element.find('tbody tr:nth-child(' + ($tr.index() + 1) + ')')[0], event);
			}
			if (this._hoverTr) {
				this._hoverTr.find('td,th').removeClass(css);
			}
		},
		_checkAndRenderHScrlbarCntnr: function () {
			// test if grid has horizontal scrollbar and renders <DIV> in fixed container with height equal to the height of the horizontal scrollbar in unfixed area. In this way when scroll to the bottom rows of the fixed/unfixed areas are synced
			var grid = this.grid,
				scroller = grid._hscrollbarcontent(),
				hscrollbar = grid._hscrollbar(),
				fixedControllerScrollerId = grid.id() + '_fixedContainerScroller',
				$fixedScroller = grid.container().find("#" + fixedControllerScrollerId);
			if ($fixedScroller.length === 0 &&
					($.ig.util.hasHorizontalScroll(grid.scrollContainer()) || // it is possible to be rendered (browser)horizontal scrollbar in grid container - e.g. height is not specified
						(scroller.length === 1 && hscrollbar.is(':visible'))
					)
				) {
				// M.H. 7 Mar 2013 Fix for bug #135253: When width and height are set to the grid, widths to the columns are not set and there is initially fixed column the fixed area has bigger height than the unfixed.
				$('<div style="height:' +
						(hscrollbar.height() || $.ig.util.getScrollHeight()) +
						'px" id="' + fixedControllerScrollerId + '"></div>')
					.appendTo(this._containers.body.fixedContainer);
			} else if ($fixedScroller.length === 1 && hscrollbar.length === 1) {
				if (hscrollbar.is(':visible')) {
					$fixedScroller.show();
				} else {
					$fixedScroller.hide();
				}
			}
		},
		syncRowsHeights: function ($trs, $anotherRows) {
			/* Syncs rows heights between $rows and $anotherRows
			paramType="array" An array of rows object of fixed/unfixed container.
			paramType="array" An array of rows object of other unfixed/fixed container.
			*/
			var i, len = $trs.length, h, h2, harr = [];
			for (i = 0; i < len; i++) {
				h = $trs[i].offsetHeight;
				h2 = $anotherRows[i].offsetHeight;
				h = h > h2 ? h : h2;
				harr.push(h);
			}
			for (i = 0; i < len; i++) {
				$trs[i].style.height = harr[i] + 'px';
				$anotherRows[i].style.height = harr[i] + 'px';
			}
		},
		_syncRowsHeights: function ($container, $containerToSync) {
			var $trs = $container.find('tr'), $trsToSync = $containerToSync.find('tr');
			this.syncRowsHeights($trs, $trsToSync);
		},
		_syncHeights: function (heights, fixedTable) {
			var trs;

			if (this.options.syncRowHeights) {
				trs = fixedTable.find('tr');
				$.each(heights, function (ci, elem) {
					var h = elem.h + 'px';
					trs[ci].style.height = h;
					elem.tr.style.height = h;
				});
			}
		},
		// M.H. 11 Jun 2013 Fix for bug #144310: When autoCommit is true and there is a fixed column deleting a row does not remove the cells from the fixed area.
		_syncContainerHeights: function () {
			// sync heights between fixed and unfixed container(especially for table body)
			var $fixedTable, $unfixedTable,
				containers = this._containers;

			if (containers && containers.body) {
				$fixedTable = containers.body.fixedTable;
				$unfixedTable = containers.body.unfixedTable;
				if ($fixedTable.height() !== $unfixedTable.height()) {
					$fixedTable.height($unfixedTable.height());
				}
			}
		},
		_syncUnfixedWidth: function (colWidth) {
			var w, $col;
			this._syncUnfixedWidthByContainer(colWidth, this._containers.body.unfixedTable, this._containers.body.unfixedContainer);
			if (this._containers.header) {
				this._syncUnfixedWidthByContainer(colWidth, this._containers.header.unfixedTable, this._containers.header.unfixedContainer);
			}
			if (this._containers.footer) {
				this._syncUnfixedWidthByContainer(colWidth, this._containers.footer.unfixedTable, this._containers.footer.unfixedContainer);
			}
			if (this._isVirtualGrid()) {
				$col = this.grid._virtualcontainer().find('colgroup col:first');
				w = parseInt($col.attr('width'), 10) - colWidth;
				$col.attr('width', w);
			}
		},
		_adjustVirtualizationContainers: function (isToFix) {
			var funcAdjust, grid = this.grid;

			if (this.options.fixingDirection === 'right') {
				funcAdjust = function (container) {
					var padding, cWidth, tWidth,
						$unfixedTable = container.unfixedTable,
						$unfixedContainer = container.unfixedContainer;
					padding = grid._scrollbarWidth();
					if (!isToFix) {
						padding = -padding;
					}
					cWidth = $unfixedContainer.outerWidth();
					tWidth = $unfixedTable.outerWidth();
					$unfixedContainer.width(cWidth - padding);
					$unfixedTable.width(tWidth - padding);
					if (isToFix) {
						$unfixedTable.css(grid._padding, '');
					} else {
						$unfixedTable.css(grid._padding, (-padding) + 'px');
					}
				};
				funcAdjust(this._containers.header);
				funcAdjust(this._containers.footer);
			}
		},
		_syncUnfixedWidthByContainer: function (colWidth, $unfixedTable, scrollContainer) {
			if ($unfixedTable.length === 0) {
				return;
			}
			var scWidth, w = $unfixedTable[0].style.width,
				oTableWidth = parseInt(w, 10),
				virtGrid = this._isVirtualGrid();
			// M.H. 6 Mar 2015 Fix for bug 188873: When continuous virtualization is enabled and you hide a column from the fixed and unfixed areas cells and headers are misaligned.
			// if grid is virtual and width is not set explicitly or it is in percentage - we should not change its width
			if (!virtGrid || (w !== '' && !(w.indexOf && w.indexOf('%') > -1))) {
			if (isNaN(oTableWidth)) {
				oTableWidth = $unfixedTable.outerWidth();
			}
			// M.H. 24 Feb 2013 Fix for bug #133421: Columns and headers are misaligned on fixing a column when grid and its columns doesn't have width set
			//if (oTableWidth > 0 && !(this.grid.options.width === null && (oTableWidth + this.grid._scrollbarWidth()) === scrollContainer.width())) {
				oTableWidth -= colWidth;
				$unfixedTable[0].style.width = oTableWidth + 'px';
			}
			//}
			if (virtGrid) {
				scWidth = parseInt(scrollContainer[0].style.width, 10);
				if (isNaN(scWidth)) {
					scWidth = scrollContainer.outerWidth();
				}
				scWidth -= colWidth;
				scrollContainer.width(scWidth);
			}
		},
		_syncVirtualizationWidth: function (colWidth) {
			var grid = this.grid, gridId = grid.id(), $fixedFooterContainer,
				scrollContainer = grid._vdisplaycontainer(),
				$unfixedHeaders = grid.container().find("#" + gridId + "_headers"),
				$unfixedFooters = grid._fixedfooters(),
				$fixedBodyContainer = grid.fixedBodyContainer();

			if ($unfixedHeaders.length > 0) {
				this._updateContainersWidth(colWidth, $unfixedHeaders.parent('div'), grid.fixedHeaderContainer(), true);
			}
			this._updateContainersWidth(colWidth, scrollContainer, $fixedBodyContainer, true);
			if ($unfixedFooters.length > 0) {
				$fixedFooterContainer = grid.fixedFooterContainer();
				// M.H. 21 May 2013 Fix for bug #141231: Column fixing breaks columns header with one normal header and other with multiple headers.
				if ($fixedFooterContainer.length > 0) {
					this._updateContainersWidth(colWidth, $unfixedFooters, $fixedFooterContainer, true);
				}
			}
			this._syncFixedVirtualizationColgroup(colWidth);
		},
		_updateFixedGridContentWidth: function (delta) {
			var fixedContainerWidth = 0, gridW, gridInnerWidth, grid = this.grid, fcW;
			if (!grid._gridHasWidthInPixels()) {
				return;
			}
			gridW = parseInt(grid.options.width, 10);
			if (this._isVirtualGrid()) {
				this._syncWidth(-delta);
				gridInnerWidth = grid._vdisplaycontainer().outerWidth();
				grid._gridInnerWidth = gridInnerWidth;
				grid._hscrollbar().css('width', gridInnerWidth + 'px');
				grid._updateHScrollbarVisibility();
				this._updateHScrollbarWidth();
			} else {
				$.each(grid._fixedColumns, function (index, col) {
					var colW;
					if (!col.width || (col.width.charAt && col.width.endsWith('%')) || col.hidden) {
						return true;
					}
					colW = parseInt(col.width, 10);
					if (col.fixed === true) {
						fixedContainerWidth += colW;
					}
				});
				fcW = parseInt(grid.fixedBodyContainer().children('table')[0].style.width);
				//fcW = grid.fixedContainer().outerWidth();
				fcW -= delta;
				this._setGridFixedTablesWidth(fcW);
				gridW = parseInt(grid.options.width, 10);
				gridInnerWidth = gridW - grid.fixedContainer().outerWidth();
				grid._hscrollbar().css('width', gridInnerWidth + 'px');
				if (grid.options.height !== null) {
					grid._gridInnerWidth = gridInnerWidth;
					grid._gridInnerWidth = grid.scrollContainer().width();
					grid._updateHScrollbarVisibility();
				}
			}
		},
		_syncFixedVirtualizationColgroup: function (colWidthDelta) {
			var w, $colFixed, $colUnfixed, $colgroup;
			
			$colgroup = this.grid._virtualcontainer().find('colgroup:first');
			$colFixed = $colgroup.find('col[data-fixed-col]');
			$colUnfixed = $colgroup.find('col:not(:last):not([data-fixed-col])');
			w = parseInt($colFixed.attr('width'), 10);
			$colFixed.attr('width', w + colWidthDelta);
			w = parseInt($colUnfixed.attr('width'), 10);
			$colUnfixed.attr('width', w - colWidthDelta);
		},
		_setGridFixedTablesWidth: function (width) {
			var grid = this.grid,
				hasFixedHeaders = grid.options.showHeader && grid.options.fixedHeaders === true && grid.options.height !== null,
				hasFixedFooters = grid.options.showFooter && grid.options.fixedFooters === true && grid.options.height !== null;
			grid.fixedTable().width(width);
			if (hasFixedHeaders) {
				grid.fixedHeadersTable().width(width);
			}
			if (hasFixedFooters) {
				grid.fixedFootersTable().width(width);
			}
		},
		_syncWidth: function (colWidth) {
			if (this._isVirtualGrid()) {
				this._syncVirtualizationWidth(colWidth);
				return;
			}
			var grid = this.grid, gridId = grid.id(),
			scrollContainer, $fixedFooterContainer,
			updateFixedTable = true,
			$unfixedHeaders = grid.container().find("#" + gridId + "_headers"),
			$unfixedFooters = grid._fixedfooters(),
			$fixedBodyContainer = grid.fixedBodyContainer();

			if (grid.options.virtualization === true || grid.options.rowVirtualization === true) {
				scrollContainer = grid._vdisplaycontainer();
			} else {
				scrollContainer = grid.scrollContainer();
				if (scrollContainer.length === 0) {
					scrollContainer = grid.element;
				}
			}
			if ($unfixedHeaders.length > 0) {
				this._updateContainersWidth(colWidth, $unfixedHeaders.parent('div'), grid.fixedHeaderContainer(), updateFixedTable);
			}
			this._updateContainersWidth(colWidth, scrollContainer, $fixedBodyContainer, updateFixedTable);
			if ($unfixedFooters.length > 0) {
				$fixedFooterContainer = grid.fixedFooterContainer();
				// M.H. 21 May 2013 Fix for bug #141231: Column fixing breaks columns header with one normal header and other with multiple headers.
				if ($fixedFooterContainer.length > 0) {
					this._updateContainersWidth(colWidth, $unfixedFooters, $fixedFooterContainer, updateFixedTable);
				}
			}
		},
		_updateContinuousHScrollbar: function () {
			var $hScrollerContainer = this.grid._vhorizontalcontainer(),
				fixedTableWidth = this._containers.body.fixedTable.outerWidth(),
				gridWidth = parseInt(this.grid.options.width, 10);
			//all columns are unfixed
			if (fixedTableWidth === 0) {
				$hScrollerContainer.css({
					position: '',
					left: ''
				});
			} else if (this.options.fixingDirection === 'left') {
				$hScrollerContainer.css({
					left: fixedTableWidth + 'px',
					position: 'relative'
				});
			}
			$hScrollerContainer.width((gridWidth - fixedTableWidth) + 'px');
			this.grid._updateVirtualHorizontalScrollbar();
			//$hScrollerContainer = this.grid._vhorizontalcontainer();
		},
		getWidthOfFixedColumns: function (fCols, excludeNonDataColumns, includeHidden) {
			/* Calculates width of the fixed columns.
			paramType="array" optional="true" Array of grid columns. If not set then it is taken fixed columns of the grid.
			paramType="bool" optional="true" If set to true do not calculate the width of non-data fixed columns(like row-selectors)
			paramType="bool" optional="true" If set to true calculates width of the hidden fixed columns(as getting their initial width)
			returnType="number" Returns total width of the fixed columns
			*/
			var $fTable, w = 0, i;
			if (!this._containers || !this._containers.body) {
				this._populateContainers();
			}
			$fTable = this._containers.body.fixedTable;
			// get width of data-skip fixed columns
			if (excludeNonDataColumns) {
				$fTable.children('colgroup').children('col[data-skip]')
					.each(function () {
						w += parseInt($(this).css('width'), 10);
					});
			}
			fCols = fCols || this.grid._fixedColumns;
			if (!fCols || !fCols.length) {
				return w;
			}
			for (i = 0; i < fCols.length; i++) {
				if (!includeHidden && fCols[i].hidden) {
					continue;
				}
				w += fCols[i].width;
			}
			return w;
		},
		_updateHScrollbarWidth: function () {
			if (this._isContinuousVirtualization()) {
				this._updateContinuousHScrollbar();
				return;
			}
			var scrollContainer, grid = this.grid, $hScrollerContainer, scW,
				oTableWidth = this._containers.body.unfixedTable.outerWidth();

			scrollContainer = this._containers.body.unfixedContainer;
			if (oTableWidth > 0) {
				// M.H. 27 Feb 2013 Fix for bug #133875: The records in fixed column are not synchronized with the unfixed columns when the grid is vertically scrolled.
				scrollContainer.scrollTop(0);
				$hScrollerContainer = grid._hscrollbar();
				// M.H. 19 August 2015 Fix for bug 204865: Horizontal scrollbar is not displayed if columns are fixed and the grid is inside a tile of TileManager.
				if (scrollContainer.is(':visible')) {
					scW = scrollContainer.width();
				} else {
					scW = parseInt(grid.options.width, 10) - this.getWidthOfFixedColumns();
				}
				// M.H. 18 Aug 2014 Fix for bug #178044: Changing the grid width at runtime breaks the scrollbars of ColumnFixing
				$hScrollerContainer.css({
					width:  (scW - 1) + 'px',
					left: 0
				});
				// M.H. 21 Feb 2013 Fix for bug #133521: When you fix and unfix a column the width of the columns changes and scrolling the grid to the right misaligns it.
				grid._hscrollbarinner().css({
					width: (grid._hasVerticalScrollbar && grid.options.fixedHeaders ? oTableWidth - grid._scrollbarWidth() : oTableWidth) + 'px',
					left: 0
				});
			}
		},
		_updateSingleContainerWidth: function (width, fixed) {
			var $bodyTbl, $headerTbl, $footerTbl, funcUpdateTbl,
				$bodyContainer, $headerContainer, $footerContainer;

			width = !width ? 0 : parseInt(width, 10);
			this._populateContainers();
			if (fixed) {
				$bodyTbl = this._containers.body.fixedTable;
				$bodyContainer = this._containers.body.fixedContainer;
				if (this._containers.header) {
					$headerTbl = this._containers.header.fixedTable;
					$headerContainer = this._containers.header.fixedContainer;
				}
				if (this._containers.footer) {
					$footerTbl = this._containers.footer.fixedTable;
					$footerContainer = this._containers.footer.fixedContainer;
				}
			} else {
				$bodyTbl = this._containers.body.unfixedTable;
				$bodyContainer = this._containers.body.unfixedContainer;
				if (this._containers.header) {
					$headerTbl = this._containers.header.unfixedTable;
					$headerContainer = this._containers.header.unfixedContainer;
				}
				if (this._containers.footer) {
					$footerTbl = this._containers.footer.unfixedTable;
					$footerContainer = this._containers.footer.unfixedContainer;
				}
			}
			funcUpdateTbl = function (nW, $tbl) {
				// M.H. 6 Mar 2015 Fix for bug 188873: When continuous virtualization is enabled and you hide a column from the fixed and unfixed areas cells and headers are misaligned.
				// if grid is virtual and width is not set explicitly or it is in percentage - we should not change its width
				var w = $tbl[0].style.width;
				if ($.type(w) === 'string' && 
						(w.indexOf('%') !== -1 || w === '')) {
					return;
				} else {
					w = parseInt($tbl[0].style.width, 10);
				}
				if (isNaN(w)) {
					w = $tbl.outerWidth();
				}
				w += nW;
				$tbl.width(w);
			};
			funcUpdateTbl(width, $bodyTbl);
			if ($headerTbl) {
				funcUpdateTbl(width, $headerTbl);
				}
			if ($footerTbl) {
				funcUpdateTbl(width, $footerTbl);
			}
			if (this._isVirtualGrid()) {
				if (fixed) {
					this._syncFixedVirtualizationColgroup(width);
				} else {
					funcUpdateTbl(width, $bodyContainer);
					if ($headerTbl) {
						funcUpdateTbl(width, $headerContainer);
					}
					if ($footerTbl) {
						funcUpdateTbl(width, $footerContainer);
					}
				}
			}
		},
		_updateContainersWidth: function (colWidth, $unfixedContainer, $fixedContainer, updateFixedTable) {
			var oTableWidth, width = 0, $unfixedTable = $unfixedContainer.find('table'), scWidth,
				virtGrid = this._isVirtualGrid(), w,
				$fixedTable = this.grid.container().find("#" + $unfixedTable.attr("id") + "_fixed");
			if ($unfixedTable.length === 0) {
				$unfixedTable = $unfixedContainer;
			}
			if ($fixedTable.length === 0) {
				return;
			}
			width = parseInt($fixedTable[0].style.width, 10);
			if (isNaN(width)) {
				width = $fixedTable.outerWidth();
			}
			// M.H. 6 Mar 2015 Fix for bug 188873: When continuous virtualization is enabled and you hide a column from the fixed and unfixed areas cells and headers are misaligned.
			// if grid is virtual and width is not set explicitly or it is in percentage - we should not change its width
			w = $unfixedTable[0].style.width;
			if (!virtGrid || (w !== '' && !(w.indexOf && w.indexOf('%') > -1))) {
			// setting width of fixed table
				oTableWidth = parseInt(w, 10);
			if (isNaN(oTableWidth)) {
				oTableWidth = $unfixedTable.outerWidth();
			}
			// M.H. 24 Feb 2013 Fix for bug #133421: Columns and headers are misaligned on fixing a column when grid and its columns doesn't have width set
			//if (oTableWidth > 0 && !(this.grid.options.width === null && (oTableWidth + this.grid._scrollbarWidth()) === $unfixedContainer.width())) {
			oTableWidth -= colWidth;
				$unfixedTable[0].style.width = oTableWidth + 'px';
			}
			//}
			if (updateFixedTable) {
				width += colWidth;
				$fixedTable.width(width);
			}
			if (virtGrid) {
				scWidth = parseInt($unfixedContainer[0].style.width, 10);
				if (isNaN(scWidth)) {
					scWidth = $unfixedContainer.outerWidth();
				}
				scWidth -= colWidth;
				$unfixedContainer.width(scWidth);
			}
		},
		_headerRendered: function (sender, args) {
			//prevent handling of other grids' events in the case of hierarchical grid
			if (args.owner.element.attr("id") !== this.grid.element.attr("id")) {
				return;
			}
			if (this.options.showFixButtons === false) {
				return;
			}
			var i, j, cs, columnKey, ths, children,
				isFixed = false,
				allowFixing = true,
				grid = this.grid,
				self = this,
				cols = grid.options.columns,
				colsLength = cols.length;

			if (grid._isMultiColumnGrid) {
				ths = grid.headersTable().find('tr[data-mch-level=' + grid._maxLevel + '] th');
				ths.each(function () {
					var $th = $(this);
					if ($th.attr('data-mch-id')) {
						// M.H. 10 Dec 2013 Fix for bug #158504: ColumnFixing combined with MultiColumnHeaders, the main columns can be fixed/unfixed with allowFixing set to false
						columnKey = $th.attr('data-mch-id');
						allowFixing = true;
						// M.H. 6 Feb 2014 Fix for bug #159858: ColumnFixing combined with MultiColumnHeaders, the main column fixing/unfixing options are overriden by the default options of the nested columns
						cs = self._getColumnSettingByKey(columnKey);
						if (cs && cs.allowFixing === false) {
							return true;// continue
						}
						for (j = 0; j < grid._oldCols.length; j++) {
							if (grid._oldCols[j].identifier === columnKey) {
								children = grid._oldCols[j].children;
								for (i = 0; i < children.length; i++) {
									cs = self._getColumnSettingByKey(children[i].key, i);
									if (cs && cs.allowFixing === false) {
										allowFixing = false;
										break;
									}
								}
								break;
							}
						}
						if (!allowFixing) {
							return true;
						}
						self._renderHeaderCellButton(columnKey, isFixed, true, $th);
					} else {
						if ($th.attr('data-skip')) {
							return true;
						}
						columnKey = $th.attr('id').replace(grid.id() + '_', '');
						// M.H. 10 Dec 2013 Fix for bug #158504: ColumnFixing combined with MultiColumnHeaders, the main columns can be fixed/unfixed with allowFixing set to false
						cs = self._getColumnSettingByKey(columnKey);
						if (cs && cs.allowFixing === false) {
							return true;
						}
						if (self._fcData[columnKey] !== true) {
							self._renderHeaderCellButton(columnKey, isFixed, false, $th);
						}
					}
				});
			} else {
				for (i = 0; i < colsLength; i++) {
					columnKey = cols[i].key;
					cs = this._getColumnSettingByKey(columnKey, i);
					isFixed = false;
					if (cs !== null) {
						// M.H. 4 Mar 2013 Fix for bug #134230: ColumnSettings do not work with columnIndex.
						if (cs.allowFixing === false) {
							continue;
						}
						if (cs.isFixed === true) {
							isFixed = true;
						}
					}
					if (this._fcData[columnKey] !== true ) {
						this._renderHeaderCellButton(columnKey, isFixed);
					}
				}
			}
		},
		_headerRendering: function () {
			var i;
			for (i = 0; i < this.grid.options.features.length; i++) {
				if (this.grid.options.features[i].name === "Hiding") {
					this._hiding = this.grid.element.data("igGridHiding");
					break;
				}
			}
		},
		_columnsMoved: function (e, ui) {
			var start = ui.start, len = ui.len, idx = ui.index;
			if (!ui.isFixed) {
				return;
			}
			this.grid._rearrangeArray(this.grid._fixedColumns, start, len, idx);
		},
		_getColumnSettingByKey: function (key, colIndex) {
			var i, cs = this.options.columnSettings, csLength = cs.length, res = null;

			for (i = 0; i < csLength; i++) {
				if (cs[i].columnKey !== null && cs[i].columnKey !== undefined) { 
					if (cs[i].columnKey === key) {
						res = cs[i];
						break;
					}
				} else if (cs[i].columnIndex !== null && cs[i].columnIndex !== undefined) {
					if (cs[i].columnIndex === colIndex) {
						res = cs[i];
						break;
					}
				}
			}
			return res;
		},
		_id: function () {
			var i, res = this.grid.id(), argumentsLength = arguments.length;

			if (argumentsLength === 0) {
				return null;
			}

			for (i = 0; i < argumentsLength; i++) {
				res += '_' + arguments[i];
			}

			return res;
		},
		_renderHeaderCellButton: function (columnKey, isFixed, isGroupHeader, $th) {
			// M.H. 25 Feb 2013 Fix for bug #133865: The filtering dropdown can't be opened for fixed column.
			var self = this,
				css = self.css,
				buttonId,
				gridId = this.grid.id(),
				$button,
				$divHeaderButtonContainer,
				$columnFixingHeaderIconContainer;

			if ($th === undefined) {
				$th = this.grid.container().find("#" + gridId + "_" + columnKey);
			}
			buttonId = this._id('header_cell', 'fixing', columnKey);
			if ($th.length === 0) {
				return;
			}
			this.grid._enableHeaderCellFeature($th);
			$columnFixingHeaderIconContainer = $th.find('.ui-iggrid-indicatorcontainer');
			if ($columnFixingHeaderIconContainer.length === 0) {
				$columnFixingHeaderIconContainer = $('<div class="ui-iggrid-indicatorcontainer"></div>').appendTo($th);
			}
			$button = this.grid.container().find("#" + buttonId);
			if ($button.length === 0) {
				// M.H. 31 Oct. 2011 Fix for bug 94362
				$button = $('<a></a>')
					.attr('href', '#')
					// M.H. 27 Feb 2013 Fix for bug #134339: The destroy method of columnFixing does not work.
					.attr('data-fixing-indicator', 'true')
					.attr('id', buttonId);
				// M.H. 31 Oct. 2011 Fix for bug 94362
				// M.H. 22 Feb 2013 Fix for bug #133719: When you fix and unfix columns some extra divs are added in the container of the fixing icon.
				$divHeaderButtonContainer = $columnFixingHeaderIconContainer.find('.ui-iggrid-fixcolumn-headerbuttoncontainer');
				if ($divHeaderButtonContainer.length === 0) {
					$divHeaderButtonContainer = $('<div></div>').addClass(css.headerButtonIconContainer).appendTo($columnFixingHeaderIconContainer);
				}
				$button.appendTo($divHeaderButtonContainer);
				$('<span></span>')
					.appendTo($button);
				$button.bind({
					mousedown: function () {
						//$(this).focus();
						// M.H. 4 Mar 2013 Fix for bug #134678: When sorting is enabled fixing a column applies focused style to its header.
						// M.H. 11 Jun 2013 Fix for bug #144395: When you fix a column, fixedHeaders is false and click "Add new row" clicking in the editor of the fixed column cancels the adding.
						//self._preventDefaultEvent(event);
						$(this).trigger('mouseout');
						// M.H. 11 Jun 2013 Fix for bug #144395: When you fix a column, fixedHeaders is false and click "Add new row" clicking in the editor of the fixed column cancels the adding.
						//return false;
					},
					click: function (event) {
						self._preventDefaultEvent(event);
						if ($button.attr('data-fixed') === 'true') { 
							self._unfixColumnInternal(columnKey, isGroupHeader);
						} else {
							self._fixColumnInternal(columnKey, isGroupHeader);
						}
					}
				});
			}
			this._changeStyleHeaderButton(columnKey, isFixed);
		},
		_getMCHHeader: function (id) {
			return this.grid.headersTable().find('th[data-mch-id=' + id + ']');
		},
		_changeStyleHeaderButton: function (columnKey, isFixed) {
			var css = this.css, fc,
				attrVal = 'true', title = this.options.headerFixButtonText,
				$button = this.grid.container().find("#" + this._id("header_cell", "fixing", columnKey)),
				$span;
			
			$span = $button.find('span');
			if (isFixed) {
				$span.removeClass(css.headerButtonIcon);
				$span.addClass(css.headerButtonUnfixIcon);
				title = this.options.headerUnfixButtonText;
			} else {
				attrVal = 'false';
				$span.removeClass(css.headerButtonUnfixIcon);
				$span.addClass(css.headerButtonIcon);
			}
			$button.attr('data-fixed', attrVal).attr('title', title);
			// M.H. 8 Jan 2014 Fix for bug #161032: The fixing icon in the feature chooser does not change when you fix a column with API method.
			fc = this.grid.element.data('igGridFeatureChooser');
			if (fc !== undefined && fc !== null) {
				fc._setSelectedState('ColumnFixing', columnKey, isFixed, false);
			}
		},
		// M.H. 18 Sep 2013 Fix for bug #152468: The fixed and unfixed areas are misalinged when there are cells with text spanned on two rows and the grid doesn't have height in IE9.
		_dataRendering: function (event, ui) {
			if (ui === undefined) {
				return;
			}
			if (this.grid.id() !== ui.owner.id()) {
				return;
			}
			if (this.grid.options.height === null  && this.grid.hasFixedColumns() &&
					$.ig.util.isIE && $.ig.util.browserVersion >= 9) {
				$('#' + this.grid.id() + '_fixed').height("");
			}
		},
		// M.H. 18 Sep 2013 Fix for bug #152468: The fixed and unfixed areas are misalinged when there are cells with text spanned on two rows and the grid doesn't have height in IE9.
		// In IE9+ there is misalignment betweed fixed and unfixed table rows although it is set table heights row. We fix this as setting height of the fixed table
		_dataRendered: function (event, ui) {
			// M.H. 27 Sep 2013 Fix for bug #147490: The "Search Result" span is relocated when column is fixed and you filter the grid in Chrome.
			//this._fixResultContainer();
			if (ui === undefined) {
				return;
			}
			// M.H. 18 Sep 2013 Fix for bug #152468: The fixed and unfixed areas are misalinged when there are cells with text spanned on two rows and the grid doesn't have height in IE9.
			if (this.grid.id() !== ui.owner.id()) {
				return;
			}
			// if there is initial column fixing
			if (!this.grid._initialized) {
				this._gridInternalRendered();
			}
			// M.H. 9 Sep 2014 Fix for bug #180223: When you call commit the fixed area shrinks.
			this.checkAndSyncHeights();
		},
		// M.H. 18 Sep 2013 Fix for bug #152468: The fixed and unfixed areas are misalinged when there are cells with text spanned on two rows and the grid doesn't have height in IE9.
		// In IE9+ there is misalignment betweed fixed and unfixed table rows although it is set table heights row. We fix this as setting height of the fixed table
		_syncTableHeights: function () {
			$('#' + this.grid.id() + '_fixed').height(this.grid.element.height());
		},
		_gridInternalRendered: function () {
			// apply initial column fixing
			var i, j, cs = this.options.columnSettings, csLength = cs.length,
				columnKeys = [], hasColumnKey, hasColumnIndex, res,
				cols = this.grid.options.columns, col, isGroupHeader,
				countHidden = 0,
				colsLength = cols.length;
			
			for (i = 0; i < csLength; i++) {
				if (cs[i].isFixed !== true) {
					continue;
				}
				hasColumnKey = (cs[i].columnKey !== null && cs[i].columnKey !== undefined);
				hasColumnIndex = (cs[i].columnIndex !== null && cs[i].columnIndex !== undefined);
				if (!hasColumnKey) {
					if (!hasColumnIndex) {
						continue;
					}
					// M.H. 4 Mar 2013 Fix for bug #134230: ColumnSettings do not work with columnIndex.
					if (cs[i].columnIndex >= 0 && cs[i].columnIndex < colsLength) {
						columnKeys.push(cols[cs[i].columnIndex].key);
						if (cols[cs[i].columnIndex].hidden) {
							countHidden++;
					}
					}
				} else {
					columnKeys.push(cs[i].columnKey);
					col = this.grid.columnByKey(cs[i].columnKey);
					if (col && col.hidden) {
						countHidden++;
					}
				}
			}
			if (countHidden === columnKeys.length && countHidden > 0) {
				this._trigger(this.events.columnFixingRefused, null, {
					'columnIdentifier': columnKeys,
					owner: this.grid
				});
				return;
			}
			// M.H. 4 Mar 2013 Fix for bug #134230: ColumnSettings do not work with columnIndex.
			for (j = 0; j < columnKeys.length; j++) {
				isGroupHeader = false;
				if (this.grid._isMultiColumnGrid && !this.grid.columnByKey(columnKeys[j])) {
					isGroupHeader = true;
				}
				res = this.fixColumn(columnKeys[j], isGroupHeader);
				if (!res.result) {
					throw new Error($.ig.util.stringFormat($.ig.ColumnFixing.locale.initialFixingNotApplied, columnKeys[j], res.error));
				}
			}
			// if width is in percentage then we should check when grid is resized(for instance its container) and sync thead/tbody rows if necessary
			if ($.type(this.grid.options.width) === 'string' && this.grid.options.width.indexOf('%') !== -1 &&
				!this.grid.element.closest(".ui-widget").data("igResponsiveContainer") && !this._responsive) {
				this._responsive = this.grid.element.closest(".ui-widget").igResponsiveContainer().data("igResponsiveContainer");
				this._callBackId = this._responsive.addCallback(this._containerResized, this, 10, "x");
			}
			if (this.options.fixNondataColumns) {
				this.fixDataSkippedColumns();
			}
		},
		_syncRowsOnAddEdit: function ($fRow, $ufRow) {
			if (!this._containers || !this._containers.body) {
				this._populateContainers();
			}
			// in case when 2 rows have synced heights and after updating one of the rows is shrunk
			this._containers.body.fixedTable.height('');
			this._containers.body.unfixedTable.height('');
			$fRow.height('');
			$ufRow.height('');
			this.syncRowsHeights($fRow, $ufRow);
			// M.H. 5 June 2015 Fix for bug 187746: When RowSelectors and ColumnFixing are enabled adding a new row makes the rows misaligned.
			this.checkAndSyncHeights();
		},
		_editRowEnded: function (e, args) {
			if (!this.options.syncRowHeights || !this.grid.hasFixedColumns()) {
				return;
			}
			var rowId = args.rowID,
				$fRow = this.grid.rowById(rowId, true),
				$ufRow = this.grid.rowById(rowId);
			if (!$fRow || !$ufRow) {
				return;
			}
			this._syncRowsOnAddEdit($fRow, $ufRow);
		},
		_preventDefaultEvent: function (event) {
			event.preventDefault();
			event.stopPropagation();
		},
		_detachEvents: function () {
			if (this._headerRenderedHandler) {
				this.grid.element.unbind('iggridheaderrendered', this._headerRenderedHandler);
			}
			if (this._headerCellRenderedHandler) {
				this.grid.element.unbind('iggridheadercellrendered', this._headerCellRenderedHandler);
			}
			if (this._headerRenderingHandler) {
				this.grid.element.unbind('iggridheaderrendering', this._headerRenderingHandler);
			}
			if (this._columnsMovedHandler) {
				this.grid.element.unbind('iggrid_columnsmoved', this._columnsMovedHandler);
			}
			// M.H. 7 Mar 2014 Fix for bug #147490: The "Search Result" span is relocated when column is fixed and you filter the grid in Chrome.
			if (this._gridHeightChangingHandler) {
				this.grid.element.unbind("iggrid_heightchanging", this._gridHeightChangingHandler);
			}
			if (this._dataRenderingHandler) {
				this.grid.element.unbind('iggriddatarendering', this._dataRenderingHandler);
			}
			if (this._dataRenderedHandler) {
				this.grid.element.unbind('iggriddatarendered', this._dataRenderedHandler);
			}
			if (this._virtualrecordsrenderHandler) {
				this.grid.element.unbind('iggridvirtualrecordsrender', this._virtualrecordsrenderHandler);
			}
			if (this._gridContainerHeightHandler) {
				this.grid.element.unbind("iggrid_heightchanged", this._gridContainerHeightHandler);
			}
			if (this._editRowEndedHandler) {
				this.grid.element.unbind('iggridupdating_editrowended', this._editRowEndedHandler);
			}
		},
		destroy: function () {
			/* destroys the columnfixing widget */
			var fc;
			if (this.grid._fixedColumns && this.grid._fixedColumns.length > 0) {
				this.unfixAllColumns();
			}
			// M.H. 27 Feb 2013 Fix for bug #134339: The destroy method of columnFixing does not work.
			this.grid.headersTable()
				.find("thead > tr > th")
				.not("[data-skip=true]")
				.each(function () {
					var th = $(this);
					th.find("a[data-fixing-indicator=true]").parent().remove();
				});
			this._detachEvents();
			if (this._gridRenderRowHandler !== undefined) {
				this.grid._renderRow = this._gridRenderRowHandler;
			}
			if (typeof this._callBackId === "number") {
				this._responsive.removeCallback(this._callBackId);
				this._callBackId = null;
			}
			fc = this.grid.element.data('igGridFeatureChooser');
			if (fc && this.renderInFeatureChooser) {
				fc._removeFeature('ColumnFixing');
			}
			this._unregisterSetOptionCallback();
			$.Widget.prototype.destroy.call(this);
			return this;
		},
		_headerCellRendered: function (event, ui) {
			/* check for which cells should be rendered in feature chooser
			*/
			//prevent handling of other grids' events in the case of hierarchical grid
			if (ui.owner.element.attr("id") !== this.grid.element.attr("id")) {
				return;
			}
			if (this._isInitFC !== true) {
				this._initFC();
			}
		},
		_heightChanged: function () {//e, args
			var grid = this.grid;
			// M.H. 20 August 2015 Fix for bug 204979: Grid with column fixing, horizontal and vertical scrollbars is throwing an error
			if (!grid.hasFixedColumns()) {
				return;
			}
			this._syncTableHeights();
			this._setFixedBodyCntnrHeight();
			// M.H. 19 August 2015 Fix for bug 204865: Horizontal scrollbar is not displayed if columns are fixed and the grid is inside a tile of TileManager.
			this._checkAndRenderHScrlbarCntnr();
			if (this._isVirtualGrid()) {
				//this.grid.fixedBodyContainer().height(args.ch - args.h);
				if (this.options.syncRowHeights) {
					this._syncRowsHeights(this._containers.body.unfixedContainer, this._containers.body.fixedContainer);
				}
			}
		},
		// M.H. 7 Mar 2014 Fix for bug #147490: The "Search Result" span is relocated when column is fixed and you filter the grid in Chrome.
		_gridHeightChanging: function (e, arg) {
			if (!this._containers.body) {
				return;
			}
			if (this._isVirtualGrid()) {
				return;
			}
			var scrollContainerHeight, diff,
				pc = this.grid._prevContainerHeight,
				$fixedBodyContainer = this.grid.fixedBodyContainer();
			if ($fixedBodyContainer.length === 0) {
				return;
			}
			scrollContainerHeight = arg.ch - arg.h;//this._containers.body.unfixedContainer.outerHeight();
			if (this.grid._hscrollbar().is(':visible')) {
				scrollContainerHeight += this.grid._hscrollbar().outerHeight();
			}
			//if ($fixedBodyContainer.outerHeight() !== parseInt(scrollContainerHeight)) {
			// M.H. 21 May 2013 Fix for bug #141227: Scrollbar is in wrong place when Grid's height set to 100%.
			$fixedBodyContainer.height(scrollContainerHeight);
			diff = Math.abs(pc - this.grid.container().height());
			$fixedBodyContainer.height(scrollContainerHeight - diff);
			// M.H. 23 Aug 2013 Fix for bug #147490: The "Search Result" span is relocated when column is fixed and you filter the grid in Chrome.
			//this._fixResultContainer();
		},
		_initFC: function () {
			 /* instantiate feature chooser */
			// check whether feature chooser is defined
			var i, fc,
				isMCH = this.grid._isMultiColumnGrid,
				o = this.options,
				cols = this.grid.options.columns,
				colsLength = cols.length, 
				cs,
				columnKey;

			this._isInitFC = true;
			// instantiate igGridFeatureChooser = if it is defined
			fc = this.grid.element.data('igGridFeatureChooser');
			// M.H. 30 Mar 2015 Fix for bug 186411: Fix button should not be shown in the feature chooser when showFixButtons is false
			if (fc !== null && fc !== undefined &&
				this.renderInFeatureChooser && o.showFixButtons) {
				if (isMCH) {
					cols = this.grid._oldCols;
					colsLength = cols.length;
				}
				for (i = 0; i < colsLength; i++) {
					columnKey = cols[i].key;
					this._fcData[columnKey] = false;
					// M.H. 11 Jun 2013 Fix for bug #144394: When filtering is enabled the fixing icon is rendered next to feature chooser.
					if (isMCH && cols[i].level !== 0) {
						continue;
					}
					cs = this._getColumnSettingByKey(columnKey, i);
					if (cs && cs.allowFixing === false) {
						continue;
					}
					if (fc._shouldRenderInFeatureChooser(columnKey) === true) {
						fc._renderInFeatureChooser(columnKey,
							{
								name: 'ColumnFixing',
								text: o.featureChooserTextUnfixedColumn,
								textHide: o.featureChooserTextFixedColumn,
								iconClass: this.css.featureChooserIconClassFixed,
								iconClassOff: this.css.featureChooserIconClassUnfixed,
								//secondaryIconClass: this.css.featureChooserIconClassUnfixed,
								// M.H. 10 Jun 2013 Fix for bug #140584: When the column is initially fixed column the text in the feature chooser is not correct.
								isSelected: (cs && cs.isFixed === true),
								method: $.proxy(this._togglefromfc, this),
								updateOnClickAll: false,
								order: 3, // order in group
								groupName: 'toggle',
								groupOrder: 1,
								type: 'toggle',
								state: 'hide'
							}
							);
						//fc._setSelectedState('Summaries', columnKey, false, false);
						this._fcData[columnKey] = true;
					}
				}
			}
		},
		_togglefromfc: function (event, columnKey) {
			var i, cols = this.grid.options.columns, colsLength = cols.length, col, ret;
			
			for (i = 0; i < colsLength; i++) {
				col = cols[i];
				if (col.key === columnKey) {
					if (col.fixed === true) {
						ret = this._unfixColumnInternal(columnKey);
					} else {
						ret = this._fixColumnInternal(columnKey);
					}
					break;
				}
			}
			// M.H. 10 Jun 2013 Fix for bug #144214: The "Fix Column" option changes even when column fixing is refused.
			return (ret.error === undefined);
		},
		_columnMap: function () {
			var i, j, isMCH = this.grid._isMultiColumnGrid, cs, columnKey, elem, result = [], cols = this.grid.options.columns, colsLength = cols.length;

			if (this.options.showFixButtons === false) {
				return false;
			}
			for (i = 0; i < colsLength; i++) {
				columnKey = cols[i].key;
				elem = {columnKey: columnKey, enabled: true};
				cs = this._getColumnSettingByKey(columnKey, i);
				if (cs && cs.allowFixing === false) {
					elem.enabled = false;
				} else if (isMCH) {
					for (j = 0; j < this.grid._oldCols.length; j++) {
						if (this.grid._oldCols[j].key === columnKey) {
							break;
						}
					}
					if (j === this.grid._oldCols.length) {
						elem.enabled = false;
					}
				}
				result.push(elem);
			}
			return result;
		},
		/* Overriden functions */
		_renderRow: function (rec, tr, rowId) {
			// overriding grid _renderRow
			if (!this.grid.hasFixedColumns()) {
				return this._gridRenderRowHandler(rec, tr, rowId);
			}
			
			var i, col, content, $fixedRow, $unfixedRow, fixedCells, unfixedCells,
				counterFixed = 0, counterUnfixed = 0, $td,
				$tr = $(tr),
				grid = this.grid, cols = grid.options.columns, colsLength = cols.length, isFixedRow = this.grid._isFixedElement($tr);

			if (isFixedRow) {
				$fixedRow = $tr;
				$unfixedRow = grid.element.find('tbody tr:nth-child(' + ($tr.index() + 1) + ')');
			} else {
				$unfixedRow = $tr;
				$fixedRow = this.grid.fixedTable().find("tbody tr:nth-child(" + ($tr.index() + 1) + ")");
			}
			
			fixedCells = $fixedRow.find('td:not([data-skip])');
			unfixedCells = $unfixedRow.find('td:not([data-skip])');
			// render fixed records
			for (i = 0; i < colsLength; i++) {
				col = cols[i];
				if (col.hidden === true) {
					continue;
				}
				if (col.fixed === true) {
					$td = fixedCells.eq(counterFixed++);
				} else {
					$td = unfixedCells.eq(counterUnfixed++);
				}
				if (col.template && col.template.length) {
					content = grid._renderTemplatedCell(rec, col);
					if (content.indexOf("<td") === 0) {
						$td.html($(content).html());
					} else {
					$td.html(content);
					}
				} else {
					$td.html(String(grid._renderCell(rec[col.key], col, rec)));
				}
			}
			return tr;
		},
		_renderRecords: function (start, end) {
			var $fixedTable, hasFixedColumns = this.grid.hasFixedColumns();
			this._gridRenderRecordsHandler(start, end);
			if (hasFixedColumns) {
				$fixedTable = this.grid.fixedTable();
				this._renderFixedRecords($fixedTable, start, end);
				// sync heights
				// M.H. 19 Feb 2014 Fix for bug #164298: When a column is fixed and other column is hidden showing this column makes some of the rows higher.
				// we shouldn't apply sync row heights when hide a column because after rendering rows it is applied adjustLastColumnWidth which could cause changes in row heights
				if (this.options.syncRowHeights && this._applySyncRowHeights !== false) {
					this._syncFixedHeights($fixedTable, this.grid.element);
				}
			}
		},
		_renderNewRow: function (rec, key) {
			var grid = this.grid, self = this, 
				tbody = this.grid.element.children("tbody"),
				index = tbody.children("[data-container!=\"true\"]").length,
				virt = (grid.options.virtualization === true || grid.options.rowVirtualization === true);

			this._gridRenderNewRowHandler(rec, key);
			if (!virt) {
				if (grid.hasFixedColumns()) {
					MSApp.execUnsafeLocalFunction(function () {
						grid.fixedTable().find('tbody').append(self._renderFixedRecord(rec, index));
					});
				}
			}
		},
		_updateVScrollbarCellPaddingHelper: function (paddingIncrement, skipHeaderFooters) {
			if (!this.grid.hasFixedColumns()) {
				this._gridUpdatePaddingHandler(paddingIncrement, skipHeaderFooters);
				return;
			}

			var grid = this.grid, gridOpts = grid.options, fTable, hTable, container,
				hasFixedHeaders = gridOpts.showHeader && gridOpts.fixedHeaders === true && gridOpts.height !== null,
				hasFixedFooters = gridOpts.showFooter && gridOpts.fixedFooters === true && gridOpts.height !== null;

			if (this.options.fixingDirection === 'right') {
				// clear scroll padding for unfixed part
				// first we will clear padding for fixed and unfixed part and then we will apply padding
				if (hasFixedHeaders && !skipHeaderFooters) {
					hTable = grid.fixedHeadersTable();
					// remove cell padding for non fixed thead cells(not only for the last)
					grid._removeHeaderCellPadding(grid.headersTable(), true);
				}
				if (hasFixedFooters && !skipHeaderFooters) {
					fTable = grid.fixedFootersTable();
					// remove cell padding for non fixed footers table(for all cells not only for the last)
					grid._removeCellPadding(grid.footersTable(), "tfoot", "td", true);
				}
				// remove cell padding for non fixed tbody cells(not only for the last)
				grid._removeCellPadding(grid.element, "tbody", "td", true);
				container = grid.fixedBodyContainer();
			} else {
				if (hasFixedHeaders && !skipHeaderFooters) {
					hTable = grid.headersTable();
					// remove cell padding for fixed thead cells(not only for the last)
					grid._removeHeaderCellPadding(grid.fixedHeadersTable(), true);
				}
				if (hasFixedFooters && !skipHeaderFooters) {
					fTable = grid.footersTable();
					// remove cell padding for fixed tfoot cells(not only for the last)
					grid._removeCellPadding(grid.fixedFootersTable(), "tfoot", "td", true);
				}
				// remove cell padding for fixed tbody cells(not only for the last)
				grid._removeCellPadding(grid.fixedBodyContainer(), "tbody", "td", true);
				container = this.element;
			}

			if (hasFixedHeaders && !skipHeaderFooters) {
				grid._increaseLastHeaderCellVScrollbarPadding(hTable, paddingIncrement);
			}
			if (hasFixedFooters && !skipHeaderFooters) {
				grid._increaseLastCellVScrollbarPadding(fTable, "tfoot", "td", paddingIncrement);
			}
			grid._increaseLastCellVScrollbarPadding(container, "tbody", "td", paddingIncrement);
		},
		/* // Override functions */
		_syncFixedHeights: function ($fixedTable, $unfixedTable) {
			var heights = [], $trsFixedTable, $trsUnfixedTable, h, fH, ufH, resetHeights = false;
			// M.H. 14 Jun 2013 Fix for bug #144693: When you fix a column and then filter a column the records increase their height.
			// in IE9+ there is misalignment between fixed and unfixed records because rendering engine of IE does not render properly records when height is epxlicitly set of table rows
			// to fix this we should set height of fixed/unfixed table
			// when filtering and there is only one row to show then row gets the height of the whole fixed area when height is explicitly set for the table
			if ($unfixedTable.lenght && $unfixedTable[0].style.height !== '') {
				resetHeights = true;
			}
			$fixedTable.css('height', '');
			$unfixedTable.css('height', '');
			$trsFixedTable = $fixedTable.find('tr');
			$trsUnfixedTable = $unfixedTable.find('tr');
			$trsUnfixedTable.map(function (ind) {
				var unfixedHeight = this.offsetHeight, fixedHeight = $trsFixedTable[ind].offsetHeight;

				if (unfixedHeight < fixedHeight) {
					unfixedHeight = fixedHeight;
				}
				heights.push(unfixedHeight);
			});
			$.each(heights, function (ci, h) {
				var height = h + 'px';

				$trsFixedTable[ci].style.height = height;
				$trsUnfixedTable[ci].style.height = height;
			});
			if (resetHeights) {
			fH = $fixedTable.height();
			ufH = $unfixedTable.height();
			h = fH;
			if (fH < ufH) {
				h = ufH;
			}
			$fixedTable.height(h);
			$unfixedTable.height(h);
			}
		},
		// M.H. 5 Mar 2013 Fix for bug #134687: Sorted style is removed the first time you fix a sorted column.
		_renderFixedRecords: function ($table, start, end, onlyRows, $trsUnfixed) {
			var grid = this.grid, tr,
				ds = grid.dataSource.dataView(), i, d = "", noCancel = true;

			if (start === undefined) { //no params => render all
				start = 0;
				end = ds.length - 1;
			}
			if (start !== undefined && end === undefined) {
				end = start;
				if (end > ds.length - 1) {
					end = ds.length - 1;
				}
				start = 0;
			}
			if (start < 0) {
				start = 0;
			}
			if (end > ds.length - 1 && !onlyRows) {
				end = ds.length - 1;
			}
			if (noCancel) {
					for (i = start; i <= end; i++) {
					if ($trsUnfixed) {
						tr = $trsUnfixed[i];
					}
						// M.H. 5 Mar 2013 Fix for bug #134687: Sorted style is removed the first time you fix a sorted column.
					d += this._renderFixedRecord(ds[i], i, onlyRows, tr);
					}
				$table.find('tbody').html(d);
			}
		},
		// M.H. 5 Mar 2013 Fix for bug #134687: Sorted style is removed the first time you fix a sorted column.
		_renderFixedRecord: function (data, rowIndex, onlyRows, tr) {
			// generate a Tr and append it to the table
			var i, grid = this.grid,
				o = grid.options, attr,
				key = o.primaryKey,/* ar = o.accessibilityRendering,*/
				dstr = "", cols = grid._fixedColumns;
			
			dstr += '<tr';
			if (tr && this.options.populateDataRowsAttributes) {
				attr = tr.attributes;
				if (attr) {
					for (i = 0; i < attr.length; i++) {
						dstr += ' ' + attr[i].name + '="' + attr[i].value + '"';
					}
				}
			} else {
			if (rowIndex % 2 !== 0 && o.alternateRowStyles) {
				dstr += ' class="' + grid.css.recordAltClass + '"';
			}
			}
			/*jshint -W106*/
			if (data) {
				if (!_aNull(key)) {
					dstr += ' data-id="' + grid._kval_from_key(key, data) + '"';
				} else if (!_aNull(data.ig_pk)) {
					dstr += ' data-id="' + data.ig_pk + '"';
				}
			}
			/*jshint +W106*/
			//data index to which the row is bound
			if (o.virtualization && o.virtualizationMode === 'continuous') {
				dstr += ' data-row-idx="' + rowIndex + '"';
			}
			//if (ar) {
			dstr += ' role="row">';
			// } else {
				// dstr += '>';
			// }
			if (onlyRows === true) {
				dstr += '</tr>';
				return dstr;
			}
			//noVisibleColumns = true;
			$(cols).each(function (colIndex) {
				var temp, k;
					if (cols[colIndex].hidden || cols[colIndex].fixed !== true) {
						return;
					}
					//noVisibleColumns = false;
					//if (ar) {
					dstr += '<td role="gridcell" aria-describedby="' + grid.id() + '_' + this.key + '" tabindex="' + grid.options.tabIndex + '"';
					// } else {
						// dstr += '<td';
					// }
				if (cols[colIndex].template && cols[colIndex].template.length) {
					temp = grid._renderTemplatedCell(data, this);
					if (temp.indexOf("<td") === 0) {
						dstr += temp.substring(3);
						} else {
						dstr += '>' + temp;
						}
					dstr = grid._editCellStyle(dstr, data, this.key, true);
					} else {
					k = this.key || colIndex;
					dstr += grid._addCellStyle(data, k, cols[colIndex], true) + '>' + grid._renderCell(data[k], this, data);
						}
						dstr += '</td>';
				});
				//if (noVisibleColumns) {
				//	dstr += '<td role="gridcell"></td>';
				//}
			dstr += '</tr>';
			return dstr;
		},
		_detachColumn: function (col) {
			var position, fixed, headerCells, grid = this.grid, tPos,
				isMultiColumnGrid = grid._isMultiColumnGrid, footerCells,
				hasFixedColumns = grid.hasFixedColumns();

			if (!hasFixedColumns) {
				this._gridDetachColumnHandler(col);
			} else {
				fixed = col.fixed;
				col.hidden = false;
				grid._visibleColumnsArray = undefined;
				// we need to get total position of header cells(no matter fixed/unfixed) - position according to this._headerCells(in case of MCH)
				tPos = $.inArray(col, this.grid._visibleColumns());
				position = this._getVisibleIndex(col.key, (col.fixed === true), true);
				col.hidden = true;
				grid._visibleColumnsArray = undefined;
				grid._initializeDetachedContainers();
				if (fixed) {
					headerCells = grid.fixedHeadersTable().children("thead").children("tr").not("[data-skip=true]");
					footerCells = grid.fixedFootersTable().children("tfoot").children("tr");
				} else {
					footerCells = grid.footersTable().children("tfoot").children("tr");
					headerCells = grid.headersTable().children("thead").children("tr").not("[data-skip=true]");
				}
				if (isMultiColumnGrid) {
					grid._hideMultiHeaderCells(grid._headerCells, tPos, col.key);
					if (fixed) {
						headerCells = grid.fixedHeadersTable().children("thead").children("tr:not([data-mch-level])").not("[data-skip=true]");
			} else {
						headerCells = grid.headersTable().children("thead").children("tr:not([data-mch-level])").not("[data-skip=true]");
					}
					grid._detachCells(
						headerCells,
						function (row) {
							return row.children("th, td").not("[data-skip=true]");
						},
						position,
						grid._detachedHeaderCells,
						col.key
					);
						} else {
					grid._detachCells(
							headerCells,
							function (row) {
								return row.children("th, td").not("[data-skip=true]");
							},
						position,
						grid._detachedHeaderCells,
						col.key
					);
				}
				grid._detachCells(
					footerCells,
					function (row) { return row.children("td").not("[data-skip=true]"); },
					position,
					grid._detachedFooterCells,
					col.key
				);
			}
		},
		_attachColumn: function (col) {
			if (!this.grid.hasFixedColumns()) {
				this._gridAttachColumnHandler(col);
				return;
						}
			var headerCells, footerCells, fixed = col.fixed,
				grid = this.grid, position = this._getVisibleIndex(col.key, (col.fixed === true), true);

			grid._initializeDetachedContainers();
			if (grid._isMultiColumnGrid) {
				grid._showMultiHeaderCells(col.key);
				if (fixed) {
					headerCells = grid.fixedHeadersTable().children("thead").children("tr:not([data-mch-level])").not("[data-skip=true]");
					footerCells = grid.fixedFootersTable().children("tfoot").children("tr");
				} else {
					headerCells = grid.headersTable().children("thead").children("tr:not([data-mch-level])").not("[data-skip=true]");
					footerCells = grid.footersTable().children("tfoot").children("tr");
					}
				grid._attachCells(
					headerCells,
					function (row) { return row.children("th, td").not("[data-skip=true]"); },
					position,
					grid._detachedHeaderCells,
					col.key
				);
				} else {
				if (fixed) {
					headerCells = grid.fixedHeadersTable().children("thead").children("tr").not("[data-skip=true]");
					footerCells = grid.fixedFootersTable().children("tfoot").children("tr");
				} else {
					headerCells = grid.headersTable().children("thead").children("tr").not("[data-skip=true]");
					footerCells = grid.footersTable().children("tfoot").children("tr");
				}
				grid._attachCells(
					headerCells,
					function (row) { return row.children("th, td").not("[data-skip=true]"); },
					position,
					grid._detachedHeaderCells,
					col.key
				);
			}
			grid._attachCells(
				footerCells,
				function (row) { return row.children("td").not("[data-skip=true]"); },
				position,
				grid._detachedFooterCells,
				col.key
			);
		},
		_renderColgroup: function (table, isHeader, isFooter, autofitLastColumn) {
			this._gridRenderColgroupHandler(table, isHeader, isFooter, autofitLastColumn);
			if (!this.grid.hasFixedColumns()) {
				return;
			}
			//w = parseInt(this.grid.fixedContainer().css('width'), 10)
			this._renderFixedColgroup(isHeader, isFooter, autofitLastColumn);
			//this._deltaWidth = nW - w;
		},
		_rerenderFixedColgroups: function () {
			if (this._containers.header.fixedTable) {
				this._renderFixedColgroup(true, false);
			}
			this._renderFixedColgroup();
			if (this._containers.footer.fixedTable) {
				this._renderFixedColgroup(false, true);
			}
		},
		_renderFixedColgroup: function (isHeader, isFooter) {
			var i, table, colgroup, w, totalWidth = 0,
				cols = this.grid._visibleColumns(true);
			// M.H. 25 Mar 2014 Fix for bug #168158: When autoGenerateColumns is TRUE fixing a column causes a JS error
			if (!this._containers || !this._containers.body) {
				this._populateContainers();
			}
			if (isHeader) {
				table = this._containers.header.fixedTable || this._containers.body.fixedTable;
			} else if (isFooter) {
				table = this._containers.footer.fixedTable || this._containers.body.fixedTable;
							} else {
				table = this._containers.body.fixedTable;
							}
			colgroup = $(table).find('colgroup');
			if (colgroup.length === 0) {
				colgroup = $("<colgroup></colgroup>").prependTo(table);
						}
			colgroup.empty();
			for (i = 0; i < cols.length; i++) {
				if (!cols[i].fixed) {
					continue;
					}
				if (cols[i].oWidth) {
					w = cols[i].oWidth;
				} else {
					w = cols[i].width;
				}
				totalWidth += parseInt(w, 10);
				$("<col></col>").appendTo(colgroup).css("width", w);
			}
			return totalWidth;
		},
		_gridWidthChanged: function () {
			if (!this.grid.hasFixedColumns()) {
				return;
			}
			if (!this._containers || !this._containers.body) {
				this._populateContainers();
			}
			var scrollContainer = this._containers.body.unfixedContainer;
			this.grid._hscrollbar().css({
				width: scrollContainer.width() + 'px',
				left: 0
			});
		},
		_containerResized: function () {
			// when grid container is resized and width is in percentage then we should sync header heights and row heights between fixed and unfixed area
			if (!this.grid.hasFixedColumns()) {
				return;
			}
			var headersTableHeight = this.grid.headersTable().outerHeight(),
				fixedHeadersTableHeight = this.grid.fixedHeadersTable().outerHeight();
			// if offset top of the last row is different between fixed and unfixed area we should sync heights of table rows(in fixed/unfixed tables)
			// we do not check offset of each table row and do not sync heights of all table rows because this could cause performance issue
			if (this._containers && this._containers.body) {
				// M.H. 6 Jan 2014 Fix for bug #160621: By setting a column as fixed, Row height does not auto resize when resizing the column.
				if (Math.abs(this._containers.body.fixedTable.outerHeight() - this._containers.body.unfixedTable.outerHeight()) > 1) {
					this.checkAndSyncHeights();
					this._syncRowsHeights(this._containers.body.unfixedContainer, this._containers.body.fixedContainer);
				}
			}
			// if headers table heights in fixed/unfixed area are different then we should sync table head rows
			if (Math.abs(headersTableHeight - fixedHeadersTableHeight) > 1) {
				this._syncRowsHeights(this.grid.headersTable().find('thead'), this.grid.fixedHeadersTable().find('thead'));
				this.grid._initializeHeights();
			}
		},
		_checkGridSupportedFeatures: function () {
			// Throw an exception for unsupported integration scenarios
			if (this.grid.options._isHierarchicalGrid) {
				throw new Error($.ig.ColumnFixing.locale.hierarchicalGridNotSupported);
			}
			var i, featureName,
				gridOptions = this.grid.options, cols = gridOptions.columns,
				dW = gridOptions.defaultColumnWidth,
				features = gridOptions.features, featuresLength = features.length;
			// M.H. 25 Nov 2014 Fix for bug #185566: ColumnFixing should throw a JavaScript exception that it doesn't support igGrid.width set in %
			if (gridOptions.width === null || gridOptions.width === '' ||
				($.type(gridOptions.width) === 'string' && gridOptions.width.indexOf('%') > 0)) {
				throw new Error($.ig.ColumnFixing.locale.noGridWidthNotSupported);
			}
			// M.H. 3 Dec 2014 Fix for bug #185566: ColumnFixing should throw a JavaScript exception that it doesn't support igGrid.width set in %
			// if defaultColumnWidth is set we should not check for each of the column widths
			if (dW) {
				if ($.type(dW) === 'string' && dW.indexOf('%') > 0) {
					throw new Error($.ig.ColumnFixing.locale.defaultColumnWidthInPercentageNotSupported);
				}
			} else {
				$.each(cols, function (ind, col) {
					var w = col.width;
					if (!w || ($.type(w) === 'string' && w.indexOf('%') > 0)) {
						throw new Error($.ig.ColumnFixing.locale.columnsWidthShouldBeSetInPixels.replace("{key}", col.key));
					}
				});
			}
			//M.K. 1/9/2015 187174: Errors should be thrown when the grid is initialized with unsupported configurations
			$.each(cols, function (ind, col) {
				if (col.unbound) {
					throw new Error($.ig.ColumnFixing.locale.unboundColumnsNotSupported);
				}
			});
			// M.H. 8 Dec 2014 Fix for bug #186237: Row virtualization is not working with Column Fixing
			if (gridOptions.columnVirtualization === true) {
				throw new Error($.ig.ColumnFixing.locale.columnVirtualizationNotSupported);
			}
			if (gridOptions.virtualization && gridOptions.virtualizationMode !== 'continuous') {
				throw new Error($.ig.ColumnFixing.locale.virtualizationNotSupported);
			}
			// There is only one feature defined - ColumnFixing - in the features collection
			if (featuresLength === 1) {
				return;
			}
			for (i = 0; i < featuresLength; i++) {
				featureName = features[i].name;
				if (!featureName) {
					continue;
				}
				featureName = featureName.toLowerCase();
				switch(featureName) {
					case "groupby":
						throw new Error($.ig.ColumnFixing.locale.groupByNotSupported);
					case "responsive":
						throw new Error($.ig.ColumnFixing.locale.responsiveNotSupported);
				}
			}
		},
		_hidingFinishing: function (args) {
			if (!this.grid.hasFixedColumns()) {
				return;
			}
			var i, cols = args.columns;
			// M.H. 19 Feb 2014 Fix for bug #164298: When a column is fixed and other column is hidden showing this column makes some of the rows higher.
			this._applySyncRowHeights = false;
			if (args.hidden) {
				for (i = 0; i < cols.length; i++) {
					this._columnHiding(null, { columnKey: cols[i].key });
				}
			}		  
			//else {
			//	 M.H. 13 Feb 2014 Fix for bug #164298: When a column is fixed and other column is hidden showing this column makes some of the rows higher.
			//	 when showing columns then renderRecords is called. In that case colgroup is not re-rendered although the new TDs are rendered inside the table rows which causes in some cases the grid rows to enlarge heights
			//	 to fix the problem we re-set hidden properties and then reRenderColgroups
			//	for (i = 0; i < cols.length; i++) {
			//		cols[i].hidden = false;
			//	}
			//	this.grid._visibleColumnsArray = undefined;
			//	this.grid._rerenderColgroups();
			//}
		},
		_hidingFinished: function (args) {
			var i, cols = args.columns, $fixedTable;

			if (args.hidden) {
				for (i = 0; i < cols.length; i++) {
					this._columnHidden(null, { columnKey: cols[i].key });
				}
			} else {
				for (i = 0; i < cols.length; i++) {
					this._columnShown(null, { columnKey: cols[i].key });
				}
			}
			// sync heights
			if (this.grid.hasFixedColumns() && this.options.syncRowHeights && this._applySyncRowHeights === false) {
				$fixedTable = this.grid.fixedTable();
				this._syncFixedHeights($fixedTable, this.grid.element);
				// M.H. 8 June 2015 Fix for bug 194635: When column fixing and summaries are enabled the fixed and unfixed area don't have the same height.
				this._syncRowsHeights(this.grid.footersTable().find('tfoot'),
						this.grid.fixedFootersTable().find('tfoot'));
				
			}
			this._checkAndRenderHScrlbarCntnr();
			// M.H. 19 Feb 2014 Fix for bug #164298: When a column is fixed and other column is hidden showing this column makes some of the rows higher.
			this._applySyncRowHeights = true;
		},
		//Hiding events
		_columnShown: function (event, ui) {
			/* If autoFitLastColumn is TRUE and we show fixed column then: 
			1. the width of fixed area should be increased(the width of the shown column)
			2. on the other hand the unfixed area should be decreased.
			*/
			var i, w, columnKey = ui.columnKey, cols = this.grid.options.columns, colsLength = cols.length, col;
			for (i = 0; i < colsLength; i++) {
				col = cols[i];
				if (col.key === columnKey) {
					break;
				}
			}
			if (!col) {
				return;
			}
			if (col.fixed) {
				w = parseInt(col.width, 10);
				this._updateSingleContainerWidth(w, true);
				if (this.grid.options.autofitLastColumn) {
					this._updateSingleContainerWidth(-w, false);
					// in case of autofitlastcolumn then we should re-render the colgroups so that columns have correct widths.
					this.grid._rerenderColgroups();
					this.grid._adjustLastColumnWidth(false);
				}
			}
			this._populateContainers();
			this._updateHScrollbarWidth();
			this.grid._columnMovingResets();
			this._checkAndRenderHScrlbarCntnr();
		},
		_columnHiding: function (event, ui) {
			// there are cases when hiding fixed column could cause misalignment because fixed part will be with another width(different then after hiding is finished)
			// rows height should be calculated according to the actual(after hiding is applied) width
			var w, columnKey = ui.columnKey, col = this.grid.columnByKey(columnKey);

			if (!col) {
				return;
			}
			if (col.fixed && col.width) {
				w = parseInt(col.width, 10);
				this._updateSingleContainerWidth(-w, true);
			}
		},
		_columnHidden: function (event, ui) {
			var i, w, columnKey = ui.columnKey, cols = this.grid.options.columns, colsLength = cols.length, col;
			for (i = 0; i < colsLength; i++) {
				col = cols[i];
				if (col.key === columnKey) {
					break;
				}
			}
			if (!col) {
				return;
			}
			if (col.fixed) {
				w = parseInt(col.width, 10);
				//this._updateSingleContainerWidth(-w, true);
				if (this.grid.options.autofitLastColumn) {
					this._updateSingleContainerWidth(w, false);
					this.grid._rerenderColgroups();
					this.grid._adjustLastColumnWidth(true);
				}
			} else {
				if (this.grid.options.autofitLastColumn) {
					this.grid._rerenderColgroups();
					this.grid._adjustLastColumnWidth(true);
				}
			}
			this._populateContainers();
			this._updateHScrollbarWidth();
		},
		_virtualrecordsrender: function () {
			var grid = this.grid, fnRemoveHeigths, h, $fixedTable, $unfixedTable;
			if (!grid.hasFixedColumns()) {
				return;
			}
			$fixedTable = this._containers.body.fixedTable;
			$unfixedTable = this._containers.body.unfixedTable;
			h = $unfixedTable[0].style.height;
			// M.H. 29 Sep 2014 Fix for bug #179959: When there is a fixed column, fixed virtualization is enabled and rows have different heights scrolling the grid changes the height of the scroll container.
			if (!$.ig.util.isChrome) {
				$fixedTable.height('');
				$unfixedTable.height('');
			}
			if (this._isContinuousVirtualization()) {
				if (this.options.syncRowHeights) {
					this.checkAndSyncHeights();
				}
				return;
			}
			fnRemoveHeigths = function ($rows) {
				$rows.each(function (ind, row) {
					row.style.height = '';
				});
			};
			fnRemoveHeigths($unfixedTable.find('tr'));
			fnRemoveHeigths($fixedTable.find('tr'));
			this._syncRowsHeights($unfixedTable, $fixedTable);
			// M.H. 29 Sep 2014 Fix for bug #179959: When there is a fixed column, fixed virtualization is enabled and rows have different heights scrolling the grid changes the height of the scroll container.
			if (!$.ig.util.isChrome) {
				$fixedTable.height(h);
				$unfixedTable.height(h);
			}
			//fnResetHeights($fixedTable, $unfixedTable);
		},
		_rearrangeOldColsByColumnKey: function (colKey, isToFix, target, after) {
			if (!this.grid._isMultiColumnGrid) {
				return;
			}
			var grid = this.grid, at, targetCol, currCol;
			if (!target) {
				if (isToFix || this.options.fixingDirection === 'right') {
					at = this._getColumnsByState(isToFix).length;
				} else {
					at = 0;
				}
				grid._rearrangeArray(grid._oldCols, this._getColumnByKey(colKey).index, 1, at);
				return;
			}
			currCol = this._getColumnByKey(colKey);
			targetCol = this._getColumnByKey(target);
			if (!currCol || !targetCol) {
				return;
			}
			at = targetCol.index;
			if (after) {
				at++;
			}
			grid._rearrangeArray(grid._oldCols, currCol.index, 1, at);
		},
		_getColumnByKey: function (id, cols) {
			// if id is specified searches for a column with the specified id - the result is object containing 2 properties - column and index in the collection
			// if cols is not specified it is taken this.grid._oldCols - array of MCH column
			var oCols = cols || this.grid._oldCols, i;
			for (i = 0; i < oCols.length; i++) {
				if (oCols[i].key === id || oCols[i].identifier === id) {
					return { column: oCols[i], index: i };
				}
			}
			return null;
		},
		_getColumnsByState: function (fixed, cols) {
			// fixed specifies which columns to search - fixed/unfixed columns
			// if cols is not specified search is applied for this.grid._oldCols - array of MCH column
			var oCols = cols || this.grid._oldCols, i, res = [];
			for (i = 0; i < oCols.length; i++) {
				if (!!oCols[i].fixed === fixed) {
					res.push(oCols[i]);
				}
			}
			return res;
		},
		_analyzeTargetIndexes: function (target, after, fixed) {
			// determines target visible index and target data column index(of the grid options columns collections)
			var grid = this.grid, targetCol, targetMCHColumn,
				children, child,
				res = {indexAt: 0, columnIndexAt: 0};
			if (_aNull(target)) {
				return false;
			}
			if (!grid._isMultiColumnGrid) {
				targetCol = this.grid.columnByKey(target);
			} else {
				targetMCHColumn = this._getColumnByKey(target);
				if (!targetMCHColumn) {
					return false;
				}
				targetCol = targetMCHColumn.column;
			}
			if (!targetCol || (!!targetCol.fixed) !== fixed) {
				return false;
			}
			if (!targetMCHColumn || !targetCol.group) {
				res.indexAt = this._getVisibleIndex(targetCol.key, fixed);
				res.columnIndexAt = this._getColumnByKey(target, grid.options.columns).index;
				if (after) {
					res.indexAt++;
					res.columnIndexAt++;
				}
			} else {
				children = targetCol.children;
				if (after) {
					child = children[children.length - 1];
					res.indexAt = this._getVisibleIndex(child.key, fixed) + 1;
					res.columnIndexAt = this._getColumnByKey(child.key, grid.options.columns).index + 1;
				} else {
					child = children[0];
					res.indexAt = this._getVisibleIndex(child.key, fixed);
					res.columnIndexAt = this._getColumnByKey(child.key, grid.options.columns).index;
				}
			}
			return res;
		},
		_unregisterSetOptionCallback: function () {
			var callbacks = this.grid._setOptionCallbacks, i, len = callbacks.length;
			for (i = 0; i < len; i++) {
				if (callbacks[i].type === 'ColumnFixing') {
					$.ig.removeFromArray(callbacks, i);
					break;
				}
			}
		},
		_registerSetOptionCallback: function () {
			var callbacks = this.grid._setOptionCallbacks, i, len = callbacks.length;
			for (i = 0; i < len; i++) {
				if (callbacks[i].type === 'ColumnFixing') {
					break;
				}
			}
			if (i === len) {
				callbacks.push({
					type: "ColumnFixing",
					func: $.proxy(this._gridSetOption, this)
				});
			}
		},
		_injectGrid: function (gridInstance, isRebind) {
			this.grid = gridInstance;
			if (!isRebind) {
				// M.H. 9 Sep 2013 Fix for bug #144030: When no width and height are set, and columnFixing is enabled, no descriptive error is thrown
				this._checkGridSupportedFeatures();
				this._registerSetOptionCallback();
			}
			// M.H. 28 May 2014 Fix for bug #172200: Memory leak when using the features of the grid
			this._detachEvents();
			this._headerCellRenderedHandler = $.proxy(this._headerCellRendered, this);
			this.grid.element.bind('iggridheadercellrendered', this._headerCellRenderedHandler);
			this._headerRenderedHandler = $.proxy(this._headerRendered, this);
			this.grid.element.bind('iggridheaderrendered', this._headerRenderedHandler);
			this._headerRenderingHandler = $.proxy(this._headerRendering, this);
			this.grid.element.bind('iggridheaderrendering', this._headerRenderingHandler);
			this._columnsMovedHandler = $.proxy(this._columnsMoved, this);
			this.grid.element.bind('iggrid_columnsmoved', this._columnsMovedHandler);
			if (this._isVirtualGrid() && this.options.syncRowHeights) {
				this._virtualrecordsrenderHandler = $.proxy(this._virtualrecordsrender, this);
				this.grid.element.bind('iggridvirtualrecordsrender', this._virtualrecordsrenderHandler);
			}
			// M.H. 11 Mar 2015 Fix for bug 187746: When row selectors and column fixing are enabled adding a new row makes the rows misaligned.
			this._editRowEndedHandler = $.proxy(this._editRowEnded, this);
			this.grid.element.bind('iggridupdating_editrowended', this._editRowEndedHandler);
			// we should re-render main fixed container when grid changes its height
			//if (this.grid.options.height !== null) {
			this._gridContainerHeightHandler = $.proxy(this._heightChanged, this);
			this.grid.element.bind("iggrid_heightchanged", this._gridContainerHeightHandler);
			// M.H. 7 Mar 2014 Fix for bug #147490: The "Search Result" span is relocated when column is fixed and you filter the grid in Chrome.
			this._gridHeightChangingHandler = $.proxy(this._gridHeightChanging, this);
			this.grid.element.bind("iggrid_heightchanging", this._gridHeightChangingHandler);
			//}
			if (this.grid._columns === undefined || this.grid._columns === null) {
				this.grid._columns = this.grid.options.columns.clone();
			}
			// M.H. 24 Jul 2013 Fix for bug #143633: If you call dataBind method while you have fixed columns the grid becomes misaligned after you scroll it horizontally.
			// we should not reset fixedColumns array - for instance on rebind(in this case isRebind is true) we should preserve _fixedColumns array
			if (this.grid._fixedColumns === undefined) {
				this.grid._fixedColumns = [];
			}
			// M.H. 18 Sep 2013 Fix for bug #152468: The fixed and unfixed areas are misalinged when there are cells with text spanned on two rows and the grid doesn't have height in IE9.
			if (this.grid.options.height === null &&
					$.ig.util.isIE && $.ig.util.browserVersion >= 9) {
				this._dataRenderingHandler = $.proxy(this._dataRendering, this);
				this.grid.element.bind('iggriddatarendering', this._dataRenderingHandler);
			}
			this._dataRenderedHandler = $.proxy(this._dataRendered, this);
			this.grid.element.bind('iggriddatarendered', this._dataRenderedHandler);
			// override functions
			if (!this._isFunctionsOverriden) {
				this.grid._visibleAreaWidth(this.options.minimalVisibleAreaWidth);
				this._gridRenderRowHandler = $.proxy(this.grid._renderRow, this.grid);
				this._renderRowHandler = $.proxy(this._renderRow, this);
				this.grid._renderRow = this._renderRowHandler;

				this._gridRenderRecordsHandler = $.proxy(this.grid._renderRecords, this.grid);
				this._renderRecordsHandler = $.proxy(this._renderRecords, this);
				this.grid._renderRecords = this._renderRecordsHandler;

				this._gridRenderNewRowHandler = $.proxy(this.grid.renderNewRow, this.grid);
				this._renderNewRowHandler = $.proxy(this._renderNewRow, this);
				this.grid.renderNewRow = this._renderNewRowHandler;
				//override detach/attach cells
				this._gridDetachColumnHandler = $.proxy(this.grid._detachColumn, this.grid);
				this._detachColumnHandler = $.proxy(this._detachColumn, this);
				this.grid._detachColumn = this._detachColumnHandler;
				this._gridAttachColumnHandler = $.proxy(this.grid._attachColumn, this.grid);
				this._attachColumnHandler = $.proxy(this._attachColumn, this);
				this.grid._attachColumn = this._attachColumnHandler;

				this._gridRenderColgroupHandler = $.proxy(this.grid._renderColgroup, this.grid);
				this._renderColgroupHandler = $.proxy(this._renderColgroup, this);
				this.grid._renderColgroup = this._renderColgroupHandler;

				this._gridUpdatePaddingHandler = $.proxy(this.grid._updateVScrollbarCellPaddingHelper, this.grid);
				this._updateVScrollbarCellPaddingHelperHandler = $.proxy(this._updateVScrollbarCellPaddingHelper, this);
				this.grid._updateVScrollbarCellPaddingHelper = this._updateVScrollbarCellPaddingHelperHandler;
				this._isFunctionsOverriden = true;
			}
		}
	});

	$.extend($.ui.igGridColumnFixing, {version: '15.1.20151.2352'});
}(jQuery));
/*jshint +W018 */