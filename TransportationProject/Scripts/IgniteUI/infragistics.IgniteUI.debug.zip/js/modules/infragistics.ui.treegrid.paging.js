﻿
/*!@license
 * Infragistics.Web.ClientUI Tree Grid 15.1.20151.2352
 *
 * Copyright (c) 2011-2015 Infragistics Inc.
 *
 * http://www.infragistics.com/
 *
 * Depends on:
 *	jquery-1.4.4.js
 *	jquery.ui.core.js
 *	jquery.ui.widget.js
 *	infragistics.dataSource.js
 *	infragistics.ui.shared.js
 *	infragistics.ui.treegrid.js
 *	infragistics.util.js
 *	infragistics.ui.grid.framework.js
 *	infragistics.ui.grid.paging.js
 */

/*global jQuery */
if (typeof jQuery !== "function") {
	throw new Error("jQuery is undefined");
}
(function ($) {
	/*
		igTreeGridPaging widget. The widget is pluggable to the element where the treegrid is instantiated and the actual igTreeGrid object doesn't know about this
		the filtering widget just attaches its functionality to the treegrid
		igTreeGridPaging is extending igGrid Paging
	*/
	$.widget("ui.igTreeGridPaging", $.ui.igGridPaging, {
		css: {},
		options: {
			/* type="rootLevelOnly|allLevels" Sets gets paging mode.
			rootLevelOnly type="string" Only pages records at the root of the tree grid are displayed.
			allLevels type="string" includes all visible records in paging.*/
			mode: "rootLevelOnly"
		},
		_create: function () {
			this.element.data($.ui.igGridPaging.prototype.widgetName, this.element.data($.ui.igTreeGridPaging.prototype.widgetName));
			$.ui.igGridPaging.prototype._create.apply(this, arguments);
		},
		// M.H. 26 June 2015 Fix for bug 201835: When filtering and paging are enabled for TreeGrid and filter and after that change the page pager label is not correct
		_getDSLocalRecordsCount: function () {
			// override _getDataSourceRecordsCount(from grid.paging)
			if (this.grid.dataSource._filter && this.options.mode === 'allLevels') {
				return this.grid.dataSource.totalLocalRecordsCount();
			}
			return $.ui.igGridPaging.prototype._getDSLocalRecordsCount.apply(this, arguments);
		},
		destroy: function () {
			$.ui.igGridPaging.prototype.destroy.apply(this, arguments);
			this.element.removeData($.ui.igGridPaging.prototype.widgetName);
		},
		_injectGrid: function () {
			var ds;
			$.ui.igGridPaging.prototype._injectGrid.apply(this, arguments);
			ds = this.grid.dataSource;
			if (ds && ds.settings && ds.settings.treeDS) {
				ds.settings.treeDS.paging.mode = this.options.mode;
			}

		}

	});
	$.extend($.ui.igTreeGridPaging, { version: "15.1.20151.2352" });
}(jQuery));


