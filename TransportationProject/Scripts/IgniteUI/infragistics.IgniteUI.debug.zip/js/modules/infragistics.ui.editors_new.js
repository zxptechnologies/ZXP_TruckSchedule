﻿
/*!@license
 * Infragistics.Web.ClientUI CountDown 15.1.20151.2352
 *
 * Copyright (c) 2011-2015 Infragistics Inc.
 *
 * http://www.infragistics.com/
 *
 * Depends on:
 *  jquery-2.1.1.js
 *	jquery.ui.core.js
 *	jquery.ui.widget.js
 */

/*global jQuery */
if (typeof jQuery !== "function") {
	throw new Error("jQuery is undefined");
}

(function ($) {
    /*
		igBaseEditor is a widget based on jQuery UI.
        
	*/
    $.widget('ui.igBaseEditor', {

        options: {
        	/* igWidget options go here */
        	/* type="string|number|null Gets sets how the width of the control can be set."
                string The widget width can be set in pixels (px) and percentage (%).
                number The widget width can be set as a number in pixels.
                null type="object" will stretch to fit data, if no other widths are defined.
            */
        	width: null,
        	/* type="string|number|null Gets sets how the height of the control can be set."
                string The height width can be set in pixels (px) and percentage (%).
                number The height width can be set as a number in pixels.
                null type="object" will fit the tree inside its parent container, if no other widths are defined.
            */
        	height: null,
        	/* type="object" Gets sets value in editor. The effect of setting/getting that option depends on type of editor and on dataMode options. That can be string, number or Date depending on type of editor. If it is used on initialization and the type option is missing, then if 'value' is Number, then 'numeric' editor is created automatically and if 'value' is Date, then the 'date' editor is created. */
        	value: null,
        	/* type="number" Gets sets value in tabIndex for editor.  */
        	tabIndex: null,
        	inputName: null

        },
        css: {
        	/* Class applied to the main/top element. Default value is 'ui-igedit ui-state-default ui-widget' */
        	editor: 'ui-state-default ui-widget ui-igedit-input',
        	/* Class applied to the top element when editor is rendered in container. Default value is 'ui-igedit-container' */
        	container: 'ui-igedit-container ui-state-default',
        	hover: "ui-state-hover",
        	active: "ui-state-active",
        	focus: "ui-state-focus"
        },
		events: {
			/* igWidget events go here */
			rendering: "rendering",
			rendered: "rendered",
			mousedown: "mousedown",
			mouseup: "mouseup",
			mousemove: "mousemove",
			mouseover: "mouseover",
			mouseout: "mouseout",
			blur: "blur",
			focus: "focus",
			valueChanging: "valueChanging",
			valueChanged: "valueChanged"

		},
		inputName: function (val) {
			if (val) {
				this._valueInput.attr("name", val);
				this.options.inputName = val;
			} else {
				return this.options.inputName;
			}
		},
		value: function (val) {
			if (val) {
				if (this._validateValue(val)) {
					this._updateValue(val);
					this._editorInput.val(this._getDisplayValue());
				} else {
					this._clearValue();
				}
			} else {
				return this.options.value;
			}
		},
		editorInput: function () {
			return this._editorInput;
		},
        _create: function () {
        	/* igWidget constructor goes here */
        	this._render();
        	this._attachEvents();
        },
        _render: function () {
        	throw ("It's not allowed to instantiate base editor. Please instantiate strong typed editor");
        },
        _attachEvents: function () {
        	var self = this;
        	this._editorContainer.on({
        		"mousedown": function (event) {
        			self._triggerMouseDown(event);
        		},
        		"mouseup": function () {

        			self._triggerMouseUp(event);
        		},
        		"mousemove": function (event) {
        			self._triggerMouseMove(event);
        		},
        		"mouseover": function (event) {
        			self._triggerMouseOver(event);
        		},
        		"mouseout": function (event) {
        			self._triggerMouseOut(event);
        		}        		
        	});
        },
        _triggerRendering: function () {
        	var args = {
        		element: this.element
        	};
        	return this._trigger(this.events.rendering, null, args);
        },
        _triggerRendered: function () {
        	var args = {
        		element: this.element
        	};
        	this._trigger(this.events.rendered, null, args);
        },
        _triggerMouseMove: function (event) {
        	var args = {
        		owner: this._editorContainer,
        		element: event.target,
        		editorInput: this._editorInput
        	};
        	this._trigger(this.events.mousemove, event, args);
        },
        _triggerMouseDown: function (event) {
        	this._editorContainer.addClass(this.css.active);
        	var args = {
        		owner: this._editorContainer,
        		element: event.target,
				editorInput: this._editorInput
        	};
        	return this._trigger(this.events.mousedown, event, args);
        },
        _triggerMouseUp: function (event) {
        	this._editorContainer.removeClass(this.css.active);
        	var args = {
        		owner: this._editorContainer,
        		element: event.target,
        		editorInput: this._editorInput
        	};
        	this._trigger(this.events.mouseup, event, args);
        },
        _triggerMouseOver: function (event) {
        	this._editorContainer.addClass(this.css.hover);
        	var args = {
        		originalEvent: event,
        		owner: this._editorContainer,
        		element: event.target,
        		editorInput: this._editorInput
        	};
        	this._trigger(this.events.mouseover, event, args);
        },
    	_triggerMouseOut:function () {
    		this._editorContainer.removeClass(this.css.hover);
        	var args = {
        		originalEvent: event,
        		owner: this._editorContainer,
        		element: event.target,
        		editorInput: this._editorInput
        	};
        	this._trigger(this.events.mouseout, event, args);
    	},
    	_triggerFocus: function (event) {
    		this._editorInput.addClass(this.css.focus);
    		var args = {
    			originalEvent: event,
    			owner: this._editorContainer,
    			element: event.target,
    			editorInput: this._editorInput
    		};
    		this._trigger(this.events.focus, event, args);
    	},
    	_triggerBlur: function (event) {
    		this._editorInput.removeClass(this.css.focus);
    		var args = {
    			owner: this._editorContainer,
    			element: event.target,
    			editorInput: this._editorInput
    		};
    		this._trigger(this.events.blur, event, args);
    	},
        _setOption: function (option, value) {
			/* igWidget custom setOption goes here */
			var prevValue = this.options[option];
			if (prevValue === value) {
				return;
			}
			// The following line applies the option value to the igWidget meaning you don't
			// have to perform this.options[option] = value;
			$.Widget.prototype._setOption.apply(this, arguments);
			switch (option) {
			    case "value":
			    	if (this._validateValue(value)) {
			    		this._updateValue(value);
			    		this._editorInput.val(this._getDisplayValue());
			    	} else {
			    		this._clearValue();
			    	}
			        break;
			    default:
			        break;
			}
        },
        _validateValue: function (val) {
        	return val ? true : false;
        },
        _updateValue: function (value) {
        	this.options.value = value;
        	this._editorInput.val(value);
        	this._valueInput.val(value);
        },
		//THis method sets the value to null, or 9 depending on the nullable option.
        _clearValue: function () {
			//TODO use null, or 0 depending on the nullable option
        	if (this.options.allowNullValue) {
        		this._valueInput.val(this.options.nullValue);
        	} else {
        		this._valueInput.val(0);
        	}
        	this._editorInput.val(this._getDisplayValue());
        },
        _detachEvents: function () {
        	/*https://css-tricks.com/namespaced-events-jquery/
			this._editorContainer
				.off("mousedown.editor")
				.off("mouseup.editor")
				.off("mousemove.editor")
				.off("mouseover.editor")
        		.off("mouseout.editor");
				
			//or just
			this._editorContainer.off(".editor");
			this._editorInput.off(".editor");
			*/
        },
        _clearDOM: function () {
        	if (this._valueInput) {
        		this._valueInput.empty();
        	}
        	this.element.empty();
        },
        _clearStyling: function() {
        	this._editorContainer.removeClass(this.css.container);
        	this._editorInput.removeClass(this.css.editor);
        },
        _deleteInternalProperties: function () {
        	delete this._editorInput;
        	delete this._editorContainer;
        	if (this._valueInput) {
        		delete this._valueInput;
        	}
        },
        destroy: function () {
        	this._detachEvents();
        	this._clearDOM();
        	this._clearStyling();
        	this._deleteInternalProperties();
        	delete this.options;
        	$.Widget.prototype.destroy.apply(this, arguments);
        	return this;
        }
    });
    $.extend($.ui.igBaseEditor, { version: '15.1.20151.2352' });
    $.widget('ui.igTextEditor', $.ui.igBaseEditor, {
    	options: {

    		/* type="dropdown|clear|spin" Sets gets visibility of spin and drop-down button. That option can be set only on initialization. Combinations like 'dropdown,spin' or 'spinclear' are supported too.
				dropdown type="string" button to open list is located on the right side of input-field (or left side if base html element has direction:rtl);
				clear type="string" button to clear value is located on the right side of input-field (or left side if base html element has direction:rtl);
				spin type="string" spin buttons are located on the right side of input-field (or left side if base html element has direction:rtl).
			*/
    		button: 'none',
    		/* type="array" Sets gets list of items which are used for drop-down list, spin, validation and auto-complete functionality.
				Items in list can be strings, numbers, dates or objects in any combination.
				If type of editor is date or datepicker and item is string, then igEditor will try to convert it to Date object and show item in display format.
				If type of editor is numeric, currency or percent and item is string, then igEditor will try to convert it to number and show item in display format.
				If item is object and it has member "text", then that member is used.
				If item is object and besides "text" has function getHtml(), then that function is used to render item in list.
				The item or item.text is used to set "value" of particular editor when list-item is selected. */
    		listItems: null,
    		/* type="number" Sets gets custom width of drop-down list in pixels. If value is equal to 0 or negative, then the width of editor is used. */
    		listWidth: 0,
    		/* type="number" Sets gets maximum height of drop-down list in pixels. If value is equal to 0 or negative, then the height of list is defined by number of items in list. */
    		dropDownMaxHeight: 300,
    		listItemHoverDuration: 0,
    		dropDownAnimationType: null,
    		dropDownAnimationDuration: 400,
    		/* type="string" Sets gets ability to enter only specific characters in input-field from keyboard and on paste.
				Notes:
				If "excludeKeys" option contains same characters as this option, then "excludeKeys" has priority.
				Letters should be set in upper case.
				Making difference between upper and lower case is not supported. */
    		includeKeys: null,
    		/* type="string" Sets gets ability to prevent entering specific characters from keyboard or on paste.
				Notes:
				If a character is specified in "includeKeys" option also, then "excludeKeys" has priority.
				Letters should be set in upper case.
				Making difference between upper and lower case is not supported. */
    		excludeKeys: null,
    			/* type="left|right|center" Sets gets horizontal alignment of text in editor. If that option is not set, then 'right' is used for 'numeric', 'currency' and 'percent' editors and the 'left' is used for all other types of editor.
					left type="string"
					right type="string"
					center type="string"
				*/
    		textAlign: "left",
    	},
    	css: {
    		/* igWidget element classes go here */
    		
    		buttonsArea: 'ui-igeditor-button-area',
    		spinButtonUpImage: "ui-igedit-spinupperimage ui-icon-carat-1-n ui-icon",
    		spinButtonDownImage: "ui-igedit-spinlowerimage ui-icon-carat-1-s ui-icon",
    		spinButtonsArea: "ui-igedit-spinarea ui-igedit-button ui-igedit-buttondefault ui-state-default",
			dropDownImage: "ui-igedit-dropdown ui-icon ui-icon-carat-1-s",
			buttonClear: "ui-igedit-buttonimage ui-icon-circle-close ui-icon ui-igedit-buttondefault",
			buttonClearArea: "ui-igedit-cleararea  ui-state-default",
			list: 'ui-igedit-list ui-widget ui-widget-content ui-corner-all',
    		/* Class applied to the SPAN element which represents item in dropdown list. Default value is 'ui-igedit-listitem ui-state-default' */
			listItem: 'ui-igedit-listitem ui-state-default',
    		/* Class applied to the Class applied to the SPAN element which represents item in dropdown list with mouse-over state. Default value is 'ui-igedit-listitemhover ui-state-hover' */
			listItemHover: 'ui-igedit-listitemhover ui-state-hover',
    		/* Class applied to the Class applied to the SPAN element which represents selected item in dropdown list. Default value is 'ui-igedit-listitemselected ui-state-highlight' */
			listItemSelected: 'ui-igedit-listitemselected ui-state-highlight',
    		/* Classes applied to the SPAN element of button in mouse-over state. Default value is 'ui-igedit-buttonhover ui-state-hover' */
			buttonHover: 'ui-igedit-buttonhover ui-state-hover',
    		/* Classes applied to the SPAN element of button in pressed state. Default value is 'ui-igedit-buttonpressed ui-state-highlight' */
			buttonPressed: 'ui-igedit-buttonpressed ui-state-highlight',
    	},
    	events: {
    		/* igWidget events go here */
    		//Key Events			
    		/* cancel="true" Event which is raised on keydown event.
				Return false in order to cancel key action.
				Function takes arguments evt and ui.
				Use evt.originalEvent to obtain reference to event of browser.
				Use ui.owner to obtain reference to igEditor.
				Use ui.key to obtain value of keyCode. */
    		keydown: "keydown",
    		/* cancel="true" Event which is raised on keypress event.
				Return false in order to cancel key action.
				Function takes arguments evt and ui.
				Use evt.originalEvent to obtain reference to event of browser.
				Use ui.owner to obtain reference to igEditor.
				Use ui.key to obtain value of keyCode.
				Set ui.key to another character which will replace original entry. */
    		keypress: "keypress",
    		/* Event which is raised on keyup event.
				Function takes arguments evt and ui.
				Use evt.originalEvent to obtain reference to event of browser.
				Use ui.owner to obtain reference to igEditor.
				Use ui.key to obtain value of keyCode. */
    		keyup: "keyup",
    		dropDownListOpening: "dropDownListOpening",
    		dropDownListOpened: "dropDownListOpening",
    		dropDownListClosing: "dropDownListClosing",
    		dropDownListClosed: "dropDownListClosed",
    		dropDownItemSelecting: "dropDownItemSelecting",
    		dropDownItemSelected: "dropDownItemSelected"

    	},
    	_create: function () {
    		$.ui.igBaseEditor.prototype._create.call(this);
    		this._applyOptions();
    	},
    	_applyOptions: function () {
    		if (this.options.inputName) {
    			//set the name attribute to the hidden input.
    			this._valueInput.attr("name", this.options.inputName);
    		} else {
    			//If missing name we need to generate it somehow
    		}
    		if (this.options.includeKeys) {
    			this._includeKeysArray = this.options.includeKeys.toString().split("");
    		}
    		if (this.options.excludeKeys) {
    			this._excludeKeysArray = this.options.excludeKeys.toString().split("");
    		}
    		if (this.options.tabIndex) {
    			this._valueInput.attr("tabindex", this.options.tabIndex);
    		}
    	},
    	_render: function () {
			//We asume the base renderer has already been invoked
    		//Call base renderer
    		var inputWidth;
    		this._triggerRendering();
    		if (this.element.is("div")) {
    			var editorElement = $("<input type='text' />");

    			this._editorInput = editorElement;
    			this._editorContainer = this.element;
    			this._editorContainer.prepend(editorElement);
    		} else if (this.element.is("input")) {

    			this._editorContainer = this.element.wrap($("<div></div>")).parent();
    			this._editorInput = this.element;
    		} else {
    			//TODO Throw target element not supported. 
    		}
    		this._editorContainer.addClass(this.css.container);
    		this._editorInput.addClass(this.css.editor);
    		this._editorInput.css("height", "100%");
    		

    		//Set input type to text
    		this._editorInput.attr("type", "text");

    		if (this.options.button && this.options.button !== "none") {
    			this._renderButtons();
    		}
    		if (this.options.width) {
    			this._editorContainer.css("width", this.options.width);
    		}
    		if (this.options.height) {
    			this._editorContainer.css("height", this.options.height);
    		}

    		this._valueInput = $("<input type='hidden'></input>");
    		this._editorInput.after(this._valueInput);
    		this._editorInput.css("text-align", this.options.textAlign);
    		this._valueInput.css("text-align", this.options.textAlign);
    		if (this.options.value && this._validateValue(this.options.value)) {
    			this._updateValue(this.options.value);
    			this._editorInput.val(this._getDisplayValue());
    		}
    		var buttonsAreaWidth = this._getButtonsAreaWidth();
    		buttonsAreaWidth += "px";
    		if ($.ig.util.isIE8) {
				//TODO use window resize to implement this.
    			var containerWidth = parseFloat(this._editorContainer.css("width")), butsWidth = parseFloat(this._buttonsArea.css("width"));
    			var s = (containerWidth - butsWidth);
    				
    			var s1 = containerWidth / 100;
    			var res = parseFloat(s / s1);
    			inputWidth = res + "%";    				
    			this._editorInput.css("width", inputWidth);
    		} else {
    			inputWidth = "calc(100% - " + buttonsAreaWidth + ")";
    			this._editorInput.css("width", inputWidth);
    		}
    		if (this.options.listItems && this.options.listItems.length > 0) {
    			this._renderList();
    			this._positionDropDownList();
    			this._attachListEvents();
    		}
    		this._triggerRendered();
    	},
    	_positionDropDownList: function () {
    		var containerLeft, containerHeight, containerOffset = this._editorContainer.offset(),
    		containerTop = containerOffset.top;
    		containerLeft = containerOffset.left;
    		containerHeight = parseFloat(this._editorContainer.css("height"));
    		this._dropDownList.css("left", containerLeft);
    		this._dropDownList.css("top", containerTop + containerHeight);

    	},
    	_renderList: function () {
    		var i, list = this.options.listItems;
    		var dropdown = $("<div></div>)").css({ position: 'absolute', overflowX: "hidden", overflowY: "scroll" }).addClass(this.css.list);
    		dropdown.hide();
    		dropdown.visible = false;
    		for (i = 0; i < list.length; i++) {
    			$("<span></span>").addClass(this.css.listItem).append(list[i]).appendTo(dropdown);
    		}

    		this._editorContainer.append(dropdown);
    		if (this.options.listWidth && this.options.listWidth > 0) {
    			dropdown.css("width", this.options.listWidth);
    		} else {
    			dropdown.css("width", this._editorContainer.css("width"));
    		}
    		if (this.options.dropDownMaxHeight && this.options.dropDownMaxHeight > 0) {
    			dropdown.css("height", this.options.dropDownMaxHeight);
    		}
    		this._dropDownList = dropdown;
			//TODO Remove this handler. Test purpose only
    		this._dropDownList.scroll(function () {
    			console.log("Scrolling");
    		});
    	},
    	_attachListEvents: function () {
    		var list = this._dropDownList, self = this;
    		list.delegate(".ui-igedit-listitem", {
    			"mouseover": function (event) {
    				self._triggerListItemMouseOver(event);
    			},
    			"mouseout": function (event) {
    				self._triggerListItemMouseOut(event);
    			},
    			"click": function (event) {
    				self._triggerListItemClick(event);
    			}
    		});
    		if ($.ig.util.isIE) {
    			list.on("mousedown", function () {
    				//var elem = event.target;
					//Under IE clicking the scrollbar fires blur on the input we 
    			
    					self._cancelBlurOnInput = true;
    					//event.preventDefault();  //prevent default DOM action
    					//event.stopPropagation();   //stop bubbling
    					//self._editorInput.focus();
    					//return false;   // return
    					
    					//self._cancelBlurOnInput = true;
    			
    			});
    		}
    	},
    	_renderButtons: function () {
    		//We need to check if there are any wrong parameters into the property
    		var buttons = this.options.button.toString().split(","), i, notSupportedIndex = 0, buttonsArea = $("<span></span>"), spinButtonUp = $("<span></span>"), spinButtonDown = $("<span></span>"), self = this,
				dropDownButton = $("<span></span>"), spinArea = $("<span></span>"), buttonClearArea = $("<span></span>"), buttonClear = $("<span></span>");
    		buttonsArea.addClass(this.css.buttonsArea);
    		for (i = 0; i < buttons.length; i++) {
    			switch (buttons[i]) {
    				case "spin": {
    					spinArea.addClass(this.css.spinButtonsArea).append(spinButtonUp.addClass(this.css.spinButtonUpImage)).append(spinButtonDown.addClass(this.css.spinButtonDownImage));   					
    					buttonsArea.append(spinArea);
    				}
    					break;
    				case "dropdown": {
						/* jshint -W083*/
    					buttonsArea.append(dropDownButton.addClass(this.css.dropDownImage));
    					dropDownButton.on({
    						"mouseover": function (event) {
    							self._triggerButtonMouseOver(event, "dropdown");
    						},
    						"mouseout": function (event) {
    							self._triggerButtonMouseOut(event, "dropdown");
    						},
    						"mousedown": function (event) {
    							$(event.target).addClass(self.css.buttonPressed);
    						},
    						"mouseup": function (event) {
    							$(event.target).removeClass(self.css.buttonPressed);
    						},
    						"click": function (event) {
    							self._triggerButtonClick(event, "dropdown");
    						}
    					});
    					/* jshint +W083*/
    				}
    					break;
    				case "clear": {
    					buttonClearArea.addClass(this.css.buttonClearArea).append(buttonClear.addClass(this.css.buttonClear));
    					buttonsArea.append(buttonClearArea);
    				}
    					break;
    				default:
    					//We use this counter in case we have CSV of not supported strings, where non of them are valid, we just don't append the buttons area at the end.
   						notSupportedIndex++;

    			}
    		}
    		if (buttons.length !== notSupportedIndex) {
    			this._editorContainer.append(buttonsArea);
    			this._buttonsArea = buttonsArea;
    		} else {
    			//TODO decide if we want this to be exception, or a warning 
    			console.log("button values not supported");
    		}
    	},
    	_getButtonsAreaWidth: function () {
    		if (this.options.button && this._buttonsArea) {
    			var width = this._buttonsArea.css("width");
    			return width;
    		} else {
    			return 0;
    		}
    	},
    	_attachEvents: function () {
    		var self = this, noCancel, newValue;
    		self._super("_attachEvents");
    		this._editorInput.on({
    			"focus": function (event) {
					//getValue and set it to the input
    				self._enterEditMode();
    				self._triggerFocus(event);
    			},
    			"blur": function (event) {
    				if (self._cancelBlurOnInput) {
    					self._editorInput.focus();
    					delete self._cancelBlurOnInput;
    				} else {
    					self._triggerBlur(event);
    					newValue = $(event.target).val();
    					noCancel = self._triggerValueChanging(newValue);
    					if (noCancel) {
    						if (self._validateValue(newValue)) {
    							self._updateValue(newValue);
    						} else {
								//If the value is not valid, we clear the editor 
    							self._clearValue();
    						}
    						self._exitEditMode();
							//We pass the new value in order to have the original value into the arguments
    						self._triggerValueChanged(newValue);
    					}
    					if (self._dropDownList && self._triggerDropDownClosing()) {
    						self._hideDropDownList();
    						self._triggerDropDownClosed();
    					}
    				}
    			},
    			"paste": function (event) {
					self._triggerPaste(event);
    			},
    			"keydown": function (event) {
    				self._triggerKeyDown(event);
    			},
    			"keyup": function (event) {
    				self._triggerKeyUp(event);
    			},
    			"keypress": function (event) {
    				self._triggerKeyPress(event);
    			}
    		});
    	},
    	_triggerKeyDown: function (event) {
    		//cancellable
    		var e = event;
    		// Allow: backspace, delete, tab, escape, enter and .
    		if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
    			// Allow: Ctrl+A
				(e.keyCode === 65 && e.ctrlKey === true) ||
    			// Allow: home, end, left, right, down, up
				(e.keyCode >= 35 && e.keyCode <= 40)) {
    			// let it happen, don't do anything
    			return;
    		}
    		var args = {
    			owner: this._editorContainer,
    			element: event.target,
    			key: event.keyCode,
    			editorInput: this._editorInput
    		};
    		return this._trigger(this.events.keydown, event, args);
    		// Ensure that it is a number and stop the keypress
    		//if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
    		//	e.preventDefault();
    		//}

        	

    	},
    	_triggerKeyUp: function (event) {
    		var args = {
    			originalEvent: event,
    			owner: this._editorContainer,
    			element: event.target,
    			editorInput: this._editorInput
    		};
    		this._trigger(this.events.keyup, event, args);
    	},
    	_triggerKeyPress: function (event) {

    		if (this._validateKey(event)) {
    			var args = {
    				owner: this._editorContainer,
    				element: event.target,
    				key: event.keyCode,
    				editorInput: this._editorInput
    			};
    			return this._trigger(this.events.keypress, event, args);
    		} else {
    			event.preventDefault();
    			event.stopPropagation();
    		}
    	},
    	_triggerValueChanged: function (originalValue) {
    		var args = {
    			owner: this._editorContainer,
    			element: event.target,
    			editorInput: this._editorInput,
    			newValue: this.options.value
    		};
    		if (originalValue) {
    			args.originalValue = originalValue;
    		}
    		this._trigger(this.events.valueChanged, null, args);
    	},
    	_triggerValueChanging: function (newValue) {
    		var args = {
    			owner: this._editorContainer,
    			element: event.target,
    			editorInput: this._editorInput,
    			oldValue: this.value(),
				newValue: newValue
    		};
    		return this._trigger(this.events.valueChanging, null, args);
    	},
    	_triggerListItemMouseOver: function (event) {
    		var item = event.target;
    		$(item).addClass(this.css.listItemHover, this.options.listItemHoverDuration);
    	},
    	_triggerListItemMouseOut: function (event) {
    		var item = event.target;
    		$(item).removeClass(this.css.listItemHover, this.options.listItemHoverDuration);
    	},
    	_triggerListItemClick: function (event) {
    		var item = event.target, noCancel;
    		//Trigger itemSelecting (Cancellable)
    		noCancel = this._triggerDropDownItemSelecting(item);
    		if (noCancel) {
    			//TODO select closest parent class
    			$(item).parent().children(".ui-igedit-listitem").removeClass(this.css.listItemSelected);
    			$(item).addClass(this.css.listItemSelected);

    			noCancel = this._triggerDropDownClosing();
    			if (noCancel) {
    				this._hideDropDownList();
    				this._triggerDropDownClosed();
    			}
    			this._triggerDropDownItemSelected(item);
    			noCancel = this._triggerValueChanging(item);
    			if (noCancel) {
    				if (this._validateValue($(item).text())) {
    					this._updateValue($(item).text());
    				} else {
    					this._clearValue();
    				}
    				this._exitEditMode();
    				this._triggerValueChanged();
    			} 
    		}
    	},
		//Next two handlers might be merged into inline invoke, if we decide we'll use the same classes
    	_triggerButtonMouseOver: function (event, buttonType) {
    		var item;
    		if (buttonType) {
    			switch (buttonType) {
    				case "dropdown": {
    					item = event.target;
    					$(item).addClass(this.css.buttonHover);
    				}
    				break;

    			}
    		}
    	},
    	_triggerButtonMouseOut: function (event, buttonType) {
    		var item;
    		if (buttonType) {
    			switch (buttonType) {
    				case "dropdown": {
    					item = event.target;
    					$(item).removeClass(this.css.buttonHover);
    				}
    					break;

    			}
    		}
    	},
    	_triggerButtonClick: function (event, buttonType) {
    		if (buttonType) {
    			switch (buttonType) {
    				case "dropdown": {    				
    					this._toggleDropDown();
    				}
    					break;

    			}
    		}
    	},
    	_triggerDropDownClosing: function () {
    		var args = {
    			editor: this._editorContainer,
    			editorInput: this._editorInput,
    			list: this._dropDownList
    		};
    		return this._trigger(this.events.dropDownListClosing, null, args);
    	},
    	_triggerDropDownClosed: function () {
    		var args = {
    			editor: this._editorContainer,
    			editorInput: this._editorInput,
    			list: this._dropDownList
    		};
    		this._trigger(this.events.dropDownListClosed, null, args);
    	},
    	_triggerDropDownOpening: function () {
    		var args = {
    			editor: this._editorContainer,
    			editorInput: this._editorInput,
    			list: this._dropDownList
    		};
    		return this._trigger(this.events.dropDownListOpening, null, args);
    	},
    	_triggerDropDownOpened: function () {
    		var args = {
    			editor: this._editorContainer,
    			editorInput: this._editorInput,
    			list: this._dropDownList
    		};
    		return this._trigger(this.events.dropDownListOpening, null, args);
    	},
    	_triggerDropDownItemSelecting: function (item) {
    		var args = {
    			editor: this._editorContainer,
    			editorInput: this._editorInput,
    			list: this._dropDownList,
				item: item
    		};
    		return this._trigger(this.events.dropDownItemSelecting, null, args);
    	},
    	_triggerDropDownItemSelected: function (item) {
    		var args = {
    			editor: this._editorContainer,
    			editorInput: this._editorInput,
    			list: this._dropDownList,
    			item: item
    		};
    		this._trigger(this.events.dropDownItemSelecting, null, args);
    	},

    	_triggerPaste: function (event) {
    		//Here we need to validate the input value
    		var newValue = $(event.target).val();
    		if (this._validateValue(newValue)) {
    			this._updateValue(newValue);
    		}
    	},
    	_showDropDownList: function () {
    		//Open Dropdown 
    		this._dropDownList.visible = true;
    		//TriggerEvents
    		try {
    			$(this._dropDownList).show(this.options.dropDownAnimationType, this.options.dropDownAnimationDuration);
    		} catch (ex) {
    			$(this._dropDownList).show(this.options.dropDownAnimationDuration);
    		}
    	},
    	_hideDropDownList: function () {
    		this._dropDownList.visible = false;
    		try {
    			$(this._dropDownList).hide(this.options.dropDownAnimationType, this.options.dropDownAnimationDuration);
    		} catch (ex) {
    			$(this._dropDownList).hide(this.options.dropDownAnimationDuration);
    		}
    	},
    	_toggleDropDown: function () {
    		var noCancel, self = this;
			//Close dropdown
    		if (this._dropDownList.visible === true) {
    			noCancel = self._triggerDropDownClosing();
    			if (noCancel) {
					//Proceed with hiding
    				this._hideDropDownList();
    				this._triggerDropDownClosed();
    			}
    		} else {
    			//Open DropDown
    			noCancel = self._triggerDropDownOpening();
    			if (noCancel) {
    				//Proceed with hiding
    				this._showDropDownList();
    				this._editorInput.focus();
    				this._triggerDropDownOpened();
    			}

    		}
    	},
    	_validateKey: function (event) {
    		var ch;
    		if (this.options.excludeKeys) {
    			ch = String.fromCharCode(event.charCode);
    			if ($.inArray(ch, this._excludeKeysArray) !== -1) {
    				return false;
    			} else {
    				return true;
    			}
    		} else if (this.options.includeKeys) {
    			ch = String.fromCharCode(event.charCode);
    			if ($.inArray(ch, this._includeKeysArray) !== -1) {
    				return true;
    			} else {
    				return false;
    			}
    		} else {
    			return true;
    		}
    	},
    	_enterEditMode: function () {
    		this._editorInput.val(this._valueInput.val());
    		this._editorInput.select();
    	},
    	_exitEditMode: function () {
    		//Update the editor input with wisplay value
    		this._editorInput.attr("type", "text");
    		this._editorInput.val(this._getDisplayValue());	
    	},
		//This method is used to get the display value according to masks, displayFactor and all the properties related to the value displayed when editor is blured. 
    	_getDisplayValue: function () {
    		return this._valueInput.val();
    	}
    });

    $.widget('ui.igNumericEditor', $.ui.igTextEditor, {
    	options: {
    		
    		/* type="string" Sets gets the character, which is used as decimal separator.
				
				Note: This option has priority over possible regional settings. */
    		negativeSign: null,
    		numericNegativePattern: null,
    		numericDecimalSeparator: null,
    		numericGroupSeparator: null,
    		numericGroups: null,
    		numericMaxDecimals: null,
    		numericMinDecimals: null,
    		/* type="left|right|center" Sets gets horizontal alignment of text in editor. If that option is not set, then 'right' is used for 'numeric', 'currency' and 'percent' editors and the 'left' is used for all other types of editor.
				left type="string"
				right type="string"
				center type="string"
			*/
    		textAlign: "right",
    		/* type="double|float|long|ulong|int|uint|short|ushort|sbyte|byte" Sets gets type of value returned by the get of value() method. That also affects functionality of the set value(val) method and the copy/paste operations of browser.
				double type="string" the Number object is used with limits of double and if value is not set, then the null or Number.NaN is used depending on the option 'nullable'. Note: that is used as default.
				float type="string" the Number object is used with limits of double and if value is not set, then the null or Number.NaN is used depending on the option 'nullable'.
				long type="string" the Number object is used with limits of signed long and if value is not set, then the null or 0 is used depending on the option 'nullable'. 
				ulong type="string" the Number object is used with limits of unsigned long and if value is not set, then the null or 0 is used depending on the option 'nullable'.
				int type="string" the Number object is used with limits of signed int and if value is not set, then the null or 0 is used depending on the option 'nullable'.
				uint type="string" the Number object is used with limits of unsigned int and if value is not set, then the null or 0 is used depending on the option 'nullable'.
				short type="string" the Number object is used with limits of signed short and if value is not set, then the null or 0 is used depending on the option 'nullable'.
				ushort type="string" the Number object is used with limits of unsigned short and if value is not set, then the null or 0 is used depending on the option 'nullable'.
				sbyte type="string" the Number object is used with limits of signed byte and if value is not set, then the null or 0 is used depending on the option 'nullable'.
				byte type="string" the Number object is used with limits of unsigned byte and if value is not set, then the null or 0 is used depending on the option 'nullable'.
			*/
    		dataMode: 'double',
    		/* type="number" Sets gets the minimum value which can be entered in editor by end user. */
    		minValue: null,
    		/* type="number" Sets gets the maximum value which can be entered in editor by end user. */
    		maxValue: null,
    		/* type="bool" Sets gets ability to prevent null value.
				If that option is disabled, and editor has no value, then value is set to 0 (or minValue/maxValue).
			*/
    		allowNullValue: true,
    		/* type="number" Sets gets the representation of null value. In case of default the value for the input is set to null, which makes the input to hold an empty string */
			nullValue: null
    	},
    	events: {
    		/* igWidget events go here */
    		

    	},
    	_create: function () {
    		this._applyRegionalSettings();
    		this._applyDataModeSettings();
    		this._setNumericType();
    		var numericChars = "0123456789", dataMode = this.options.dataMode;
    		//Allow decimal separator as a char.
    		//TODO: When the dataMode is set to int, decimal separator should not be allowed
    		if (dataMode === "double" || dataMode === "float") {
    			numericChars += this.options[this._numericType + "DecimalSeparator"];
    		}
    		//Allow negativeSign as a char only where negative values are supported
    		if (dataMode === "double" || dataMode === "float" || dataMode === "long" || dataMode === "int" || dataMode === "short" || dataMode === "sbyte") {
    			numericChars += this.options.negativeSign;
    		}
			//Setting Exclude keys is not allowed into numeric/percent/currency editor
    		if (this.options.excludeKeys) {
    			this.options.excludeKeys = null;
    		}
			//This property is only internally used and it's not configurable in this widget.
    		this.options.includeKeys = numericChars;
			//We need this option internaly for parsing the value, set this option via method so we can overwrite it. 
    		$.ui.igTextEditor.prototype._create.call(this);
    		this._editorInput.attr("type", "tel");
    	},
    	_setNumericType: function () {
    		this._numericType = "numeric";
    	},
    	_applyRegionalSettings: function () {
			
    		this.options.negativeSign = this._getRegionalOption("negativeSign");
    		this.options.numericNegativePattern = this._getRegionalOption("numericNegativePattern");
    		this.options.numericDecimalSeparator = this._getRegionalOption("numericDecimalSeparator");
    		this.options.numericGroupSeparator = this._getRegionalOption("numericGroupSeparator");
    		this.options.numericGroups = this._getRegionalOption("numericGroups");
    		this.options.numericMaxDecimals = this._getRegionalOption("numericMaxDecimals");
    		this.options.numericMinDecimals = this._getRegionalOption("numericMinDecimals");   		   			
    		
    	},
    	_applyDataModeSettings: function () {
    		//We need to adjust max decimals, based on the dataMode limits
    		var doubleMaxDecimals = 15;
    		switch (this.options.dataMode) {
    			case "double": {
    				this._setMinMaxValues(-(Number.MAX_VALUE), Number.MAX_VALUE);
    				this._setMinMaxDecimals(doubleMaxDecimals);
    			}
    				break;
    			case "float": {
    				var floatMaxDecimals = 7, floatMinValue = -3.40282347e38, floatMaxValue = 3.40282347e38;
    				this._setMinMaxValues(floatMinValue, floatMaxValue);
    				this._setMinMaxDecimals(floatMaxDecimals);
    			}
    				break;
    			case "long": {
    				var longMinValue = -9223372036854775807, longMaxValue = 9223372036854775807;
    				this._setMinMaxValues(longMinValue, longMaxValue);
    			}
    				break;
    			case "ulong": {
    				var ulongMinValue = 0, ulongMaxValue = 18446744073709551615;
    				this._setMinMaxValues(ulongMinValue, ulongMaxValue);
    			}
    				break;
    			case "int": {
    				var intMinValue = -2147483647, intMaxValue = 2147483647;
    				this._setMinMaxValues(intMinValue, intMaxValue);
    			}
    				break;
    			case "uint": {
    				var uintMinValue = 0, uintMaxValue = 4294967295;
    				this._setMinMaxValues(uintMinValue, uintMaxValue);
    			}
    				break;
    			case "short": {
    				var shortMinValue = -32768, shortMaxValue = 32767;
    				this._setMinMaxValues(shortMinValue, shortMaxValue);
    			}
    				break;
    			case "ushort": {
    				var ushortMinValue = 0, ushortMaxValue = 65535;
    				this._setMinMaxValues(ushortMinValue, ushortMaxValue);
    			}
    				break;
    			case "sbyte": {
    				var sbyteMinValue = -127, sbyteMaxValue = 127;
    				this._setMinMaxValues(sbyteMinValue, sbyteMaxValue);
    			}
    				break;
    			case "byte": {
    				var byteMinValue = 0, byteMaxValue = 256;
    				this._setMinMaxValues(byteMinValue, byteMaxValue);
    			}
    				break;
    			//If dataMode doesn't match the editor fails back to dataMode double
    			default: {
    				this.options.dataMode = "double";
    				this._setMinMaxValues(Number.MIN_VALUE, Number.MAX_VALUE);
    				this._setMinMaxDecimals(doubleMaxDecimals);
    			}
    		}
    	},
    	_setMinMaxDecimals: function (typeMaxDecimals) {
    		if (!this.options.numericMaxDecimals || this.options.numericMaxDecimals > typeMaxDecimals) {
    			this.options.numericMaxDecimals = typeMaxDecimals;
    		}
    		this.options.numericMinDecimals = this._getRegionalOption("numericMinDecimals");
    		//In case of conflict between min and max decimals - both values are equaled to the max decimals
    		if (this.options.numericMinDecimals && this.options.numericMinDecimals > this.options.numericMaxDecimals) {
    			this.options.numericMinDecimals = this.options.numericMaxDecimals;
    		}
    	},
    	_setMinMaxValues: function (typeMinValue, typeMaxValue) {
    		//Set bounderies based on the type
    		if (!this.options.minValue || this.options.minValue < typeMinValue) {
    			this.options.minValue = typeMinValue;
    		}
    		if (!this.options.maxValue || this.options.maxValue > typeMaxValue) {
    			this.options.maxValue = typeMaxValue;
    		}
    	},
    	_parseNumericValueByMode: function (value, numericEditorType, dataMode) {
    		var val, stringValue, decimalSeparator, minDecimals, maxDecimals;
    		decimalSeparator = this.options[numericEditorType + "DecimalSeparator"];
    		minDecimals = this.options[numericEditorType + "MinDecimals"];
    		maxDecimals =  this.options[numericEditorType + "MaxDecimals"];
    		if (dataMode === "double" || dataMode === "float") {
    			stringValue = value.toString().toLowerCase();
    			if (stringValue.indexOf("e") !== -1) {
    				//In that case leave the value as it is
    				//TODO work on validation method
    				val = value;
    			} else {
    				//In that case we need to validate the value against the constraints. 
    				if (stringValue.indexOf(decimalSeparator) !== -1) {
    					var integerDigits, fractionalDigits = stringValue.substring(stringValue.indexOf(decimalSeparator) + 1);
						//In case of pasted value with multiple decimal points. We can't use parseFloat because we want to keep the number of the fractional digits, but parseFloat cuts to 6th
    					if (fractionalDigits.indexOf(decimalSeparator) > 0) {
    						fractionalDigits = fractionalDigits.substring(0, fractionalDigits.indexOf(decimalSeparator));
    					}
    					if (fractionalDigits.length > maxDecimals) {
    						fractionalDigits = fractionalDigits.substring(0, maxDecimals);
    					}
    					integerDigits = stringValue.substring(0, stringValue.indexOf(decimalSeparator));
    					//We want to evaluate the number without losing fractional digits, as parseFloat cuts six digits after the decimal point.
    					val = (integerDigits + "." + fractionalDigits) / 1;
    				} else {
    					//In that case we don't have fractional digits, so we can use ParseInt for the integer digits. 
    					val = parseFloat(parseInt(value).toFixed(minDecimals));
    				}
    			}
    		} else {
    			val = parseInt(value);
    		}
    		return val;
    	},
		//This method validates and updates the value input the hidden input
    	_updateValue: function (value) {
    		//WE should detect dataMode, so we can use the options. 
    		var val, dataMode = this.options.dataMode;
    		val = this._parseNumericValueByMode(value, this._numericType, dataMode);

    		if (val > this.options.maxValue) {
    			val = this.options.maxValue;
    		} else if (val < this.options.minValue) {
    			val = this.options.minValue;
    		}
    		this.options.value = val;
    		this._valueInput.val(val);   		
    	},
    	_validateKey: function (event) {
    		if (this._super(event)) {
    			var dataMode = this.options.dataMode, negativeSign = this.options.negativeSign, ch, val;
				//We need this extra validation in case the user tries to enter decimal separator multiple times
    			if (dataMode === "double" || dataMode === "float") {
    				var decimalSeparator = this.options[this._numericType + "DecimalSeparator"];
    				ch = String.fromCharCode(event.charCode);
    				//val = $(event.target).val();
    				val = this._editorInput.val();
    				if ((ch === decimalSeparator && val.indexOf(decimalSeparator) !== -1) || (ch === negativeSign && val.indexOf(negativeSign) !== -1)) {
						//We already have decimal separator so prevent default
    					return false;
    				} else {
    					return true;
    				}
    			} else if (dataMode === "long" || dataMode === "int" || dataMode === "short" || dataMode === "sbyte") {
    				ch = String.fromCharCode(event.charCode);
    				val = $(event.target).val();
    				if (ch === negativeSign && val.indexOf(negativeSign) > 0) {
    					//We already have decimal separator so prevent default
    					return false;
    				} else {
    					return true;
    				}
    			} else {
					//If the dataMode defers from double, or float and the super method returns true the cher is valid
    				return true;
    			}
    		} else {
				//If the super method fails, the char is not allowed
    			return false;
    		}
    	},
    	_validateValue: function (val) {
    		if (!isNaN(parseFloat(val)) || !isNaN(parseInt(val))) {
    			return true;
    		} else {
    			return false;
    		}
    	},
    	_getRegionalOption: function (key) {
    		var regional = this.options.regional;
    		if (this.options[key]) {
    			return this.options[key];
    		}
    		if (typeof regional === "string") {
    			regional = $.ig.regional[regional];
    		}
    		if (regional && regional[key]) {
    			return regional[key];
    		} else {
    			//return defaults
    			return $.ig.regional.defaults[key];
    		}
    	},
    	_getDisplayValue: function () {
    		var value = this._valueInput.val(), decimalSeparator = this.options[this._numericType + "DecimalSeparator"], decimalPoint = ".",
    			minDecimals = this.options[this._numericType + "MinDecimals"], dataMode = this.options.dataMode, stringValue, displayValue,
				positivePattern, negativePattern, groups, groupSeparator, symbol = "";
    		if (value === this.options.nullValue || value === "") {
    			return "";
    		}
    		if (this._numericType !== "numeric") {
    			positivePattern = this.options[this._numericType + "PositivePattern"];
    			symbol = this.options[this._numericType + "Symbol"];
    		}
    		negativePattern = this.options[this._numericType + "NegativePattern"];
    		groups = this.options[this._numericType + "Groups"];
    		groupSeparator = this.options[this._numericType + "GroupSeparator"];
    		//Min decimals check.
    		if (dataMode === "double" || dataMode === "float") {
    			stringValue = value.toString().toLowerCase();
    			if (stringValue.indexOf("e") !== -1) {
    				//In that case leave the value as it is
    				//TODO work on validation method
    				displayValue = value;
    			} else {
    				var integerDigits, fractionalDigits;
    				//In that case we need to validate the value against the constraints. 
					//Here decimalPoint is used instead of the decimalSeparator, as we work with the value from the hiddedn input, which is Number, so the decimalSeparator is dot. 
    				if (stringValue.indexOf(decimalPoint) !== -1) {
    					fractionalDigits = stringValue.substring(stringValue.indexOf(decimalPoint) + 1);
    					if (fractionalDigits.length < minDecimals) {
    						var missingDecimals = minDecimals - fractionalDigits.length;
    						while (missingDecimals > 0) {
    							fractionalDigits += "0";
    							missingDecimals--;
    						}
    					}
    					integerDigits = stringValue.substring(0, stringValue.indexOf(decimalPoint));
    				} else {
    					integerDigits = stringValue;
    					if (minDecimals > 0) {
    						stringValue = parseInt(stringValue).toFixed(minDecimals);
    						fractionalDigits = stringValue.substring(stringValue.indexOf(decimalPoint) + 1);
    					}
    				}
    				integerDigits = this._applyGroups(integerDigits, groups, groupSeparator);
    				if (fractionalDigits && fractionalDigits.length > 0) {
    					displayValue = integerDigits + decimalSeparator + fractionalDigits;
    				} else {
    					displayValue = integerDigits;
    				}
    			}
    		} else {
    			displayValue = this._applyGroups(value.toString(), groups, groupSeparator);
    		}
    		if (value < 0) {
    			displayValue = displayValue.replace("-", "");
    			displayValue = negativePattern.replace("n", displayValue).replace("$", symbol);
    		} else if (positivePattern) {
    			//Apply Positive Pattern
    			displayValue = positivePattern.replace("n", displayValue).replace("$", symbol);
    		}
    		

    		return displayValue;
    	},
    	_applyGroups: function (integerDigits, groups, groupSeparator) {
    		var digitsPosition = integerDigits.length - 1, br = 1, l = groups.length, digitsLimit = 0, group;
    		group = (groups.length > 0) ? groups[0] : 0;
			//The first group is longer than the integer - we can't insert group separator
    		if (group > integerDigits.length || group === 0) {
    			return integerDigits;
    		}
			//If the value is negative we need to skip the minus sign
    		if (parseFloat(integerDigits) < 0) {
    			digitsLimit = 1;
    		}
    		for (digitsPosition; digitsPosition > digitsLimit; digitsPosition--) {
				//group size exceeded - we need to insert group separator
    			if (--group === 0) {
    				//TODO insert
    				integerDigits = integerDigits.substring(0, digitsPosition) + groupSeparator + integerDigits.substring(digitsPosition);
    				if (br === l) {
    					//We are on the last group 
    					group = groups[--br];
    				} else {
    					group = groups[br];
    					br++;
    				}
    			}
    		}
    		return integerDigits;
    	},
    	_enterEditMode: function () {
    		this._editorInput.attr("type", "tel");
    		if (this._valueInput.val() < 0) {
				//Remove negative css into edit mode
    		}
    		this._editorInput.val(this._valueInput.val());
    		this._editorInput.select();
    	},
    });
    $.widget('ui.igCurrencyEditor', $.ui.igNumericEditor, {
    	options: {
    		currencyPositivePattern: '$n',
    		currencyNegativePattern: '$(n)',
    		currencySymbol: '$',
    		currencyDecimalSeparator: '.',
    		currencyGroupSeparator: ',',
    		currencyGroups: [3],
    		currencyMaxDecimals: 2,
    		currencyMinDecimals: 2
    	},
    	events: {
    		/* igWidget events go here */
    	},
    	_setMinMaxDecimals: function (typeMaxDecimals) {
    		if (!this.options.currencyMaxDecimals || this.options.currencyMaxDecimals > typeMaxDecimals) {
    			this.options.numericMaxDecimals = typeMaxDecimals;
    		}
    		this.options.currencyMinDecimals = this._getRegionalOption("currencyMinDecimals");
    		//In case of conflict between min and max decimals - both values are equaled to the max decimals
    		if (this.options.currencyMinDecimals && this.options.currencyMinDecimals > this.options.currencyMaxDecimals) {
    			this.options.currencyMinDecimals = this.options.currencyMaxDecimals;
    		}
    	},
    	_create: function () {
    		$.ui.igNumericEditor.prototype._create.call(this);
    	},
    	_setNumericType: function () {
    		this._numericType = "currency";
    	},
    	_applyRegionalSettings: function () {
    		this.options.negativeSign = this._getRegionalOption("negativeSign");
    		this.options.currencyPositivePattern = this._getRegionalOption("currencyPositivePattern");
    		this.options.currencyNegativePattern = this._getRegionalOption("currencyNegativePattern");
    		this.options.currencySymbol = this._getRegionalOption("currencySymbol");
    		this.options.currencyDecimalSeparator = this._getRegionalOption("currencyDecimalSeparator");
    		this.options.currencyGroupSeparator = this._getRegionalOption("currencyGroupSeparator");
    		this.options.currencyGroups = this._getRegionalOption("currencyGroups");
    		this.options.currencyMaxDecimals = this._getRegionalOption("currencyMaxDecimals");
    		this.options.currencyMinDecimals = this._getRegionalOption("currencyMinDecimals");
    	},
    });
    $.widget('ui.igPercentEditor', $.ui.igNumericEditor, {
    	options: {
    		/* type="object" Sets gets custom regional settings for editor. If it is string, then $.ig.regional[stringValue] is assumed. */

    		/* type="string" Sets gets the character, which is used as decimal separator.
	
			Note: This option has priority over possible regional settings. */
    		percentPositivePattern: null,
    		percentNegativePattern: null,
    		percentSymbol: null,
    		percentDecimalSeparator: null,
    		percentGroupSeparator: null,
    		percentGroups: null,
    		percentDisplayFactor: null,
    		percentMaxDecimals: null,
    		percentMinDecimals: null
    	},
    	events: {
    		/* igWidget events go here */
    		

    	},
    	_create: function () {
    		$.ui.igNumericEditor.prototype._create.call(this);
    	},
    	_setNumericType: function () {
    		this._numericType = "percent";
    	},
    	_applyRegionalSettings: function () {
    		this.options.negativeSign = this._getRegionalOption("negativeSign");
    		this.options.percentPositivePattern = this._getRegionalOption("percentPositivePattern");
    		this.options.percentNegativePattern = this._getRegionalOption("percentNegativePattern");
    		this.options.percentSymbol = this._getRegionalOption("percentSymbol");
    		this.options.percentDecimalSeparator = this._getRegionalOption("percentDecimalSeparator");
    		this.options.percentGroupSeparator = this._getRegionalOption("percentGroupSeparator");
    		this.options.percentGroups = this._getRegionalOption("percentGroups");
    		this.options.percentDisplayFactor = this._getRegionalOption("percentDisplayFactor");
    		this.options.percentMaxDecimals = this._getRegionalOption("percentMaxDecimals");
    		this.options.percentMinDecimals = this._getRegionalOption("percentMinDecimals");
    	}
    });
    $.widget('ui.igMaskEditor', $.ui.igTextEditor, {
    	options: {
    		/* type="object" Sets gets custom regional settings for editor. If it is string, then $.ig.regional[stringValue] is assumed. */
    		regional: null


    	},
    	events: {
    		/* igWidget events go here */

    	},
    	_create: function () {

    		$.ui.igBaseEditor.prototype._create.call(this);   	

    	}

    });
    $.widget('ui.igDateEditor', $.ui.igTextEditor, {
    	options: {
    		/* type="object" Sets gets custom regional settings for editor. If it is string, then $.ig.regional[stringValue] is assumed. */
    	},
    	events: {
    		/* igWidget events go here */
    	},
    	_create: function () {
    		$.ui.igBaseEditor.prototype._create.call(this);
    	},

    });
    $.widget('ui.igDatePicker', $.ui.igDateEditor, {
    	options: {
    		/* type="object" Sets gets custom regional settings for editor. If it is string, then $.ig.regional[stringValue] is assumed. */
    		regional: null


    	},
    	events: {
    	

    	},
    	_create: function () {

    		$.ui.igBaseEditor.prototype._create.call(this);
    	}
    });
    $.widget('ui.igCheckboxEditor', $.ui.igBaseEditor, {
    	options: {
    		/* type="string|number|null Gets sets how the height of the checkbox."
				string The widget width can be set in pixels (px) and percentage (%).
				number The widget width can be set as a number in pixels.
			*/
    		checkboxHeight: null,
    		/* type="string|number|null Gets sets how the width of the checkbox."
				string The widget width can be set in pixels (px) and percentage (%).
				number The widget width can be set as a number in pixels.
			*/
    		checkboxWidth: null,
			/* type="boolean" Gets/sets the checked state of the check box */
			checked: false
    	},
    	events: {
    		checked: "checked",
			unchecked: "unchecked"
    	},
    	css: {
    		checkboxContainer: "ui-state-checkbox-container",
    		selected: "ui-state-checkbox-selected"
    	},
    	_create: function () {
    		$.ui.igBaseEditor.prototype._create.call(this);
    	},
    	_render: function () {
    		this._triggerRendering();
    		if (this.element.is("div")) {
    			var editorElement = $("<input type='text' />");

    			this._editorInput = editorElement;
    			this._editorContainer = this.element;
    			this._editorContainer.prepend(editorElement);
    		} else if (this.element.is("input")) {

    			this._editorContainer = this.element.wrap($("<div></div>")).parent();
    			this._editorInput = this.element;
    		} else {
    			throw ("It's only allowed to instantiate igCheckboxEditor on INPUT or DIV");
    		}
    		this._editorContainer.addClass(this.css.container).addClass(this.css.checkboxContainer);
    		this._editorInput.addClass(this.css.editor);
    		if (this.options.checkboxHeight) {
    			this._editorInput.css("height", this.options.checkboxHeight);
    		}
    		if (this.options.checkboxWidth) {
    			this._editorInput.css("width", this.options.checkboxWidth);
    		}

    		if (this.options.width) {
    			this._editorContainer.css("width", this.options.width);
    		}
    		if (this.options.height) {
    			this._editorContainer.css("height", this.options.height);
    		}

    		if (this._editorInput.attr("type") !== "checkbox") {
    			this._editorInput.attr("type", "checkbox");
    		}
    		if (this.options.checked) {
    			this._updateState(true);
    		} else {
    			this.options.checked = false;
    		}
    		this._triggerRendered();
    	},
    	_attachEvents: function () {
    		var self = this, noCancel, newVal;
    		this._super("_attachEvents");
    		this._editorInput.on({
    			"change.editor": function (event) {
    				newVal = $(this).is(":checked");
    				noCancel = self._triggerValueChanging(newVal);
    				if (noCancel) {
    					self._updateState(newVal);
    					self._triggerValueChanged(event);
    				} else {
    					self.toggle(); //Change the state back
    				}
    			},
    			"focus.editor": function (event) {
    				self._triggerFocus(event);
    			},
    			"blur.editor": function (event) {
    				self._triggerBlur(event);
    			}
    		});
    	},
    	_triggerValueChanging: function (newValue) {
    		var args = {
    			owner: this._editorContainer,
    			element: event.target,
    			editorInput: this._editorInput,
    			oldValue: this.options.checked,
				newValue: newValue
    		};
    		return this._trigger(this.events.valueChanging, event, args);
    	},
    	_triggerValueChanged: function (event) {
    		var args = {
    			owner: this._editorContainer,
    			element: event.target,
    			editorInput: this._editorInput,
    			newValue: this.options.checked
    		};
    		this._trigger(this.events.valueChanged, event, args);
    		this._trigger(this.options.checked ? this.events.checked : this.events.unchecked, event, args);
    	},
    	_updateValue: function (value) {
    		this.options.value = value;
    		this._editorInput.val(value);
    	},
    	_getDisplayValue: function () {
    		return this._editorInput.val();
    	},
    	_getState: function () {
    		var s = this._editorInput.prop("checked");
    		return s;
    	},
    	_updateState: function (value) {
    		this.options.checked = value;
    		this._editorInput.prop("checked", value);
    		if (value) {
    			this._editorContainer.addClass(this.css.selected);
    		} else {
    			this._editorContainer.removeClass(this.css.selected);
    		}
    	},
    	_clearStyling: function () {
    		this._editorContainer
				.removeClass(this.css.checkboxContainer)
    			.removeClass(this.css.selected);

    		this._super("_clearStyling");
    	},
    	value: function (value) {
    		/* Gets/Sets the current checked state of the checkbox. 
				Note that it is not setting/getting the attribute "value" of the input. 
				Use $editor.igCheckboxEditor("option", "value") to get/set the attribute "value" of the input. 
				returnType="boolean" Checked state.
			*/
    		if (value !== undefined) {
    			this._updateState(value && value !== "false" ? true : false);
    		} else {
    			return this._getState();
    		}
    	},
    	toggle: function () {
    		/* Toggles the state of the checkbox. */
    		if (this._getState()) {
    			this._updateState(false);
    		} else {
    			this._updateState(true);
    		}
    	}
    });
}(jQuery));



