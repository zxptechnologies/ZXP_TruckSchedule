﻿/*!@license
* Infragistics.Web.ClientUI infragistics.encoding_iso-8859-2.js 15.1.20151.2352
*
* Copyright (c) 2011-2015 Infragistics Inc.
*
* http://www.infragistics.com/
*
* Depends:
*     jquery-1.4.4.js
*     jquery.ui.core.js
*     jquery.ui.widget.js
*     infragistics.util.js
*/

// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["AbstractEnumerable:a", 
"Object:b", 
"Type:c", 
"Boolean:d", 
"ValueType:e", 
"Void:f", 
"IConvertible:g", 
"IFormatProvider:h", 
"Number:i", 
"String:j", 
"IComparable:k", 
"Number:l", 
"Number:m", 
"Number:n", 
"Number:o", 
"NumberStyles:p", 
"Enum:q", 
"Array:r", 
"IList:s", 
"ICollection:t", 
"IEnumerable:u", 
"IEnumerator:v", 
"NotSupportedException:w", 
"Error:x", 
"Number:y", 
"String:z", 
"StringComparison:aa", 
"RegExp:ab", 
"CultureInfo:ac", 
"DateTimeFormatInfo:ad", 
"Calendar:ae", 
"Date:af", 
"Number:ag", 
"DayOfWeek:ah", 
"DateTimeKind:ai", 
"CalendarWeekRule:aj", 
"NumberFormatInfo:ak", 
"CompareInfo:al", 
"CompareOptions:am", 
"IEnumerable$1:an", 
"IEnumerator$1:ao", 
"IDisposable:ap", 
"StringSplitOptions:aq", 
"Number:ar", 
"Number:as", 
"Number:at", 
"Number:au", 
"Number:av", 
"Number:aw", 
"Assembly:ax", 
"Stream:ay", 
"SeekOrigin:az", 
"RuntimeTypeHandle:a0", 
"MethodInfo:a1", 
"MethodBase:a2", 
"MemberInfo:a3", 
"ParameterInfo:a4", 
"TypeCode:a5", 
"ConstructorInfo:a6", 
"PropertyInfo:a7", 
"Func$1:a8", 
"MulticastDelegate:a9", 
"IntPtr:ba", 
"AbstractEnumerator:bb", 
"Array:bm", 
"GenericEnumerable$1:ci", 
"GenericEnumerator$1:cj"]);


} (jQuery));



// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["IEncoding:a", 
"String:b", 
"ValueType:c", 
"Object:d", 
"Type:e", 
"Boolean:f", 
"IConvertible:g", 
"IFormatProvider:h", 
"Number:i", 
"String:j", 
"IComparable:k", 
"Number:l", 
"Number:m", 
"Number:n", 
"Number:o", 
"NumberStyles:p", 
"Enum:q", 
"Array:r", 
"IList:s", 
"ICollection:t", 
"IEnumerable:u", 
"IEnumerator:v", 
"Void:w", 
"NotSupportedException:x", 
"Error:y", 
"Number:z", 
"StringComparison:aa", 
"RegExp:ab", 
"CultureInfo:ac", 
"DateTimeFormatInfo:ad", 
"Calendar:ae", 
"Date:af", 
"Number:ag", 
"DayOfWeek:ah", 
"DateTimeKind:ai", 
"CalendarWeekRule:aj", 
"NumberFormatInfo:ak", 
"CompareInfo:al", 
"CompareOptions:am", 
"IEnumerable$1:an", 
"IEnumerator$1:ao", 
"IDisposable:ap", 
"StringSplitOptions:aq", 
"Number:ar", 
"Number:as", 
"Number:at", 
"Number:au", 
"Number:av", 
"Number:aw", 
"Assembly:ax", 
"Stream:ay", 
"SeekOrigin:az", 
"RuntimeTypeHandle:a0", 
"MethodInfo:a1", 
"MethodBase:a2", 
"MemberInfo:a3", 
"ParameterInfo:a4", 
"TypeCode:a5", 
"ConstructorInfo:a6", 
"PropertyInfo:a7", 
"Encoding:a9", 
"UTF8Encoding:ba", 
"InvalidOperationException:bb", 
"NotImplementedException:bc", 
"Script:bd", 
"Decoder:be", 
"UnicodeEncoding:bf", 
"Math:bg", 
"AsciiEncoding:bh", 
"ArgumentNullException:bi", 
"DefaultDecoder:bj", 
"ArgumentException:bk", 
"Dictionary$2:bl", 
"IDictionary$2:bm", 
"ICollection$1:bn", 
"IDictionary:bo", 
"Func$2:bp", 
"MulticastDelegate:bq", 
"IntPtr:br", 
"KeyValuePair$2:bs", 
"Enumerable:bt", 
"Thread:bu", 
"ThreadStart:bv", 
"Func$3:bw", 
"IList$1:bx", 
"IOrderedEnumerable$1:by", 
"SortedList$1:bz", 
"List$1:b0", 
"IArray:b1", 
"IArrayList:b2", 
"Array:b3", 
"CompareCallback:b4", 
"Action$1:b5", 
"Comparer$1:b6", 
"IComparer:b7", 
"IComparer$1:b8", 
"DefaultComparer$1:b9", 
"IComparable$1:ca", 
"Comparison$1:cb", 
"ReadOnlyCollection$1:cc", 
"Predicate$1:cd", 
"IEqualityComparer$1:ce", 
"EqualityComparer$1:cf", 
"IEqualityComparer:cg", 
"DefaultEqualityComparer$1:ch", 
"StringBuilder:ci", 
"Environment:cj", 
"SingleByteEncoding:ck", 
"RuntimeHelpers:cn", 
"RuntimeFieldHandle:co", 
"Iso8859Dash2:cv", 
"AbstractEnumerable:di", 
"Func$1:dj", 
"AbstractEnumerator:dk", 
"GenericEnumerable$1:dl", 
"GenericEnumerator$1:dm"]);


$.ig.util.defType('SingleByteEncoding', 'Encoding', {
	_reverseCodePage: null,
	_codePageLayout: null,
	__codePage: 0,
	__name: null,
	codePageLayout: function () {
	}
	,
	init: function (initNumber, codePage) {
		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}
		$.ig.Encoding.prototype.init.call(this);
		this.setCodePage(codePage);
	},
	init1: function (initNumber, codePage, name) {
		$.ig.Encoding.prototype.init.call(this);
		this.setCodePage(codePage);
		this.__name = name;
	},
	setCodePage: function (codePage) {
		this.__codePage = codePage;
		this._codePageLayout = this.codePageLayout();
		if (this._codePageLayout == null) {
			return;
		}
		this._reverseCodePage = new $.ig.Dictionary$2($.ig.String.prototype.$type, $.ig.Number.prototype.$type, 0);
		for (var i = 0; i < this._codePageLayout.length; i++) {
			var c = this._codePageLayout[i];
			if (c != '\uffff') {
				this._reverseCodePage.add(c, i);
			}
		}
	}
	,
	fallbackCharacter: function () {
		return $.ig.SingleByteEncoding.prototype._questionMark;
	}
	,
	codePage: function () {
		return this.__codePage;
	}
	,
	name: function () {
		return this.__name;
	}
	,
	getByteCount: function (chars, index, count) {
		return count;
	}
	,
	getBytes2: function (chars, charIndex, charCount, bytes, byteIndex) {
		for (var i = charIndex; i < charIndex + charCount; i++) {
			if (this._reverseCodePage.containsKey(chars[i])) {
				bytes[byteIndex + i - charIndex] = this._reverseCodePage.item(chars[i]);
			} else {
				bytes[byteIndex + i - charIndex] = this.getBytes1(this.fallbackCharacter().toString())[0];
			}
		}
		return charCount;
	}
	,
	getString1: function (bytes, index, count) {
		var layout = this._codePageLayout;
		var sb = new $.ig.StringBuilder(0);
		for (var i = index; i < index + count; i++) {
			if (layout[bytes[i]] != '\uffff') {
				sb.append1(layout[bytes[i]]);
			}
		}
		return sb.toString();
	}
	,
	$type: new $.ig.Type('SingleByteEncoding', $.ig.Encoding.prototype.$type, [$.ig.IEncoding.prototype.$type])
}, true);

$.ig.util.defType('Iso8859Dash2', 'SingleByteEncoding', {
	__codePageLayout: null,
	codePageLayout: function () {
		return this.__codePageLayout;
	}
	,
	init: function () {
		this.__codePageLayout = [ '\0', '\u0001', '\u0002', '\u0003', '\u0004', '\u0005', '\u0006', '\u0007', '\b', '\t', '\n', '\v', '\u000c', '\r', '\u000e', '\u000f', '\u0010', '\u0011', '\u0012', '\u0013', '\u0014', '\u0015', '\u0016', '\u0017', '\u0018', '\u0019', '\u001a', '\u001b', '\u001c', '\u001d', '\u001e', '\u001f', ' ', '!', '\"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?', '@', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[', '\\', ']', '^', '_', '`', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~', '\u007f', '\u0080', '\u0081', '\u0082', '\u0083', '\u0084', '\u0085', '\u0086', '\u0087', '\u0088', '\u0089', '\u008a', '\u008b', '\u008c', '\u008d', '\u008e', '\u008f', '\u0090', '\u0091', '\u0092', '\u0093', '\u0094', '\u0095', '\u0096', '\u0097', '\u0098', '\u0099', '\u009a', '\u009b', '\u009c', '\u009d', '\u009e', '\u009f', ' ', 'Ą', '˘', 'Ł', '¤', 'Ľ', 'Ś', '§', '¨', 'Š', 'Ş', 'Ť', 'Ź', '­', 'Ž', 'Ż', '°', 'ą', '˛', 'ł', '´', 'ľ', 'ś', 'ˇ', '¸', 'š', 'ş', 'ť', 'ź', '˝', 'ž', 'ż', 'Ŕ', 'Á', 'Â', 'Ă', 'Ä', 'Ĺ', 'Ć', 'Ç', 'Č', 'É', 'Ę', 'Ë', 'Ě', 'Í', 'Î', 'Ď', 'Đ', 'Ń', 'Ň', 'Ó', 'Ô', 'Ő', 'Ö', '×', 'Ř', 'Ů', 'Ú', 'Ű', 'Ü', 'Ý', 'Ţ', 'ß', 'ŕ', 'á', 'â', 'ă', 'ä', 'ĺ', 'ć', 'ç', 'č', 'é', 'ę', 'ë', 'ě', 'í', 'î', 'ď', 'đ', 'ń', 'ň', 'ó', 'ô', 'ő', 'ö', '÷', 'ř', 'ů', 'ú', 'ű', 'ü', 'ý', 'ţ', '˙' ];
		$.ig.SingleByteEncoding.prototype.init1.call(this, 1, 28592, "iso-8859-2");
	},
	$type: new $.ig.Type('Iso8859Dash2', $.ig.SingleByteEncoding.prototype.$type)
}, true);

$.ig.SingleByteEncoding.prototype._questionMark = '?';

} (jQuery));


