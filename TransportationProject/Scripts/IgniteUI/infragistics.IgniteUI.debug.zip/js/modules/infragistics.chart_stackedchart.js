﻿/*!@license
* Infragistics.Web.ClientUI infragistics.chart_stackedchart.js 15.1.20151.2352
*
* Copyright (c) 2011-2015 Infragistics Inc.
*
* http://www.infragistics.com/
*
* Depends:
*     jquery-1.4.4.js
*     jquery.ui.core.js
*     jquery.ui.widget.js
*     infragistics.util.js
*/

// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["AbstractEnumerable:a", 
"Object:b", 
"Type:c", 
"Boolean:d", 
"ValueType:e", 
"Void:f", 
"IConvertible:g", 
"IFormatProvider:h", 
"Number:i", 
"String:j", 
"IComparable:k", 
"Number:l", 
"Number:m", 
"Number:n", 
"Number:o", 
"NumberStyles:p", 
"Enum:q", 
"Array:r", 
"IList:s", 
"ICollection:t", 
"IEnumerable:u", 
"IEnumerator:v", 
"NotSupportedException:w", 
"Error:x", 
"Number:y", 
"String:z", 
"StringComparison:aa", 
"RegExp:ab", 
"CultureInfo:ac", 
"DateTimeFormatInfo:ad", 
"Calendar:ae", 
"Date:af", 
"Number:ag", 
"DayOfWeek:ah", 
"DateTimeKind:ai", 
"CalendarWeekRule:aj", 
"NumberFormatInfo:ak", 
"CompareInfo:al", 
"CompareOptions:am", 
"IEnumerable$1:an", 
"IEnumerator$1:ao", 
"IDisposable:ap", 
"StringSplitOptions:aq", 
"Number:ar", 
"Number:as", 
"Number:at", 
"Number:au", 
"Number:av", 
"Number:aw", 
"Assembly:ax", 
"Stream:ay", 
"SeekOrigin:az", 
"RuntimeTypeHandle:a0", 
"MethodInfo:a1", 
"MethodBase:a2", 
"MemberInfo:a3", 
"ParameterInfo:a4", 
"TypeCode:a5", 
"ConstructorInfo:a6", 
"PropertyInfo:a7", 
"Func$1:a8", 
"MulticastDelegate:a9", 
"IntPtr:ba", 
"AbstractEnumerator:bb", 
"Array:bm", 
"GenericEnumerable$1:ci", 
"GenericEnumerator$1:cj"]);


} (jQuery));



// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["Object:d", 
"Type:e", 
"Boolean:f", 
"ValueType:g", 
"Void:h", 
"IConvertible:i", 
"IFormatProvider:j", 
"Number:k", 
"String:l", 
"IComparable:m", 
"Number:n", 
"Number:o", 
"Number:p", 
"Number:q", 
"NumberStyles:r", 
"Enum:s", 
"Array:t", 
"IList:u", 
"ICollection:v", 
"IEnumerable:w", 
"IEnumerator:x", 
"NotSupportedException:y", 
"Error:z", 
"Number:aa", 
"String:ab", 
"StringComparison:ac", 
"RegExp:ad", 
"CultureInfo:ae", 
"DateTimeFormatInfo:af", 
"Calendar:ag", 
"Date:ah", 
"Number:ai", 
"DayOfWeek:aj", 
"DateTimeKind:ak", 
"CalendarWeekRule:al", 
"NumberFormatInfo:am", 
"CompareInfo:an", 
"CompareOptions:ao", 
"IEnumerable$1:ap", 
"IEnumerator$1:aq", 
"IDisposable:ar", 
"StringSplitOptions:as", 
"Number:at", 
"Number:au", 
"Number:av", 
"Number:aw", 
"Number:ax", 
"Number:ay", 
"Assembly:az", 
"Stream:a0", 
"SeekOrigin:a1", 
"RuntimeTypeHandle:a2", 
"MethodInfo:a3", 
"MethodBase:a4", 
"MemberInfo:a5", 
"ParameterInfo:a6", 
"TypeCode:a7", 
"ConstructorInfo:a8", 
"PropertyInfo:a9", 
"Array:bf", 
"MulticastDelegate:bh", 
"IntPtr:bi", 
"Func$1:hf", 
"AbstractEnumerable:js", 
"AbstractEnumerator:jt", 
"GenericEnumerable$1:ju", 
"GenericEnumerator$1:jv"]);


} (jQuery));



// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["IProvidesViewport:a", 
"Void:b", 
"ValueType:c", 
"Object:d", 
"Type:e", 
"Boolean:f", 
"IConvertible:g", 
"IFormatProvider:h", 
"Number:i", 
"String:j", 
"IComparable:k", 
"Number:l", 
"Number:m", 
"Number:n", 
"Number:o", 
"NumberStyles:p", 
"Enum:q", 
"Array:r", 
"IList:s", 
"ICollection:t", 
"IEnumerable:u", 
"IEnumerator:v", 
"NotSupportedException:w", 
"Error:x", 
"Number:y", 
"String:z", 
"StringComparison:aa", 
"RegExp:ab", 
"CultureInfo:ac", 
"DateTimeFormatInfo:ad", 
"Calendar:ae", 
"Date:af", 
"Number:ag", 
"DayOfWeek:ah", 
"DateTimeKind:ai", 
"CalendarWeekRule:aj", 
"NumberFormatInfo:ak", 
"CompareInfo:al", 
"CompareOptions:am", 
"IEnumerable$1:an", 
"IEnumerator$1:ao", 
"IDisposable:ap", 
"StringSplitOptions:aq", 
"Number:ar", 
"Number:as", 
"Number:at", 
"Number:au", 
"Number:av", 
"Number:aw", 
"Assembly:ax", 
"Stream:ay", 
"SeekOrigin:az", 
"RuntimeTypeHandle:a0", 
"MethodInfo:a1", 
"MethodBase:a2", 
"MemberInfo:a3", 
"ParameterInfo:a4", 
"TypeCode:a5", 
"ConstructorInfo:a6", 
"PropertyInfo:a7", 
"Rect:a8", 
"Size:a9", 
"Point:ba", 
"Math:bb", 
"Series:bc", 
"Control:bd", 
"FrameworkElement:be", 
"UIElement:bf", 
"DependencyObject:bg", 
"Dictionary:bh", 
"DependencyProperty:bi", 
"PropertyMetadata:bj", 
"PropertyChangedCallback:bk", 
"MulticastDelegate:bl", 
"IntPtr:bm", 
"DependencyPropertyChangedEventArgs:bn", 
"DependencyPropertiesCollection:bo", 
"UnsetValue:bp", 
"Script:bq", 
"Binding:br", 
"PropertyPath:bs", 
"Transform:bt", 
"Visibility:bu", 
"Style:bv", 
"Thickness:bw", 
"HorizontalAlignment:bx", 
"VerticalAlignment:by", 
"INotifyPropertyChanged:bz", 
"PropertyChangedEventHandler:b0", 
"PropertyChangedEventArgs:b1", 
"SeriesView:b2", 
"ISchedulableRender:b3", 
"SeriesViewer:b4", 
"SeriesViewerView:b5", 
"CanvasRenderScheduler:b6", 
"List$1:b7", 
"IList$1:b8", 
"ICollection$1:b9", 
"IArray:ca", 
"IArrayList:cb", 
"Array:cc", 
"CompareCallback:cd", 
"Func$3:ce", 
"Action$1:cf", 
"Comparer$1:cg", 
"IComparer:ch", 
"IComparer$1:ci", 
"DefaultComparer$1:cj", 
"IComparable$1:ck", 
"Comparison$1:cl", 
"ReadOnlyCollection$1:cm", 
"Predicate$1:cn", 
"NotImplementedException:co", 
"Callback:cp", 
"window:cq", 
"RenderingContext:cr", 
"IRenderer:cs", 
"Rectangle:ct", 
"Shape:cu", 
"Brush:cv", 
"Color:cw", 
"ArgumentException:cx", 
"DoubleCollection:cy", 
"Path:cz", 
"Geometry:c0", 
"GeometryType:c1", 
"TextBlock:c2", 
"Polygon:c3", 
"PointCollection:c4", 
"Polyline:c5", 
"DataTemplateRenderInfo:c6", 
"DataTemplatePassInfo:c7", 
"ContentControl:c8", 
"DataTemplate:c9", 
"DataTemplateRenderHandler:da", 
"DataTemplateMeasureHandler:db", 
"DataTemplateMeasureInfo:dc", 
"DataTemplatePassHandler:dd", 
"Line:de", 
"FontInfo:df", 
"XamOverviewPlusDetailPane:dg", 
"XamOverviewPlusDetailPaneView:dh", 
"XamOverviewPlusDetailPaneViewManager:di", 
"JQueryObject:dj", 
"Element:dk", 
"ElementAttributeCollection:dl", 
"ElementCollection:dm", 
"WebStyle:dn", 
"ElementNodeType:dp", 
"Document:dq", 
"EventListener:dr", 
"IElementEventHandler:ds", 
"ElementEventHandler:dt", 
"ElementAttribute:du", 
"JQueryPosition:dv", 
"JQueryCallback:dw", 
"JQueryEvent:dx", 
"JQueryUICallback:dy", 
"EventProxy:dz", 
"ModifierKeys:d0", 
"Func$2:d1", 
"MouseWheelHandler:d2", 
"Delegate:d3", 
"Interlocked:d4", 
"GestureHandler:d5", 
"ContactHandler:d6", 
"TouchHandler:d7", 
"MouseOverHandler:d8", 
"MouseHandler:d9", 
"KeyHandler:ea", 
"Key:eb", 
"JQuery:ec", 
"JQueryDeferred:ed", 
"JQueryPromise:ee", 
"Action:ef", 
"CanvasViewRenderer:eg", 
"CanvasContext2D:eh", 
"CanvasContext:ei", 
"TextMetrics:ej", 
"ImageData:ek", 
"CanvasElement:el", 
"Gradient:em", 
"LinearGradientBrush:en", 
"GradientStop:eo", 
"GeometryGroup:ep", 
"GeometryCollection:eq", 
"FillRule:er", 
"PathGeometry:es", 
"PathFigureCollection:et", 
"LineGeometry:eu", 
"RectangleGeometry:ev", 
"EllipseGeometry:ew", 
"ArcSegment:ex", 
"PathSegment:ey", 
"PathSegmentType:ez", 
"SweepDirection:e0", 
"PathFigure:e1", 
"PathSegmentCollection:e2", 
"LineSegment:e3", 
"PolyLineSegment:e4", 
"BezierSegment:e5", 
"PolyBezierSegment:e6", 
"GeometryUtil:e7", 
"Tuple$2:e8", 
"TransformGroup:e9", 
"TransformCollection:fa", 
"TranslateTransform:fb", 
"RotateTransform:fc", 
"ScaleTransform:fd", 
"DivElement:fe", 
"DOMEventProxy:ff", 
"MSGesture:fg", 
"MouseEventArgs:fh", 
"EventArgs:fi", 
"DoubleAnimator:fj", 
"EasingFunctionHandler:fk", 
"ImageElement:fl", 
"RectUtil:fm", 
"MathUtil:fn", 
"RuntimeHelpers:fo", 
"RuntimeFieldHandle:fp", 
"PropertyChangedEventArgs$1:fq", 
"InteractionState:fr", 
"OverviewPlusDetailPaneMode:fs", 
"IOverviewPlusDetailControl:ft", 
"EventHandler$1:fu", 
"ArgumentNullException:fv", 
"OverviewPlusDetailViewportHost:fw", 
"SeriesCollection:fx", 
"ObservableCollection$1:fy", 
"INotifyCollectionChanged:fz", 
"NotifyCollectionChangedEventHandler:f0", 
"NotifyCollectionChangedEventArgs:f1", 
"NotifyCollectionChangedAction:f2", 
"AxisCollection:f3", 
"SeriesViewerViewManager:f4", 
"AxisTitlePosition:f5", 
"PointerTooltipStyle:f6", 
"Dictionary$2:f7", 
"IDictionary$2:f8", 
"IDictionary:f9", 
"KeyValuePair$2:ga", 
"Enumerable:gb", 
"Thread:gc", 
"ThreadStart:gd", 
"IOrderedEnumerable$1:ge", 
"SortedList$1:gf", 
"IEqualityComparer$1:gg", 
"EqualityComparer$1:gh", 
"IEqualityComparer:gi", 
"DefaultEqualityComparer$1:gj", 
"InvalidOperationException:gk", 
"BrushCollection:gl", 
"InterpolationMode:gm", 
"Random:gn", 
"ColorUtil:go", 
"CssHelper:gp", 
"CssGradientUtil:gq", 
"FontUtil:gr", 
"TileZoomTile:gs", 
"TileZoomTileInfo:gt", 
"TileZoomTileCache:gu", 
"TileZoomManager:gv", 
"RectChangedEventHandler:gw", 
"RectChangedEventArgs:gx", 
"Debug:gy", 
"TileZoomInfo:gz", 
"LinkedList$1:g0", 
"LinkedListNode$1:g1", 
"RenderSurface:g2", 
"DataContext:g3", 
"SeriesViewerComponentsFromView:g4", 
"SeriesViewerSurfaceViewer:g5", 
"Canvas:g6", 
"Panel:g7", 
"UIElementCollection:g8", 
"StackedSeriesBase:g9", 
"CategorySeries:ha", 
"MarkerSeries:hb", 
"MarkerSeriesView:hc", 
"Marker:hd", 
"MarkerTemplates:he", 
"HashPool$2:hf", 
"IHashPool$2:hg", 
"IPool$1:hh", 
"Func$1:hi", 
"Pool$1:hj", 
"IIndexedPool$1:hk", 
"MarkerType:hl", 
"SeriesVisualData:hm", 
"PrimitiveVisualDataList:hn", 
"IVisualData:ho", 
"PrimitiveVisualData:hp", 
"PrimitiveAppearanceData:hq", 
"BrushAppearanceData:hr", 
"StringBuilder:hs", 
"Environment:ht", 
"AppearanceHelper:hu", 
"LinearGradientBrushAppearanceData:hv", 
"GradientStopAppearanceData:hw", 
"SolidBrushAppearanceData:hx", 
"GeometryData:hy", 
"GetPointsSettings:hz", 
"EllipseGeometryData:h0", 
"RectangleGeometryData:h1", 
"LineGeometryData:h2", 
"PathGeometryData:h3", 
"PathFigureData:h4", 
"SegmentData:h5", 
"LineSegmentData:h6", 
"PolylineSegmentData:h7", 
"ArcSegmentData:h8", 
"PolyBezierSegmentData:h9", 
"BezierSegmentData:ia", 
"LabelAppearanceData:ib", 
"ShapeTags:ic", 
"PointerTooltipVisualDataList:id", 
"MarkerVisualDataList:ie", 
"MarkerVisualData:ig", 
"PointerTooltipVisualData:ih", 
"RectangleVisualData:ii", 
"PolygonVisualData:ij", 
"PolyLineVisualData:ik", 
"IFastItemsSource:il", 
"IFastItemColumn$1:im", 
"IFastItemColumnPropertyName:io", 
"FastItemsSourceEventArgs:ip", 
"FastItemsSourceEventAction:iq", 
"IHasCategoryModePreference:ir", 
"IHasCategoryAxis:is", 
"CategoryAxisBase:it", 
"Axis:iu", 
"AxisView:iv", 
"XamDataChart:iw", 
"GridMode:ix", 
"XamDataChartView:iy", 
"FragmentBase:iz", 
"HorizontalAnchoredCategorySeries:i0", 
"AnchoredCategorySeries:i1", 
"IIsCategoryBased:i2", 
"CategoryMode:i3", 
"ICategoryScaler:i4", 
"IScaler:i5", 
"ScalerParams:i6", 
"IBucketizer:i7", 
"IDetectsCollisions:i8", 
"IHasSingleValueCategory:i9", 
"IHasCategoryTrendline:ja", 
"IHasTrendline:jb", 
"TrendLineType:jc", 
"IPreparesCategoryTrendline:jd", 
"TrendResolutionParams:je", 
"AnchoredCategorySeriesView:jf", 
"CategorySeriesView:jg", 
"ISupportsMarkers:jh", 
"CategoryBucketCalculator:ji", 
"ISortingAxis:jj", 
"CategoryFrame:jk", 
"Frame:jl", 
"BrushUtil:jm", 
"CategoryTrendLineManagerBase:jn", 
"TrendLineManagerBase$1:jo", 
"Clipper:jp", 
"EdgeClipper:jq", 
"LeftClipper:jr", 
"BottomClipper:js", 
"RightClipper:jt", 
"TopClipper:ju", 
"Flattener:jv", 
"Stack$1:jw", 
"ReverseArrayEnumerator$1:jx", 
"SpiralTodo:jy", 
"FlattenerSettings:jz", 
"Func$4:j0", 
"SortingTrendLineManager:j1", 
"TrendFitCalculator:j2", 
"LeastSquaresFit:j3", 
"Numeric:j4", 
"TrendAverageCalculator:j5", 
"CategoryTrendLineManager:j6", 
"AnchoredCategoryBucketCalculator:j7", 
"CategoryDateTimeXAxis:j8", 
"CategoryDateTimeXAxisView:j9", 
"CategoryAxisBaseView:ka", 
"TimeAxisDisplayType:kb", 
"FastItemDateTimeColumn:kc", 
"IFastItemColumnInternal:kd", 
"FastItemColumn:ke", 
"FastReflectionHelper:kf", 
"AxisOrientation:kg", 
"AxisLabelPanelBase:kh", 
"AxisLabelPanelBaseView:ki", 
"AxisLabelSettings:kj", 
"AxisLabelsLocation:kk", 
"PropertyUpdatedEventHandler:kl", 
"PropertyUpdatedEventArgs:km", 
"PathRenderingInfo:kn", 
"LabelPosition:ko", 
"NumericAxisBase:kp", 
"NumericAxisBaseView:kq", 
"NumericAxisRenderer:kr", 
"AxisRendererBase:ks", 
"ShouldRenderHandler:kt", 
"ScaleValueHandler:ku", 
"AxisRenderingParametersBase:kv", 
"RangeInfo:kw", 
"TickmarkValues:kx", 
"TickmarkValuesInitializationParameters:ky", 
"GetGroupCenterHandler:kz", 
"GetUnscaledGroupCenterHandler:k0", 
"RenderStripHandler:k1", 
"RenderLineHandler:k2", 
"ShouldRenderLinesHandler:k3", 
"ShouldRenderContentHandler:k4", 
"RenderAxisLineHandler:k5", 
"DetermineCrossingValueHandler:k6", 
"ShouldRenderLabelHandler:k7", 
"GetLabelLocationHandler:k8", 
"TransformToLabelValueHandler:k9", 
"AxisLabelManager:la", 
"GetLabelForItemHandler:lb", 
"CreateRenderingParamsHandler:lc", 
"SnapMajorValueHandler:ld", 
"AdjustMajorValueHandler:le", 
"CategoryAxisRenderingParameters:lf", 
"LogarithmicTickmarkValues:lg", 
"LogarithmicNumericSnapper:lh", 
"Snapper:li", 
"LinearTickmarkValues:lj", 
"LinearNumericSnapper:lk", 
"AxisRangeChangedEventArgs:ll", 
"AxisRange:lm", 
"IEquatable$1:ln", 
"AutoRangeCalculator:lo", 
"NumericYAxis:lp", 
"StraightNumericAxisBase:lq", 
"StraightNumericAxisBaseView:lr", 
"NumericScaler:ls", 
"NumericScaleMode:lt", 
"LogarithmicScaler:lu", 
"NumericYAxisView:lv", 
"VerticalAxisLabelPanel:lw", 
"VerticalAxisLabelPanelView:lx", 
"TitleSettings:ly", 
"NumericAxisRenderingParameters:lz", 
"VerticalLogarithmicScaler:l0", 
"VerticalLinearScaler:l1", 
"LinearScaler:l2", 
"NumericRadiusAxis:l3", 
"NumericRadiusAxisView:l4", 
"NumericAngleAxis:l5", 
"IAngleScaler:l6", 
"NumericAngleAxisView:l7", 
"PolarAxisRenderingManager:l8", 
"ViewportUtils:l9", 
"PolarAxisRenderingParameters:ma", 
"IPolarRadialRenderingParameters:mb", 
"RadialAxisRenderingParameters:mc", 
"AngleAxisLabelPanel:md", 
"AngleAxisLabelPanelView:me", 
"Extensions:mf", 
"CategoryAngleAxis:mg", 
"CategoryAngleAxisView:mh", 
"CategoryAxisRenderer:mi", 
"LinearCategorySnapper:mj", 
"CategoryTickmarkValues:mk", 
"RadialAxisLabelPanel:ml", 
"HorizontalAxisLabelPanelBase:mm", 
"HorizontalAxisLabelPanelBaseView:mn", 
"RadialAxisLabelPanelView:mo", 
"SmartAxisLabelPanel:mp", 
"AxisExtentType:mq", 
"SmartAxisLabelPanelView:mr", 
"HorizontalAxisLabelPanel:ms", 
"CoercionInfo:mt", 
"SortedListView$1:mu", 
"ArrayUtil:mv", 
"CategoryLineRasterizer:mw", 
"UnknownValuePlotting:mx", 
"Action$5:my", 
"PenLineCap:mz", 
"CategorySeriesMarkerCollisionAvoidance:m0", 
"CategoryFramePreparer:m1", 
"CategoryFramePreparerBase:m2", 
"FramePreparer:m3", 
"ISupportsErrorBars:m4", 
"DefaultSupportsMarkers:m5", 
"DefaultProvidesViewport:m6", 
"DefaultSupportsErrorBars:m7", 
"PreparationParams:m8", 
"CategoryYAxis:m9", 
"CategoryYAxisView:na", 
"SyncSettings:nb", 
"NumericXAxis:nc", 
"NumericXAxisView:nd", 
"HorizontalLogarithmicScaler:ne", 
"HorizontalLinearScaler:nf", 
"ValuesHolder:ng", 
"LineSeries:nh", 
"LineSeriesView:ni", 
"PathVisualData:nj", 
"CategorySeriesRenderManager:nk", 
"AssigningCategoryStyleEventArgs:nl", 
"AssigningCategoryStyleEventArgsBase:nm", 
"GetCategoryItemsHandler:nn", 
"HighlightingInfo:no", 
"HighlightingState:np", 
"AssigningCategoryMarkerStyleEventArgs:nq", 
"HighlightingManager:nr", 
"SplineSeriesBase:ns", 
"SplineSeriesBaseView:nt", 
"SplineType:nu", 
"CollisionAvoider:nv", 
"SafeSortedReadOnlyDoubleCollection:nw", 
"SafeReadOnlyDoubleCollection:nx", 
"SafeEnumerable:ny", 
"AreaSeries:nz", 
"AreaSeriesView:n0", 
"LegendTemplates:n1", 
"PieChartBase:n2", 
"PieChartBaseView:n3", 
"PieChartViewManager:n4", 
"PieChartVisualData:n5", 
"PieSliceVisualDataList:n6", 
"PieSliceVisualData:n7", 
"PieSliceDataContext:n8", 
"Slice:n9", 
"SliceView:oa", 
"PieLabel:ob", 
"MouseButtonEventArgs:oc", 
"FastItemsSource:od", 
"ColumnReference:oe", 
"FastItemObjectColumn:of", 
"FastItemIntColumn:og", 
"LabelsPosition:oh", 
"LeaderLineType:oi", 
"OthersCategoryType:oj", 
"IndexCollection:ok", 
"LegendBase:ol", 
"LegendBaseView:om", 
"LegendBaseViewManager:on", 
"GradientData:oo", 
"GradientStopData:op", 
"DataChartLegendMouseButtonEventArgs:oq", 
"DataChartMouseButtonEventArgs:or", 
"ChartLegendMouseEventArgs:os", 
"ChartMouseEventArgs:ot", 
"DataChartLegendMouseButtonEventHandler:ou", 
"DataChartLegendMouseEventHandler:ov", 
"LegendVisualData:ow", 
"LegendVisualDataList:ox", 
"LegendItemVisualData:oy", 
"FunnelSliceDataContext:oz", 
"PieChartFormatLabelHandler:o0", 
"SliceClickEventHandler:o1", 
"SliceClickEventArgs:o2", 
"ItemLegend:o3", 
"ItemLegendView:o4", 
"LegendItemInfo:o5", 
"BubbleSeries:o6", 
"ScatterBase:o7", 
"ScatterBaseView:o8", 
"MarkerManagerBase:o9", 
"OwnedPoint:pa", 
"MarkerManagerBucket:pb", 
"ScatterTrendLineManager:pc", 
"NumericMarkerManager:pd", 
"CollisionAvoidanceType:pe", 
"SmartPlacer:pf", 
"ISmartPlaceable:pg", 
"SmartPosition:ph", 
"SmartPlaceableWrapper$1:pi", 
"ScatterAxisInfoCache:pj", 
"ScatterErrorBarSettings:pk", 
"ErrorBarSettingsBase:pl", 
"EnableErrorBars:pm", 
"ErrorBarCalculatorReference:pn", 
"IErrorBarCalculator:po", 
"ErrorBarCalculatorType:pp", 
"ScatterFrame:pq", 
"ScatterFrameBase$1:pr", 
"DictInterpolator$3:ps", 
"Action$6:pt", 
"SyncLink:pu", 
"IFastItemsSourceProvider:pv", 
"ChartCollection:pw", 
"FastItemsSourceReference:px", 
"SyncManager:py", 
"SyncLinkManager:pz", 
"ErrorBarsHelper:p0", 
"BubbleSeriesView:p1", 
"BubbleMarkerManager:p2", 
"SizeScale:p3", 
"BrushScale:p4", 
"ScaleLegend:p5", 
"ScaleLegendView:p6", 
"CustomPaletteBrushScale:p7", 
"BrushSelectionMode:p8", 
"ValueBrushScale:p9", 
"RingSeriesBase:qa", 
"XamDoughnutChart:qb", 
"RingCollection:qc", 
"Ring:qd", 
"RingControl:qe", 
"RingControlView:qf", 
"Arc:qg", 
"ArcView:qh", 
"ArcItem:qi", 
"SliceItem:qj", 
"Legend:qk", 
"LegendView:ql", 
"SplineFragmentBase:qm", 
"StackedFragmentSeries:qn", 
"StackedAreaSeries:qo", 
"HorizontalStackedSeriesBase:qp", 
"StackedSplineAreaSeries:qq", 
"AreaFragment:qr", 
"AreaFragmentView:qs", 
"AreaFragmentBucketCalculator:qt", 
"IStacked100Series:qu", 
"SplineAreaFragment:qv", 
"SplineAreaFragmentView:qw", 
"StackedSeriesManager:qx", 
"StackedSeriesCollection:qy", 
"StackedSeriesView:qz", 
"StackedBucketCalculator:q0", 
"StackedLineSeries:q1", 
"StackedSplineSeries:q2", 
"StackedColumnSeries:q3", 
"StackedColumnSeriesView:q4", 
"StackedColumnBucketCalculator:q5", 
"ColumnFragment:q6", 
"ColumnFragmentView:q7", 
"CategoryMarkerManager:q8", 
"LineFragment:q9", 
"LineFragmentView:ra", 
"LineFragmentBucketCalculator:rb", 
"StackedBarSeries:rc", 
"VerticalStackedSeriesBase:rd", 
"IBarSeries:re", 
"StackedBarSeriesView:rf", 
"StackedBarBucketCalculator:rg", 
"BarFragment:rh", 
"SplineFragment:ri", 
"SplineFragmentView:rj", 
"SplineFragmentBucketCalculator:rk", 
"BarSeries:rl", 
"VerticalAnchoredCategorySeries:rm", 
"BarSeriesView:rn", 
"BarTrendLineManager:ro", 
"BarTrendFitCalculator:rp", 
"BarBucketCalculator:rq", 
"CategoryTransitionInMode:rr", 
"BarFramePreparer:rs", 
"DefaultCategoryTrendlineHost:rt", 
"DefaultCategoryTrendlinePreparer:ru", 
"DefaultSingleValueProvider:rv", 
"SingleValuesHolder:rw", 
"RingSeriesBaseView:rx", 
"Nullable$1:ry", 
"RingSeriesCollection:rz", 
"SliceCollection:r0", 
"XamDoughnutChartView:r1", 
"Action$2:r2", 
"DoughnutChartVisualData:r3", 
"RingSeriesVisualDataList:r4", 
"RingSeriesVisualData:r5", 
"RingVisualDataList:r6", 
"RingVisualData:r7", 
"ArcVisualDataList:r8", 
"ArcVisualData:r9", 
"SliceVisualDataList:sa", 
"SliceVisualData:sb", 
"DoughnutChartLabelVisualData:sc", 
"HoleDimensionsChangedEventHandler:sd", 
"HoleDimensionsChangedEventArgs:se", 
"XamFunnelChart:sf", 
"IItemProvider:sg", 
"MessageHandler:sh", 
"MessageHandlerEventHandler:si", 
"Message:sj", 
"ServiceProvider:sk", 
"MessageChannel:sl", 
"MessageEventHandler:sm", 
"Queue$1:sn", 
"XamFunnelConnector:so", 
"XamFunnelController:sp", 
"SliceInfoList:sq", 
"SliceInfo:sr", 
"SliceAppearance:ss", 
"PointList:st", 
"FunnelSliceVisualData:su", 
"SliceInfoUnaryComparison:sv", 
"Bezier:sw", 
"BezierPoint:sx", 
"BezierOp:sy", 
"BezierPointComparison:sz", 
"DoubleColumn:s0", 
"ObjectColumn:s1", 
"XamFunnelView:s2", 
"IOuterLabelWidthDecider:s3", 
"IFunnelLabelSizeDecider:s4", 
"MouseLeaveMessage:s5", 
"InteractionMessage:s6", 
"MouseMoveMessage:s7", 
"MouseButtonMessage:s8", 
"MouseButtonAction:s9", 
"MouseButtonType:ta", 
"SetAreaSizeMessage:tb", 
"RenderingMessage:tc", 
"RenderSliceMessage:td", 
"RenderOuterLabelMessage:te", 
"TooltipValueChangedMessage:tf", 
"TooltipUpdateMessage:tg", 
"FunnelDataContext:th", 
"PropertyChangedMessage:ti", 
"ConfigurationMessage:tj", 
"ClearMessage:tk", 
"ClearTooltipMessage:tl", 
"ContainerSizeChangedMessage:tm", 
"ViewportChangedMessage:tn", 
"ViewPropertyChangedMessage:to", 
"OuterLabelAlignment:tp", 
"FunnelSliceDisplay:tq", 
"SliceSelectionManager:tr", 
"DataUpdatedMessage:ts", 
"ItemsSourceAction:tt", 
"FunnelFrame:tu", 
"UserSelectedItemsChangedMessage:tv", 
"LabelSizeChangedMessage:tw", 
"FrameRenderCompleteMessage:tx", 
"IntColumn:ty", 
"IntColumnComparison:tz", 
"Convert:t0", 
"SelectedItemsChangedMessage:t1", 
"ModelUpdateMessage:t2", 
"SliceClickedMessage:t3", 
"FunnelSliceClickedEventHandler:t4", 
"FunnelSliceClickedEventArgs:t5", 
"FunnelChartVisualData:t6", 
"FunnelSliceVisualDataList:t7", 
"RingSeries:t8", 
"WaterfallSeries:t9", 
"WaterfallSeriesView:ua", 
"FinancialSeries:ub", 
"FinancialSeriesView:uc", 
"FinancialBucketCalculator:ud", 
"CategoryTransitionSourceFramePreparer:ue", 
"TransitionInSpeedType:uf", 
"FinancialCalculationDataSource:ug", 
"CalculatedColumn:uh", 
"FinancialEventArgs:ui", 
"FinancialCalculationSupportingCalculations:uj", 
"ColumnSupportingCalculation:uk", 
"SupportingCalculation$1:ul", 
"SupportingCalculationStrategy:um", 
"DataSourceSupportingCalculation:un", 
"ProvideColumnValuesStrategy:uo", 
"AssigningCategoryStyleEventHandler:up", 
"FinancialValueList:uq", 
"FinancialEventHandler:ur", 
"StepLineSeries:us", 
"StepLineSeriesView:ut", 
"StepAreaSeries:uu", 
"StepAreaSeriesView:uv", 
"RangeAreaSeries:uw", 
"HorizontalRangeCategorySeries:ux", 
"RangeCategorySeries:uy", 
"IHasHighLowValueCategory:uz", 
"RangeCategorySeriesView:u0", 
"RangeCategoryBucketCalculator:u1", 
"RangeCategoryFramePreparer:u2", 
"DefaultHighLowValueProvider:u3", 
"HighLowValuesHolder:u4", 
"RangeValueList:u5", 
"RangeAreaSeriesView:u6", 
"NonCollisionAvoider:u7", 
"AxisRangeChangedEventHandler:u8", 
"DataChartAxisRangeChangedEventHandler:u9", 
"ChartAxisRangeChangedEventArgs:va", 
"ChartVisualData:vb", 
"AxisVisualDataList:vc", 
"SeriesVisualDataList:vd", 
"ChartTitleVisualData:ve", 
"VisualDataSerializer:vf", 
"AxisVisualData:vg", 
"AxisLabelVisualDataList:vh", 
"AxisLabelVisualData:vi", 
"RadialBase:vj", 
"RadialBaseView:vk", 
"RadialBucketCalculator:vl", 
"SeriesRenderer$2:vm", 
"SeriesRenderingArguments:vn", 
"RadialFrame:vo", 
"RadialAxes:vp", 
"PolarBase:vq", 
"PolarBaseView:vr", 
"PolarTrendLineManager:vs", 
"PolarLinePlanner:vt", 
"AngleRadiusPair:vu", 
"PolarAxisInfoCache:vv", 
"PolarFrame:vw", 
"PolarAxes:vx", 
"AxisComponentsForView:vy", 
"AxisComponentsFromView:vz", 
"AxisFormatLabelHandler:v0", 
"VisualExportHelper:v1", 
"ContentInfo:v2", 
"ChartContentManager:v3", 
"ChartContentType:v4", 
"RenderRequestedEventArgs:v5", 
"AssigningCategoryMarkerStyleEventHandler:v6", 
"SeriesComponentsForView:v7", 
"StackedSeriesFramePreparer:v8", 
"StackedSeriesCreatedEventHandler:v9", 
"StackedSeriesCreatedEventArgs:wa", 
"StackedSeriesVisualData:wb", 
"LabelPanelArranger:wc", 
"LabelPanelsArrangeState:wd", 
"WindowResponse:we", 
"ViewerSurfaceUsage:wf", 
"SeriesViewerComponentsForView:wg", 
"DataChartCursorEventHandler:wh", 
"ChartCursorEventArgs:wi", 
"DataChartMouseButtonEventHandler:wj", 
"DataChartMouseEventHandler:wk", 
"AnnotationLayer:wl", 
"AnnotationLayerView:wm", 
"RefreshCompletedEventHandler:wn", 
"SeriesComponentsFromView:wo", 
"EasingFunctions:wp", 
"TrendCalculators:wq", 
"CategoryXAxis:xj", 
"CategoryXAxisView:xk", 
"Stacked100BarBucketCalculator:ab9", 
"Stacked100ColumnBucketCalculator:aca", 
"Stacked100AreaSeries:acb", 
"Stacked100BarSeries:acc", 
"Stacked100BarSeriesView:acd", 
"Stacked100ColumnSeries:ace", 
"Stacked100ColumnSeriesView:acf", 
"Stacked100LineSeries:acg", 
"Stacked100SplineAreaSeries:ach", 
"Stacked100SplineSeries:aci", 
"AbstractEnumerable:acm", 
"AbstractEnumerator:acn", 
"GenericEnumerable$1:aco", 
"GenericEnumerator$1:acp"]);


$.ig.util.defType('CategoryXAxis', 'CategoryAxisBase', {
	createView: function () {
		return new $.ig.CategoryXAxisView(this);
	}
	,
	onViewCreated: function (view) {
		$.ig.CategoryAxisBase.prototype.onViewCreated.call(this, view);
		this.xView(view);
	}
	,
	_xView: null,
	xView: function (value) {
		if (arguments.length === 1) {
			this._xView = value;
			return value;
		} else {
			return this._xView;
		}
	}
	,
	init: function () {
		this.__actualMinimum = 1;
		this.__actualMaximum = 1;
		$.ig.CategoryAxisBase.prototype.init.call(this);
		this.majorLinePositions(new $.ig.List$1(Number, 0));
		this.defaultStyleKey($.ig.CategoryXAxis.prototype.$type);
	},
	__actualMinimum: 0,
	actualMinimum: function (value) {
		if (arguments.length === 1) {
			this.__actualMinimum = value;
			return value;
		} else {
			return this.__actualMinimum;
		}
	}
	,
	__actualMaximum: 0,
	actualMaximum: function (value) {
		if (arguments.length === 1) {
			this.__actualMaximum = value;
			return value;
		} else {
			return this.__actualMaximum;
		}
	}
	,
	createLabelPanel: function () {
		if (this.useSmartAxis()) {
			return new $.ig.SmartAxisLabelPanel();
		} else {
			return new $.ig.HorizontalAxisLabelPanel();
		}
	}
	,
	getCategorySize: function (windowRect, viewportRect) {
		return viewportRect.width() / (this._cachedItemsCount * windowRect.width());
	}
	,
	getGroupSize: function (windowRect, viewportRect) {
		var gap = !$.ig.util.isNaN(this.gap()) ? $.ig.MathUtil.prototype.clamp(this.gap(), 0, 1) : 0;
		var overlap = 0;
		if (!$.ig.util.isNaN(this.overlap())) {
			overlap = Math.min(this.overlap(), 1);
		} else {
			overlap = 0;
		}
		;
		var categorySpace = 1 - 0.5 * gap;
		var mode2GroupCount = this.mode2GroupCount() == 0 ? 1 : this.mode2GroupCount();
		var ret = this.getCategorySize(windowRect, viewportRect) * categorySpace / (mode2GroupCount - (mode2GroupCount - 1) * overlap);
		return ret;
	}
	,
	getGroupCenter: function (groupIndex, windowRect, viewportRect) {
		var groupCenter = 0.5;
		if (this.mode2GroupCount() > 1) {
			var gap = !$.ig.util.isNaN(this.gap()) ? $.ig.MathUtil.prototype.clamp(this.gap(), 0, 1) : 0;
			var overlap = 0;
			if (!$.ig.util.isNaN(this.overlap())) {
				overlap = Math.min(this.overlap(), 1);
			}
			var categorySpace = 1 - 0.5 * gap;
			var groupWidth = categorySpace / (this.mode2GroupCount() - (this.mode2GroupCount() - 1) * overlap);
			var groupSep = (categorySpace - groupWidth) / (this.mode2GroupCount() - 1);
			groupCenter = 0.25 * gap + 0.5 * groupWidth + groupIndex * groupSep;
		}
		return this.getCategorySize(windowRect, viewportRect) * groupCenter;
	}
	,
	scrollIntoView: function (item) {
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = this.viewportRect();
		var unitRect = new $.ig.Rect(0, 0, 0, 1, 1);
		var xParams = new $.ig.ScalerParams(unitRect, unitRect, this.isInverted());
		var index = !windowRect.isEmpty() && !viewportRect.isEmpty() && this.fastItemsSource() != null ? this.fastItemsSource().indexOf(item) : -1;
		var cx = index > -1 ? this.getScaledValue(index, xParams) : NaN;
		if (!$.ig.util.isNaN(cx) && this.seriesViewer().isSyncReady()) {
			if (!$.ig.util.isNaN(cx)) {
				if (cx < windowRect.left() + 0.1 * windowRect.width()) {
					cx = cx + 0.4 * windowRect.width();
					windowRect.x(cx - 0.5 * windowRect.width());
				}
				if (cx > windowRect.right() - 0.1 * windowRect.width()) {
					cx = cx - 0.4 * windowRect.width();
					windowRect.x(cx - 0.5 * windowRect.width());
				}
			}
			this.seriesViewer().windowNotify(windowRect, false);
		}
	}
	,
	getScaledValue: function (unscaledValue, p) {
		var itemCount = this.categoryMode() == $.ig.CategoryMode.prototype.mode0 ? this._cachedItemsCount - 1 : this._cachedItemsCount;
		if (itemCount < 0) {
			itemCount = 0;
		}
		var scaledValue = itemCount >= 1 ? (unscaledValue) / (itemCount) : itemCount == 0 ? 0.5 : NaN;
		if (this.isInvertedCached()) {
			scaledValue = 1 - scaledValue;
		}
		return p._viewportRect.left() + p._viewportRect.width() * (scaledValue - p._windowRect.left()) / p._windowRect.width();
	}
	,
	getUnscaledValue: function (scaledValue, p) {
		return this.getUnscaledValue2(scaledValue, p._windowRect, p._viewportRect, this.categoryMode());
	}
	,
	getUnscaledValue2: function (scaledValue, windowRect, viewportRect, categoryMode) {
		var unscaledValue = windowRect.left() + (scaledValue - viewportRect.left()) * windowRect.width() / viewportRect.width();
		if (this.isInvertedCached()) {
			unscaledValue = 1 - unscaledValue;
		}
		var itemCount = categoryMode == $.ig.CategoryMode.prototype.mode0 ? this._cachedItemsCount - 1 : this._cachedItemsCount;
		if (itemCount < 0) {
			itemCount = 0;
		}
		return unscaledValue * itemCount;
	}
	,
	renderAxisOverride: function (animate) {
		$.ig.CategoryAxisBase.prototype.renderAxisOverride.call(this, animate);
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = this.viewportRect();
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, this.isInverted());
		var axisGeometry = this.view().getAxisLinesGeometry();
		var stripsGeometry = this.view().getStripsGeometry();
		var majorGeometry = this.view().getMajorLinesGeometry();
		var minorGeometry = this.view().getMinorLinesGeometry();
		var axisLinesPathInfo = this.view().getAxisLinesPathInfo();
		var majorLinesPathInfo = this.view().getMajorLinesPathInfo();
		var minorLinesPathInfo = this.view().getMinorLinesPathInfo();
		var fastItemsSource = this.fastItemsSource();
		this.updateLineVisibility();
		this.clearMarks(axisGeometry);
		this.clearMarks(stripsGeometry);
		this.clearMarks(majorGeometry);
		this.clearMarks(minorGeometry);
		this.labelDataContext().clear();
		this.labelPositions().clear();
		this.majorLinePositions().clear();
		this.view().updateLabelPanel(this, windowRect, viewportRect);
		if (windowRect.isEmpty() || viewportRect.isEmpty()) {
			this.textBlocks().count(0);
		}
		if (this.textBlocks().count() == 0) {
			this.view().clearLabelPanel();
		}
		if (this.labelSettings() != null) {
			this.labelSettings().registerAxis(this);
		}
		if (this.itemsSource() == null || fastItemsSource == null || fastItemsSource.count() == 0) {
			this.textBlocks().count(0);
			this.view().clearLabelPanel();
			return;
		}
		if (!windowRect.isEmpty() && !viewportRect.isEmpty()) {
			var visibleMinimum = this.getUnscaledValue(viewportRect.left(), xParams);
			var visibleMaximum = this.getUnscaledValue(viewportRect.right(), xParams);
			if (this.isInverted()) {
				visibleMinimum = Math.ceil(visibleMinimum);
				visibleMaximum = Math.floor(visibleMaximum);
			} else {
				visibleMinimum = Math.floor(visibleMinimum);
				visibleMaximum = Math.ceil(visibleMaximum);
			}
			var crossingValue = viewportRect.bottom();
			var relativeCrossingValue = crossingValue - viewportRect.top();
			if (this.crossingAxis() != null) {
				var yAxis = $.ig.util.cast($.ig.NumericYAxis.prototype.$type, this.crossingAxis());
				if (yAxis != null) {
					var yParams = new $.ig.ScalerParams(windowRect, viewportRect, yAxis.isInverted());
					crossingValue = this.crossingValue();
					crossingValue = yAxis.getScaledValue(crossingValue, yParams);
					relativeCrossingValue = crossingValue - viewportRect.top();
					if (crossingValue < viewportRect.top()) {
						crossingValue = viewportRect.top();
					} else if (crossingValue > viewportRect.bottom()) {
						crossingValue = viewportRect.bottom();
					}
					if (relativeCrossingValue < 0) {
						relativeCrossingValue = 0;
					} else if (relativeCrossingValue > viewportRect.height()) {
						relativeCrossingValue = viewportRect.height();
					}
				}
			}
			this.horizontalLine(axisGeometry, crossingValue, viewportRect, axisLinesPathInfo);
			this.view().setLabelPanelCrossingValue(relativeCrossingValue);
			var trueVisibleMinimum = Math.min(visibleMinimum, visibleMaximum);
			var trueVisibleMaximum = Math.max(visibleMinimum, visibleMaximum);
			var snapper = new $.ig.LinearCategorySnapper(1, trueVisibleMinimum, trueVisibleMaximum, viewportRect.width(), this.interval(), this.categoryMode());
			var firstValue = Math.floor((trueVisibleMinimum - 0) / snapper.interval());
			var lastValue = Math.ceil((trueVisibleMaximum - 0) / snapper.interval());
			if (!$.ig.util.isNaN(firstValue) && !$.ig.util.isNaN(lastValue)) {
				var first = $.ig.truncate(firstValue);
				var last = $.ig.truncate(lastValue);
				var majorValue = this.getScaledValue(0 + first * snapper.interval(), xParams);
				this.view().setLabelPanelInterval(this.getScaledValue(snapper.interval(), xParams));
				var viewportPixelRight = $.ig.truncate(Math.ceil(viewportRect.right()));
				var viewportPixelLeft = $.ig.truncate(Math.floor(viewportRect.left()));
				for (var i = first; i <= last; ++i) {
					var nextMajorValue = this.getScaledValue(0 + (i + 1) * snapper.interval(), xParams);
					if (majorValue <= viewportRect.right()) {
						if (i % 2 == 0) {
							this.verticalStrip(stripsGeometry, majorValue, nextMajorValue, viewportRect);
						}
						this.verticalLine(majorGeometry, majorValue, viewportRect, majorLinesPathInfo);
						this.majorLinePositions().add(majorValue);
						if (this.categoryMode() != $.ig.CategoryMode.prototype.mode0 && this.mode2GroupCount() != 0 && this.shouldRenderMinorLines()) {
							for (var categoryNumber = 0; categoryNumber < $.ig.truncate(snapper.interval()); categoryNumber++) {
								for (var groupNumber = 0; groupNumber < this.mode2GroupCount(); groupNumber++) {
									var center = this.getGroupCenter(groupNumber, windowRect, viewportRect);
									if (this.isInverted()) {
										center = -center;
									}
									var minorValue = this.getScaledValue(categoryNumber + i * snapper.interval(), xParams) + center;
									this.verticalLine(minorGeometry, minorValue, viewportRect, minorLinesPathInfo);
								}
							}
						}
					}
					var categoryValue = majorValue;
					if (this.categoryMode() != $.ig.CategoryMode.prototype.mode0) {
						var nextCategoryValue = this.getScaledValue(i * snapper.interval() + 1, xParams);
						categoryValue = (majorValue + nextCategoryValue) / 2;
					}
					var categoryPixelValue = $.ig.truncate(Math.round(categoryValue));
					if (categoryPixelValue >= viewportPixelLeft && categoryPixelValue <= viewportPixelRight) {
						var itemIndex = 0;
						if (snapper.interval() >= 1) {
							itemIndex = i * $.ig.truncate(Math.floor(snapper.interval()));
						} else {
							if ((i * snapper.interval()) * 2 % 2 == 0) {
								itemIndex = $.ig.truncate(Math.floor(i * snapper.interval()));
							} else {
								itemIndex = -1;
							}
						}
						if (fastItemsSource != null && itemIndex < fastItemsSource.count() && itemIndex >= 0) {
							var dataItem = fastItemsSource.item(itemIndex);
							var labelText = this.getLabel(dataItem);
							if (!$.ig.util.isNaN(categoryValue) && !Number.isInfinity(categoryValue) && labelText != null) {
								if ((typeof labelText === 'string') && (labelText).equals("")) {
								} else {
									this.labelDataContext().add1(labelText);
									this.labelPositions().add(new $.ig.LabelPosition(categoryValue));
								}
							}
						}
					}
					majorValue = nextMajorValue;
				}
			}
			if ((this.labelSettings() == null || this.labelSettings().visibility() == $.ig.Visibility.prototype.visible) && this.crossingAxis() != null) {
				if (this.labelSettings() != null && (this.labelSettings().location() == $.ig.AxisLabelsLocation.prototype.insideTop || this.labelSettings().location() == $.ig.AxisLabelsLocation.prototype.insideBottom)) {
					this.seriesViewer().invalidatePanels();
				}
			}
			this.view().updateLabelPanelContent(this.labelDataContext(), this.labelPositions());
			this.renderLabels();
		}
	}
	,
	updateRangeOverride: function () {
		if (this.fastItemsSource() == null) {
			return false;
		}
		var max = this.fastItemsSource().count();
		if (max != this.actualMaximum()) {
			var ea = new $.ig.AxisRangeChangedEventArgs(1, 1, this.actualMaximum(), max);
			this.actualMaximum(max);
			this.raiseRangeChanged(ea);
			return true;
		}
		return false;
	}
	,
	interval: function (value) {
		if (arguments.length === 1) {
			this.setValue($.ig.CategoryXAxis.prototype.intervalProperty, value);
			return value;
		} else {
			return this.getValue($.ig.CategoryXAxis.prototype.intervalProperty);
		}
	}
	,
	shouldShareMode: function (chart) {
		if (chart == null) {
			return false;
		}
		var settings = this.getSyncSettings();
		if (settings == null) {
			return false;
		}
		return settings.synchronizeHorizontally();
	}
	,
	orientation: function () {
		return $.ig.AxisOrientation.prototype.horizontal;
	}
	,
	$type: new $.ig.Type('CategoryXAxis', $.ig.CategoryAxisBase.prototype.$type)
}, true);

$.ig.util.defType('CategoryXAxisView', 'CategoryAxisBaseView', {
	_xModel: null,
	xModel: function (value) {
		if (arguments.length === 1) {
			this._xModel = value;
			return value;
		} else {
			return this._xModel;
		}
	}
	,
	init: function (model) {
		$.ig.CategoryAxisBaseView.prototype.init.call(this, model);
		this.xModel(model);
	},
	$type: new $.ig.Type('CategoryXAxisView', $.ig.CategoryAxisBaseView.prototype.$type)
}, true);

$.ig.util.defType('Stacked100BarBucketCalculator', 'StackedBarBucketCalculator', {
	init: function (view) {
		$.ig.StackedBarBucketCalculator.prototype.init.call(this, view);
	},
	getBucket: function (index) {
		return $.ig.StackedBarBucketCalculator.prototype.getBucket.call(this, index);
	}
	,
	getBucket1: function (series, index, sortingIndex, windowRect, viewportRect, currentFrame) {
		var barSeries = $.ig.util.cast($.ig.StackedBarSeries.prototype.$type, this.view().categoryModel());
		var bucket = [ NaN, NaN, NaN ];
		var fragment = $.ig.util.cast($.ig.BarFragment.prototype.$type, series);
		if (fragment == null || fragment.logicalSeriesLink() == null) {
			return bucket;
		}
		var value = series.valueColumn().item(sortingIndex);
		var total = 0;
		var zero = 0;
		var min = NaN;
		var max = NaN;
		var high = Number.NEGATIVE_INFINITY;
		var low = Number.POSITIVE_INFINITY;
		var count = Math.min(barSeries.lows() != null ? barSeries.lows().length : 0, barSeries.highs() != null ? barSeries.highs().length : 0);
		var i0 = sortingIndex * this._bucketSize;
		var i1 = Math.min(i0 + this._bucketSize - 1, count - 1);
		for (var i = i0; i <= i1; ++i) {
			value = series.valueColumn().item(i);
			total = Math.abs(barSeries.lows()[i]) + barSeries.highs()[i];
			if (value < zero) {
				low = Math.min(low, (fragment.logicalSeriesLink().lowValues().__inner[i] + value) / total * 100);
				high = Math.max(high, fragment.logicalSeriesLink().lowValues().__inner[i] / total * 100);
			} else {
				low = Math.min(low, fragment.logicalSeriesLink().highValues().__inner[i] / total * 100);
				high = Math.max(high, (fragment.logicalSeriesLink().highValues().__inner[i] + value) / total * 100);
			}
			if (!$.ig.util.isNaN(min)) {
				if (!$.ig.util.isNaN(low)) {
					min = Math.min(min, low);
					max = Math.max(max, low);
				}
				if (!$.ig.util.isNaN(high)) {
					min = Math.min(min, high);
					max = Math.max(max, high);
				}
			} else {
				min = low;
				max = high;
			}
		}
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, barSeries.xAxis().isInverted());
		bucket = [ currentFrame._buckets.__inner[index - this._firstBucket][0], barSeries.xAxis().getScaledValue(max, xParams), barSeries.xAxis().getScaledValue(min, xParams) ];
		return bucket;
	}
	,
	$type: new $.ig.Type('Stacked100BarBucketCalculator', $.ig.StackedBarBucketCalculator.prototype.$type)
}, true);

$.ig.util.defType('Stacked100ColumnBucketCalculator', 'StackedColumnBucketCalculator', {
	init: function (view) {
		$.ig.StackedColumnBucketCalculator.prototype.init.call(this, view);
	},
	getBucket: function (index) {
		return $.ig.StackedColumnBucketCalculator.prototype.getBucket.call(this, index);
	}
	,
	getBucket1: function (series, index, sortingIndex, windowRect, viewportRect, currentFrame) {
		var stackedSeries = $.ig.util.cast($.ig.StackedSeriesBase.prototype.$type, this.view().categoryModel());
		var bucket = [ NaN, NaN, NaN ];
		var fragment = $.ig.util.cast($.ig.ColumnFragment.prototype.$type, series);
		if (fragment == null || fragment.logicalSeriesLink() == null) {
			return bucket;
		}
		var value = series.valueColumn().item(sortingIndex);
		var zero = 0;
		var min = NaN;
		var max = NaN;
		var high = Number.NEGATIVE_INFINITY;
		var low = Number.POSITIVE_INFINITY;
		var total = 0;
		var count = Math.min(stackedSeries.lows() != null ? stackedSeries.lows().length : 0, stackedSeries.highs() != null ? stackedSeries.highs().length : 0);
		var i0 = sortingIndex * this._bucketSize;
		var i1 = Math.min(i0 + this._bucketSize - 1, count - 1);
		for (var i = i0; i <= i1; ++i) {
			value = series.valueColumn().item(i);
			total = Math.abs(stackedSeries.lows()[i]) + stackedSeries.highs()[i];
			if (value < zero) {
				low = Math.min(low, (fragment.logicalSeriesLink().lowValues().__inner[i] + value) / total * 100);
				high = Math.max(high, fragment.logicalSeriesLink().lowValues().__inner[i] / total * 100);
			} else {
				low = Math.min(low, fragment.logicalSeriesLink().highValues().__inner[i] / total * 100);
				high = Math.max(high, (fragment.logicalSeriesLink().highValues().__inner[i] + value) / total * 100);
			}
			if (!$.ig.util.isNaN(min)) {
				if (!$.ig.util.isNaN(low)) {
					min = Math.min(min, low);
					max = Math.max(max, low);
				}
				if (!$.ig.util.isNaN(high)) {
					min = Math.min(min, high);
					max = Math.max(max, high);
				}
			} else {
				min = low;
				max = high;
			}
		}
		var yParams = new $.ig.ScalerParams(windowRect, viewportRect, fragment.yAxis().isInverted());
		bucket = [ currentFrame._buckets.__inner[index - this._firstBucket][0], fragment.yAxis().getScaledValue(max, yParams), fragment.yAxis().getScaledValue(min, yParams) ];
		return bucket;
	}
	,
	$type: new $.ig.Type('Stacked100ColumnBucketCalculator', $.ig.StackedColumnBucketCalculator.prototype.$type)
}, true);

$.ig.util.defType('Stacked100AreaSeries', 'StackedAreaSeries', {
	init: function () {
		$.ig.StackedAreaSeries.prototype.init.call(this);
		this.defaultStyleKey($.ig.Stacked100AreaSeries.prototype.$type);
	},
	onApplyTemplate: function () {
		$.ig.StackedAreaSeries.prototype.onApplyTemplate.call(this);
		this.renderSeries(false);
	}
	,
	prepareData: function () {
		$.ig.StackedAreaSeries.prototype.prepareData.call(this);
		if (this.fastItemsSource() == null) {
			return;
		}
		var min = Number.POSITIVE_INFINITY;
		var max = Number.NEGATIVE_INFINITY;
		for (var i = 0; i < this.fastItemsSource().count(); i++) {
			var total = Math.abs(this.lows()[i]) + this.highs()[i];
			if (total == 0) {
				min = Math.min(min, 0);
				max = Math.max(max, 0);
				continue;
			}
			min = Math.min(min, this.lows()[i] / total * 100);
			max = Math.max(max, this.highs()[i] / total * 100);
		}
		this.minimum(min);
		this.maximum(max);
	}
	,
	$type: new $.ig.Type('Stacked100AreaSeries', $.ig.StackedAreaSeries.prototype.$type, [$.ig.IStacked100Series.prototype.$type])
}, true);

$.ig.util.defType('Stacked100BarSeries', 'StackedBarSeries', {
	init: function () {
		$.ig.StackedBarSeries.prototype.init.call(this);
		this.defaultStyleKey($.ig.Stacked100BarSeries.prototype.$type);
	},
	onApplyTemplate: function () {
		$.ig.StackedBarSeries.prototype.onApplyTemplate.call(this);
		this.renderSeries(false);
	}
	,
	createView: function () {
		return new $.ig.Stacked100BarSeriesView(this);
	}
	,
	_stacked100BarView: null,
	stacked100BarView: function (value) {
		if (arguments.length === 1) {
			this._stacked100BarView = value;
			return value;
		} else {
			return this._stacked100BarView;
		}
	}
	,
	onViewCreated: function (view) {
		$.ig.StackedBarSeries.prototype.onViewCreated.call(this, view);
		this.stacked100BarView(view);
	}
	,
	getSeriesView: function () {
		return this.stacked100BarView();
	}
	,
	prepareData: function () {
		$.ig.StackedBarSeries.prototype.prepareData.call(this);
		if (this.fastItemsSource() == null) {
			return;
		}
		var min = Number.POSITIVE_INFINITY;
		var max = Number.NEGATIVE_INFINITY;
		for (var i = 0; i < this.fastItemsSource().count(); i++) {
			var total = Math.abs(this.lows()[i]) + this.highs()[i];
			if (total == 0) {
				min = Math.min(min, 0);
				max = Math.max(max, 0);
				continue;
			}
			min = Math.min(min, this.lows()[i] / total * 100);
			max = Math.max(max, this.highs()[i] / total * 100);
		}
		this.minimum(min);
		this.maximum(max);
	}
	,
	$type: new $.ig.Type('Stacked100BarSeries', $.ig.StackedBarSeries.prototype.$type, [$.ig.IStacked100Series.prototype.$type])
}, true);

$.ig.util.defType('Stacked100BarSeriesView', 'StackedBarSeriesView', {
	_stacked100BarModel: null,
	stacked100BarModel: function (value) {
		if (arguments.length === 1) {
			this._stacked100BarModel = value;
			return value;
		} else {
			return this._stacked100BarModel;
		}
	}
	,
	init: function (model) {
		$.ig.StackedBarSeriesView.prototype.init.call(this, model);
		this.stacked100BarModel(model);
	},
	createBucketCalculator: function () {
		return new $.ig.Stacked100BarBucketCalculator(this);
	}
	,
	$type: new $.ig.Type('Stacked100BarSeriesView', $.ig.StackedBarSeriesView.prototype.$type)
}, true);

$.ig.util.defType('Stacked100ColumnSeries', 'StackedColumnSeries', {
	init: function () {
		$.ig.StackedColumnSeries.prototype.init.call(this);
		this.defaultStyleKey($.ig.Stacked100ColumnSeries.prototype.$type);
	},
	onApplyTemplate: function () {
		$.ig.StackedColumnSeries.prototype.onApplyTemplate.call(this);
		this.renderSeries(false);
	}
	,
	createView: function () {
		return new $.ig.Stacked100ColumnSeriesView(this);
	}
	,
	_stacked100ColumnView: null,
	stacked100ColumnView: function (value) {
		if (arguments.length === 1) {
			this._stacked100ColumnView = value;
			return value;
		} else {
			return this._stacked100ColumnView;
		}
	}
	,
	onViewCreated: function (view) {
		$.ig.StackedColumnSeries.prototype.onViewCreated.call(this, view);
		this.stacked100ColumnView(view);
	}
	,
	getSeriesView: function () {
		return this.stacked100ColumnView();
	}
	,
	prepareData: function () {
		$.ig.StackedColumnSeries.prototype.prepareData.call(this);
		if (this.fastItemsSource() == null) {
			return;
		}
		var min = Number.POSITIVE_INFINITY;
		var max = Number.NEGATIVE_INFINITY;
		for (var i = 0; i < this.fastItemsSource().count(); i++) {
			var total = Math.abs(this.lows()[i]) + this.highs()[i];
			if (total == 0) {
				min = Math.min(min, 0);
				max = Math.max(max, 0);
				continue;
			}
			min = Math.min(min, this.lows()[i] / total * 100);
			max = Math.max(max, this.highs()[i] / total * 100);
		}
		this.minimum(min);
		this.maximum(max);
	}
	,
	$type: new $.ig.Type('Stacked100ColumnSeries', $.ig.StackedColumnSeries.prototype.$type, [$.ig.IStacked100Series.prototype.$type])
}, true);

$.ig.util.defType('Stacked100ColumnSeriesView', 'StackedColumnSeriesView', {
	_stacked100ColumnModel: null,
	stacked100ColumnModel: function (value) {
		if (arguments.length === 1) {
			this._stacked100ColumnModel = value;
			return value;
		} else {
			return this._stacked100ColumnModel;
		}
	}
	,
	init: function (model) {
		$.ig.StackedColumnSeriesView.prototype.init.call(this, model);
		this.stacked100ColumnModel(model);
	},
	createBucketCalculator: function () {
		return new $.ig.Stacked100ColumnBucketCalculator(this);
	}
	,
	$type: new $.ig.Type('Stacked100ColumnSeriesView', $.ig.StackedColumnSeriesView.prototype.$type)
}, true);

$.ig.util.defType('Stacked100LineSeries', 'StackedLineSeries', {
	init: function () {
		$.ig.StackedLineSeries.prototype.init.call(this);
		this.defaultStyleKey($.ig.Stacked100LineSeries.prototype.$type);
	},
	onApplyTemplate: function () {
		$.ig.StackedLineSeries.prototype.onApplyTemplate.call(this);
		this.renderSeries(false);
	}
	,
	prepareData: function () {
		$.ig.StackedLineSeries.prototype.prepareData.call(this);
		if (this.fastItemsSource() == null) {
			return;
		}
		var min = Number.POSITIVE_INFINITY;
		var max = Number.NEGATIVE_INFINITY;
		for (var i = 0; i < this.fastItemsSource().count(); i++) {
			var total = Math.abs(this.lows()[i]) + this.highs()[i];
			if (total == 0) {
				min = Math.min(min, 0);
				max = Math.max(max, 0);
				continue;
			}
			min = Math.min(min, this.lows()[i] / total * 100);
			max = Math.max(max, this.highs()[i] / total * 100);
		}
		this.minimum(min);
		this.maximum(max);
	}
	,
	$type: new $.ig.Type('Stacked100LineSeries', $.ig.StackedLineSeries.prototype.$type, [$.ig.IStacked100Series.prototype.$type])
}, true);

$.ig.util.defType('Stacked100SplineAreaSeries', 'StackedSplineAreaSeries', {
	init: function () {
		$.ig.StackedSplineAreaSeries.prototype.init.call(this);
		this.defaultStyleKey($.ig.Stacked100SplineAreaSeries.prototype.$type);
	},
	onApplyTemplate: function () {
		$.ig.StackedSplineAreaSeries.prototype.onApplyTemplate.call(this);
		this.renderSeries(false);
	}
	,
	prepareData: function () {
		$.ig.StackedSplineAreaSeries.prototype.prepareData.call(this);
		if (this.fastItemsSource() == null) {
			return;
		}
		var min = Number.POSITIVE_INFINITY;
		var max = Number.NEGATIVE_INFINITY;
		for (var i = 0; i < this.fastItemsSource().count(); i++) {
			var total = Math.abs(this.lows()[i]) + this.highs()[i];
			if (total == 0) {
				min = Math.min(min, 0);
				max = Math.max(max, 0);
				continue;
			}
			min = Math.min(min, this.lows()[i] / total * 100);
			max = Math.max(max, this.highs()[i] / total * 100);
		}
		this.minimum(min);
		this.maximum(max);
	}
	,
	$type: new $.ig.Type('Stacked100SplineAreaSeries', $.ig.StackedSplineAreaSeries.prototype.$type, [$.ig.IStacked100Series.prototype.$type])
}, true);

$.ig.util.defType('Stacked100SplineSeries', 'StackedSplineSeries', {
	init: function () {
		$.ig.StackedSplineSeries.prototype.init.call(this);
		this.defaultStyleKey($.ig.Stacked100SplineSeries.prototype.$type);
	},
	onApplyTemplate: function () {
		$.ig.StackedSplineSeries.prototype.onApplyTemplate.call(this);
		this.renderSeries(false);
	}
	,
	prepareData: function () {
		$.ig.StackedSplineSeries.prototype.prepareData.call(this);
		if (this.fastItemsSource() == null) {
			return;
		}
		var min = Number.POSITIVE_INFINITY;
		var max = Number.NEGATIVE_INFINITY;
		for (var i = 0; i < this.fastItemsSource().count(); i++) {
			var total = Math.abs(this.lows()[i]) + this.highs()[i];
			if (total == 0) {
				min = Math.min(min, 0);
				max = Math.max(max, 0);
				continue;
			}
			min = Math.min(min, this.lows()[i] / total * 100);
			max = Math.max(max, this.highs()[i] / total * 100);
		}
		this.minimum(min);
		this.maximum(max);
	}
	,
	$type: new $.ig.Type('Stacked100SplineSeries', $.ig.StackedSplineSeries.prototype.$type, [$.ig.IStacked100Series.prototype.$type])
}, true);

$.ig.CategoryXAxis.prototype._intervalPropertyName = "Interval";
$.ig.CategoryXAxis.prototype.intervalProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryXAxis.prototype._intervalPropertyName, Number, $.ig.CategoryXAxis.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	(sender).raisePropertyChanged($.ig.CategoryXAxis.prototype._intervalPropertyName, e.oldValue(), e.newValue());
	(sender).renderAxis1(false);
}));

} (jQuery));


