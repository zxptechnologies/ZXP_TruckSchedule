﻿
/*!@license
 * Infragistics.Web.ClientUI Tree Grid 15.1.20151.2352
 *
 * Copyright (c) 2011-2015 Infragistics Inc.
 *
 * http://www.infragistics.com/
 *
 * Depends on:
 *	jquery-1.4.4.js
 *	jquery.ui.core.js
 *	jquery.ui.widget.js
 *	infragistics.dataSource.js
 *	infragistics.ui.shared.js
 *	infragistics.ui.treegrid.js
 *	infragistics.util.js
 *	infragistics.ui.grid.framework.js
 *	infragistics.ui.grid.filtering.js
 */

/*global jQuery */
if (typeof jQuery !== "function") {
	throw new Error("jQuery is undefined");
}
(function ($) {
	var _aNull = function (val) { return val === null || val === undefined; };
	/*
		igTreeGridFiltering widget. The widget is pluggable to the element where the treegrid is instantiated and the actual igTreeGrid object doesn't know about this
		the filtering widget just attaches its functionality to the treegrid
		igTreeGridFiltering is extending igGrid Filtering
	*/
	$.widget("ui.igTreeGridFiltering", $.ui.igGridFiltering, {
		css: {
			/* classes applied to the row that matches filtering condition */
			recordMatchFiltering: 'ig-igtreegrid-filter-matching-row',
			/*classes applied to the cell that matches the filtering condition */
			cellMatchFiltering: 'ig-igtreegrid-filter-matching-cell',
			/* classes applied to the row that does not match filtering condition */
			recordNotMatchFiltering: 'ui-igtreegrid-record-not-matchfiltering'
		},
		options: {
				/* type="number" specifies from which data bound level to be applied filtering - 0 is the first level */
				fromLevel: 0,
				/* type="number" specifies to which data bound level to be applied filtering - if -1 filtering should be applied to the last data bound level*/
				toLevel: -1,
				/* type="showWithAncestors|showWithAncestorsAndDescendants" If displayMode is showWithAncestorsAndDescendants, show all records that match filtering conditions and their child records, even if child records don't match filtering conditions. If displayMode is showWithAncestors show only those records that match filtering conditions and do not show child records(if any) that don't match filtering conditions */
				displayMode: 'showWithAncestors',
				/* type="string" Specifies the name of a boolean property in the dataRecord object that indicates whether the dataRow matches the filtering conditions. 
				When filtering a boolean flag  with the specified name is added on each data record object with a value of true if it matches the condition or false if it doesn't. 
				This is used mainly for internal purposes.*/
				matchFiltering: "__matchFiltering"
		},
		_create: function () {
			this.element.data($.ui.igGridFiltering.prototype.widgetName, this.element.data($.ui.igTreeGridFiltering.prototype.widgetName));
			$.ui.igGridFiltering.prototype._create.apply(this, arguments);
		},
		_transformCss: function (cssClass, dataRow) {
			var matchFiltering, grid = this.grid, ds = grid.dataSource;
			if (this._gridTransformCssCallback) {
				cssClass = this._gridTransformCssCallback.apply(grid, arguments);
			}
			if (this._filteringApplied()) {
				matchFiltering = ds.settings.treeDS.filtering.matchFiltering;
				if (cssClass !== '') {
					cssClass += ' ';
				}
				if (!_aNull(matchFiltering)) {
					if (dataRow[matchFiltering]) {
						cssClass += this.css.recordMatchFiltering;
					} else {
						cssClass += this.css.recordNotMatchFiltering;
					}
				}
			}
			return cssClass;
		},
		_filteringApplied: function () {
			// returns whether filtering is applied
			var ds = this.grid.dataSource, expr = ds.settings.filtering.expressions;
			if (this.options.type === 'local') {
				return ds._filter;
			}
			return expr && expr.length;
		},
		getFilteringMatchesCount: function () {
			/* returns the count of data records that match filtering conditions
			returnType="number" count of filtered records
			*/
			var o = this.options, ds = this.grid.dataSource, matches;
			if (o.type === "local" || (o.type === "remote" && ds.hasTotalRecordsCount() === false)) {
				if (ds._filter) {
					//matches = this.grid.dataSource.dataView().length; // this should be used when applyToAllData = false
					matches = ds.getFilteredRecordsCount();
				} else {
					matches = ds.flatDataView().length;
				}
				// we need that when, say, both paging and filtering are enabled, and both are remote
			} else {
				matches = ds.totalRecordsCount();
			}
			return matches;
		},
		destroy: function () {
			$.ui.igGridFiltering.prototype.destroy.apply(this, arguments);
			this.element.removeData($.ui.igGridFiltering.prototype.widgetName);
		},
		_injectGrid: function (gridInstance, isRebind) {
			var ds, fDSSettings = this.options;
			$.ui.igGridFiltering.prototype._injectGrid.apply(this, arguments);
			if (!isRebind) {
				if (this.grid._transformCssCallback) {
					this._gridTransformCssCallback = this.grid._transformCssCallback;
				}
				this.grid._transformCssCallback = $.proxy(this._transformCss, this);
			}
			ds = this.grid.dataSource;
			if (ds && ds.settings && ds.settings.treeDS) {
				ds.settings.filtering.enabled = true;
				ds.settings.treeDS.filtering.fromLevel = fDSSettings.fromLevel;
				ds.settings.treeDS.filtering.toLevel = fDSSettings.toLevel;
				ds.settings.treeDS.filtering.displayMode = fDSSettings.displayMode;
				ds.settings.treeDS.filtering.matchFiltering = fDSSettings.matchFiltering;
			}
		}
	});
	$.extend($.ui.igTreeGridFiltering, { version: '15.1.20151.2352' });
}(jQuery));


