﻿/*!@license
* Infragistics.Web.ClientUI Tree Grid localization resources 15.1.20151.2352
*
* Copyright (c) 2011-2015 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/

/*global jQuery */
(function ($) {
    $.ig = $.ig || {};

    if (!$.ig.TreeGrid) {
        $.ig.TreeGrid = {};

        $.extend($.ig.TreeGrid, {
            locale: {
            	fixedVirtualizationNotSupported: "Row Virtualization requires a different virtualizationMode setting. The virtualizationMode should be set to 'continuous'."
            }
        });
    }
})(jQuery);

/*!@license
 * Infragistics.Web.ClientUI Tree Grid 15.1.20151.2352
 *
 * Copyright (c) 2011-2015 Infragistics Inc.
 *
 * http://www.infragistics.com/
 *
 * Depends on:
 *	jquery-1.4.4.js
 *	jquery.ui.core.js
 *	jquery.ui.widget.js
 *	infragistics.dataSource.js
 *	infragistics.ui.shared.js
 *	infragistics.util.js
 *	infragistics.ui.grid.framework.js
 */

/*global jQuery, MSApp */
/*jshint -W106 */
(function ($) {
	var _aNull = function (val) { return val === null || val === undefined; };
	$.widget("ui.igTreeGrid", $.ui.igGrid, {
		css: {
			/* class applied to root DOM element container for the grid */
			containerClasses: "ui-igtreegrid",
			/* classes applied to the expander span element, when the row is expanded */
			expandCellExpanded: "ui-icon ui-igtreegrid-expansion-indicator ui-icon-minus",
			/* classes applied to the expansion indicator SPAN when the row is collapsed */
			expandCellCollapsed: "ui-icon ui-igtreegrid-expansion-indicator ui-icon-plus",
			/* class applied to the expansion indicator's TD element of the when renderExpansionIndicatorColumn is set to true */
			dataSkipCell: "ui-igtreegrid-non-data-column",
			/* class applied to the TD element that contains the expansion indicator */
			expandColumn: "ui-igtreegrid-expansion-indicator-cell",
			/* class applied to data cell of the expansion indicator container */
			dataColumnExpandContainer: "ui-igtreegrid-expansion-indicator-container",
			/*class applied to the expansion indicator container if the expansion column is rendered in the grid. */
			expandColumnContainer: "ui-igtreegrid-expansion-column-container",
			/* class applied to the element (in the non-data-cell) holding expansion indicator column - applied only when renderExpansionIndicatorColumn is false. */
			expandContainer: "ui-igtreegrid-expandcell",
			/* class applied to the expansion indicator column's TH element if renderExpansionIndicatorColumn is set to true */
			expandHeaderCell: "ui-igtreegrid-expansion-indicator-header-cell ui-iggrid-header ui-widget-header",
			/* classes applied to the data row. For instance if a row is part of the root level (at index 0) then the class of ui-igtreegrid-rowlevel0 is applied to the row. The numbered suffix in the class name changes to reflect the grid row's index. */
			rowLevel: "ui-igtreegrid-rowlevel"
		},
		options: {
			/* type="string" Specifies the indentation (in pixels or percent) for a tree grid row. Nested indentation is achieved by calculating the level times the indentation value. Ex: '10px' or '5%'. Default is 30. */
			indentation: 30,
			/* type="number" if initial indentation level is set then it is used to be calculated width of the data skip column(usually used when remote load on demand is enabled)*/
			initialIndentationLevel: -1,
			/* type="bool" Specifies if rows(that have child rows) will have an expander image that will allow end users to expand and collapse them. This option can be set only at initialization. */
			showExpansionIndicator: true,
			/* type="string" Specifies the expansion indicator tooltip text. */
			expandTooltipText: $.ig.Grid.locale.expandTooltip,
			/* type="string" Specifies the collapse indicator tooltip text.*/
			collapseTooltipText: $.ig.Grid.locale.collapseTooltip,
			/* type="string" Unique identifier used in a self-referencing flat data source. Used with primaryKey to create a relationship among flat data sources. */
			foreignKey: null,
			/* type="number" Specifies the depth down to which the tree grid would be expanded upon initial render. To expand all rows set value to -1. Default is -1. */
			initialExpandDepth: -1,
			/* type="number"      Specifies the foreign key value in the data source to treat as the root level once the grid is data bound. Defaults to -1 (which includes the entire data source) */
			foreignKeyRootValue: -1,
			/* type="bool" Specify whether to render non-data column which contains expander indicators */
			renderExpansionIndicatorColumn: false,
			/* type="string|object" a reference or name of a javascript function which changes first data cell - renders indentation according to databound level */
			renderFirstDataCellFunction: null,
			/* type="string" Property name of the array of child data in a hierarchical data source.*/
			childDataKey: "childData",
			/* type="string|object" a reference or name of a javascript function which renders expand indicators(called ONLY IF option renderExpansionIndicatorColumn is true) */
			renderExpansionCellFunction: null,
			/*Specifies to the tree grid if data is loaded on demand from a remote server. Default is false. */
			enableRemoteLoadOnDemand: false,
			/* type="object" Options object to configure data source-specific settings*/
			dataSourceSettings: {
				/* The name of the property that keeps track of the expansion state of a data item. Defaults to __ig_options.expanded.*/
				propertyExpanded: "__ig_options.expanded",
				/* The name of the property that keeps track of the level in the hierarchy.Defaults to __ig_options.dataLevel.*/
				propertyDataLevel: "__ig_options.dataLevel"
			}
		},
		events: {
			/* cancel="true" Fired when a row is about to be expanded.
				use args.owner to access the instance of the igTreeGrid
				use args.row to access the row element (as a wrapped jQuery object) that is about to be expanded
				use args.fixedRow to access the row element (as a jQuery wrapped object) in a fixed column that is about to expanded. If there are no fixed columns then this property returns undefined.
				use args.dataLevel to access the level in the hierarchy associated with the row
			*/
			rowExpanding: "rowExpanding",
			/* Fired when a row is expanded.
				use args.owner to access the instance of the igTreeGrid
				use args.row to access the row element (as a wrapped jQuery object) that is about to be expanded
				use args.fixedRow to access the row element (as a jQuery wrapped object) in a fixed column that is about to expanded. If there are no fixed columns then this property returns undefined.
				use args.dataLevel to access the level in the hierarchy associated with the row
				use args.dataRecord to access the source data record
			*/
			rowExpanded: "rowExpanded",
			/* cancel="true" Fired when a row is about to be collapsed.
				use args.owner to access the instance of the igTreeGrid
				use args.row to access the row element (as a wrapped jQuery object) that is about to be expanded
				use args.fixedRow to access the row element (as a jQuery wrapped object) in a fixed column that is about to expanded. If there are no fixed columns then this property returns undefined.
				use args.dataLevel to access the level in the hierarchy associated with the row
			*/
			rowCollapsing: "rowCollapsing",
			/* Fired after a row is collapsed
				use args.owner to access the instance of the igTreeGrid
				use args.row to access the row element (as a wrapped jQuery object) that is about to be expanded
				use args.fixedRow to access the row element (as a jQuery wrapped object) in a fixed column that is about to expanded. If there are no fixed columns then this property returns undefined.
				use args.dataLevel to access the level in the hierarchy associated with the row
				use args.dataRecord to access the source data record
			*/
			rowCollapsed: "rowCollapsed"
		},
		/* type="bool" if false data source is flat with self-referencing data. */
		_isHierarchicalDataSource: true,
		_create: function () {
			this._checkForUnsoppertedScenarios();
			var func = this.options.renderFirstDataCellFunction;
			if (func && $.type(func) !== "function") {
				if (window[func] && typeof window[func] === 'function') {
					func = window[func];
				}
			}
			if (func && $.type(func) === "function") {
				this._renderFirstDataCellHandler = func;
			} else {
				this._renderFirstDataCellHandler = $.proxy(this._renderFirstDataCell, this);
			}
			func = this.options.renderExpansionCellFunction;
			if (func && $.type(func) !== "function") {
				if (window[func] && typeof window[func] === 'function') {
					func = window[func];
				}
			}
			if (func && $.type(func) === "function") {
				this._renderExpandCellHandler = func;
			} else {
				this._renderExpandCellHandler = $.proxy(this._renderExpandCell, this);
			}
			// in grid features for binding to events it is used iggrid as widgetEventName - e.g. this.elememnt.bind('iggridheaderrendered')
			// now for binding to client events it should be used igTreeGrid - e.g. this.element.bind('igtreegridheaderrendered').
			// to not re-write each igGridFeaure we will re-write this.element.bind and this.element.unbind

			this._overrideFunction('bind');
			this._overrideFunction('unbind');
			this._attachEvents();
			this.element.data($.ui.igGrid.prototype.widgetName, this.element.data($.ui.igTreeGrid.prototype.widgetName));
			$.ui.igGrid.prototype._create.apply(this, arguments);
		},
		_checkForUnsoppertedScenarios: function () {
			if (this._rowVirtualizationEnabled() &&
				this.options.virtualizationMode === 'fixed') {
				throw new Error($.ig.TreeGrid.locale.fixedVirtualizationNotSupported);
			}
		},
		_wrapElementDiv: function () {
			$.ui.igGrid.prototype._wrapElementDiv.apply(this, arguments);
			this.element.data($.ui.igTreeGrid.prototype.widgetName, this);
			// when igGrid is instantiated on DIV then this.element is referencing inner data table - binding should be applied to the NEW this.element
			this._overrideFunction('bind');
			this._overrideFunction('unbind');
		},
		_removeOverridenFunction: function () {
			if (!this._functionsOverriden) {
				return;
			}
			var f, funcs = this._functionsOverriden;
			for (f in funcs) {
				if (funcs.hasOwnProperty(f)) {
					this.element[f] = funcs[f];
				}
			}
			delete this._functionsOverriden;
		},
		_overrideFunction: function (functionName) {
			// igGrid features are binding to the grid events using igGrid event namespace but in case of igTreeGrid the event name space is igTreeGrid
			// for now a workaround is to override function bind(of this.element) - better solution 
			// TO DO: USE event namespace when binding to grid events in igGrid features
			var e = this.element, func;
			if ($.type(e[functionName]) !== 'function') {
				return;
			}
			if (!this._functionsOverriden) {
				this._functionsOverriden = {};
			}
			func = e[functionName];
			if (!this._functionsOverriden[functionName]) {
				this._functionsOverriden[functionName] = func;
			}
			e[functionName] = function (name, arg1, arg2) {
				var strIgGrid = 'iggrid', argsLen = arguments.length;
				if ($.type(name) === 'string' &&
						name.indexOf(strIgGrid) === 0 && name.length > strIgGrid.length &&
						(argsLen === 2 || argsLen === 3)) {
					name = 'igtreegrid' + name.substr(strIgGrid.length);
					if (argsLen === 2) {
						return func.call(e, name, arg1);
					}
					return func.call(e, name, arg1, arg2);
				}
				return func.apply(e, arguments);
			};
		},
		dataBind: function () {
			if (!this._initialized) {
				this._renderExtraHeaderCellHandler = $.proxy(this._renderExtraHeaderCells, this);
				this._renderExtraFooterCellHandler = $.proxy(this._renderExtraFooterCells, this);
				this._headerInitCallbacks.push({ type: "TreeGrid", func: this._renderExtraHeaderCellHandler });
				this._footerInitCallbacks.push({ type: "TreeGrid", func: this._renderExtraFooterCellHandler });
			}
			$.ui.igGrid.prototype.dataBind.apply(this, arguments);
		},
		_generateDataSourceOptions: function () {
			var o = this.options, ds = o.dataSource, instanceOfDs, tds,
				opts = $.ui.igGrid.prototype._generateDataSourceOptions.apply(this, arguments);

			opts.treeDS = {
				childDataKey: o.childDataKey,
				initialExpandDepth: o.initialExpandDepth,
				foreignKey: o.foreignKey,
				key: o.primaryKey,
				foreignKeyRootValue: o.foreignKeyRootValue
			};
			opts.treeDS = $.extend(opts.treeDS, o.dataSourceSettings);
			opts.treeDS.enableRemoteLoadOnDemand = o.enableRemoteLoadOnDemand;
			opts.treeDS.dataSourceUrl = o.dataSourceUrl;
			//M.K. 2/13/2015 Fix for bug 189157: When only DataSourceUrl is set via the MVC wrapper Load On Demand requests are incorrect
			if (o.dataSourceUrl === null && typeof(ds) === "string") {
				opts.treeDS.dataSourceUrl = ds;
			}

			instanceOfDs = ds &&
					typeof ds._xmlToArray === "function" &&
					typeof ds._encodePkParams === "function";
			if (instanceOfDs) {
				// instance of tree hierarchical datasource
				if (ds._isHierarchicalDataSource !== undefined) {
					ds.settings.treeDS = ds.settings.treeDS || {};
					ds.settings.treeDS = $.extend(ds.settings.treeDS, opts.treeDS);
				} else {
					if ($.type(ds.settings.dataSource) === "array" || $.type(ds.settings.dataSource) === "object") {
						tds = ds.settings.dataSource;
					} else if ($.type(ds.settings.dataSource) !== "string") {
						tds = ds.data();
					} else {
						tds = [];
					}
					ds.settings.dataSource = null;
					ds.settings.data = null;
					if (opts && opts.dataSource) {
						opts.dataSource = null;
					}
					opts = $.extend(true, {}, ds.settings, opts);
					opts.dataSource = tds;
					tds = null;
					o.dataSource = new $.ig.TreeHierarchicalDataSource(opts);
				}
			} else {
				opts.dataSource = ds;
			}
			if (o.dataSourceType !== null) {
				opts.type = o.dataSourceType;
			}
			return opts;
		},
		_getDataColumns: function (cols) {
			var i, j, res = [], colsLength = cols.length, dCols;

			for (i = 0; i < colsLength; i++) {
				if (cols[i].group !== undefined && cols[i].group !== null) {
					dCols = this._getDataColumns(this._getDataColumns(cols[i].group));
					for (j = 0; j < dCols.length; j++) {
						res.push(dCols[j]);
					}
				} else {
					res.push(cols[i]);
				}
			}
			return res;
		},
		_generateDataSourceSchema: function () {
			var schema, i, j, rec, prop, cols = this._getDataColumns(this.options.columns), k, c, ds = this.options.dataSource;
			// generate top level schema
			if (cols.length > 0 && !this.options.autoGenerateColumns) {
				// if autoGenerateColumns is true, fields for all columns in the data source must be specified
				schema = {};
				schema.fields = [];
				j = 0;
				for (i = 0; i < cols.length; i++) {
					// M.H. 4 Sep 2012 Fix for bug #120414
					if (cols[i].unbound === true) {
						continue;
					}
					schema.fields[j] = {};
					schema.fields[j].name = cols[i].key;
					schema.fields[j].type = cols[i].dataType;
					j++;
				}
				schema.searchField = this.options.responseDataKey;
			} else if (this.options.autoGenerateColumns) {
				schema = {};
				schema.fields = [];
				if (this.options.dataSource && this.options.dataSource.length && this.options.dataSource.length > 0 &&
						$.type(this.options.dataSource) === "array") {
					rec = this.options.dataSource[0];
					for (prop in rec) {
						if (rec.hasOwnProperty(prop)) {
							// if the column isn't already defined in the columns collection
							for (k = 0; k < cols; k++) {
								if (cols[k].key === prop) {
									c = cols[k];
									break;
								}
							}
							if (_aNull(c)) {
								schema.fields.push({ name: prop, type: $.ig.getColType(rec[prop]) });
							} else {
								// M.H. 4 Sep 2012 Fix for bug #120414
								if (c.unbound === true) {
									continue;
								}
								schema.fields.push({ name: prop, type: c.dataType });
							}
							//count++;
						}
					}
				}
			}
			this._trigger(this.events.schemaGenerated, null, { owner: this, schema: schema, dataSource: ds });
			return schema;
		},
		_createDataSource: function (dataOptions) {
			var ds = this.options.dataSource, currentDataSource;
			if (!ds ||
				typeof ds._xmlToArray !== "function" ||
				typeof ds._encodePkParams !== "function") {
				currentDataSource = new $.ig.TreeHierarchicalDataSource(dataOptions);
			} else {
				currentDataSource = $.ui.igGrid.prototype._createDataSource.apply(this, arguments);
				}
				return currentDataSource;
		},
		_renderRecords: function (start, end) {
			var tbody = this.element.children("tbody"), html, ds, ph, noCancelInternal = true,
				noCancel = true, tbodytmp, fh = false;
			noCancelInternal = this._trigger("_rowsRendering", null, { owner: this, tbody: tbody, vrtWnd: { start: start, end: end } });
			if (noCancelInternal) {
				noCancel = this._trigger(this.events.rowsRendering, null, { owner: this, tbody: tbody, vrtWnd: { start: start, end: end } });
				if (noCancel) {
					this._indent = parseInt(this.options.indentation, 10);
					if (this._isMultiColumnGrid) {
						this._colspan = this.container().find("#" + this.id() + " colgroup:first>col").length - 1;
					} else {
						if (this.options.showHeader) {
							this._colspan = this.container().find("#" + this.id() + (fh === true ? "_headers" : "") + " thead>tr:first")
								.children("th:not(.ui-iggrid-expandheadercellgb)").length;
						} else {
							this._colspan = this.container().find("#" + this.id() + " colgroup:first>col").length - 1;
						}
					}
					if (_aNull(this._dataBoundDepth)) {
						this._dataBoundDepth = this.dataSource.getDataBoundDepth();
					}
					ds = this.dataSource.flatDataView();
					html = this._renderRecordsByFlatDataView(ds, false, start, end);
					//	html = this._renderRecordsPerLayout(0, ds, 0, ds.length - 1, false);
					if (this.options.renderExpansionIndicatorColumn) {
						this._addDataSkipColumn();
					}
					if (!this._canreplaceinner || $.ig.util.isWebKit) { // Chrome is a special case, with it innerHTML is actually slower 
						ph = document.createElement("div");
						ph.innerHTML = "<table><tbody>" + html + "</tbody></table>";
						tbodytmp = ph.firstChild.firstChild;
						this.element[0].replaceChild(tbodytmp, tbody[0]);
					} else if (this._canreplaceinner) {
						MSApp.execUnsafeLocalFunction(function () {
							tbody[0].innerHTML = html;
						});
					}
					html = "";
					//_virtualDom should be built because features like selection expects it
					this._buildVirtualDomForContinuousVirtualization();
					if (!this.options.renderExpansionIndicatorColumn) {
						this._stopPropagationgForExpandCellIndicators();
					}
					this._trigger(this.events.rowsRendered, null, { owner: this, tbody: tbody });
				}
			}
		},
		_stopPropagationgForExpandCellIndicators: function () {
			// if we try with delegate and feature Updating is enabled then clicking on expand button will first toggle layout and then will enter in edit mode
			// because first is called click of the updating(which cancel propagation of the event) - that's why we should bind to click event
			var $exp = this.container().find("span[data-expandcell-indicator]");
			$exp.unbind("click.expanders")
				.bind("click.expanders", function (e) { e.stopPropagation(); });
		},
		/* Virtualization support */
		// continuous support
		_getTotalRowCount: function () {
			return this._getDataView().length;
		},
		_getDataView: function () {
			return this.dataSource.flatDataView();
		},
		_renderVirtualRecordsContinuous: function (from) {
			//when expand/collapse rows we need to re-build virtual rows, re-calculate average row height. 
			// But when using _renderVirtualRecordsContinuous of the igGrid framework the scrolling position is reset to 0.
			// for this specific case we do not reset scrolling position and renders virtual rows from the passed argument
			var to, $scrollContainer, scrllToBttm = false;
			if (_aNull(from)) {
				$.ui.igGrid.prototype._renderVirtualRecordsContinuous.apply(this, arguments);
			} else {
				this._totalRowCount = this._getTotalRowCount();
				if (from > this._totalRowCount) {
					return $.ui.igGrid.prototype._renderVirtualRecordsContinuous.apply(this, arguments);
				}
				this._virtualRowCount = this._determineVirtualRowCount();
				if (this._virtualRowCount > this._totalRowCount) {
					this._virtualRowCount = this._totalRowCount;
				}
				to = from + parseInt(this._virtualRowCount, 0);
				if (to > this._totalRowCount) {
					to = this._totalRowCount - 1;
					from = to - this._virtualRowCount;
					scrllToBttm = true;
					if (from < 0) {
						from = 0;
					}
				}
				this._renderRecords(from, to);
				this._avgRowHeight = this._calculateAvgRowHeight();
				this._setScrollContainerHeight(this._totalRowCount * this._avgRowHeight);
				// M.H. 17 July 2015 Fix for bug 201854: Collapsing the last row does not scroll to the correct view in the treegrid when there is virtualization enabled
				if (scrllToBttm) {
					$scrollContainer = this._scrollContainer();
					$scrollContainer[0].scrollTop = this._totalRowCount * this._avgRowHeight + 1;
				}
			}
		},
		/* //Virtualization support */
		_addDataSkipColumn: function () {
			if (!this.options.renderExpansionIndicatorColumn) {
				return;
			}
			var indent = 0, indentation = parseInt(this.options.indentation, 10),
				$thDataSkip, $gridColgroup, $headersTbl, $footersTbl, cf;
			if (this.options.initialIndentationLevel > 0) {
				this._dataBoundDepth = this.options.initialIndentationLevel;
			} else {
				this._dataBoundDepth = this.dataSource.getDataBoundDepth();
			}
			if (this._dataBoundDepth >= 0) {
				indent += indentation * this._dataBoundDepth;
				if (this.options.indentation && this.options.indentation.indexOf &&
						this.options.indentation.indexOf('%') >= 0) {
					// M.H. 13 Nov 2014 Fix for bug #185115: Indentaion option for the treegrid does not work with percentages
					indent = indent + '%';
				}
				// when we have columnFixing we should detect where dataSkip column should be rendered - in fixed or unfixed part
				// for now when fixing direction is left then this should be rendered on the fixed part
				cf = (this.hasFixedColumns() && this.fixingDirection() === 'left');
				if (cf) {
					$gridColgroup = this.fixedBodyContainer().find("colgroup:first");
				} else {
					$gridColgroup = this.element.find("colgroup:first");
				}
				this._addColHelper($gridColgroup, indent);
				if (cf) {
					$headersTbl = this.fixedHeadersTable();
				} else {
					$headersTbl = this.headersTable();
				}
				// in case of fixed header headers
				if ($headersTbl.attr('id') !== this.element.attr('id')) {
					this._addColHelper($headersTbl.find('colgroup:first'), indent);
				}
				if (cf) {
					$footersTbl = this.fixedFootersTable();
				} else {
					$footersTbl = this.footersTable();
				}
				// in case of fixed footers
				if ($footersTbl.attr('id') !== this.element.attr('id')) {
					this._addColHelper($footersTbl.find('colgroup'), indent);
				}
				if (!$headersTbl.find("> thead th[data-treegrid-th]").length) {
					$thDataSkip = $('<th></th>').prependTo($headersTbl.find('> thead tr:nth-child(1)'));
					$thDataSkip
						.addClass(this.css.expandHeaderCell)
						.attr('data-skip', true)
						.attr('data-treegrid-th', true);
					if (this._isMultiColumnGrid) {
						$thDataSkip.attr('rowspan', this._maxLevel + 1);
					}

				}
			}
		},
		_addColHelper: function ($colgroup, width) {
			var $col = $colgroup.find('col[data-treegrid-col]');
			if ($col.length === 0) {
				$col = $("<col />").prependTo($colgroup)
							.attr('data-skip', 'true')
							.attr('data-treegrid-col', 'true');
			}
			if (width) {
				$col.width(width);
			}
		},
		_renderHeader: function () {
			$.ui.igGrid.prototype._renderHeader.apply(this, arguments);
			this.container().addClass(this.css.containerClasses);
		},
		_renderRecordsByFlatDataView: function (ds, isFixed, start, end) {
			var i, data, rowData, hasChildren, children,
				o = this.options,
				propertyDataLevel = o.dataSourceSettings.propertyDataLevel,
				propertyExpanded = o.dataSourceSettings.propertyExpanded,
				childDataKey = o.childDataKey,
				html = '';
			if (start === undefined) { //no params => render all
				start = 0;
				end = ds.length - 1;
			}
			if (start !== undefined && end === undefined) {
				end = start;
				if (end > ds.length - 1) {
					end = ds.length - 1;
				}
				start = 0;
			}
			if (start < 0) {
				start = 0;
			}
			if (end > ds.length - 1) {
				end = ds.length - 1;
			}
			for (i = start; i <= end; i++) {
				data = ds[i];
				hasChildren = false;
				children = data[childDataKey];
				if (children &&
					(($.type(children) === 'array' && (o.enableRemoteLoadOnDemand || children.length > 0)) ||
						children === true)) {
					hasChildren = true;
				}
				rowData = {
					dataBoundDepth: data[propertyDataLevel],
					parentCollapsed: false,
					hasExpandCell: hasChildren,
					expand: data[propertyExpanded]
				};
				html += this._renderRecordInternal(i, data, rowData, isFixed);
			}
			return html;
		},
		_determineVirtualRowCount: function () {
			var div, rowNumber = 10, ds, rows = '', html, height, avgRowHeight, displayContainerHeight, rowsPerPage, result;
			ds = this.dataSource.flatDataView();
			if (rowNumber > ds.length) {
				rowNumber = ds.length;
			}
			div = $('<div></div>)').appendTo('body').css({ position: 'absolute', top: -1800, left: -1800, visibility: 'hidden' });

			rows = this._renderRecordsByFlatDataView(ds, false, 0, rowNumber);
			// M.H. 28 Nov 2014 Fix for bug #185811: User can't scroll down with mouse wheel if continuous virtualization is enabled and binding specific data.
			html = '<table class="' + this.css.gridTableClass + '"><tbody>' + rows + '</tbody></table>';
			div.html(html);
			height = div.height();
			avgRowHeight = height / rowNumber;
			displayContainerHeight = this._getDisplayContainerHeight();
			rowsPerPage = displayContainerHeight / avgRowHeight;
			result = Math.ceil(rowsPerPage * 3);
			div.remove();
			this._fireInternalEvent("_virtRowCountDetermined", result);
			return result;
		},
		_renderRecord: function (data, rowIndex, isFixed) {
			return this._renderRecordInternal(rowIndex, data, { dataBoundDepth: 0, parentCollapsed: false }, isFixed);
		},
		_renderRecordInternal: function (rowIndex, data, rowData, isFixed) {
			// rowData is an object with properties dataBoundDepth, dataParent, hasExpandCell, expand
			var html = '', expState, markup, isContainerOnTheLeft, idxStart,
				key = this.options.primaryKey,
				dataBoundDepth = rowData.dataBoundDepth,
				ar = this.options.accessibilityRendering, cssClass = this.css.rowLevel + dataBoundDepth;
			html += '<tr';
			if (rowIndex % 2 !== 0 && this.options.alternateRowStyles) {
				cssClass += ' ' + this.css.recordAltClass;
			}
			if (this._transformCssCallback) {
				cssClass = this._transformCssCallback(cssClass, data);
			}
			html += ' class="' + cssClass + '" data-row-idx="' + rowIndex + '" data-level="' + dataBoundDepth + '"';
			/*jshint -W106*/
			if (!_aNull(key)) {
				html += ' data-id="' + this._kval_from_key(key, data) + '"';
			} else if (!_aNull(data.ig_pk)) {
				html += ' data-id="' + data.ig_pk + '"';
			}
			/*jshint +W106*/
			if (rowData.hasExpandCell) {
				expState = rowData.expand ? 'expanded' : 'collapsed';
				html += ' data-state="' + expState + '"';
			}
			if (rowData.parentCollapsed && dataBoundDepth > 0) {
				html += ' style="display: none;"';
			}
			if (ar) {
				html += ' role="row" tabIndex="' + this.options.tabIndex + '">';
			} else {
				html += ' tabIndex="' + this.options.tabIndex + '">';
			}
			isContainerOnTheLeft = this._isDataContainerOnTheLeft(isFixed);
			if (this._shouldRenderDataSkipColumn(isFixed)) {
				html += this._renderExpandCellHandler(rowData);
			}
			markup = $.ui.igGrid.prototype._renderRecord.call(this, data, rowIndex, isFixed);
			// we should remove this specific TD because no visible data-columns are rendered WHEN expansion indicator column is rendered
			// M.H. 25 Feb 2015 Fix for bug #189486: When a column is fixed after databinding the treegrid there is no data in the fixed columns and row height increases
			if (isFixed) {
				markup = markup.replace('<td role="gridcell" tabIndex="' + this.options.tabIndex + '"></td>', '');
			}
			// M.H. 7 Nov 2014 Fix for bug #184802: When there are fixed columns calling dataBind for the treegrid renders them in fixed area as well
			if (isContainerOnTheLeft) {
				html += this._renderFirstDataCellHandler(markup, rowData);
			} else {
				idxStart = markup.indexOf('<td');
				html += markup.substring(idxStart);
			}
			return html;
		},
		_shouldRenderDataSkipColumn: function (isFixed) {
			var fdLeft;
			if (!this.options.renderExpansionIndicatorColumn) {
				return false;
			}
			if (!this.hasFixedColumns()) {
				return true;
			}
			fdLeft = (this.fixingDirection() === 'left');
			// when there are ONLY non-data columns fixed AND fixing direction is LEFT
			if (!isFixed && fdLeft && this._isFixedNonDataColumnsOnly()) {
				return false;
			}
			return this._isDataContainerOnTheLeft(isFixed);
		},
		_renderFirstDataCell: function (markup, rowData) {
			var newTDSmarkup = '', idxStart, TDSmarkup, tdContentFirstInd, otherTDSmarkup;
			idxStart = markup.indexOf('<td');
			// M.H. 25 Nov 2014 Fix for bug #185609: When renderExpansionIndicatorColumn, ColumnFixing and Paging are enabled then going to the second page desyncronize the row heights
			// in case of columnfixing(and no fixed columns but expand column is rendered - which should be fixed by default) then markup does not contain TDs rendered and we should return empty string
			if (idxStart === -1) {
				return "";
			}
			TDSmarkup = markup.substring(idxStart);
			tdContentFirstInd = TDSmarkup.indexOf(">", 2);
			otherTDSmarkup = TDSmarkup.substring(tdContentFirstInd + 1);// find first td
			newTDSmarkup = TDSmarkup.substring(0, tdContentFirstInd);
			if (this.options.renderExpansionIndicatorColumn) {
				newTDSmarkup += ' data-cell-shift-container="1">';
			} else {
				newTDSmarkup += ' class="' + this.css.expandColumn + '" data-expand-cell="1">';
			}
			newTDSmarkup += this._renderExpandCellContainer(rowData);
			newTDSmarkup += otherTDSmarkup;
			return newTDSmarkup;
		},
		_renderExpandCellContainer: function (rowData) {
			var span = '', margin, dataBoundDepth = rowData.dataBoundDepth;// find first td

			margin = dataBoundDepth > 0 ? parseInt(this.options.indentation, 10) * dataBoundDepth : 0;
			if (this.options.renderExpansionIndicatorColumn) {
				span = '<span class="' + this.css.dataColumnExpandContainer + '" data-shift-container="1" style="display: inline-block; margin-left:' + margin + 'px;"></span>';
			} else {
				span = this._renderExpandCellContainerHelper(rowData);
			}
			return span;
		},
		_renderExpandCellContainerHelper: function (rowData) {
			var span = '', css, title, margin,
				dataBoundDepth = rowData.dataBoundDepth,
				cssEC = this.css.expandContainer,
				renderExpandButton = rowData.hasExpandCell;// find first td
			if (this.options.renderExpansionIndicatorColumn) {
				cssEC = this.css.expandColumnContainer;
			}
			margin = dataBoundDepth > 0 ? parseInt(this.options.indentation, 10) * dataBoundDepth : 0;
			// M.H. 13 Nov 2014 Fix for bug #185115: Indentaion option for the treegrid does not work with percentages
			if ($.type(this.options.indentation) === 'string' && this.options.indentation.indexOf('%') > 0) {
				margin += '%';
			} else {
				margin += 'px';
			}
			span = '<span data-expandcell-indicator="1" class="' + cssEC + '" style="padding-left:' + margin + ';">';
			if (renderExpandButton && this.options.showExpansionIndicator) {
				if (rowData.expand) {
					css = this.css.expandCellExpanded;
					title = this.options.collapseTooltipText;
				} else {
					css = this.css.expandCellCollapsed;
					title = this.options.expandTooltipText;
				}
				span += '<span data-expand-button class="' + css + '" title="' + title + '" tabIndex="' + this.options.tabIndex + '"></span>';
			}
			span += '</span>';
			return span;
		},
		_renderExpandCell: function (rowData) {
			if (!rowData.hasExpandCell) {
				return this._renderDataSkipCell();
			}
			var html, css;
			css = (this.css.expandColumn + ' ' + this.css.dataSkipCell).trim();
			html = '<td class="' + css + '" data-expand-cell="1" data-skip="true" tabIndex="' + this.options.tabIndex + '">';
			if (this.options.showExpansionIndicator) {
				html += this._renderExpandCellContainerHelper(rowData);
			}
			return html + '</td>';
		},
		_renderDataSkipCell: function () {
			return '<td class="' + this.css.dataSkipCell + '" data-skip="true" tabIndex="' + this.options.tabIndex + '"></td>';
		},
		_rerenderColgroups: function () {
			$.ui.igGrid.prototype._rerenderColgroups.apply(this, arguments);
			this._addDataSkipColumn();
		},
		// M.H. 24 Jan 2015 Fix for bug #187687: When columns are auto generated extra columns are rendered in treegrid
		_columnsGenerated: function () {
			// when autogeneratecolumns is TRUE we want to exclude columns like childDataKey, expanded property, etc.
			var cols = this.options.columns,
				key, i,
				sDS = this.options.dataSourceSettings,
				arrSkipColumns = [this.options.childDataKey, sDS.propertyExpanded, sDS.propertyDataLevel];
			for (i = 0; i < cols.length; i++) {
				key = cols[i].key;
				if ($.inArray(key, arrSkipColumns) !== -1) {
					$.ig.removeFromArray(cols, i);
					i--;
				}
			}
		},
		_rowVirtualizationEnabled: function () {
			/* check whether grid has row virtualization enabled
			returnType="bool"
			*/
			return this.options.rowVirtualization || this.options.virtualization;
		},
		_rerenderGridRowsOnToggle: function () {
			/* returns whether it should be re-rendered grid rows on expand/collapse. E.g. grid should be re-rendered when pagingOnRootRecordsOnly is false(and paging is enabled) OR row virtualization is enabled
			returnType="bool"
			*/
			var virtualizationEnabled = this._rowVirtualizationEnabled(),
				dsSettings = this.dataSource.settings;
			return (dsSettings.paging.enabled && dsSettings.treeDS.paging.mode !== "rootLevelOnly") ||
					virtualizationEnabled;
		},
		_onDataRecordToggled: function (rec, expand, res, args) {
			// result is not successful
			if (!res || !args) {
				return;
			}
			// if there isn't paging or paging is enabled but pagingOnRootRecordsOnly is TRUE then it should be rendered only expanded/collapsed rows
			// 1. Set data-state attribute
			// 2. Refresh flatDataView
			// 3. Render new DOM ONLY IF expand and children are not populated
			var flatData, html, level, dataIdx, diff, triggerEvents, $row, callAsync = false,
				rows, $fRow, $ufRow, $curRow, offsetTop, customCallback, $this = this,
				fRows, ufRows,
				eArgs, $scrollContainer;

			$row = args.row;
			triggerEvents = args.triggerEvents;
			customCallback = args.customCallback;
			rows = this._getRows($row);
			$fRow = rows.fixedRow;
			$ufRow = rows.unfixedRow;
			level = parseInt($row.attr('data-level'), 10);
			eArgs = {
				owner: this,
				row: $ufRow,
				fixedRow: $fRow,
				dataLevel: level,
				dataRecord: rec
			};
			//M.K.2/19/2015 Fix for bug 189178: Loading indicator does not show when loading data on demand
			this._loadingIndicator.hide();
			if (!this._rerenderGridRowsOnToggle()) {
				if (expand && !$row.attr('data-populated')) {
					if (rec) {
						this._toggleRowSuccessors($ufRow);
						$ufRow.add($fRow).attr('data-populated', '1');
						flatData = this.dataSource.getFlatDataForRecord(rec, level + 1);
						if (flatData && flatData.flatVisibleData) {
							html = this._renderRecordsByFlatDataView(flatData.flatVisibleData, false);
							ufRows = $(html).insertAfter($ufRow);
							if ($fRow) {
								html = this._renderRecordsByFlatDataView(flatData.flatVisibleData, true);
								fRows = $(html).insertAfter($fRow);
							}
							this._trigger("_buildDOMOnToggle", this, { fRows: fRows, ufRows: ufRows });
							if (!this.options.renderExpansionIndicatorColumn) {
								this._stopPropagationgForExpandCellIndicators();
							}
						}
					}
				} else {
					this._toggleRowSuccessors($row);
				}
			} else {
				if (this._rowVirtualizationEnabled() && this.options.virtualizationMode === "continuous") {
					if ($row.length) {
						dataIdx = $row.closest('tbody').children('tr[data-row-idx]:first').attr('data-row-idx');
						offsetTop = $row.offset().top;
						this._renderVirtualRecordsContinuous(parseInt(dataIdx, 10));
						// M.H. 25 Feb 2015 Fix for bug #189482: After clicking the expanding button no cells can be selected in Chrome.
						this._trigger('virtualrecordsrender', null, { owner: this, dom: this._virtualDom });
						if (!expand) {
							$curRow = $('#' + this.id() + ' > tbody > tr[data-row-idx=' + $row.attr('data-row-idx') + ']');
							// if you try to collapse some of the last rows diff will be not 0
							diff = ($curRow.offset().top - offsetTop);
							if (Math.abs(diff) > 1) {
								$scrollContainer = this._scrollContainer();
								callAsync = true;
								setTimeout(function () {
									$scrollContainer[0].scrollTop = $scrollContainer.scrollTop() + diff;
								}, 50);
							}
						}
					} else {
						callAsync = true;
						this._updateVirtualScrollContainer();
					}
				}
			}
			if (callAsync) {
				setTimeout(function () {
					$this._callDataToggledEventsAndCallbacks(customCallback, expand, eArgs, triggerEvents);
				}, 55);
			} else {
				this._callDataToggledEventsAndCallbacks(customCallback, expand, eArgs, triggerEvents);
			}
		},
		_callDataToggledEventsAndCallbacks: function (customCallback, expand, eArgs, triggerEvents) {
			var hasHeight = this.options.height && parseInt(this.options.height, 10) > 0,
				isVirt = this.options.virtualization === true || this.options.columnVirtualization === true || this.options.rowVirtualization === true;
			if (customCallback) {
				$.ig.util.invokeCallback(customCallback, [
					this,
					{
						unfixedRow: eArgs.row,
						fixedRow: eArgs.fixedRow
					},
					eArgs.dataRecord, 
					expand]);
			}
			// M.H. 8 Sep 2015 Fix for bug 206038: Headers and cells become misaligned when expanding a tree grid row causes a scrollbar to show
			// when virtualization is enabled vertical scrollbar is always rendered,
			// if height is not set vertical scrollbar is not rendered
			if (hasHeight && !isVirt &&
				this._hasVerticalScrollbar !== this.hasVerticalScrollbar()) {
				// calling _adjustLastColumnWidth updates padding of the right cell AND updates value of this._hasVerticalScrollbar
				this._adjustLastColumnWidth();
			}
			if (expand) {
				this._fireInternalEvent("_rowExpanded", eArgs);
			} else {
				this._fireInternalEvent("_rowCollapsed", eArgs);
			}
			if (triggerEvents) {
				if (expand) {
					this._trigger(this.events.rowExpanded, null, eArgs);
				} else {
					this._trigger(this.events.rowCollapsed, null, eArgs);
				}
			}
		},
		toggleRow: function (row, callback) {
			/* Toggle row by specified row or row identifier
				paramType="object" jQuery table row object or a row id.
				paramType="function" optional="true" Specifies a custom function to be called when row is expanded/collapsed. The callback has 4 arguments- a reference to the current context(this), object that holds 2 properties(unfixedRow - DOM representation of the unfixed row, fixedRow - DOM representation of the fixed row, if there is no fixed columns it is undefined), reference to the dataRecord, expand - specifies whether row is expanded
			*/
			var $row, state, expand, ds = this.dataSource;

			if (row instanceof jQuery) {
				$row = row;
			} else {
				$row = this.element.find('tr[data-id=' + row + ']');
			}

			state = $row.attr('data-state');
			if (!$row.length) {
				expand = !ds.getExpandStateById(row);
			} else {
				expand = (state === 'collapsed');
			}
			this._expandCollapseRow(row, expand, false, callback);
		},
		expandRow: function (row, callback) {
			/* Expands a parent row by specified row or row identifier
				paramType="object" jQuery table row object or a row id.
				paramType="function" optional="true" Specifies a custom function to be called when row is expanded/collapsed. The callback has 4 arguments- a reference to the current context(this), object that holds 2 properties(unfixedRow - DOM representation of the unfixed row, fixedRow - DOM representation of the fixed row, if there is no fixed columns it is undefined), reference to the dataRecord, expand - specifies whether row is expanded
			*/
			this._expandCollapseRow(row, true, false, callback);
		},
		collapseRow: function (row, callback) {
			/* Collapses a parent row by specified row or row identifier
				paramType="object" jQuery table row object, raw DOM row object or a row id.
				paramType="function" optional="true" Specifies a custom function to be called when row is expanded/collapsed. The callback has 4 arguments- a reference to the current context(this), object that holds 2 properties(unfixedRow - DOM representation of the unfixed row, fixedRow - DOM representation of the fixed row, if there is no fixed columns it is undefined), reference to the dataRecord, expand - specifies whether row is expanded
			*/
			this._expandCollapseRow(row, false, false, callback);
		},
		_toggleRow: function (event) {
			var $row = $(event.target).closest('tr'),
				state = $row.attr('data-state'), expand;
			if (state === undefined) {
				return;
			}
			expand = (state === 'collapsed');
			this._expandCollapseRow($row, expand, true);
		},
		_expandCollapseRow: function (row, expand, triggerEvents, callback) {
			/* expand or collapse row
				When virtualization is enabled it is possible $row to be with length 0 but rowId to be set - in case we want to toggle a row that is not in rendered chunks - in this case we should update the expand state in the datasource(for this data record) and render virtual rows
				paramType="object" jquery jQuery table row object that should be collapsed/expanded
				paramType="bool" specify whether the row should be expanded/collapsed. If true the row should be expanded. If it is already expanded it should return no result
				paramType="bool" optional="true" If true client events should be fired
				paramType="function" optional="true" If specified it is called once the row is expanded/collapsed
			*/
			var primaryKeyCol, noCancel = true, func, args, callbackArgs, rowId, $row, me = this,
				rows, $fRow, $ufRow, dataState = expand ? 'expanded' : 'collapsed';
			if (row instanceof jQuery) {
				$row = row;
				if (!_aNull(this.options.primaryKey)) {
					primaryKeyCol = this.columnByKey(this.options.primaryKey);
					rowId = $row.attr('data-id');
					if (primaryKeyCol &&
							(primaryKeyCol.dataType === "number" || primaryKeyCol.dataType === "numeric")) {
						rowId = parseInt(rowId, 10);
					}
				} else {
					rowId = $row.index();
				}
			} else {
				rowId = row;
				$row = this.element.find('tr[data-id=' + row + ']');
			}
			// we should not allow to apply expand/collapse for a row that is already expanded/collapsed
			if ($row.length === 1 && $row.attr('data-state') === dataState) {
				return;
			}
			func = $.proxy(this._onDataRecordToggled, this);
			callbackArgs = {
				callback: func,
				args: {
					row: $row,
					triggerEvents: triggerEvents
				}
			};
			if (callback) {
				callbackArgs.args.customCallback = callback;
			}
			rows = this._getRows($row);
			$fRow = rows.fixedRow;
			$ufRow = rows.unfixedRow;
			args = {
				owner: this,
				row: $ufRow,
				fixedRow: $fRow,
				dataLevel: parseInt($row.attr('data-level'), 10)
			};
			if (triggerEvents) {
				if (expand) {
					noCancel = this._trigger(this.events.rowExpanding, null, args);
				} else {
					noCancel = this._trigger(this.events.rowCollapsing, null, args);
				}
			}
			if (noCancel) {
				//M.K.2/19/2015 Fix for bug 189178: Loading indicator does not show when loading data on demand
				this._loadingIndicator.show();
				setTimeout(function () {
					if (!_aNull(me.options.primaryKey)) {
						me.dataSource.setExpandedStateByPrimaryKey(rowId, expand, callbackArgs);
					} else {
						me.dataSource.setExpandedStateByRowIndex(rowId, expand, callbackArgs);
					}
				}, 0);
			}
		},
		_toggleRowSuccessors: function ($row) {
			var $nextRow = $row, foundUpperLevel = false, dL, $fRow, $ufRow = $row,
				levelCollapsed = null, $container,
				dataBoundDepth = parseInt($row.attr('data-level'), 10),
				state = $row.attr('data-state'),
				styleDisplay = '',
				expanded = (state === 'expanded');
			if (expanded) {
				styleDisplay = 'none';
			}
			if (this.hasFixedColumns()) {
				if (this._isFixedElement($row)) {
					$fRow = $row;
					if (this._rowVirtualizationEnabled()) {
						$container = this._vdisplaycontainer();
					} else {
						$container = this.scrollContainer();
					}
					$ufRow = $container.find('tbody > tr').eq($row.index());
				} else {
					$fRow = this.fixedBodyContainer().find("tbody > tr").eq($row.index());
				}
			}
			// update 
			while ($nextRow.length === 1 && !foundUpperLevel) {
				$nextRow = $nextRow.next('tr[data-level]');
				dL = parseInt($nextRow.attr('data-level'), 10);
				if (isNaN(dL) || dL <= dataBoundDepth) {
					foundUpperLevel = true;
					break;
				}
				// we should show records but if some of the children is collapsed we should not show its children
				if (!expanded) {
					if (levelCollapsed !== null) {
						if (dL <= levelCollapsed) {
							levelCollapsed = null;
						} else {
							// we should not 
							continue;
						}
					}
					if ($nextRow.attr('data-state') === 'collapsed') {
						levelCollapsed = dL;
					}
				}
				this._showHideRow($nextRow, styleDisplay);
			}
			if (expanded) {
				// we should hide next rows
				$ufRow.add($fRow)
					.attr('data-populated', '1')
					.attr('data-state', 'collapsed').find("[data-expand-button]")
					.attr('title', this.options.expandTooltipText)
					.removeClass(this.css.expandCellExpanded).addClass(this.css.expandCellCollapsed);
			} else {
				$ufRow.add($fRow).attr('data-state', 'expanded').find("[data-expand-button]")
					.attr('title', this.options.collapseTooltipText)
					.removeClass(this.css.expandCellCollapsed).addClass(this.css.expandCellExpanded);
			}
		},
		_showHideRow: function ($row, styleDisplay) {
			var rows, $ufRow = $row, $fRow,
				fixedColumns = this.hasFixedColumns();
			if (fixedColumns) {
				rows = this._getRows($row);
				$fRow = rows.fixedRow;
				$ufRow = rows.unfixedRow;
			}
			$ufRow.css('display', styleDisplay);
			if ($fRow) {
				$fRow.css('display', styleDisplay);
			}
			if (styleDisplay === '') {
				this._trigger("_rowShown", this, { fRow: $fRow, ufRow: $ufRow });
			} else {
				this._trigger("_rowHidden", this, { fRow: $fRow, ufRow: $ufRow });
			}
		},
		_renderExtraHeaderCells: function (row, colgroup, prepend) {
			if (!this.options.renderExpansionIndicatorColumn) {
				return;
			}
			// its how many grouped columns we have, the cell is only one
			// also mark the extra cell with a data-skip attribute so that features can do their calculations based on this
			if (prepend === true) {
				$('<td></td>').prependTo(row).css('border-width', 0).attr('data-skip', true);
				if (colgroup) {
					$('<col />').prependTo(colgroup).attr('data-skip', true).css('width', this.options.indentation);
				}
			} else {
				$('<td></td>').appendTo(row).css('border-width', 0).attr('data-skip', true);
				if (colgroup) {
					$('<col />').appendTo(colgroup).attr('data-skip', true).css('width', this.options.indentation);
				}
			}
		},
		/* integration with ColumnFixing */
		_isFixedNonDataColumnsOnly: function () {
			// returns whether ONLY non data columns are fixed
			if (this.hasFixedColumns() &&
					(!this._fixedColumns || !this._fixedColumns.length)) {
				return true;
			}
			return false;
		},
		_isDataContainerOnTheLeft: function (isFixed) {
			// when there is at least one fixed column - rendering of non-data column and expansion indicators should be rendered only on the left container
			var fdLeft = (this.fixingDirection() === 'left');
			if (!this.hasFixedColumns()) {
				return true;
			}
			// in case data-skip column is fixed
			if ($.type(this._fixedColumns) === 'array' &&
					!this._fixedColumns.length) {
				return true;
			}
			if (isFixed) {
				return fdLeft;
			}
			return !fdLeft;
		},
		_getRows: function ($row) {
			// if $row is fixed gets the unfixed row()
			var index, $fRow, $ufRow = $row;
			if (this.hasFixedColumns()) {
				index = $row.index();
				if (this._isFixedElement($row)) {
					$fRow = $row;
					$ufRow = $(this.rowAt(index));
				} else {
					$fRow = $(this.fixedRowAt(index));
				}
			}
			return { fixedRow: $fRow, unfixedRow: $ufRow };
		},
		/* //integration with ColumnFixing */
		_renderRow: function (rec, tr) {
			var funcCallbak;
			funcCallbak = function (rec, tr) {
				return $.ui.igGrid.prototype._renderRow.call(this, rec, tr);
			};
			return this._persistExpansionIndicator(rec, tr, funcCallbak, this);
		},
		_persistExpansionIndicator: function (rec, tr, funcCallback, funcCallee) {
			var $td, trRes = tr, $tr = $(tr), $span, renderEC = this.options.renderExpansionIndicatorColumn;
			if (renderEC) {
				$span = $tr.find('span[data-shift-container]');
				$td = $span.closest('td');
			} else {
				$span = $tr.find('[data-expandcell-indicator]');
				$td = $span.closest('td');
				$span.detach();
			}
			if (funcCallback && funcCallee) {
				trRes = funcCallback.call(funcCallee, rec, tr);
				$tr = $(trRes);
			}
			if ($span.length > 0) {
				$span.prependTo($td);
			}
			return trRes;
		},
		_detachEvents: function () {
			var renderExpansionIndicatorColumn = this.options.renderExpansionIndicatorColumn, gridContainerId = this.element[0].id;
			if (this.element.is('div')) {
				gridContainerId = this.element[0].id;
			} else {
				gridContainerId += "_container";
			}
			if (this._columnsGeneratedHandler) {
				this.element.unbind('igtreegrid_columnsgenerated', this._columnsGeneratedHandler);
			}
			if (this._toggleRowHandler) {
				if (!renderExpansionIndicatorColumn) {
					$(document).undelegate("#" + gridContainerId + " tr td span[data-expandcell-indicator]", "mouseup", this._toggleRowHandler);
				} else {
					$(document).undelegate("#" + gridContainerId + " td[data-expand-cell=1]", "mouseup", this._toggleRowHandler);
				}
			}
		},
		_attachEvents: function () {
			var renderExpansionIndicatorColumn = this.options.renderExpansionIndicatorColumn,
				gridContainerId = this.element[0].id;
			if (this.element.is('div')) {
				gridContainerId = this.element[0].id;
			} else {
				gridContainerId += "_container";
			}
			this._toggleRowHandler = $.proxy(this._toggleRow, this);

			if (!renderExpansionIndicatorColumn) {
				$(document).delegate("#" + gridContainerId + " tr td span[data-expandcell-indicator]", "mouseup", this._toggleRowHandler);
			} else {
				$(document).delegate("#" + gridContainerId + " td[data-expand-cell=1]", "mouseup", this._toggleRowHandler);
			}
			// column fixing events
			// M.H. 24 Jan 2015 Fix for bug #187687: When columns are auto generated extra columns are rendered in treegrid
			this._columnsGeneratedHandler = $.proxy(this._columnsGenerated, this);
			this.element.bind('igtreegrid_columnsgenerated', this._columnsGeneratedHandler);
		},
		_initFeature: function (featureObject) {
			if (!featureObject) {
				return;
			}
			// construct widget name
			if (featureObject.name === undefined) {
				return;
			}
			var widgetTreeGrid = 'igTreeGrid' + featureObject.name;
			// check whether there is igTreeGrid version of the feature
			if ($.type(this.element[widgetTreeGrid]) === "function") {
				if (this.element.data(widgetTreeGrid)) {
					this.element[widgetTreeGrid]('destroy');
				}
				// instantiate widget
				this.element[widgetTreeGrid](featureObject);
				this.element.data(widgetTreeGrid)._injectGrid(this);
			} else {
				return $.ui.igGrid.prototype._initFeature.apply(this, arguments);
			}
		},
		_destroyFeatures: function () {
			var i, features = this.options.features, e = this.element;
			for (i = 0; i < features.length; i++) {
				// Don't call destroy on non existing widget (or already destroyed one)
				if (e.data('igTreeGrid' + features[i].name)) {
					e['igTreeGrid' + features[i].name]('destroy');
				} else if (e.data('igGrid' + features[i].name)) {
					e['igGrid' + features[i].name]('destroy');
				}
			}
		},
		destroy: function () {
			/* Destroys igTreeGrid
			returnType="object" Returns reference to this igTreeGrid.
			*/
			this._detachEvents();
			$.ui.igGrid.prototype.destroy.apply(this, arguments);
			this.element.removeData($.ui.igGrid.prototype.widgetName);
			this._removeOverridenFunction();
			return this;
		}
	});
	$.extend($.ui.igTreeGrid, { version: '15.1.20151.2352' });
}(jQuery));


