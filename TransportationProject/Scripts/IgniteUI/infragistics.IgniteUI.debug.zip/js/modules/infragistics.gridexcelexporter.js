﻿/// <reference path="infragistics.excel.js" />
/*!@license
 * Infragistics.Web.ClientUI Widget 15.1.20151.2352
 *
 * Copyright (c) 2011-2015 Infragistics Inc.
 *
 * http://www.infragistics.com/
 *
 * 
 * Depends on:
 *  jquery-1.4.4.js
 *  jquery.ui.core.js
 *  jquery.ui.widget.js
 *  FileSaver.js
 *  infragistics.ui.grid.framework.js
 *  infragistics.ui.grid.columnfixing.js
 *  infragistics.ui.grid.filtering.js
 *  infragistics.ui.grid.hiding.js
 *  infragistics.ui.grid.paging.js
 *  infragistics.ui.grid.sorting.js
 *  infragistics.ui.grid.summaries.js
 *  infragistics.excel.js
 */

/*global jQuery, Class, saveAs */
if (typeof jQuery !== "function") {
    throw new Error("jQuery is undefined");
}

(function ($) {

    $.ig = $.ig || {};

    $.ig.GridExcelExporter = $.ig.GridExcelExporter || Class.extend({
        /* The Infragistics Grid Excel exporter client-side component is implemented as a class, and exports the igGrid control with the columnfixing, filtering, hiding, paging, sorting, and summaries features
		*/
        settings: {
            /* type="string" Specifies the name of the excel file that will be generated. */
            fileName: "igGrid",
            /* List of export settings which can be used with Grid Excel exporter */
            gridFeatureOptions: {
                /* type="none|applied" Indicates whether sorting will be applied in the exported table. This is set_ to none by default, but will change to applied if sorting feature is defined in the igGrid.
                    none type="string" No sorting will be applied in the excel document.
                    applied type="string" Sorting will be applied in the excel document.
                */
                sorting: "none",
                /* type="currentPage|allRows" Indicates whether the rows on the current page or entire data will exported.
                    currentPage type="string" Only current page will be exported to the excel document.
                    allRows type="string" All pages will be exported to the excel document.
                */
                paging: "allRows",
                /* type="none|applied|visibleColumnsOnly" Indicates whether hidden columns will be removed from the exported table. This is set to none by default, but will change to applied if hiding feature is defined in the igGrid. 
                    none type="string" All hidden columns will be exported to the excel document.
                    applied type="string" Hidden columns will be exported as hidden in the excel document.
                    visibleColumnsOnly type="string" Only visible columns will be exported.
                */
                hiding: "none",
                /* type="none|applied|filteredRowsOnly" Indicates whether filtering will be applied in the exported table. this is set to none by default, but will change to applied if filtering feature is defined in the igGrid. 
                    none type="string" No filtering will be applied in the excel document.
                    applied type="string" Filtering will be applied in the excel document.
                    filteredRowsOnly type="string" Filtering will be exported in the excel document.
                */
                filtering: "none",
                /* type="none|applied" Indicates whether fixed columns will be applied in the exported table. This is set to none by default, but will change to applied if column fixing feature is defined in the igGrid. 
                    none type="string" No column fixing will be applied in the excel document.
                    applied type="string" Column fixing will be applied in the excel document.
                */
                columnfixing: "none",
                /* type="none|applied" Indicates whether summaries will be added in the exported table. This is set to none by default, but will change to applied if summaries feature is defined in the igGrid.
                    none type="string" No summaries will be exported to the excel document.
                    applied type="string" Summaries will be exported to the excel document.
                */
                summaries: "none"
            },
            /* type="string" Specifies the name of workbook where the igGrid will be exported. */
            worksheetName: "Sheet1",
            /* type="array" List of strings containing the keys for the columns that will not be exported*/
            columnsToSkip: [],
            /* type="string" Specifies the excel table style region. 
               You can set the following table style
               TableStyleMedium[1-28]
               TableStyleLight[1-21]
               TableStyleLight[1-11]
             */
            tableStyle: "TableStyleMedium1",
            /* type="none|applied" Indicates whether excel table styles will be the same as grid styles. This is set to applied by default. Custom grid themes are not supported.
                none type="string" The styles from the grid are not applied to the table region.
                applied type="string" The styles from the grid are applied to the table region.
            */
            gridStyling: "applied"
        },

        /* Callback for the exporter events */
        callbacks: {
            /* cancel="true" Callback fired when the exporting has started.
			Function takes arguments sender and args.
			Use args.grid to get reference to igGrid widget.
			*/
            exportStarting: null,
            /* cancel="true" Callback fired when cell exporting has begin.
			Function takes arguments sender and args.
			Use args.columnKey to get the igGrid column key of the cell.
			Use args.columnIndex to get the igGrid column index of the cell.
			Use args.cellValue to get the igGrid cell value.
            Use args.rowId to get key or index of row.
			Use args.xlRow to get reference to the worksheet row.
			*/
            cellExporting: null,
            /* Callback fired when cell exporting has end.
            Function takes arguments sender and args.
            Use args.columnKey to get the igGrid column key of the cell.
            Use args.columnIndex to get the igGrid column index of the cell.
            Use args.cellValue to get the igGrid cell value.
            Use args.rowId to get key or index of row.
            Use args.xlRow to get reference to the worksheet row.
            */
            cellExported: null,
            /* cancel="true" Callback fired when header cell exporting has begin.
            Function takes arguments sender and args.
            Use args.headerText to get the igGrid column key of the header cell.
            Use args.columnKey to get the igGrid column key of the header cell.
            Use args.columnIndex to get the igGrid column index of the header cell.
            */
            headerCellExporting: null,
            /* Callback fired when header cell exporting has end.
            Function takes arguments sender and args.
            Use args.headerText to get the igGrid column key of the header cell.
            Use args.columnKey to get the igGrid column key of the header cell.
            Use args.columnIndex to get the igGrid column index of the header cell.
            */
            headerCellExported: null,
            /* cancel="true" Callback fired when row exporting has begin.
            Function takes arguments sender and args.
            Use args.rowId to get key or index of row.
            Use args.element to get row TR element.
            Use args.xlRow to get reference to the worksheet row.
            Use args.owner to get reference to the igGrid widget.
            */
            rowExporting: null,
            /* cancel="true" Callback fired when row exporting has ended.
            Function takes arguments sender and args.
            Use args.rowId to get key or index of row.
            Use args.element to get row TR element.
            Use args.xlRow to get reference to the worksheet row.
            Use args.owner to get reference to the igGrid widget.
            */
            rowExported: null,
            /* cancel="true" Callback fired when summary exporting has begun.
            Function takes arguments sender and args.
            Use args.headerText to get the igGrid column header text.
            Use args.columnKey to get the igGrid column key.
            Use args.columnIndex to get the igGrid column index. 
            Use args.summary to get a reference to the summary object.
            Use args.xlRowIndex to get reference to worksheet row index.
			*/
            summaryExporting: null,
            /* Callback fired when cell exporting has end.
            Function takes arguments sender and args.
            Use args.headerText to get the igGrid column header text.
            Use args.columnKey to get the igGrid column key.
            Use args.columnIndex to get the igGrid column index. 
            Use args.summary to get a reference to the summary object.
            Use args.xlRowIndex to get the worksheet row index.
            */
            summaryExported: null,
            /* cancel="true" Callback fired when export is ending, but the document is not saved.
            Function takes arguments sender and args.
            Use args.grid to get reference to the igGrid widget.
            Use args.workbook to get reference to the excel workbook.
            Use args.worksheet to get reference to the excel worksheet.
            Use args.xlRowIndex to get the worksheet row index.
            */
            exportEnding: null,
            /* Callback fired when exporting is successful.
            Use data to get the reference of saved object.
            */
            success: null,
            /* Callback fired when exporting is failed.
            Use error to get the reference of error object.
            */
            error: null
        },
        init: function () {
            this.settings = $.extend({}, this.settings);
            this.callbacks = $.extend({}, this.callbacks);
        },

        export: function (grid, userSettings, userCallbacks) {
            /* Exports the provided igGrid to Excel document.
				paramType="object" Grid to be exported.
				paramType="object" Settings for exporting the grid.
				paramType="object" Callbacks for the events.
			*/

            this._setGridReferences(grid);
            this._setSettings(userSettings);
            this._setCallbacks(userCallbacks);

            if (!this._handleEventCallback(this.callbacks.exportStarting, { grid: this._gridWidget })) {
                return;
            }

            var self = this;

            setTimeout(function () {
                self._createExcelWorkbookWithWorksheet();

                if (self._columnsToExport.length > 0) {
                    self._getGridStyles();
                    self._exportHeaders();
                    self._setDataToExport();
                    self._createExcelTableRegion();
                    self._exportDataSegment();

                    // This should be true when row exporting is canceled 
                    // so the table size should be resized also.
                    if (self._shouldResizeTableRegion) {
                        self._resizeTableRegion();
                    }

                    self._exportFeatures();
                    self._calculateColumnsSize();
                }

                var noCancel = self._handleEventCallback(self.callbacks.exportEnding, { grid: self._gridWidget, workbook: self._workbook, worksheet: self._worksheet });

                if (!noCancel) {
                    return;
                }

                self._saveWorkbook();
            }, 0);
        },

        _setGridReferences: function (grid) {
            this._grid = grid.data("igGrid");
            this._gridData = this._grid.dataSource.dataSource();
            this._gridWidget = grid;
            this._dataRows = this._gridWidget.igGrid("rows");
        },

        _setSettings: function (userSettings) {
            this._enableFeaturesAsInGrid();
            this._setUserSettings(userSettings);
            this._setColumnsToExport(this.settings.columnsToSkip);
        },

        _enableFeaturesAsInGrid: function () {
            for (var gridFeatureOption in this.settings.gridFeatureOptions) {
                if (!this._getFeature(gridFeatureOption)) {
                    continue;
                }

                if (gridFeatureOption === "paging") {
                    this.settings.gridFeatureOptions[gridFeatureOption] = "allRows";
                } else {
                    this.settings.gridFeatureOptions[gridFeatureOption] = "applied";
                }
            }
        },

        _setUserSettings: function (userSettings) {
            this.settings = $.extend(this.settings, userSettings);
        },

        _setColumnsToExport: function () {
            var gridColumns = this._grid.options.columns,
                columnsToSkip = this.settings.columnsToSkip;

            this._columnsToExport = [];

            for (var i = 0; i < gridColumns.length; i++) {
                var gridColumn = gridColumns[i];

                if (gridColumn.hidden && this.settings.gridFeatureOptions.hiding === "visibleColumnsOnly") {
                    continue;
                }

                if (columnsToSkip.indexOf(gridColumn.key) < 0) {
                    this._columnsToExport.push(gridColumn);
                }
            }
        },

        _setCallbacks: function (userCallbacks) {
            this.callbacks = $.extend(this.callbacks, userCallbacks);
        },

        _createExcelWorkbookWithWorksheet: function () {
            this._xlRowIndex = 0;
            this._workbook = new $.ig.excel.Workbook($.ig.excel.WorkbookFormat.excel2007);
            this._worksheet = this._workbook.worksheets().add(this.settings.worksheetName);
        },

        //Getting the grid styles for headers and rows (back & fore colors) for the different themes
        _getGridStyles: function () {
            if (this.settings.gridStyling === "applied") {
                var $stylesTR = $("<tr>").attr({
                    class: "ui-ig-altrecord ui-iggrid-altrecord"
                }).appendTo(this._gridWidget.igGrid("headersTable")).css("display", "none");

                var $th = $(this._gridWidget.igGrid("headersTable").find("tr[data-header-row]").find("th")[0]).clone().css("display", "none");
                $stylesTR.append($th);

                this._headersBackColor = $th.removeClass("ui-state-active").css("background-color");

                $th.remove();

                this._headersForeColor = this._gridWidget.igGrid("headersTable").find(".ui-iggrid-headertext").css("color");

                if ($stylesTR.css("background-color").indexOf("rgba") > -1) {
                    var backTopColor = $stylesTR.css("background-color").replace("rgba(", "").replace(")", "").split(", ");
                    var backBotColor = this._gridWidget.css("background-color").replace("rgb(", "").replace(")", "").split(", ");
                    this._altRowColor = this._RGBAtoRGB(backTopColor[0], backTopColor[1], backTopColor[2], backTopColor[3], backBotColor[0], backBotColor[1], backBotColor[2]);
                } else {
                    this._altRowColor = $stylesTR.css("background-color");
                }

                this._notAltRowColor = this._gridWidget.css("background-color");
                this._rowForeColor = this._gridWidget.css("color");

                $stylesTR.remove();
            }
        },

        //Function to convert RGBA to RGB colors from the grid
        _RGBAtoRGB: function (r, g, b, a, r2, g2, b2) {
            var r3 = a * r + (1 - a) * r2;
            var g3 = a * g + (1 - a) * g2;
            var b3 = a * b + (1 - a) * b2;
            return "rgb(" + r3 + "," + g3 + "," + b3 + ")";
        },

        _setDataToExport: function () {
            var paging = this.settings.gridFeatureOptions.paging,
                filtering = this.settings.gridFeatureOptions.filtering;
            this._dataToExport = [];

            if (paging === "currentPage" && this._getFeature("Paging")) {
                this._dataToExport = this._grid.dataSource.dataView();
            } else if (filtering !== "filteredRowsOnly") {
                this._dataToExport = this._gridData;
            } else {
                this._dataToExport = this._grid.dataSource._filteredData;
                if (this._dataToExport === undefined) {
                    this._dataToExport = this._gridData;
                }
            }
        },

        _createExcelTableRegion: function () {
            var regionRowsLength,
                counter = 0;
            
            regionRowsLength = this._dataToExport.length;

            for (var i = 0; i < this._columnsToExport.length; i++) {
                if (this._columnsToExport[i].hidden) {
                    counter++;
                }
            }

            this._worksheetRegion = new $.ig.excel.WorksheetRegion(this._worksheet, 0, 0, regionRowsLength, this._columnsToExport.length - 1);
            this._worksheetTable = this._worksheetRegion.formatAsTable(true);
            this._worksheetTable.style(this._workbook.standardTableStyles(this.settings.tableStyle));
            this._woorksheetTableColumns = this._worksheetTable.columns();
        },

        _exportHeaders: function () {
            var gridColumn,
                xlRow = this._worksheet.rows(this._xlRowIndex),
                headerFill = $.ig.excel.CellFill.createSolidFill(this._headersBackColor);

            xlRow.cellFormat().font().bold(1);

            for (var columnIndex = 0; columnIndex < this._columnsToExport.length; columnIndex++) {
                gridColumn = this._columnsToExport[columnIndex];
                var args = {
                    headerText: gridColumn.headerText,
                    columnKey: gridColumn.key,
                    columnIndex: columnIndex, xlRow: xlRow
                },
                    noCancel = this._handleEventCallback(this.callbacks.headerCellExporting, args);

                if (!noCancel) {
                    return;
                }

                if (this.settings.gridStyling === "applied") {
                    xlRow.getCellFormat(columnIndex).fill(headerFill);
                    xlRow.getCellFormat(columnIndex).font().colorInfo(new $.ig.excel.WorkbookColorInfo(this._headersForeColor));
                }

                this._exportCell(xlRow, gridColumn, columnIndex, args.headerText);
                this._handleEventCallback(this.callbacks.headerCellExported, args);
            }

            this._xlRowIndex++;
            this._worksheet.displayOptions().frozenPaneSettings().frozenRows(this._xlRowIndex);
            this._worksheet.displayOptions().panesAreFrozen(true);
        },

        _exportDataSegment: function () {
            var xlRow,
                dataRow;

            var wasRowExportingCancelled = false;

            for (var rowIndex = 0; rowIndex < this._dataToExport.length; rowIndex++) {

                xlRow = this._worksheet.rows(this._xlRowIndex);
                dataRow = this._dataToExport[rowIndex];

                var args = { element: this._dataRows[rowIndex], rowId: this._getGridRowId(dataRow, rowIndex), xlRow: xlRow, grid: this._gridWidget },
                noCancel = this._handleEventCallback(this.callbacks.rowExporting, args);

                if (!noCancel) {
                    wasRowExportingCancelled = true;
                    continue;
                }

                this._exportDataSegmentRow(xlRow, dataRow, rowIndex);
                this._handleEventCallback(this.callbacks.rowExported, args);
                this._xlRowIndex++;
            }

            if (wasRowExportingCancelled) {
                this._recalculateTableEnd();
                this._shouldResizeTableRegion = true;
            }
        },

        _exportDataSegmentRow: function (xlRow, dataRow, rowIndex) {
            var gridColumn,
                dataCell,
                cellFill;

            if (xlRow.index() % 2 === 0) {
                cellFill = $.ig.excel.CellFill.createSolidFill(this._altRowColor);
            } else {
                cellFill = $.ig.excel.CellFill.createSolidFill(this._notAltRowColor);
            }

            for (var columnIndex = 0; columnIndex < this._columnsToExport.length; columnIndex++) {
                gridColumn = this._columnsToExport[columnIndex];
                dataCell = dataRow[gridColumn.key];

                if (this.settings.gridStyling === "applied") {
                    xlRow.getCellFormat(columnIndex).fill(cellFill);
                    xlRow.getCellFormat(columnIndex).font().colorInfo(new $.ig.excel.WorkbookColorInfo(this._rowForeColor));
                }

                // we don't need to check if dataCell is object, because if it is it will be handled during initialization using the column formatter,
                // if there is no formatter grid cell will display "[object object]" and dataCell will return "[object object]"

                if (gridColumn.unbound && gridColumn.formula === undefined && dataCell === undefined) { // when column is unbound and there is formula defined, then we already have the value of the cell in dataCell
                    dataCell = this._gridWidget.igGrid("getCellText", this._getGridRowId(dataRow, rowIndex), gridColumn.key);
                }

                if (gridColumn.formatter !== undefined) {
                    dataCell = gridColumn.formatter(dataCell);
                }

                this._exportCell(xlRow, gridColumn, columnIndex, dataCell, rowIndex);
            }

        },

        _exportCell: function (xlRow, gridColumn, columnIndex, cellValue, rowIndex) {
            var args = {
                columnKey: gridColumn.key,
                columnIndex: columnIndex, xlRow: xlRow,
                cellValue: cellValue,
            },
                noCancel;

            if (rowIndex !== undefined) {
                args.rowId = this._getGridRowId(this._dataToExport[rowIndex], rowIndex);
            }

            noCancel = this._handleEventCallback(this.callbacks.cellExporting, args);

            if (!noCancel) {
                return;
            }

            // we do this because excel is not able to filter on boolean datatype
            if (typeof cellValue === "boolean") {
                //  cellValue = cellValue.toString();
            }
            xlRow.setCellValue(columnIndex, cellValue);
            this._handleEventCallback(this.callbacks.cellExported, args);
        },

        _getGridRowId: function (dataRow, rowIndex) {
            var rowId;

            if (this._grid.options.primaryKey !== null) {
                rowId = dataRow[this._grid.options.primaryKey];
            } else {
                rowId = rowIndex;
            }

            return rowId;
        },

        _recalculateTableEnd: function () {
            var cols = this._worksheetTable.columns().count() - 1;
            var xlRowIndex = this._xlRowIndex - 1;
            this._tableRegionEndCellReference = $.ig.excel.WorksheetCell.getCellAddressString(this._worksheet.rows().item(xlRowIndex), cols, $.ig.excel.CellReferenceMode.a1, false).toString();
        },

        _resizeTableRegion: function () {
            var tableRegionStartCellReference = $.ig.excel.WorksheetCell.getCellAddressString(this._worksheet.rows().item(0), 0, $.ig.excel.CellReferenceMode.a1, false).toString();

            if (tableRegionStartCellReference.substring(tableRegionStartCellReference.lastIndexOf("$") + 1) === this._tableRegionEndCellReference.substring(this._tableRegionEndCellReference.lastIndexOf("$") + 1)) {
                var nextRowIndex = parseInt(this._tableRegionEndCellReference.substring(this._tableRegionEndCellReference.lastIndexOf("$") + 1)) + 1;
                this._tableRegionEndCellReference = this._tableRegionEndCellReference.substring(0, this._tableRegionEndCellReference.lastIndexOf("$") + 1) + nextRowIndex.toString();
            }

            this._worksheetTable.resize(tableRegionStartCellReference + ":" + this._tableRegionEndCellReference);
        },

        _exportFeatures: function () {
            var features = this.settings.gridFeatureOptions;
            var featureName; //_grid.data("igGrid").options.features[i].name

            for (var i = 0; i < this._grid.options.features.length; i++) {
                featureName = this._grid.options.features[i].name;

                if (features[featureName.toLowerCase()] === undefined) {
                    continue;
                }

                // Paging is handled inside exportDataSegment, Hiding is implemented in _calculateColumnsSize
                if (featureName !== "Paging" && featureName !== "Hiding") {
                    if (features[featureName.toLowerCase()] !== "none") {
                        this["_export" + featureName]();
                    }
                }
            }
        },

        // The following method gets the feature by case insensitive name
        _getFeature: function (name) {
            var features = this._grid.options.features;

            for (var featureIndex = 0; featureIndex < features.length; featureIndex++) {
                var feature = features[featureIndex];

                if (feature.name.toLowerCase() === name.toLowerCase()) {
                    return feature;
                }
            }

            return null;
        },

        _exportSorting: function () {
            var orderedSortConditions = this._createSortingConditions();
            var sortExpressions = this._grid.dataSource.settings.sorting.expressions;
            var columnToSort,
                sortDirection;

            for (var i = 0; i < sortExpressions.length; i++) {

                for (var j = 0; j < this._columnsToExport.length; j++) {

                    if (sortExpressions[i].fieldName === this._columnsToExport[j].key) {
                        columnToSort = this._worksheetTable.columns().item(j);
                        sortDirection = sortExpressions[i].dir;

                        if (columnToSort !== undefined && sortDirection !== undefined) {
                            this._worksheetTable.sortSettings().sortConditions().add(columnToSort, orderedSortConditions[sortDirection]);
                        }
                    }
                }
            }
        },

        _createSortingConditions: function () {
            var orderedSortConditions = {
                "asc": new $.ig.excel.OrderedSortCondition($.ig.excel.SortDirection.ascending),
                "desc": new $.ig.excel.OrderedSortCondition($.ig.excel.SortDirection.descending)
            };

            return orderedSortConditions;
        },

        _exportFiltering: function () {
            if (this.settings.gridFeatureOptions.filtering === "filteredRowsOnly") {
                return;
            }

            var filteringConditions = this._createFilteringConditions();
            var filtExpressions = this._grid.dataSource.settings.filtering.expressions;
            var columnToFilter,
                filtCond,
                filtExpr;

            if (filtExpressions.length > 0) {
                for (var i = 0; i < filtExpressions.length; i++) {

                    for (var j = 0; j < this._columnsToExport.length; j++) {
                        if (this._columnsToExport[j].key === filtExpressions[i].fieldName) {
                            columnToFilter = this._worksheetTable.columns().item(j);

                            filtCond = filtExpressions[i].cond;
                            filtExpr = filtExpressions[i].expr;

                            switch (typeof(filtExpr)) {
                                case "string":
                                    columnToFilter.applyCustomFilter(new $.ig.excel.CustomFilterCondition(filteringConditions[filtCond], filtExpr));
                                    break;
                                case "number":
                                    columnToFilter.applyCustomFilter(new $.ig.excel.CustomFilterCondition(filteringConditions[filtCond], filtExpr));
                                    break;
                            }
                        }
                    }

                }
            }

        },

        _createFilteringConditions: function () {
            var filteringConditions = {
                // when column dataType is Number
                "equals":
                // value will return 0
                    $.ig.excel.ExcelComparisonOperator.equals,
                "doesNotEqual":
                // value will return 1
                    $.ig.excel.ExcelComparisonOperator.notEqual,
                "greaterThan":
                // value will return 2
                    $.ig.excel.ExcelComparisonOperator.greaterThan,
                "greaterThanOrEqualTo":
                // value will return 3
                    $.ig.excel.ExcelComparisonOperator.greaterThanOrEqual,
                "lessThan":
                // value will return 4
                    $.ig.excel.ExcelComparisonOperator.lessThan,
                "lessThanOrEqualTo":
                // value will return 5
                    $.ig.excel.ExcelComparisonOperator.lessThanOrEqual,

                // when column dataType is String
                "startsWith":
                // value will return 6
                    $.ig.excel.ExcelComparisonOperator.beginsWith,
                "endsWith":
                // value will return 8
                    $.ig.excel.ExcelComparisonOperator.endsWith,
                "contains":
                // value will return 10
                    $.ig.excel.ExcelComparisonOperator.contains,
                "doesNotContain":
                // value will return 11
                    $.ig.excel.ExcelComparisonOperator.doesNotContain,

                // when column dataType is Date
                // TO DO implement

                // when column dataType is Bool, will return 0
                "false": $.ig.excel.ExcelComparisonOperator.equals,
                "true": $.ig.excel.ExcelComparisonOperator.equals

                // when column dataType is Object
                // *** will require further implementation
            };

            return filteringConditions;
        },

        _exportSummaries: function () {
            if (this._xlRowIndex === 1) {
                return;
            }

            var argumentSeparator = this._getSummariesArgumentSeparator($.ig.CultureInfo.prototype.currentCulture().numberFormat().numberDecimalSeparator());
            var dataEndRowIndex = this._xlRowIndex - 1;

            var summaries = this._gridWidget.igGridSummaries("summaryCollection");
            var worksheet = this._worksheet;

            for (var i = 0; i < this._columnsToExport.length; i++) {

                var columnIndex = i;
                var column = this._columnsToExport[columnIndex];

                //To ensure potential summaries for undefined columns are not exported
                if (summaries[column.key] === undefined) {
                    continue;
                }

                var summariesForColumn = summaries[column.key];
                var dataStartRowIndex = 1;

                // To get the range string in the form of "A1:A45", we can construct a WorksheetRegion instance
                // and then get its string representation in the A1 reference mode, without the sheet name, and
                // with relative row and column identifiers. This is the range to which each summary in the
                // current column will apply.
                var columnReference =
                    new $.ig.excel.WorksheetRegion(this._worksheet, dataStartRowIndex, columnIndex, dataEndRowIndex, columnIndex)
                    .toString($.ig.excel.CellReferenceMode.a1, false, true, true);

                // Export each summary cell applied to the current column
                for (var summaryIndex = 0; summaryIndex < summariesForColumn.length; summaryIndex++) {
                    var summary = summariesForColumn[summaryIndex],
                        summaryType,
                        formatString;
                    switch (summary.type.toLowerCase()) {
                        case "avg":
                            summaryType = 101;
                            formatString = '"' + $.ig.GridSummaries.locale.defaultSummaryRowDisplayLabelAvg + ' = "0.00';
                            break;
                        case "min":
                            summaryType = 105;
                            formatString = '"' + $.ig.GridSummaries.locale.defaultSummaryRowDisplayLabelMin + ' = "0.00';
                            break;
                        case "max":
                            summaryType = 104;
                            formatString = '"' + $.ig.GridSummaries.locale.defaultSummaryRowDisplayLabelMax + ' = "0.00';
                            break;
                        case "count":
                            summaryType = 103;
                            formatString = '"' + $.ig.GridSummaries.locale.defaultSummaryRowDisplayLabelCount + ' = "0.00';
                            break;
                        case "sum":
                            summaryType = 109;
                            formatString = '"' + $.ig.GridSummaries.locale.defaultSummaryRowDisplayLabelSum + ' = "0.00';
                            break;
                    }

                    var args = {
                        headerText: this._grid.options.columns[columnIndex].headerText,
                        columnKey: this._grid.options.columns[columnIndex].key,
                        columnIndex: columnIndex,
                        summary: summariesForColumn[summaryIndex],
                        xlRowIndex: this._xlRowIndex
                    },
                    noCancel = this._handleEventCallback(this.callbacks.summaryExporting, args);

                    if (!noCancel) {
                        return;
                    }

                    if (summaryType) {
                        var xlRow = worksheet.rows(this._xlRowIndex + summaryIndex);
                        xlRow.applyCellFormula(columnIndex, "=SUBTOTAL(" + summaryType + argumentSeparator + columnReference + ")");
                        xlRow.getCellFormat(columnIndex).formatString(formatString);

                        this._handleEventCallback(this.callbacks.summaryExported, args);
                    }
                }
            }
        },

        _getSummariesArgumentSeparator: function (decimalSeparator) {
            if (decimalSeparator === ",") {
                return ";";
            }

            return ",";
        },

        _exportColumnFixing: function () {
            var numberOfFrozenCols = 0;

            for (var i = 0; i < this._columnsToExport.length; i++) {
                if (this._columnsToExport[i].fixed) {
                    numberOfFrozenCols++;
                }
            }

            this._worksheet.displayOptions().frozenPaneSettings().frozenColumns(numberOfFrozenCols);
        },

        _calculateColumnsSize: function () {
            var gridFeatureOptions = this.settings.gridFeatureOptions,
                headers = this._gridWidget.igGrid("headersTable").find("thead"),
                i,
                col,
                colWidth;

            for (i = 0; i < this._columnsToExport.length; i++) {
                var column = this._columnsToExport[i];

                if ((this._getFeature("Hiding") && gridFeatureOptions.hiding === "none") ||
                    (column.fixed && !column.hidden)) {
                    col = this._worksheet.columns().item(i);
                    colWidth = column.width;

                    if (colWidth && !column.hidden) {
                        if (!isNaN(colWidth)) {
                            col.setWidth(colWidth, $.ig.excel.WorksheetColumnWidthUnit.pixel);
                        } else if (isNaN(colWidth)) {
                            var widthSize = colWidth.match(/\d+/)[0];
                            if (colWidth.contains("px")) {
                                col.setWidth(widthSize, $.ig.excel.WorksheetColumnWidthUnit.pixel);
                            } else {
                                col.setWidth((widthSize / 100) * this._gridWidget.width(), $.ig.excel.WorksheetColumnWidthUnit.pixel);
                            }
                        }
                    }
                } else {
                    col = this._worksheet.columns().item(i);
                    var colElemId = (this._grid.id() + "_" + column.key);
                    colWidth = $(headers).find('[id="' + colElemId + '"]').width();
                    col.setWidth(colWidth, $.ig.excel.WorksheetColumnWidthUnit.pixel);
                }
            }
        },

        _saveWorkbook: function () {
            var self = this;

            setTimeout(function () {
                // Finally, save the workbook and create a link so the .xlsx document can be downloaded
                self._workbook.save({ type: "blob" }, function (data) {
                    saveAs(data, self.settings.fileName + ".xlsx");
                    self._handleEventCallback(self.callbacks.success, data);
                }, function (err) {
                    self._handleEventCallback(self.callbacks.error, err);
                });
            }, 1);
        },

        _handleEventCallback: function (callback, args) {
            if (!$.isFunction(callback)) {
                return true;
            }

            var noCancel = callback(this, args);

            if (noCancel === false) {
                return false;
            }

            return true;
        }
    });

    $.ig.GridExcelExporter.export = function (grid, userSettings, userCallbacks) {
        /* Exports the provided igGrid to Excel document.
			paramType="object" Grid to be exported.
			paramType="object" Settings for exporting the grid.
			paramType="object" Callbacks for the events.
		*/
        var exp = new $.ig.GridExcelExporter();
        exp.export(grid, userSettings, userCallbacks);
        exp = null;
    };
}(jQuery));