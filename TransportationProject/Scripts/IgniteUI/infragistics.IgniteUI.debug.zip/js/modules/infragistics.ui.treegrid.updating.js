﻿
/*!@license
 * Infragistics.Web.ClientUI Tree Grid 15.1.20151.2352
 *
 * Copyright (c) 2011-2015 Infragistics Inc.
 *
 * http://www.infragistics.com/
 *
 * Depends on:
 *	jquery-1.4.4.js
 *	jquery.ui.core.js
 *	jquery.ui.widget.js
 *	infragistics.dataSource.js
 *	infragistics.ui.shared.js
 *	infragistics.ui.treegrid.js
 *	infragistics.util.js
 *	infragistics.ui.grid.framework.js
 *	infragistics.ui.grid.updating.js
 */

/*global jQuery */
if (typeof jQuery !== "function") {
	throw new Error("jQuery is undefined");
}
(function ($) {
	var _aNull = function (val) { return val === null || val === undefined; };
	/*
		igTreeGridUpdating widget. The widget is pluggable to the element where the treegrid is instantiated and the actual igTreeGrid object doesn't know about this
		The treegrid updating widget just attaches its functionality to the treegrid
		igTreeGridUpdating is extending the igGridUpdating
	*/
	$.widget("ui.igTreeGridUpdating", $.ui.igGridUpdating, {
			options: {
				enableAddRow: false
			},
			_create: function () {
				this.element.data($.ui.igGridUpdating.prototype.widgetName, this.element.data($.ui.igTreeGridUpdating.prototype.widgetName));
				$.ui.igGridUpdating.prototype._create.apply(this, arguments);
		},
		_getRecord: function (id) {
			var record = $.ui.igGridUpdating.prototype._getRecord.apply(this, arguments),
				pKey, data;
			if (!record) {
				data = this.grid.dataSource._data;
				pKey = this.grid.options.primaryKey;
				if (_aNull(pKey)) {
					pKey = 'ig_pk';
				}
				record = this._getRecordRecursive(id, data, pKey);
			}
			return record;
		},
		_getRecordRecursive: function (id, data, pKey) {
			var i, len = data.length, record,
				dataLayouts = [],
				dsLayoutKey = this.grid.options.childDataKey;
			for (i = 0; i < len; i++) {
				if (data[i][pKey] === id) {
					return data[i];
				}
				if (data[i][dsLayoutKey]) {
					dataLayouts.push(data[i][dsLayoutKey]);
				}
			}
			len = dataLayouts.length;
			for (i = 0; i < len; i++) {
				record = this._getRecordRecursive(id, dataLayouts[i], pKey);
				if (record) {
					return record;
				}
			}
			return null;
		},
		_rowDeleting: function (e, args) {
			var $row = args.row, dataLevel = parseInt($row.attr('data-level'), 10);
			if (!$row || !$row.length) {
				return false;
			}
			if ($row.attr('data-state')) {
				this.grid._toggleRowSuccessors($row, 'none');
			}
			this._pRow = null;
			if (!isNaN(dataLevel) && dataLevel >= 0) {
				this._pRow = $row.prev('tr');
			}
		},
		_rowDeleted: function (e, args) {
			// TO DO uncomment
			//this._syncColumnFixingContainersHeights();
			if (!this.grid.options.autoCommit ||
					!this._pRow ||
					!this._pRow.length) {
				return;
			}
			var $row = args.row, $pRow = this._pRow, dL, found, rowId, children,
				ds = this.grid.dataSource,
				primaryKeyCol, rec, dataLevel = parseInt($row.attr('data-level'), 10);
			if (isNaN(dataLevel) || dataLevel <= 0) {
				return;
			}
			while ($pRow.length === 1) {
				dL = parseInt($pRow.attr('data-level'), 10);
				if (isNaN(dL)) {
					break;
				}
				if (dL < dataLevel) {
					found = true;
					break;
				}
				$pRow = $pRow.prev('tr');
			}
			// detect whether parentRow has children
			if (found) {
				rowId = $pRow.attr('data-id');
				primaryKeyCol = this.grid.columnByKey(this.grid.options.primaryKey);
				if (primaryKeyCol.dataType === "number" || primaryKeyCol.dataType === "numeric") {
					rec = ds.findRecordByKey(parseInt(rowId, 10));
				} else {
					rec = ds.findRecordByKey(rowId);
				}
				if (rec) {
					children = rec[this.grid.options.childDataKey];
					if (children && children.length === 0) {
						if (this.grid.hasFixedColumns()) {
							$pRow = this.container().find('tr[data-id=' + rowId + ']');
						}
						$pRow.find('span[data-expandcell-indicator]').empty();
						$pRow.find('td[data-expand-cell]').removeAttr('data-expand-cell');
					}
				}
			}
			this._pRow = null;
		},
		_generatePrimaryKeyValue: function (e, col) {
			var value, ds = this.grid.dataSource;
			if (col) {
				// M.H. 13 Nov 2014 Fix for bug #185114: The generation of the primary key value when adding new row is not correct for the treegrid
				value = Math.max(this._recCount || 1,
								ds._totalRecordsCount || 1,
								ds._data.length);
				if (this.element.find('tr[data-id=' + value + ']').length) {
					value++;
				}
				this._recCount = value;
				col.value = value;
			}
		},
		_detachEvents: function () {
			if (this._rowDeletingHandler) {
				this.element.unbind('igtreegridupdating_rowdeleting', this._rowDeletingHandler);
			}
			if (this._generatePrimaryKeyValueHandler) {
				this.element.unbind('igtreegridupdatinggenerateprimarykeyvalue', this._generatePrimaryKeyValueHandler);
			}
			if (this._rowDeletedHandler) {
				this.element.unbind('igtreegridupdatinginternalrowdeleted', this._rowDeletedHandler);
			}
		},
		_attachEvents: function () {
			// M.H. 14 Nov 2014 Fix for bug #185126: When autoCommit:true deleting all childs of a row does not remove the expand indicator for the root row of the treegrid
			this._rowDeletedHandler = $.proxy(this._rowDeleted, this);
			this.element.bind('igtreegridupdatinginternalrowdeleted', this._rowDeletedHandler);
			this._rowDeletingHandler = $.proxy(this._rowDeleting, this);
			this.element.bind('igtreegridupdating_rowdeleting', this._rowDeletingHandler);
			this._generatePrimaryKeyValueHandler = $.proxy(this._generatePrimaryKeyValue, this);
			this.element.bind('igtreegridupdatinggenerateprimarykeyvalue', this._generatePrimaryKeyValueHandler);
		},
		_rewriteEvents: function (eventsObject) {
			if ($.type(eventsObject) !== 'object') {
				return;
			}
			var eventName, name, strIgGrid = 'iggrid';
			for (eventName in eventsObject) {
				if (eventsObject.hasOwnProperty(eventName)) {
					if ($.type(eventName) === 'string' &&
						eventName.indexOf(strIgGrid) === 0 && eventName.length > strIgGrid.length) {
						name = 'igtreegrid' + eventName.substr(strIgGrid.length);
						eventsObject[name] = eventsObject[eventName];
						delete eventsObject[eventName];
					}
				}
			}
			return eventsObject;
		},
		destroy: function () {
			this._detachEvents();
			$.ui.igGridUpdating.prototype.destroy.apply(this, arguments);
			this.element.removeData($.ui.igGridUpdating.prototype.widgetName);
		},
		_injectGrid: function (grid, isRebind) {
			$.ui.igGridUpdating.prototype._injectGrid.apply(this, arguments);
			if (!isRebind) {
				this._detachEvents();
				this._attachEvents();
			}
			// overwrite event handlers because events with name like this me._gEvts.iggridvirtualrendering will be not triggered
			if (this._gEvts) {
				grid.element.unbind(this._gEvts);
			}
			this._gEvts = this._rewriteEvents(this._gEvts);
			grid.element.bind(this._gEvts);
			this._evts = this._rewriteEvents(this._evts);
		}
	});
	$.extend($.ui.igTreeGridUpdating, { version: '15.1.20151.2352' });
}(jQuery));


