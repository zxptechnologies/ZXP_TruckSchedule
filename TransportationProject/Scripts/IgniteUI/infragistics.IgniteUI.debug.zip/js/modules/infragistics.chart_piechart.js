﻿/*!@license
* Infragistics.Web.ClientUI infragistics.chart_piechart.js 15.1.20151.2352
*
* Copyright (c) 2011-2015 Infragistics Inc.
*
* http://www.infragistics.com/
*
* Depends:
*     jquery-1.4.4.js
*     jquery.ui.core.js
*     jquery.ui.widget.js
*     infragistics.util.js
*/

// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["AbstractEnumerable:a", 
"Object:b", 
"Type:c", 
"Boolean:d", 
"ValueType:e", 
"Void:f", 
"IConvertible:g", 
"IFormatProvider:h", 
"Number:i", 
"String:j", 
"IComparable:k", 
"Number:l", 
"Number:m", 
"Number:n", 
"Number:o", 
"NumberStyles:p", 
"Enum:q", 
"Array:r", 
"IList:s", 
"ICollection:t", 
"IEnumerable:u", 
"IEnumerator:v", 
"NotSupportedException:w", 
"Error:x", 
"Number:y", 
"String:z", 
"StringComparison:aa", 
"RegExp:ab", 
"CultureInfo:ac", 
"DateTimeFormatInfo:ad", 
"Calendar:ae", 
"Date:af", 
"Number:ag", 
"DayOfWeek:ah", 
"DateTimeKind:ai", 
"CalendarWeekRule:aj", 
"NumberFormatInfo:ak", 
"CompareInfo:al", 
"CompareOptions:am", 
"IEnumerable$1:an", 
"IEnumerator$1:ao", 
"IDisposable:ap", 
"StringSplitOptions:aq", 
"Number:ar", 
"Number:as", 
"Number:at", 
"Number:au", 
"Number:av", 
"Number:aw", 
"Assembly:ax", 
"Stream:ay", 
"SeekOrigin:az", 
"RuntimeTypeHandle:a0", 
"MethodInfo:a1", 
"MethodBase:a2", 
"MemberInfo:a3", 
"ParameterInfo:a4", 
"TypeCode:a5", 
"ConstructorInfo:a6", 
"PropertyInfo:a7", 
"Func$1:a8", 
"MulticastDelegate:a9", 
"IntPtr:ba", 
"AbstractEnumerator:bb", 
"Array:bm", 
"GenericEnumerable$1:ci", 
"GenericEnumerator$1:cj"]);


} (jQuery));



// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["Object:d", 
"Type:e", 
"Boolean:f", 
"ValueType:g", 
"Void:h", 
"IConvertible:i", 
"IFormatProvider:j", 
"Number:k", 
"String:l", 
"IComparable:m", 
"Number:n", 
"Number:o", 
"Number:p", 
"Number:q", 
"NumberStyles:r", 
"Enum:s", 
"Array:t", 
"IList:u", 
"ICollection:v", 
"IEnumerable:w", 
"IEnumerator:x", 
"NotSupportedException:y", 
"Error:z", 
"Number:aa", 
"String:ab", 
"StringComparison:ac", 
"RegExp:ad", 
"CultureInfo:ae", 
"DateTimeFormatInfo:af", 
"Calendar:ag", 
"Date:ah", 
"Number:ai", 
"DayOfWeek:aj", 
"DateTimeKind:ak", 
"CalendarWeekRule:al", 
"NumberFormatInfo:am", 
"CompareInfo:an", 
"CompareOptions:ao", 
"IEnumerable$1:ap", 
"IEnumerator$1:aq", 
"IDisposable:ar", 
"StringSplitOptions:as", 
"Number:at", 
"Number:au", 
"Number:av", 
"Number:aw", 
"Number:ax", 
"Number:ay", 
"Assembly:az", 
"Stream:a0", 
"SeekOrigin:a1", 
"RuntimeTypeHandle:a2", 
"MethodInfo:a3", 
"MethodBase:a4", 
"MemberInfo:a5", 
"ParameterInfo:a6", 
"TypeCode:a7", 
"ConstructorInfo:a8", 
"PropertyInfo:a9", 
"Array:bf", 
"MulticastDelegate:bh", 
"IntPtr:bi", 
"Func$1:hf", 
"AbstractEnumerable:js", 
"AbstractEnumerator:jt", 
"GenericEnumerable$1:ju", 
"GenericEnumerator$1:jv"]);


} (jQuery));



// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["IProvidesViewport:a", 
"Void:b", 
"ValueType:c", 
"Object:d", 
"Type:e", 
"Boolean:f", 
"IConvertible:g", 
"IFormatProvider:h", 
"Number:i", 
"String:j", 
"IComparable:k", 
"Number:l", 
"Number:m", 
"Number:n", 
"Number:o", 
"NumberStyles:p", 
"Enum:q", 
"Array:r", 
"IList:s", 
"ICollection:t", 
"IEnumerable:u", 
"IEnumerator:v", 
"NotSupportedException:w", 
"Error:x", 
"Number:y", 
"String:z", 
"StringComparison:aa", 
"RegExp:ab", 
"CultureInfo:ac", 
"DateTimeFormatInfo:ad", 
"Calendar:ae", 
"Date:af", 
"Number:ag", 
"DayOfWeek:ah", 
"DateTimeKind:ai", 
"CalendarWeekRule:aj", 
"NumberFormatInfo:ak", 
"CompareInfo:al", 
"CompareOptions:am", 
"IEnumerable$1:an", 
"IEnumerator$1:ao", 
"IDisposable:ap", 
"StringSplitOptions:aq", 
"Number:ar", 
"Number:as", 
"Number:at", 
"Number:au", 
"Number:av", 
"Number:aw", 
"Assembly:ax", 
"Stream:ay", 
"SeekOrigin:az", 
"RuntimeTypeHandle:a0", 
"MethodInfo:a1", 
"MethodBase:a2", 
"MemberInfo:a3", 
"ParameterInfo:a4", 
"TypeCode:a5", 
"ConstructorInfo:a6", 
"PropertyInfo:a7", 
"Rect:a8", 
"Size:a9", 
"Point:ba", 
"Math:bb", 
"Series:bc", 
"Control:bd", 
"FrameworkElement:be", 
"UIElement:bf", 
"DependencyObject:bg", 
"Dictionary:bh", 
"DependencyProperty:bi", 
"PropertyMetadata:bj", 
"PropertyChangedCallback:bk", 
"MulticastDelegate:bl", 
"IntPtr:bm", 
"DependencyPropertyChangedEventArgs:bn", 
"DependencyPropertiesCollection:bo", 
"UnsetValue:bp", 
"Script:bq", 
"Binding:br", 
"PropertyPath:bs", 
"Transform:bt", 
"Visibility:bu", 
"Style:bv", 
"Thickness:bw", 
"HorizontalAlignment:bx", 
"VerticalAlignment:by", 
"INotifyPropertyChanged:bz", 
"PropertyChangedEventHandler:b0", 
"PropertyChangedEventArgs:b1", 
"SeriesView:b2", 
"ISchedulableRender:b3", 
"SeriesViewer:b4", 
"SeriesViewerView:b5", 
"CanvasRenderScheduler:b6", 
"List$1:b7", 
"IList$1:b8", 
"ICollection$1:b9", 
"IArray:ca", 
"IArrayList:cb", 
"Array:cc", 
"CompareCallback:cd", 
"Func$3:ce", 
"Action$1:cf", 
"Comparer$1:cg", 
"IComparer:ch", 
"IComparer$1:ci", 
"DefaultComparer$1:cj", 
"IComparable$1:ck", 
"Comparison$1:cl", 
"ReadOnlyCollection$1:cm", 
"Predicate$1:cn", 
"NotImplementedException:co", 
"Callback:cp", 
"window:cq", 
"RenderingContext:cr", 
"IRenderer:cs", 
"Rectangle:ct", 
"Shape:cu", 
"Brush:cv", 
"Color:cw", 
"ArgumentException:cx", 
"DoubleCollection:cy", 
"Path:cz", 
"Geometry:c0", 
"GeometryType:c1", 
"TextBlock:c2", 
"Polygon:c3", 
"PointCollection:c4", 
"Polyline:c5", 
"DataTemplateRenderInfo:c6", 
"DataTemplatePassInfo:c7", 
"ContentControl:c8", 
"DataTemplate:c9", 
"DataTemplateRenderHandler:da", 
"DataTemplateMeasureHandler:db", 
"DataTemplateMeasureInfo:dc", 
"DataTemplatePassHandler:dd", 
"Line:de", 
"FontInfo:df", 
"XamOverviewPlusDetailPane:dg", 
"XamOverviewPlusDetailPaneView:dh", 
"XamOverviewPlusDetailPaneViewManager:di", 
"JQueryObject:dj", 
"Element:dk", 
"ElementAttributeCollection:dl", 
"ElementCollection:dm", 
"WebStyle:dn", 
"ElementNodeType:dp", 
"Document:dq", 
"EventListener:dr", 
"IElementEventHandler:ds", 
"ElementEventHandler:dt", 
"ElementAttribute:du", 
"JQueryPosition:dv", 
"JQueryCallback:dw", 
"JQueryEvent:dx", 
"JQueryUICallback:dy", 
"EventProxy:dz", 
"ModifierKeys:d0", 
"Func$2:d1", 
"MouseWheelHandler:d2", 
"Delegate:d3", 
"Interlocked:d4", 
"GestureHandler:d5", 
"ContactHandler:d6", 
"TouchHandler:d7", 
"MouseOverHandler:d8", 
"MouseHandler:d9", 
"KeyHandler:ea", 
"Key:eb", 
"JQuery:ec", 
"JQueryDeferred:ed", 
"JQueryPromise:ee", 
"Action:ef", 
"CanvasViewRenderer:eg", 
"CanvasContext2D:eh", 
"CanvasContext:ei", 
"TextMetrics:ej", 
"ImageData:ek", 
"CanvasElement:el", 
"Gradient:em", 
"LinearGradientBrush:en", 
"GradientStop:eo", 
"GeometryGroup:ep", 
"GeometryCollection:eq", 
"FillRule:er", 
"PathGeometry:es", 
"PathFigureCollection:et", 
"LineGeometry:eu", 
"RectangleGeometry:ev", 
"EllipseGeometry:ew", 
"ArcSegment:ex", 
"PathSegment:ey", 
"PathSegmentType:ez", 
"SweepDirection:e0", 
"PathFigure:e1", 
"PathSegmentCollection:e2", 
"LineSegment:e3", 
"PolyLineSegment:e4", 
"BezierSegment:e5", 
"PolyBezierSegment:e6", 
"GeometryUtil:e7", 
"Tuple$2:e8", 
"TransformGroup:e9", 
"TransformCollection:fa", 
"TranslateTransform:fb", 
"RotateTransform:fc", 
"ScaleTransform:fd", 
"DivElement:fe", 
"DOMEventProxy:ff", 
"MSGesture:fg", 
"MouseEventArgs:fh", 
"EventArgs:fi", 
"DoubleAnimator:fj", 
"EasingFunctionHandler:fk", 
"ImageElement:fl", 
"RectUtil:fm", 
"MathUtil:fn", 
"RuntimeHelpers:fo", 
"RuntimeFieldHandle:fp", 
"PropertyChangedEventArgs$1:fq", 
"InteractionState:fr", 
"OverviewPlusDetailPaneMode:fs", 
"IOverviewPlusDetailControl:ft", 
"EventHandler$1:fu", 
"ArgumentNullException:fv", 
"OverviewPlusDetailViewportHost:fw", 
"SeriesCollection:fx", 
"ObservableCollection$1:fy", 
"INotifyCollectionChanged:fz", 
"NotifyCollectionChangedEventHandler:f0", 
"NotifyCollectionChangedEventArgs:f1", 
"NotifyCollectionChangedAction:f2", 
"AxisCollection:f3", 
"SeriesViewerViewManager:f4", 
"AxisTitlePosition:f5", 
"PointerTooltipStyle:f6", 
"Dictionary$2:f7", 
"IDictionary$2:f8", 
"IDictionary:f9", 
"KeyValuePair$2:ga", 
"Enumerable:gb", 
"Thread:gc", 
"ThreadStart:gd", 
"IOrderedEnumerable$1:ge", 
"SortedList$1:gf", 
"IEqualityComparer$1:gg", 
"EqualityComparer$1:gh", 
"IEqualityComparer:gi", 
"DefaultEqualityComparer$1:gj", 
"InvalidOperationException:gk", 
"BrushCollection:gl", 
"InterpolationMode:gm", 
"Random:gn", 
"ColorUtil:go", 
"CssHelper:gp", 
"CssGradientUtil:gq", 
"FontUtil:gr", 
"TileZoomTile:gs", 
"TileZoomTileInfo:gt", 
"TileZoomTileCache:gu", 
"TileZoomManager:gv", 
"RectChangedEventHandler:gw", 
"RectChangedEventArgs:gx", 
"Debug:gy", 
"TileZoomInfo:gz", 
"LinkedList$1:g0", 
"LinkedListNode$1:g1", 
"RenderSurface:g2", 
"DataContext:g3", 
"SeriesViewerComponentsFromView:g4", 
"SeriesViewerSurfaceViewer:g5", 
"Canvas:g6", 
"Panel:g7", 
"UIElementCollection:g8", 
"StackedSeriesBase:g9", 
"CategorySeries:ha", 
"MarkerSeries:hb", 
"MarkerSeriesView:hc", 
"Marker:hd", 
"MarkerTemplates:he", 
"HashPool$2:hf", 
"IHashPool$2:hg", 
"IPool$1:hh", 
"Func$1:hi", 
"Pool$1:hj", 
"IIndexedPool$1:hk", 
"MarkerType:hl", 
"SeriesVisualData:hm", 
"PrimitiveVisualDataList:hn", 
"IVisualData:ho", 
"PrimitiveVisualData:hp", 
"PrimitiveAppearanceData:hq", 
"BrushAppearanceData:hr", 
"StringBuilder:hs", 
"Environment:ht", 
"AppearanceHelper:hu", 
"LinearGradientBrushAppearanceData:hv", 
"GradientStopAppearanceData:hw", 
"SolidBrushAppearanceData:hx", 
"GeometryData:hy", 
"GetPointsSettings:hz", 
"EllipseGeometryData:h0", 
"RectangleGeometryData:h1", 
"LineGeometryData:h2", 
"PathGeometryData:h3", 
"PathFigureData:h4", 
"SegmentData:h5", 
"LineSegmentData:h6", 
"PolylineSegmentData:h7", 
"ArcSegmentData:h8", 
"PolyBezierSegmentData:h9", 
"BezierSegmentData:ia", 
"LabelAppearanceData:ib", 
"ShapeTags:ic", 
"PointerTooltipVisualDataList:id", 
"MarkerVisualDataList:ie", 
"MarkerVisualData:ig", 
"PointerTooltipVisualData:ih", 
"RectangleVisualData:ii", 
"PolygonVisualData:ij", 
"PolyLineVisualData:ik", 
"IFastItemsSource:il", 
"IFastItemColumn$1:im", 
"IFastItemColumnPropertyName:io", 
"FastItemsSourceEventArgs:ip", 
"FastItemsSourceEventAction:iq", 
"IHasCategoryModePreference:ir", 
"IHasCategoryAxis:is", 
"CategoryAxisBase:it", 
"Axis:iu", 
"AxisView:iv", 
"XamDataChart:iw", 
"GridMode:ix", 
"XamDataChartView:iy", 
"FragmentBase:iz", 
"HorizontalAnchoredCategorySeries:i0", 
"AnchoredCategorySeries:i1", 
"IIsCategoryBased:i2", 
"CategoryMode:i3", 
"ICategoryScaler:i4", 
"IScaler:i5", 
"ScalerParams:i6", 
"IBucketizer:i7", 
"IDetectsCollisions:i8", 
"IHasSingleValueCategory:i9", 
"IHasCategoryTrendline:ja", 
"IHasTrendline:jb", 
"TrendLineType:jc", 
"IPreparesCategoryTrendline:jd", 
"TrendResolutionParams:je", 
"AnchoredCategorySeriesView:jf", 
"CategorySeriesView:jg", 
"ISupportsMarkers:jh", 
"CategoryBucketCalculator:ji", 
"ISortingAxis:jj", 
"CategoryFrame:jk", 
"Frame:jl", 
"BrushUtil:jm", 
"CategoryTrendLineManagerBase:jn", 
"TrendLineManagerBase$1:jo", 
"Clipper:jp", 
"EdgeClipper:jq", 
"LeftClipper:jr", 
"BottomClipper:js", 
"RightClipper:jt", 
"TopClipper:ju", 
"Flattener:jv", 
"Stack$1:jw", 
"ReverseArrayEnumerator$1:jx", 
"SpiralTodo:jy", 
"FlattenerSettings:jz", 
"Func$4:j0", 
"SortingTrendLineManager:j1", 
"TrendFitCalculator:j2", 
"LeastSquaresFit:j3", 
"Numeric:j4", 
"TrendAverageCalculator:j5", 
"CategoryTrendLineManager:j6", 
"AnchoredCategoryBucketCalculator:j7", 
"CategoryDateTimeXAxis:j8", 
"CategoryDateTimeXAxisView:j9", 
"CategoryAxisBaseView:ka", 
"TimeAxisDisplayType:kb", 
"FastItemDateTimeColumn:kc", 
"IFastItemColumnInternal:kd", 
"FastItemColumn:ke", 
"FastReflectionHelper:kf", 
"AxisOrientation:kg", 
"AxisLabelPanelBase:kh", 
"AxisLabelPanelBaseView:ki", 
"AxisLabelSettings:kj", 
"AxisLabelsLocation:kk", 
"PropertyUpdatedEventHandler:kl", 
"PropertyUpdatedEventArgs:km", 
"PathRenderingInfo:kn", 
"LabelPosition:ko", 
"NumericAxisBase:kp", 
"NumericAxisBaseView:kq", 
"NumericAxisRenderer:kr", 
"AxisRendererBase:ks", 
"ShouldRenderHandler:kt", 
"ScaleValueHandler:ku", 
"AxisRenderingParametersBase:kv", 
"RangeInfo:kw", 
"TickmarkValues:kx", 
"TickmarkValuesInitializationParameters:ky", 
"GetGroupCenterHandler:kz", 
"GetUnscaledGroupCenterHandler:k0", 
"RenderStripHandler:k1", 
"RenderLineHandler:k2", 
"ShouldRenderLinesHandler:k3", 
"ShouldRenderContentHandler:k4", 
"RenderAxisLineHandler:k5", 
"DetermineCrossingValueHandler:k6", 
"ShouldRenderLabelHandler:k7", 
"GetLabelLocationHandler:k8", 
"TransformToLabelValueHandler:k9", 
"AxisLabelManager:la", 
"GetLabelForItemHandler:lb", 
"CreateRenderingParamsHandler:lc", 
"SnapMajorValueHandler:ld", 
"AdjustMajorValueHandler:le", 
"CategoryAxisRenderingParameters:lf", 
"LogarithmicTickmarkValues:lg", 
"LogarithmicNumericSnapper:lh", 
"Snapper:li", 
"LinearTickmarkValues:lj", 
"LinearNumericSnapper:lk", 
"AxisRangeChangedEventArgs:ll", 
"AxisRange:lm", 
"IEquatable$1:ln", 
"AutoRangeCalculator:lo", 
"NumericYAxis:lp", 
"StraightNumericAxisBase:lq", 
"StraightNumericAxisBaseView:lr", 
"NumericScaler:ls", 
"NumericScaleMode:lt", 
"LogarithmicScaler:lu", 
"NumericYAxisView:lv", 
"VerticalAxisLabelPanel:lw", 
"VerticalAxisLabelPanelView:lx", 
"TitleSettings:ly", 
"NumericAxisRenderingParameters:lz", 
"VerticalLogarithmicScaler:l0", 
"VerticalLinearScaler:l1", 
"LinearScaler:l2", 
"NumericRadiusAxis:l3", 
"NumericRadiusAxisView:l4", 
"NumericAngleAxis:l5", 
"IAngleScaler:l6", 
"NumericAngleAxisView:l7", 
"PolarAxisRenderingManager:l8", 
"ViewportUtils:l9", 
"PolarAxisRenderingParameters:ma", 
"IPolarRadialRenderingParameters:mb", 
"RadialAxisRenderingParameters:mc", 
"AngleAxisLabelPanel:md", 
"AngleAxisLabelPanelView:me", 
"Extensions:mf", 
"CategoryAngleAxis:mg", 
"CategoryAngleAxisView:mh", 
"CategoryAxisRenderer:mi", 
"LinearCategorySnapper:mj", 
"CategoryTickmarkValues:mk", 
"RadialAxisLabelPanel:ml", 
"HorizontalAxisLabelPanelBase:mm", 
"HorizontalAxisLabelPanelBaseView:mn", 
"RadialAxisLabelPanelView:mo", 
"SmartAxisLabelPanel:mp", 
"AxisExtentType:mq", 
"SmartAxisLabelPanelView:mr", 
"HorizontalAxisLabelPanel:ms", 
"CoercionInfo:mt", 
"SortedListView$1:mu", 
"ArrayUtil:mv", 
"CategoryLineRasterizer:mw", 
"UnknownValuePlotting:mx", 
"Action$5:my", 
"PenLineCap:mz", 
"CategorySeriesMarkerCollisionAvoidance:m0", 
"CategoryFramePreparer:m1", 
"CategoryFramePreparerBase:m2", 
"FramePreparer:m3", 
"ISupportsErrorBars:m4", 
"DefaultSupportsMarkers:m5", 
"DefaultProvidesViewport:m6", 
"DefaultSupportsErrorBars:m7", 
"PreparationParams:m8", 
"CategoryYAxis:m9", 
"CategoryYAxisView:na", 
"SyncSettings:nb", 
"NumericXAxis:nc", 
"NumericXAxisView:nd", 
"HorizontalLogarithmicScaler:ne", 
"HorizontalLinearScaler:nf", 
"ValuesHolder:ng", 
"LineSeries:nh", 
"LineSeriesView:ni", 
"PathVisualData:nj", 
"CategorySeriesRenderManager:nk", 
"AssigningCategoryStyleEventArgs:nl", 
"AssigningCategoryStyleEventArgsBase:nm", 
"GetCategoryItemsHandler:nn", 
"HighlightingInfo:no", 
"HighlightingState:np", 
"AssigningCategoryMarkerStyleEventArgs:nq", 
"HighlightingManager:nr", 
"SplineSeriesBase:ns", 
"SplineSeriesBaseView:nt", 
"SplineType:nu", 
"CollisionAvoider:nv", 
"SafeSortedReadOnlyDoubleCollection:nw", 
"SafeReadOnlyDoubleCollection:nx", 
"SafeEnumerable:ny", 
"AreaSeries:nz", 
"AreaSeriesView:n0", 
"LegendTemplates:n1", 
"PieChartBase:n2", 
"PieChartBaseView:n3", 
"PieChartViewManager:n4", 
"PieChartVisualData:n5", 
"PieSliceVisualDataList:n6", 
"PieSliceVisualData:n7", 
"PieSliceDataContext:n8", 
"Slice:n9", 
"SliceView:oa", 
"PieLabel:ob", 
"MouseButtonEventArgs:oc", 
"FastItemsSource:od", 
"ColumnReference:oe", 
"FastItemObjectColumn:of", 
"FastItemIntColumn:og", 
"LabelsPosition:oh", 
"LeaderLineType:oi", 
"OthersCategoryType:oj", 
"IndexCollection:ok", 
"LegendBase:ol", 
"LegendBaseView:om", 
"LegendBaseViewManager:on", 
"GradientData:oo", 
"GradientStopData:op", 
"DataChartLegendMouseButtonEventArgs:oq", 
"DataChartMouseButtonEventArgs:or", 
"ChartLegendMouseEventArgs:os", 
"ChartMouseEventArgs:ot", 
"DataChartLegendMouseButtonEventHandler:ou", 
"DataChartLegendMouseEventHandler:ov", 
"LegendVisualData:ow", 
"LegendVisualDataList:ox", 
"LegendItemVisualData:oy", 
"FunnelSliceDataContext:oz", 
"PieChartFormatLabelHandler:o0", 
"SliceClickEventHandler:o1", 
"SliceClickEventArgs:o2", 
"ItemLegend:o3", 
"ItemLegendView:o4", 
"LegendItemInfo:o5", 
"BubbleSeries:o6", 
"ScatterBase:o7", 
"ScatterBaseView:o8", 
"MarkerManagerBase:o9", 
"OwnedPoint:pa", 
"MarkerManagerBucket:pb", 
"ScatterTrendLineManager:pc", 
"NumericMarkerManager:pd", 
"CollisionAvoidanceType:pe", 
"SmartPlacer:pf", 
"ISmartPlaceable:pg", 
"SmartPosition:ph", 
"SmartPlaceableWrapper$1:pi", 
"ScatterAxisInfoCache:pj", 
"ScatterErrorBarSettings:pk", 
"ErrorBarSettingsBase:pl", 
"EnableErrorBars:pm", 
"ErrorBarCalculatorReference:pn", 
"IErrorBarCalculator:po", 
"ErrorBarCalculatorType:pp", 
"ScatterFrame:pq", 
"ScatterFrameBase$1:pr", 
"DictInterpolator$3:ps", 
"Action$6:pt", 
"SyncLink:pu", 
"IFastItemsSourceProvider:pv", 
"ChartCollection:pw", 
"FastItemsSourceReference:px", 
"SyncManager:py", 
"SyncLinkManager:pz", 
"ErrorBarsHelper:p0", 
"BubbleSeriesView:p1", 
"BubbleMarkerManager:p2", 
"SizeScale:p3", 
"BrushScale:p4", 
"ScaleLegend:p5", 
"ScaleLegendView:p6", 
"CustomPaletteBrushScale:p7", 
"BrushSelectionMode:p8", 
"ValueBrushScale:p9", 
"RingSeriesBase:qa", 
"XamDoughnutChart:qb", 
"RingCollection:qc", 
"Ring:qd", 
"RingControl:qe", 
"RingControlView:qf", 
"Arc:qg", 
"ArcView:qh", 
"ArcItem:qi", 
"SliceItem:qj", 
"Legend:qk", 
"LegendView:ql", 
"SplineFragmentBase:qm", 
"StackedFragmentSeries:qn", 
"StackedAreaSeries:qo", 
"HorizontalStackedSeriesBase:qp", 
"StackedSplineAreaSeries:qq", 
"AreaFragment:qr", 
"AreaFragmentView:qs", 
"AreaFragmentBucketCalculator:qt", 
"IStacked100Series:qu", 
"SplineAreaFragment:qv", 
"SplineAreaFragmentView:qw", 
"StackedSeriesManager:qx", 
"StackedSeriesCollection:qy", 
"StackedSeriesView:qz", 
"StackedBucketCalculator:q0", 
"StackedLineSeries:q1", 
"StackedSplineSeries:q2", 
"StackedColumnSeries:q3", 
"StackedColumnSeriesView:q4", 
"StackedColumnBucketCalculator:q5", 
"ColumnFragment:q6", 
"ColumnFragmentView:q7", 
"CategoryMarkerManager:q8", 
"LineFragment:q9", 
"LineFragmentView:ra", 
"LineFragmentBucketCalculator:rb", 
"StackedBarSeries:rc", 
"VerticalStackedSeriesBase:rd", 
"IBarSeries:re", 
"StackedBarSeriesView:rf", 
"StackedBarBucketCalculator:rg", 
"BarFragment:rh", 
"SplineFragment:ri", 
"SplineFragmentView:rj", 
"SplineFragmentBucketCalculator:rk", 
"BarSeries:rl", 
"VerticalAnchoredCategorySeries:rm", 
"BarSeriesView:rn", 
"BarTrendLineManager:ro", 
"BarTrendFitCalculator:rp", 
"BarBucketCalculator:rq", 
"CategoryTransitionInMode:rr", 
"BarFramePreparer:rs", 
"DefaultCategoryTrendlineHost:rt", 
"DefaultCategoryTrendlinePreparer:ru", 
"DefaultSingleValueProvider:rv", 
"SingleValuesHolder:rw", 
"RingSeriesBaseView:rx", 
"Nullable$1:ry", 
"RingSeriesCollection:rz", 
"SliceCollection:r0", 
"XamDoughnutChartView:r1", 
"Action$2:r2", 
"DoughnutChartVisualData:r3", 
"RingSeriesVisualDataList:r4", 
"RingSeriesVisualData:r5", 
"RingVisualDataList:r6", 
"RingVisualData:r7", 
"ArcVisualDataList:r8", 
"ArcVisualData:r9", 
"SliceVisualDataList:sa", 
"SliceVisualData:sb", 
"DoughnutChartLabelVisualData:sc", 
"HoleDimensionsChangedEventHandler:sd", 
"HoleDimensionsChangedEventArgs:se", 
"XamFunnelChart:sf", 
"IItemProvider:sg", 
"MessageHandler:sh", 
"MessageHandlerEventHandler:si", 
"Message:sj", 
"ServiceProvider:sk", 
"MessageChannel:sl", 
"MessageEventHandler:sm", 
"Queue$1:sn", 
"XamFunnelConnector:so", 
"XamFunnelController:sp", 
"SliceInfoList:sq", 
"SliceInfo:sr", 
"SliceAppearance:ss", 
"PointList:st", 
"FunnelSliceVisualData:su", 
"SliceInfoUnaryComparison:sv", 
"Bezier:sw", 
"BezierPoint:sx", 
"BezierOp:sy", 
"BezierPointComparison:sz", 
"DoubleColumn:s0", 
"ObjectColumn:s1", 
"XamFunnelView:s2", 
"IOuterLabelWidthDecider:s3", 
"IFunnelLabelSizeDecider:s4", 
"MouseLeaveMessage:s5", 
"InteractionMessage:s6", 
"MouseMoveMessage:s7", 
"MouseButtonMessage:s8", 
"MouseButtonAction:s9", 
"MouseButtonType:ta", 
"SetAreaSizeMessage:tb", 
"RenderingMessage:tc", 
"RenderSliceMessage:td", 
"RenderOuterLabelMessage:te", 
"TooltipValueChangedMessage:tf", 
"TooltipUpdateMessage:tg", 
"FunnelDataContext:th", 
"PropertyChangedMessage:ti", 
"ConfigurationMessage:tj", 
"ClearMessage:tk", 
"ClearTooltipMessage:tl", 
"ContainerSizeChangedMessage:tm", 
"ViewportChangedMessage:tn", 
"ViewPropertyChangedMessage:to", 
"OuterLabelAlignment:tp", 
"FunnelSliceDisplay:tq", 
"SliceSelectionManager:tr", 
"DataUpdatedMessage:ts", 
"ItemsSourceAction:tt", 
"FunnelFrame:tu", 
"UserSelectedItemsChangedMessage:tv", 
"LabelSizeChangedMessage:tw", 
"FrameRenderCompleteMessage:tx", 
"IntColumn:ty", 
"IntColumnComparison:tz", 
"Convert:t0", 
"SelectedItemsChangedMessage:t1", 
"ModelUpdateMessage:t2", 
"SliceClickedMessage:t3", 
"FunnelSliceClickedEventHandler:t4", 
"FunnelSliceClickedEventArgs:t5", 
"FunnelChartVisualData:t6", 
"FunnelSliceVisualDataList:t7", 
"RingSeries:t8", 
"WaterfallSeries:t9", 
"WaterfallSeriesView:ua", 
"FinancialSeries:ub", 
"FinancialSeriesView:uc", 
"FinancialBucketCalculator:ud", 
"CategoryTransitionSourceFramePreparer:ue", 
"TransitionInSpeedType:uf", 
"FinancialCalculationDataSource:ug", 
"CalculatedColumn:uh", 
"FinancialEventArgs:ui", 
"FinancialCalculationSupportingCalculations:uj", 
"ColumnSupportingCalculation:uk", 
"SupportingCalculation$1:ul", 
"SupportingCalculationStrategy:um", 
"DataSourceSupportingCalculation:un", 
"ProvideColumnValuesStrategy:uo", 
"AssigningCategoryStyleEventHandler:up", 
"FinancialValueList:uq", 
"FinancialEventHandler:ur", 
"StepLineSeries:us", 
"StepLineSeriesView:ut", 
"StepAreaSeries:uu", 
"StepAreaSeriesView:uv", 
"RangeAreaSeries:uw", 
"HorizontalRangeCategorySeries:ux", 
"RangeCategorySeries:uy", 
"IHasHighLowValueCategory:uz", 
"RangeCategorySeriesView:u0", 
"RangeCategoryBucketCalculator:u1", 
"RangeCategoryFramePreparer:u2", 
"DefaultHighLowValueProvider:u3", 
"HighLowValuesHolder:u4", 
"RangeValueList:u5", 
"RangeAreaSeriesView:u6", 
"NonCollisionAvoider:u7", 
"AxisRangeChangedEventHandler:u8", 
"DataChartAxisRangeChangedEventHandler:u9", 
"ChartAxisRangeChangedEventArgs:va", 
"ChartVisualData:vb", 
"AxisVisualDataList:vc", 
"SeriesVisualDataList:vd", 
"ChartTitleVisualData:ve", 
"VisualDataSerializer:vf", 
"AxisVisualData:vg", 
"AxisLabelVisualDataList:vh", 
"AxisLabelVisualData:vi", 
"RadialBase:vj", 
"RadialBaseView:vk", 
"RadialBucketCalculator:vl", 
"SeriesRenderer$2:vm", 
"SeriesRenderingArguments:vn", 
"RadialFrame:vo", 
"RadialAxes:vp", 
"PolarBase:vq", 
"PolarBaseView:vr", 
"PolarTrendLineManager:vs", 
"PolarLinePlanner:vt", 
"AngleRadiusPair:vu", 
"PolarAxisInfoCache:vv", 
"PolarFrame:vw", 
"PolarAxes:vx", 
"AxisComponentsForView:vy", 
"AxisComponentsFromView:vz", 
"AxisFormatLabelHandler:v0", 
"VisualExportHelper:v1", 
"ContentInfo:v2", 
"ChartContentManager:v3", 
"ChartContentType:v4", 
"RenderRequestedEventArgs:v5", 
"AssigningCategoryMarkerStyleEventHandler:v6", 
"SeriesComponentsForView:v7", 
"StackedSeriesFramePreparer:v8", 
"StackedSeriesCreatedEventHandler:v9", 
"StackedSeriesCreatedEventArgs:wa", 
"StackedSeriesVisualData:wb", 
"LabelPanelArranger:wc", 
"LabelPanelsArrangeState:wd", 
"WindowResponse:we", 
"ViewerSurfaceUsage:wf", 
"SeriesViewerComponentsForView:wg", 
"DataChartCursorEventHandler:wh", 
"ChartCursorEventArgs:wi", 
"DataChartMouseButtonEventHandler:wj", 
"DataChartMouseEventHandler:wk", 
"AnnotationLayer:wl", 
"AnnotationLayerView:wm", 
"RefreshCompletedEventHandler:wn", 
"SeriesComponentsFromView:wo", 
"EasingFunctions:wp", 
"TrendCalculators:wq", 
"HierarchicalRingSeries:xx", 
"IgQueue$1:xy", 
"Node:xz", 
"XamPieChart:abm", 
"XamPieChartView:abn", 
"AbstractEnumerable:acm", 
"AbstractEnumerator:acn", 
"GenericEnumerable$1:aco", 
"GenericEnumerator$1:acp"]);


$.ig.util.defType('HierarchicalRingSeries', 'RingSeriesBase', {
	init: function () {
		$.ig.RingSeriesBase.prototype.init.call(this);
		this.defaultStyleKey($.ig.HierarchicalRingSeries.prototype.$type);
	},
	_rings: null,
	rings: function (value) {
		if (arguments.length === 1) {
			this._rings = value;
			return value;
		} else {
			return this._rings;
		}
	}
	,
	childrenMemberPath: function (value) {
		if (arguments.length === 1) {
			this.setValue($.ig.HierarchicalRingSeries.prototype.childrenMemberPathProperty, value);
			return value;
		} else {
			return this.getValue($.ig.HierarchicalRingSeries.prototype.childrenMemberPathProperty);
		}
	}
	,
	analyzeRings: function () {
		if (this.itemsSource() == null) {
			return new $.ig.RingCollection();
		}
		this.rings(this.traverseTree(this.itemsSource()));
		return this.rings();
	}
	,
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.RingSeriesBase.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		if (propertyName == $.ig.RingSeriesBase.prototype.startAnglePropertyName) {
			var oldAngle = oldValue;
			var newAngle = newValue;
			var delta = newAngle - oldAngle;
			if (this.rings() != null && this.rings().count() > 0) {
				for (var index = 0; index < this.rings().count(); index++) {
					var ring = this.rings().__inner[index];
					var en = ring.arcItems().getEnumerator();
					while (en.moveNext()) {
						var arc = en.current();
						arc.startAngle(arc.startAngle() + delta);
					}
				}
			}
		}
		if (propertyName == $.ig.RingSeriesBase.prototype.brushesPropertyName) {
			this.prepareBrushes();
		}
		if (this.rings() != null && this.view().isReady()) {
			var resized = false;
			var en1 = this.rings().getEnumerator();
			while (en1.moveNext()) {
				var ring1 = en1.current();
				ring1.prepareArcs();
				if (ring1.renderArcs()) {
					resized = true;
				}
			}
			if (resized) {
				var en2 = this.rings().getEnumerator();
				while (en2.moveNext()) {
					var ring2 = en2.current();
					ring2.ringSeries().view().onSizeChanged();
				}
			}
		}
	}
	,
	prepareData: function () {
		if (this.chart() != null) {
			this.chart().prepareRingCollection();
			this.chart().renderChart();
		}
	}
	,
	prepareBrushes: function () {
		if (this.rings() != null) {
			var en = this.rings().getEnumerator();
			while (en.moveNext()) {
				var ring = en.current();
				var en1 = ring.arcItems().getEnumerator();
				while (en1.moveNext()) {
					var arcItem = en1.current();
					this.setBrush(arcItem);
				}
			}
		}
	}
	,
	renderSeries: function () {
		if (this.rings() != null && this.rings().count() > 0) {
			var outerRing = this.rings().__inner[this.rings().count() - 1];
			this.width(outerRing.controlSize().width());
			this.height(outerRing.controlSize().height());
			this.view().positionSeries(outerRing.center().__x, outerRing.center().__y);
		}
	}
	,
	renderLegendItems: function () {
		for (var i = 0; i < this.rings().count(); i++) {
			var en = this.rings().__inner[i].ringControl()._arcs.active().getEnumerator();
			while (en.moveNext()) {
				var arc = en.current();
				arc.renderLegendItems();
			}
		}
	}
	,
	reflectItemSource: function (obj_) {
		var memberPath_ = this.childrenMemberPath();
		if (obj_[memberPath_] !== undefined) {
			return obj_[memberPath_];
		}
		return null;
	}
	,
	traverseTree: function (root) {
		var $self = this;
		var parents = new $.ig.IgQueue$1($.ig.ArcItem.prototype.$type);
		var nodes = new $.ig.IgQueue$1($.ig.ArcItem.prototype.$type);
		var rootInfo = (function () {
			var $ret = new $.ig.ArcItem();
			$ret.levelDepth(0);
			$ret.itemSource(root);
			$ret.valueMemberPath($self.valueMemberPath());
			$ret.othersCategoryType($self.othersCategoryType());
			$ret.othersCategoryThreshold($self.othersCategoryThreshold());
			return $ret;
		}());
		rootInfo.prepareSliceItems(this.startAngle());
		var parentInfo = (function () {
			var $ret = new $.ig.ArcItem();
			$ret.levelDepth(-1);
			$ret.itemSource(null);
			return $ret;
		}());
		nodes.enqueue(rootInfo);
		parents.enqueue(parentInfo);
		var rings = new $.ig.RingCollection();
		var currentRing = null;
		var prevLevelDepth = -1;
		while (nodes.count() > 0) {
			var current;
			var $ret = nodes.dequeue(current);
			current = $ret.p0;
			var parent;
			var $ret1 = parents.dequeue(parent);
			parent = $ret1.p0;
			if (current == null) {
				continue;
			}
			var index = 0;
			var en = current.sliceItems().getEnumerator();
			while (en.moveNext()) {
				var child = en.current();
				var childItemSource = this.reflectItemSource(child.data());
				if ((childItemSource != null && this.isEmpty(childItemSource) == false) || child.isOther()) {
					var childInfo = (function () {
						var $ret = new $.ig.ArcItem();
						$ret.levelDepth(current.levelDepth() + 1);
						$ret.itemSource(child.isOther() ? (function () {
							var $ret = new $.ig.List$1($.ig.Number.prototype.$type, 0);
							$ret.add(0);
							return $ret;
						}()) : childItemSource);
						$ret.index(index);
						$ret.parent(current);
						$ret.valueMemberPath($self.valueMemberPath());
						$ret.parentSlice(child);
						return $ret;
					}());
					childInfo.prepareSliceItems(this.startAngle());
					nodes.enqueue(childInfo);
					parents.enqueue(current);
				}
				index++;
			}
			var newRing = this.doSomething(current, parent, prevLevelDepth, currentRing);
			if (newRing != currentRing) {
				rings.add(newRing);
				currentRing = newRing;
			}
			prevLevelDepth = current.levelDepth();
		}
		return rings;
	}
	,
	doSomething: function (current, parent, prevLevelDepth, currentRing) {
		var $self = this;
		current.startAngle(current.parentSlice() == null ? this.startAngle() : current.parentSlice().startAngle());
		current.endAngle(current.parentSlice() == null ? 360 : current.parentSlice().endAngle());
		this.setBrush(current);
		if (current.levelDepth() != prevLevelDepth) {
			var newRing = (function () {
				var $ret = new $.ig.Ring();
				$ret.ringSeries($self);
				return $ret;
			}());
			newRing.arcItems().add(current);
			current.ring(newRing);
			return newRing;
		}
		current.ring(currentRing);
		currentRing.arcItems().add(current);
		return currentRing;
	}
	,
	isEmpty: function (en) {
		var en1 = en.getEnumerator();
		while (en1.moveNext()) {
			var c = en1.current();
			return false;
		}
		return true;
	}
	,
	setBrush: function (arcItem) {
		if (arcItem.parent() == null) {
			arcItem.brushes(this.brushes());
		} else if (arcItem.parent().levelDepth() == 0) {
			arcItem.brushes(new $.ig.BrushCollection());
			if (arcItem.parent().brushes() != null) {
				arcItem.brushes().add(arcItem.parent().brushes().item(arcItem.index() % arcItem.parent().brushes().count()));
			}
		} else {
			arcItem.brushes(arcItem.parent().brushes());
		}
	}
	,
	$type: new $.ig.Type('HierarchicalRingSeries', $.ig.RingSeriesBase.prototype.$type)
}, true);

$.ig.util.defType('IgQueue$1', 'Object', {
	$t: null,
	init: function ($t) {
		this.$t = $t;
		this.$type = this.$type.specialize(this.$t);
		this._count = 0;
		this._front = null;
		this._end = null;
		this._temp = null;
		$.ig.Object.prototype.init.call(this);
	},
	_count: 0,
	_front: null,
	_end: null,
	_temp: null,
	empty: function () {
		return (this._count == 0);
	}
	,
	count: function () {
		return this._count;
	}
	,
	enqueue: function (obj) {
		if (this._count == 0) {
			this._front = this._end = new $.ig.Node($.ig.util.getBoxIfEnum(this.$t, obj), this._front);
		} else {
			this._end._next = new $.ig.Node($.ig.util.getBoxIfEnum(this.$t, obj), this._end._next);
			this._end = this._end._next;
		}
		this._count++;
	}
	,
	dequeue: function (value) {
		this._temp = this._front;
		if (this._count == 0) {
			throw new $.ig.Error(1, "tried to serve from an empty Queue");
		}
		this._front = this._front._next;
		this._count--;
		value = $.ig.util.cast(this.$t, this._temp._value);
		return {
			p0: value
		};
	}
	,
	$type: new $.ig.Type('IgQueue$1', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('Node', 'Object', {
	_next: null,
	_value: null,
	init: function (value, next) {
		$.ig.Object.prototype.init.call(this);
		this._next = next;
		this._value = value;
	},
	$type: new $.ig.Type('Node', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('RingSeries', 'RingSeriesBase', {
	init: function () {
		var $self = this;
		$.ig.RingSeriesBase.prototype.init.call(this);
		this.ring((function () {
			var $ret = new $.ig.Ring();
			$ret.ringSeries($self);
			$ret.clearContent(false);
			return $ret;
		}()));
		var arcItem = (function () {
			var $ret = new $.ig.ArcItem();
			$ret.startAngle($self.startAngle());
			$ret.ring($self.ring());
			$ret.valueMemberPath($self.valueMemberPath());
			$ret.othersCategoryType($self.othersCategoryType());
			$ret.othersCategoryThreshold($self.othersCategoryThreshold());
			return $ret;
		}());
		this.ring().arcItems().add(arcItem);
		this.defaultStyleKey($.ig.RingSeries.prototype.$type);
	},
	_ring: null,
	ring: function (value) {
		if (arguments.length === 1) {
			this._ring = value;
			return value;
		} else {
			return this._ring;
		}
	}
	,
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.RingSeriesBase.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		if (propertyName == $.ig.RingSeriesBase.prototype.formatLabelPropertyName) {
			for (var i = 0; i < this.ring().ringControl()._arcs.count(); i++) {
				this.ring().ringControl()._arcs.item(i).formatLabel(newValue);
			}
		}
		if (propertyName == $.ig.RingSeriesBase.prototype.brushesPropertyName) {
			this.prepareBrushes();
		}
		if (propertyName == $.ig.RingSeriesBase.prototype.startAnglePropertyName) {
			if (this.ring().arcItems() != null && this.ring().arcItems().count() > 0) {
				this.ring().arcItems().__inner[0].startAngle(this.startAngle());
			}
		}
		if (propertyName == $.ig.RingSeriesBase.prototype.valueMemberPathPropertyName) {
			if (this.ring().arcItems() != null && this.ring().arcItems().count() > 0) {
				this.ring().arcItems().__inner[0].valueMemberPath(this.valueMemberPath());
				this.prepareData();
			}
		}
		if (this.ring() != null && this.view().isReady()) {
			this.ring().prepareArcs();
			if (this.ring().renderArcs()) {
				this.ring().ringSeries().view().onSizeChanged();
			}
		}
	}
	,
	analyzeRings: function () {
		var coll = new $.ig.RingCollection();
		if (this.ring().arcItems().__inner[0].sliceItems().count() > 0) {
			coll.add(this.ring());
		}
		return coll;
	}
	,
	prepareData: function () {
		if (this.ring() != null) {
			this.ring().arcItems().__inner[0].itemSource(this.itemsSource());
			this.ring().arcItems().__inner[0].prepareSliceItems(this.startAngle());
			if (this.chart() != null) {
				this.chart().prepareRingCollection();
				this.chart().renderChart();
			}
		}
	}
	,
	prepareBrushes: function () {
		if (this.ring() != null) {
			this.ring().arcItems().__inner[0].brushes(this.brushes());
		}
	}
	,
	renderSeries: function () {
		if (this.ring() != null) {
			this.width(this.ring().controlSize().width());
			this.height(this.ring().controlSize().height());
			this.view().positionSeries(this.ring().center().__x, this.ring().center().__y);
		}
	}
	,
	renderLegendItems: function () {
		if (this.ring() != null) {
			var en = this.ring().ringControl()._arcs.active().getEnumerator();
			while (en.moveNext()) {
				var arc = en.current();
				arc.renderLegendItems();
			}
		}
	}
	,
	$type: new $.ig.Type('RingSeries', $.ig.RingSeriesBase.prototype.$type)
}, true);

$.ig.util.defType('XamPieChart', 'PieChartBase', {
	createView: function () {
		return new $.ig.XamPieChartView(this);
	}
	,
	onViewCreated: function (view) {
		$.ig.PieChartBase.prototype.onViewCreated.call(this, view);
		this.pieChartView(view);
	}
	,
	_pieChartView: null,
	pieChartView: function (value) {
		if (arguments.length === 1) {
			this._pieChartView = value;
			return value;
		} else {
			return this._pieChartView;
		}
	}
	,
	init: function () {
		$.ig.PieChartBase.prototype.init.call(this);
		this.defaultStyleKey($.ig.XamPieChart.prototype.$type);
	},
	$type: new $.ig.Type('XamPieChart', $.ig.PieChartBase.prototype.$type)
}, true);

$.ig.util.defType('XamPieChartView', 'PieChartBaseView', {
	_pieChartModel: null,
	pieChartModel: function (value) {
		if (arguments.length === 1) {
			this._pieChartModel = value;
			return value;
		} else {
			return this._pieChartModel;
		}
	}
	,
	init: function (model) {
		$.ig.PieChartBaseView.prototype.init.call(this, model);
		this.pieChartModel(model);
	},
	$type: new $.ig.Type('XamPieChartView', $.ig.PieChartBaseView.prototype.$type)
}, true);

$.ig.HierarchicalRingSeries.prototype.childrenMemberPathPropertyName = "ChildrenMemberPath";
$.ig.HierarchicalRingSeries.prototype.childrenMemberPathProperty = $.ig.DependencyProperty.prototype.register($.ig.HierarchicalRingSeries.prototype.childrenMemberPathPropertyName, String, $.ig.HierarchicalRingSeries.prototype.$type, new $.ig.PropertyMetadata(1, function (o, e) {
	($.ig.util.cast($.ig.HierarchicalRingSeries.prototype.$type, o)).raisePropertyChanged($.ig.HierarchicalRingSeries.prototype.childrenMemberPathPropertyName, e.oldValue(), e.newValue());
}));

} (jQuery));


