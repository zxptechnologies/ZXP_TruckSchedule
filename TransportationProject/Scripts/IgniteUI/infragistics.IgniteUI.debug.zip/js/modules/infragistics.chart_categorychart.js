﻿/*!@license
* Infragistics.Web.ClientUI infragistics.chart_categorychart.js 15.1.20151.2352
*
* Copyright (c) 2011-2015 Infragistics Inc.
*
* http://www.infragistics.com/
*
* Depends:
*     jquery-1.4.4.js
*     jquery.ui.core.js
*     jquery.ui.widget.js
*     infragistics.util.js
*/

// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["AbstractEnumerable:a", 
"Object:b", 
"Type:c", 
"Boolean:d", 
"ValueType:e", 
"Void:f", 
"IConvertible:g", 
"IFormatProvider:h", 
"Number:i", 
"String:j", 
"IComparable:k", 
"Number:l", 
"Number:m", 
"Number:n", 
"Number:o", 
"NumberStyles:p", 
"Enum:q", 
"Array:r", 
"IList:s", 
"ICollection:t", 
"IEnumerable:u", 
"IEnumerator:v", 
"NotSupportedException:w", 
"Error:x", 
"Number:y", 
"String:z", 
"StringComparison:aa", 
"RegExp:ab", 
"CultureInfo:ac", 
"DateTimeFormatInfo:ad", 
"Calendar:ae", 
"Date:af", 
"Number:ag", 
"DayOfWeek:ah", 
"DateTimeKind:ai", 
"CalendarWeekRule:aj", 
"NumberFormatInfo:ak", 
"CompareInfo:al", 
"CompareOptions:am", 
"IEnumerable$1:an", 
"IEnumerator$1:ao", 
"IDisposable:ap", 
"StringSplitOptions:aq", 
"Number:ar", 
"Number:as", 
"Number:at", 
"Number:au", 
"Number:av", 
"Number:aw", 
"Assembly:ax", 
"Stream:ay", 
"SeekOrigin:az", 
"RuntimeTypeHandle:a0", 
"MethodInfo:a1", 
"MethodBase:a2", 
"MemberInfo:a3", 
"ParameterInfo:a4", 
"TypeCode:a5", 
"ConstructorInfo:a6", 
"PropertyInfo:a7", 
"Func$1:a8", 
"MulticastDelegate:a9", 
"IntPtr:ba", 
"AbstractEnumerator:bb", 
"Array:bm", 
"GenericEnumerable$1:ci", 
"GenericEnumerator$1:cj"]);


} (jQuery));



// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["Object:d", 
"Type:e", 
"Boolean:f", 
"ValueType:g", 
"Void:h", 
"IConvertible:i", 
"IFormatProvider:j", 
"Number:k", 
"String:l", 
"IComparable:m", 
"Number:n", 
"Number:o", 
"Number:p", 
"Number:q", 
"NumberStyles:r", 
"Enum:s", 
"Array:t", 
"IList:u", 
"ICollection:v", 
"IEnumerable:w", 
"IEnumerator:x", 
"NotSupportedException:y", 
"Error:z", 
"Number:aa", 
"String:ab", 
"StringComparison:ac", 
"RegExp:ad", 
"CultureInfo:ae", 
"DateTimeFormatInfo:af", 
"Calendar:ag", 
"Date:ah", 
"Number:ai", 
"DayOfWeek:aj", 
"DateTimeKind:ak", 
"CalendarWeekRule:al", 
"NumberFormatInfo:am", 
"CompareInfo:an", 
"CompareOptions:ao", 
"IEnumerable$1:ap", 
"IEnumerator$1:aq", 
"IDisposable:ar", 
"StringSplitOptions:as", 
"Number:at", 
"Number:au", 
"Number:av", 
"Number:aw", 
"Number:ax", 
"Number:ay", 
"Assembly:az", 
"Stream:a0", 
"SeekOrigin:a1", 
"RuntimeTypeHandle:a2", 
"MethodInfo:a3", 
"MethodBase:a4", 
"MemberInfo:a5", 
"ParameterInfo:a6", 
"TypeCode:a7", 
"ConstructorInfo:a8", 
"PropertyInfo:a9", 
"Array:bf", 
"MulticastDelegate:bh", 
"IntPtr:bi", 
"Func$1:hf", 
"AbstractEnumerable:js", 
"AbstractEnumerator:jt", 
"GenericEnumerable$1:ju", 
"GenericEnumerator$1:jv"]);


} (jQuery));



// Declare empty types
$.ig = $.ig || {};
(function ($) {
var $$t = {}
$.ig.$currDefinitions = $$t;
$.ig.util.bulkDefine(["IProvidesViewport:a", 
"Void:b", 
"ValueType:c", 
"Object:d", 
"Type:e", 
"Boolean:f", 
"IConvertible:g", 
"IFormatProvider:h", 
"Number:i", 
"String:j", 
"IComparable:k", 
"Number:l", 
"Number:m", 
"Number:n", 
"Number:o", 
"NumberStyles:p", 
"Enum:q", 
"Array:r", 
"IList:s", 
"ICollection:t", 
"IEnumerable:u", 
"IEnumerator:v", 
"NotSupportedException:w", 
"Error:x", 
"Number:y", 
"String:z", 
"StringComparison:aa", 
"RegExp:ab", 
"CultureInfo:ac", 
"DateTimeFormatInfo:ad", 
"Calendar:ae", 
"Date:af", 
"Number:ag", 
"DayOfWeek:ah", 
"DateTimeKind:ai", 
"CalendarWeekRule:aj", 
"NumberFormatInfo:ak", 
"CompareInfo:al", 
"CompareOptions:am", 
"IEnumerable$1:an", 
"IEnumerator$1:ao", 
"IDisposable:ap", 
"StringSplitOptions:aq", 
"Number:ar", 
"Number:as", 
"Number:at", 
"Number:au", 
"Number:av", 
"Number:aw", 
"Assembly:ax", 
"Stream:ay", 
"SeekOrigin:az", 
"RuntimeTypeHandle:a0", 
"MethodInfo:a1", 
"MethodBase:a2", 
"MemberInfo:a3", 
"ParameterInfo:a4", 
"TypeCode:a5", 
"ConstructorInfo:a6", 
"PropertyInfo:a7", 
"Rect:a8", 
"Size:a9", 
"Point:ba", 
"Math:bb", 
"Series:bc", 
"Control:bd", 
"FrameworkElement:be", 
"UIElement:bf", 
"DependencyObject:bg", 
"Dictionary:bh", 
"DependencyProperty:bi", 
"PropertyMetadata:bj", 
"PropertyChangedCallback:bk", 
"MulticastDelegate:bl", 
"IntPtr:bm", 
"DependencyPropertyChangedEventArgs:bn", 
"DependencyPropertiesCollection:bo", 
"UnsetValue:bp", 
"Script:bq", 
"Binding:br", 
"PropertyPath:bs", 
"Transform:bt", 
"Visibility:bu", 
"Style:bv", 
"Thickness:bw", 
"HorizontalAlignment:bx", 
"VerticalAlignment:by", 
"INotifyPropertyChanged:bz", 
"PropertyChangedEventHandler:b0", 
"PropertyChangedEventArgs:b1", 
"SeriesView:b2", 
"ISchedulableRender:b3", 
"SeriesViewer:b4", 
"SeriesViewerView:b5", 
"CanvasRenderScheduler:b6", 
"List$1:b7", 
"IList$1:b8", 
"ICollection$1:b9", 
"IArray:ca", 
"IArrayList:cb", 
"Array:cc", 
"CompareCallback:cd", 
"Func$3:ce", 
"Action$1:cf", 
"Comparer$1:cg", 
"IComparer:ch", 
"IComparer$1:ci", 
"DefaultComparer$1:cj", 
"IComparable$1:ck", 
"Comparison$1:cl", 
"ReadOnlyCollection$1:cm", 
"Predicate$1:cn", 
"NotImplementedException:co", 
"Callback:cp", 
"window:cq", 
"RenderingContext:cr", 
"IRenderer:cs", 
"Rectangle:ct", 
"Shape:cu", 
"Brush:cv", 
"Color:cw", 
"ArgumentException:cx", 
"DoubleCollection:cy", 
"Path:cz", 
"Geometry:c0", 
"GeometryType:c1", 
"TextBlock:c2", 
"Polygon:c3", 
"PointCollection:c4", 
"Polyline:c5", 
"DataTemplateRenderInfo:c6", 
"DataTemplatePassInfo:c7", 
"ContentControl:c8", 
"DataTemplate:c9", 
"DataTemplateRenderHandler:da", 
"DataTemplateMeasureHandler:db", 
"DataTemplateMeasureInfo:dc", 
"DataTemplatePassHandler:dd", 
"Line:de", 
"FontInfo:df", 
"XamOverviewPlusDetailPane:dg", 
"XamOverviewPlusDetailPaneView:dh", 
"XamOverviewPlusDetailPaneViewManager:di", 
"JQueryObject:dj", 
"Element:dk", 
"ElementAttributeCollection:dl", 
"ElementCollection:dm", 
"WebStyle:dn", 
"ElementNodeType:dp", 
"Document:dq", 
"EventListener:dr", 
"IElementEventHandler:ds", 
"ElementEventHandler:dt", 
"ElementAttribute:du", 
"JQueryPosition:dv", 
"JQueryCallback:dw", 
"JQueryEvent:dx", 
"JQueryUICallback:dy", 
"EventProxy:dz", 
"ModifierKeys:d0", 
"Func$2:d1", 
"MouseWheelHandler:d2", 
"Delegate:d3", 
"Interlocked:d4", 
"GestureHandler:d5", 
"ContactHandler:d6", 
"TouchHandler:d7", 
"MouseOverHandler:d8", 
"MouseHandler:d9", 
"KeyHandler:ea", 
"Key:eb", 
"JQuery:ec", 
"JQueryDeferred:ed", 
"JQueryPromise:ee", 
"Action:ef", 
"CanvasViewRenderer:eg", 
"CanvasContext2D:eh", 
"CanvasContext:ei", 
"TextMetrics:ej", 
"ImageData:ek", 
"CanvasElement:el", 
"Gradient:em", 
"LinearGradientBrush:en", 
"GradientStop:eo", 
"GeometryGroup:ep", 
"GeometryCollection:eq", 
"FillRule:er", 
"PathGeometry:es", 
"PathFigureCollection:et", 
"LineGeometry:eu", 
"RectangleGeometry:ev", 
"EllipseGeometry:ew", 
"ArcSegment:ex", 
"PathSegment:ey", 
"PathSegmentType:ez", 
"SweepDirection:e0", 
"PathFigure:e1", 
"PathSegmentCollection:e2", 
"LineSegment:e3", 
"PolyLineSegment:e4", 
"BezierSegment:e5", 
"PolyBezierSegment:e6", 
"GeometryUtil:e7", 
"Tuple$2:e8", 
"TransformGroup:e9", 
"TransformCollection:fa", 
"TranslateTransform:fb", 
"RotateTransform:fc", 
"ScaleTransform:fd", 
"DivElement:fe", 
"DOMEventProxy:ff", 
"MSGesture:fg", 
"MouseEventArgs:fh", 
"EventArgs:fi", 
"DoubleAnimator:fj", 
"EasingFunctionHandler:fk", 
"ImageElement:fl", 
"RectUtil:fm", 
"MathUtil:fn", 
"RuntimeHelpers:fo", 
"RuntimeFieldHandle:fp", 
"PropertyChangedEventArgs$1:fq", 
"InteractionState:fr", 
"OverviewPlusDetailPaneMode:fs", 
"IOverviewPlusDetailControl:ft", 
"EventHandler$1:fu", 
"ArgumentNullException:fv", 
"OverviewPlusDetailViewportHost:fw", 
"SeriesCollection:fx", 
"ObservableCollection$1:fy", 
"INotifyCollectionChanged:fz", 
"NotifyCollectionChangedEventHandler:f0", 
"NotifyCollectionChangedEventArgs:f1", 
"NotifyCollectionChangedAction:f2", 
"AxisCollection:f3", 
"SeriesViewerViewManager:f4", 
"AxisTitlePosition:f5", 
"PointerTooltipStyle:f6", 
"Dictionary$2:f7", 
"IDictionary$2:f8", 
"IDictionary:f9", 
"KeyValuePair$2:ga", 
"Enumerable:gb", 
"Thread:gc", 
"ThreadStart:gd", 
"IOrderedEnumerable$1:ge", 
"SortedList$1:gf", 
"IEqualityComparer$1:gg", 
"EqualityComparer$1:gh", 
"IEqualityComparer:gi", 
"DefaultEqualityComparer$1:gj", 
"InvalidOperationException:gk", 
"BrushCollection:gl", 
"InterpolationMode:gm", 
"Random:gn", 
"ColorUtil:go", 
"CssHelper:gp", 
"CssGradientUtil:gq", 
"FontUtil:gr", 
"TileZoomTile:gs", 
"TileZoomTileInfo:gt", 
"TileZoomTileCache:gu", 
"TileZoomManager:gv", 
"RectChangedEventHandler:gw", 
"RectChangedEventArgs:gx", 
"Debug:gy", 
"TileZoomInfo:gz", 
"LinkedList$1:g0", 
"LinkedListNode$1:g1", 
"RenderSurface:g2", 
"DataContext:g3", 
"SeriesViewerComponentsFromView:g4", 
"SeriesViewerSurfaceViewer:g5", 
"Canvas:g6", 
"Panel:g7", 
"UIElementCollection:g8", 
"StackedSeriesBase:g9", 
"CategorySeries:ha", 
"MarkerSeries:hb", 
"MarkerSeriesView:hc", 
"Marker:hd", 
"MarkerTemplates:he", 
"HashPool$2:hf", 
"IHashPool$2:hg", 
"IPool$1:hh", 
"Func$1:hi", 
"Pool$1:hj", 
"IIndexedPool$1:hk", 
"MarkerType:hl", 
"SeriesVisualData:hm", 
"PrimitiveVisualDataList:hn", 
"IVisualData:ho", 
"PrimitiveVisualData:hp", 
"PrimitiveAppearanceData:hq", 
"BrushAppearanceData:hr", 
"StringBuilder:hs", 
"Environment:ht", 
"AppearanceHelper:hu", 
"LinearGradientBrushAppearanceData:hv", 
"GradientStopAppearanceData:hw", 
"SolidBrushAppearanceData:hx", 
"GeometryData:hy", 
"GetPointsSettings:hz", 
"EllipseGeometryData:h0", 
"RectangleGeometryData:h1", 
"LineGeometryData:h2", 
"PathGeometryData:h3", 
"PathFigureData:h4", 
"SegmentData:h5", 
"LineSegmentData:h6", 
"PolylineSegmentData:h7", 
"ArcSegmentData:h8", 
"PolyBezierSegmentData:h9", 
"BezierSegmentData:ia", 
"LabelAppearanceData:ib", 
"ShapeTags:ic", 
"PointerTooltipVisualDataList:id", 
"MarkerVisualDataList:ie", 
"MarkerVisualData:ig", 
"PointerTooltipVisualData:ih", 
"RectangleVisualData:ii", 
"PolygonVisualData:ij", 
"PolyLineVisualData:ik", 
"IFastItemsSource:il", 
"IFastItemColumn$1:im", 
"IFastItemColumnPropertyName:io", 
"FastItemsSourceEventArgs:ip", 
"FastItemsSourceEventAction:iq", 
"IHasCategoryModePreference:ir", 
"IHasCategoryAxis:is", 
"CategoryAxisBase:it", 
"Axis:iu", 
"AxisView:iv", 
"XamDataChart:iw", 
"GridMode:ix", 
"XamDataChartView:iy", 
"FragmentBase:iz", 
"HorizontalAnchoredCategorySeries:i0", 
"AnchoredCategorySeries:i1", 
"IIsCategoryBased:i2", 
"CategoryMode:i3", 
"ICategoryScaler:i4", 
"IScaler:i5", 
"ScalerParams:i6", 
"IBucketizer:i7", 
"IDetectsCollisions:i8", 
"IHasSingleValueCategory:i9", 
"IHasCategoryTrendline:ja", 
"IHasTrendline:jb", 
"TrendLineType:jc", 
"IPreparesCategoryTrendline:jd", 
"TrendResolutionParams:je", 
"AnchoredCategorySeriesView:jf", 
"CategorySeriesView:jg", 
"ISupportsMarkers:jh", 
"CategoryBucketCalculator:ji", 
"ISortingAxis:jj", 
"CategoryFrame:jk", 
"Frame:jl", 
"BrushUtil:jm", 
"CategoryTrendLineManagerBase:jn", 
"TrendLineManagerBase$1:jo", 
"Clipper:jp", 
"EdgeClipper:jq", 
"LeftClipper:jr", 
"BottomClipper:js", 
"RightClipper:jt", 
"TopClipper:ju", 
"Flattener:jv", 
"Stack$1:jw", 
"ReverseArrayEnumerator$1:jx", 
"SpiralTodo:jy", 
"FlattenerSettings:jz", 
"Func$4:j0", 
"SortingTrendLineManager:j1", 
"TrendFitCalculator:j2", 
"LeastSquaresFit:j3", 
"Numeric:j4", 
"TrendAverageCalculator:j5", 
"CategoryTrendLineManager:j6", 
"AnchoredCategoryBucketCalculator:j7", 
"CategoryDateTimeXAxis:j8", 
"CategoryDateTimeXAxisView:j9", 
"CategoryAxisBaseView:ka", 
"TimeAxisDisplayType:kb", 
"FastItemDateTimeColumn:kc", 
"IFastItemColumnInternal:kd", 
"FastItemColumn:ke", 
"FastReflectionHelper:kf", 
"AxisOrientation:kg", 
"AxisLabelPanelBase:kh", 
"AxisLabelPanelBaseView:ki", 
"AxisLabelSettings:kj", 
"AxisLabelsLocation:kk", 
"PropertyUpdatedEventHandler:kl", 
"PropertyUpdatedEventArgs:km", 
"PathRenderingInfo:kn", 
"LabelPosition:ko", 
"NumericAxisBase:kp", 
"NumericAxisBaseView:kq", 
"NumericAxisRenderer:kr", 
"AxisRendererBase:ks", 
"ShouldRenderHandler:kt", 
"ScaleValueHandler:ku", 
"AxisRenderingParametersBase:kv", 
"RangeInfo:kw", 
"TickmarkValues:kx", 
"TickmarkValuesInitializationParameters:ky", 
"GetGroupCenterHandler:kz", 
"GetUnscaledGroupCenterHandler:k0", 
"RenderStripHandler:k1", 
"RenderLineHandler:k2", 
"ShouldRenderLinesHandler:k3", 
"ShouldRenderContentHandler:k4", 
"RenderAxisLineHandler:k5", 
"DetermineCrossingValueHandler:k6", 
"ShouldRenderLabelHandler:k7", 
"GetLabelLocationHandler:k8", 
"TransformToLabelValueHandler:k9", 
"AxisLabelManager:la", 
"GetLabelForItemHandler:lb", 
"CreateRenderingParamsHandler:lc", 
"SnapMajorValueHandler:ld", 
"AdjustMajorValueHandler:le", 
"CategoryAxisRenderingParameters:lf", 
"LogarithmicTickmarkValues:lg", 
"LogarithmicNumericSnapper:lh", 
"Snapper:li", 
"LinearTickmarkValues:lj", 
"LinearNumericSnapper:lk", 
"AxisRangeChangedEventArgs:ll", 
"AxisRange:lm", 
"IEquatable$1:ln", 
"AutoRangeCalculator:lo", 
"NumericYAxis:lp", 
"StraightNumericAxisBase:lq", 
"StraightNumericAxisBaseView:lr", 
"NumericScaler:ls", 
"NumericScaleMode:lt", 
"LogarithmicScaler:lu", 
"NumericYAxisView:lv", 
"VerticalAxisLabelPanel:lw", 
"VerticalAxisLabelPanelView:lx", 
"TitleSettings:ly", 
"NumericAxisRenderingParameters:lz", 
"VerticalLogarithmicScaler:l0", 
"VerticalLinearScaler:l1", 
"LinearScaler:l2", 
"NumericRadiusAxis:l3", 
"NumericRadiusAxisView:l4", 
"NumericAngleAxis:l5", 
"IAngleScaler:l6", 
"NumericAngleAxisView:l7", 
"PolarAxisRenderingManager:l8", 
"ViewportUtils:l9", 
"PolarAxisRenderingParameters:ma", 
"IPolarRadialRenderingParameters:mb", 
"RadialAxisRenderingParameters:mc", 
"AngleAxisLabelPanel:md", 
"AngleAxisLabelPanelView:me", 
"Extensions:mf", 
"CategoryAngleAxis:mg", 
"CategoryAngleAxisView:mh", 
"CategoryAxisRenderer:mi", 
"LinearCategorySnapper:mj", 
"CategoryTickmarkValues:mk", 
"RadialAxisLabelPanel:ml", 
"HorizontalAxisLabelPanelBase:mm", 
"HorizontalAxisLabelPanelBaseView:mn", 
"RadialAxisLabelPanelView:mo", 
"SmartAxisLabelPanel:mp", 
"AxisExtentType:mq", 
"SmartAxisLabelPanelView:mr", 
"HorizontalAxisLabelPanel:ms", 
"CoercionInfo:mt", 
"SortedListView$1:mu", 
"ArrayUtil:mv", 
"CategoryLineRasterizer:mw", 
"UnknownValuePlotting:mx", 
"Action$5:my", 
"PenLineCap:mz", 
"CategorySeriesMarkerCollisionAvoidance:m0", 
"CategoryFramePreparer:m1", 
"CategoryFramePreparerBase:m2", 
"FramePreparer:m3", 
"ISupportsErrorBars:m4", 
"DefaultSupportsMarkers:m5", 
"DefaultProvidesViewport:m6", 
"DefaultSupportsErrorBars:m7", 
"PreparationParams:m8", 
"CategoryYAxis:m9", 
"CategoryYAxisView:na", 
"SyncSettings:nb", 
"NumericXAxis:nc", 
"NumericXAxisView:nd", 
"HorizontalLogarithmicScaler:ne", 
"HorizontalLinearScaler:nf", 
"ValuesHolder:ng", 
"LineSeries:nh", 
"LineSeriesView:ni", 
"PathVisualData:nj", 
"CategorySeriesRenderManager:nk", 
"AssigningCategoryStyleEventArgs:nl", 
"AssigningCategoryStyleEventArgsBase:nm", 
"GetCategoryItemsHandler:nn", 
"HighlightingInfo:no", 
"HighlightingState:np", 
"AssigningCategoryMarkerStyleEventArgs:nq", 
"HighlightingManager:nr", 
"SplineSeriesBase:ns", 
"SplineSeriesBaseView:nt", 
"SplineType:nu", 
"CollisionAvoider:nv", 
"SafeSortedReadOnlyDoubleCollection:nw", 
"SafeReadOnlyDoubleCollection:nx", 
"SafeEnumerable:ny", 
"AreaSeries:nz", 
"AreaSeriesView:n0", 
"LegendTemplates:n1", 
"PieChartBase:n2", 
"PieChartBaseView:n3", 
"PieChartViewManager:n4", 
"PieChartVisualData:n5", 
"PieSliceVisualDataList:n6", 
"PieSliceVisualData:n7", 
"PieSliceDataContext:n8", 
"Slice:n9", 
"SliceView:oa", 
"PieLabel:ob", 
"MouseButtonEventArgs:oc", 
"FastItemsSource:od", 
"ColumnReference:oe", 
"FastItemObjectColumn:of", 
"FastItemIntColumn:og", 
"LabelsPosition:oh", 
"LeaderLineType:oi", 
"OthersCategoryType:oj", 
"IndexCollection:ok", 
"LegendBase:ol", 
"LegendBaseView:om", 
"LegendBaseViewManager:on", 
"GradientData:oo", 
"GradientStopData:op", 
"DataChartLegendMouseButtonEventArgs:oq", 
"DataChartMouseButtonEventArgs:or", 
"ChartLegendMouseEventArgs:os", 
"ChartMouseEventArgs:ot", 
"DataChartLegendMouseButtonEventHandler:ou", 
"DataChartLegendMouseEventHandler:ov", 
"LegendVisualData:ow", 
"LegendVisualDataList:ox", 
"LegendItemVisualData:oy", 
"FunnelSliceDataContext:oz", 
"PieChartFormatLabelHandler:o0", 
"SliceClickEventHandler:o1", 
"SliceClickEventArgs:o2", 
"ItemLegend:o3", 
"ItemLegendView:o4", 
"LegendItemInfo:o5", 
"BubbleSeries:o6", 
"ScatterBase:o7", 
"ScatterBaseView:o8", 
"MarkerManagerBase:o9", 
"OwnedPoint:pa", 
"MarkerManagerBucket:pb", 
"ScatterTrendLineManager:pc", 
"NumericMarkerManager:pd", 
"CollisionAvoidanceType:pe", 
"SmartPlacer:pf", 
"ISmartPlaceable:pg", 
"SmartPosition:ph", 
"SmartPlaceableWrapper$1:pi", 
"ScatterAxisInfoCache:pj", 
"ScatterErrorBarSettings:pk", 
"ErrorBarSettingsBase:pl", 
"EnableErrorBars:pm", 
"ErrorBarCalculatorReference:pn", 
"IErrorBarCalculator:po", 
"ErrorBarCalculatorType:pp", 
"ScatterFrame:pq", 
"ScatterFrameBase$1:pr", 
"DictInterpolator$3:ps", 
"Action$6:pt", 
"SyncLink:pu", 
"IFastItemsSourceProvider:pv", 
"ChartCollection:pw", 
"FastItemsSourceReference:px", 
"SyncManager:py", 
"SyncLinkManager:pz", 
"ErrorBarsHelper:p0", 
"BubbleSeriesView:p1", 
"BubbleMarkerManager:p2", 
"SizeScale:p3", 
"BrushScale:p4", 
"ScaleLegend:p5", 
"ScaleLegendView:p6", 
"CustomPaletteBrushScale:p7", 
"BrushSelectionMode:p8", 
"ValueBrushScale:p9", 
"RingSeriesBase:qa", 
"XamDoughnutChart:qb", 
"RingCollection:qc", 
"Ring:qd", 
"RingControl:qe", 
"RingControlView:qf", 
"Arc:qg", 
"ArcView:qh", 
"ArcItem:qi", 
"SliceItem:qj", 
"Legend:qk", 
"LegendView:ql", 
"SplineFragmentBase:qm", 
"StackedFragmentSeries:qn", 
"StackedAreaSeries:qo", 
"HorizontalStackedSeriesBase:qp", 
"StackedSplineAreaSeries:qq", 
"AreaFragment:qr", 
"AreaFragmentView:qs", 
"AreaFragmentBucketCalculator:qt", 
"IStacked100Series:qu", 
"SplineAreaFragment:qv", 
"SplineAreaFragmentView:qw", 
"StackedSeriesManager:qx", 
"StackedSeriesCollection:qy", 
"StackedSeriesView:qz", 
"StackedBucketCalculator:q0", 
"StackedLineSeries:q1", 
"StackedSplineSeries:q2", 
"StackedColumnSeries:q3", 
"StackedColumnSeriesView:q4", 
"StackedColumnBucketCalculator:q5", 
"ColumnFragment:q6", 
"ColumnFragmentView:q7", 
"CategoryMarkerManager:q8", 
"LineFragment:q9", 
"LineFragmentView:ra", 
"LineFragmentBucketCalculator:rb", 
"StackedBarSeries:rc", 
"VerticalStackedSeriesBase:rd", 
"IBarSeries:re", 
"StackedBarSeriesView:rf", 
"StackedBarBucketCalculator:rg", 
"BarFragment:rh", 
"SplineFragment:ri", 
"SplineFragmentView:rj", 
"SplineFragmentBucketCalculator:rk", 
"BarSeries:rl", 
"VerticalAnchoredCategorySeries:rm", 
"BarSeriesView:rn", 
"BarTrendLineManager:ro", 
"BarTrendFitCalculator:rp", 
"BarBucketCalculator:rq", 
"CategoryTransitionInMode:rr", 
"BarFramePreparer:rs", 
"DefaultCategoryTrendlineHost:rt", 
"DefaultCategoryTrendlinePreparer:ru", 
"DefaultSingleValueProvider:rv", 
"SingleValuesHolder:rw", 
"RingSeriesBaseView:rx", 
"Nullable$1:ry", 
"RingSeriesCollection:rz", 
"SliceCollection:r0", 
"XamDoughnutChartView:r1", 
"Action$2:r2", 
"DoughnutChartVisualData:r3", 
"RingSeriesVisualDataList:r4", 
"RingSeriesVisualData:r5", 
"RingVisualDataList:r6", 
"RingVisualData:r7", 
"ArcVisualDataList:r8", 
"ArcVisualData:r9", 
"SliceVisualDataList:sa", 
"SliceVisualData:sb", 
"DoughnutChartLabelVisualData:sc", 
"HoleDimensionsChangedEventHandler:sd", 
"HoleDimensionsChangedEventArgs:se", 
"XamFunnelChart:sf", 
"IItemProvider:sg", 
"MessageHandler:sh", 
"MessageHandlerEventHandler:si", 
"Message:sj", 
"ServiceProvider:sk", 
"MessageChannel:sl", 
"MessageEventHandler:sm", 
"Queue$1:sn", 
"XamFunnelConnector:so", 
"XamFunnelController:sp", 
"SliceInfoList:sq", 
"SliceInfo:sr", 
"SliceAppearance:ss", 
"PointList:st", 
"FunnelSliceVisualData:su", 
"SliceInfoUnaryComparison:sv", 
"Bezier:sw", 
"BezierPoint:sx", 
"BezierOp:sy", 
"BezierPointComparison:sz", 
"DoubleColumn:s0", 
"ObjectColumn:s1", 
"XamFunnelView:s2", 
"IOuterLabelWidthDecider:s3", 
"IFunnelLabelSizeDecider:s4", 
"MouseLeaveMessage:s5", 
"InteractionMessage:s6", 
"MouseMoveMessage:s7", 
"MouseButtonMessage:s8", 
"MouseButtonAction:s9", 
"MouseButtonType:ta", 
"SetAreaSizeMessage:tb", 
"RenderingMessage:tc", 
"RenderSliceMessage:td", 
"RenderOuterLabelMessage:te", 
"TooltipValueChangedMessage:tf", 
"TooltipUpdateMessage:tg", 
"FunnelDataContext:th", 
"PropertyChangedMessage:ti", 
"ConfigurationMessage:tj", 
"ClearMessage:tk", 
"ClearTooltipMessage:tl", 
"ContainerSizeChangedMessage:tm", 
"ViewportChangedMessage:tn", 
"ViewPropertyChangedMessage:to", 
"OuterLabelAlignment:tp", 
"FunnelSliceDisplay:tq", 
"SliceSelectionManager:tr", 
"DataUpdatedMessage:ts", 
"ItemsSourceAction:tt", 
"FunnelFrame:tu", 
"UserSelectedItemsChangedMessage:tv", 
"LabelSizeChangedMessage:tw", 
"FrameRenderCompleteMessage:tx", 
"IntColumn:ty", 
"IntColumnComparison:tz", 
"Convert:t0", 
"SelectedItemsChangedMessage:t1", 
"ModelUpdateMessage:t2", 
"SliceClickedMessage:t3", 
"FunnelSliceClickedEventHandler:t4", 
"FunnelSliceClickedEventArgs:t5", 
"FunnelChartVisualData:t6", 
"FunnelSliceVisualDataList:t7", 
"RingSeries:t8", 
"WaterfallSeries:t9", 
"WaterfallSeriesView:ua", 
"FinancialSeries:ub", 
"FinancialSeriesView:uc", 
"FinancialBucketCalculator:ud", 
"CategoryTransitionSourceFramePreparer:ue", 
"TransitionInSpeedType:uf", 
"FinancialCalculationDataSource:ug", 
"CalculatedColumn:uh", 
"FinancialEventArgs:ui", 
"FinancialCalculationSupportingCalculations:uj", 
"ColumnSupportingCalculation:uk", 
"SupportingCalculation$1:ul", 
"SupportingCalculationStrategy:um", 
"DataSourceSupportingCalculation:un", 
"ProvideColumnValuesStrategy:uo", 
"AssigningCategoryStyleEventHandler:up", 
"FinancialValueList:uq", 
"FinancialEventHandler:ur", 
"StepLineSeries:us", 
"StepLineSeriesView:ut", 
"StepAreaSeries:uu", 
"StepAreaSeriesView:uv", 
"RangeAreaSeries:uw", 
"HorizontalRangeCategorySeries:ux", 
"RangeCategorySeries:uy", 
"IHasHighLowValueCategory:uz", 
"RangeCategorySeriesView:u0", 
"RangeCategoryBucketCalculator:u1", 
"RangeCategoryFramePreparer:u2", 
"DefaultHighLowValueProvider:u3", 
"HighLowValuesHolder:u4", 
"RangeValueList:u5", 
"RangeAreaSeriesView:u6", 
"NonCollisionAvoider:u7", 
"AxisRangeChangedEventHandler:u8", 
"DataChartAxisRangeChangedEventHandler:u9", 
"ChartAxisRangeChangedEventArgs:va", 
"ChartVisualData:vb", 
"AxisVisualDataList:vc", 
"SeriesVisualDataList:vd", 
"ChartTitleVisualData:ve", 
"VisualDataSerializer:vf", 
"AxisVisualData:vg", 
"AxisLabelVisualDataList:vh", 
"AxisLabelVisualData:vi", 
"RadialBase:vj", 
"RadialBaseView:vk", 
"RadialBucketCalculator:vl", 
"SeriesRenderer$2:vm", 
"SeriesRenderingArguments:vn", 
"RadialFrame:vo", 
"RadialAxes:vp", 
"PolarBase:vq", 
"PolarBaseView:vr", 
"PolarTrendLineManager:vs", 
"PolarLinePlanner:vt", 
"AngleRadiusPair:vu", 
"PolarAxisInfoCache:vv", 
"PolarFrame:vw", 
"PolarAxes:vx", 
"AxisComponentsForView:vy", 
"AxisComponentsFromView:vz", 
"AxisFormatLabelHandler:v0", 
"VisualExportHelper:v1", 
"ContentInfo:v2", 
"ChartContentManager:v3", 
"ChartContentType:v4", 
"RenderRequestedEventArgs:v5", 
"AssigningCategoryMarkerStyleEventHandler:v6", 
"SeriesComponentsForView:v7", 
"StackedSeriesFramePreparer:v8", 
"StackedSeriesCreatedEventHandler:v9", 
"StackedSeriesCreatedEventArgs:wa", 
"StackedSeriesVisualData:wb", 
"LabelPanelArranger:wc", 
"LabelPanelsArrangeState:wd", 
"WindowResponse:we", 
"ViewerSurfaceUsage:wf", 
"SeriesViewerComponentsForView:wg", 
"DataChartCursorEventHandler:wh", 
"ChartCursorEventArgs:wi", 
"DataChartMouseButtonEventHandler:wj", 
"DataChartMouseEventHandler:wk", 
"AnnotationLayer:wl", 
"AnnotationLayerView:wm", 
"RefreshCompletedEventHandler:wn", 
"SeriesComponentsFromView:wo", 
"EasingFunctions:wp", 
"TrendCalculators:wq", 
"CategoryXAxis:xj", 
"CategoryXAxisView:xk", 
"PointSeries:xm", 
"PointSeriesView:xn", 
"SplineAreaSeriesView:xq", 
"SplineAreaSeries:xr", 
"ColumnSeries:xs", 
"ColumnSeriesView:xt", 
"SplineSeries:xu", 
"SplineSeriesView:xv", 
"AbstractEnumerable:acm", 
"AbstractEnumerator:acn", 
"GenericEnumerable$1:aco", 
"GenericEnumerator$1:acp"]);


$.ig.util.defType('CategoryXAxis', 'CategoryAxisBase', {
	createView: function () {
		return new $.ig.CategoryXAxisView(this);
	}
	,
	onViewCreated: function (view) {
		$.ig.CategoryAxisBase.prototype.onViewCreated.call(this, view);
		this.xView(view);
	}
	,
	_xView: null,
	xView: function (value) {
		if (arguments.length === 1) {
			this._xView = value;
			return value;
		} else {
			return this._xView;
		}
	}
	,
	init: function () {
		this.__actualMinimum = 1;
		this.__actualMaximum = 1;
		$.ig.CategoryAxisBase.prototype.init.call(this);
		this.majorLinePositions(new $.ig.List$1(Number, 0));
		this.defaultStyleKey($.ig.CategoryXAxis.prototype.$type);
	},
	__actualMinimum: 0,
	actualMinimum: function (value) {
		if (arguments.length === 1) {
			this.__actualMinimum = value;
			return value;
		} else {
			return this.__actualMinimum;
		}
	}
	,
	__actualMaximum: 0,
	actualMaximum: function (value) {
		if (arguments.length === 1) {
			this.__actualMaximum = value;
			return value;
		} else {
			return this.__actualMaximum;
		}
	}
	,
	createLabelPanel: function () {
		if (this.useSmartAxis()) {
			return new $.ig.SmartAxisLabelPanel();
		} else {
			return new $.ig.HorizontalAxisLabelPanel();
		}
	}
	,
	getCategorySize: function (windowRect, viewportRect) {
		return viewportRect.width() / (this._cachedItemsCount * windowRect.width());
	}
	,
	getGroupSize: function (windowRect, viewportRect) {
		var gap = !$.ig.util.isNaN(this.gap()) ? $.ig.MathUtil.prototype.clamp(this.gap(), 0, 1) : 0;
		var overlap = 0;
		if (!$.ig.util.isNaN(this.overlap())) {
			overlap = Math.min(this.overlap(), 1);
		} else {
			overlap = 0;
		}
		;
		var categorySpace = 1 - 0.5 * gap;
		var mode2GroupCount = this.mode2GroupCount() == 0 ? 1 : this.mode2GroupCount();
		var ret = this.getCategorySize(windowRect, viewportRect) * categorySpace / (mode2GroupCount - (mode2GroupCount - 1) * overlap);
		return ret;
	}
	,
	getGroupCenter: function (groupIndex, windowRect, viewportRect) {
		var groupCenter = 0.5;
		if (this.mode2GroupCount() > 1) {
			var gap = !$.ig.util.isNaN(this.gap()) ? $.ig.MathUtil.prototype.clamp(this.gap(), 0, 1) : 0;
			var overlap = 0;
			if (!$.ig.util.isNaN(this.overlap())) {
				overlap = Math.min(this.overlap(), 1);
			}
			var categorySpace = 1 - 0.5 * gap;
			var groupWidth = categorySpace / (this.mode2GroupCount() - (this.mode2GroupCount() - 1) * overlap);
			var groupSep = (categorySpace - groupWidth) / (this.mode2GroupCount() - 1);
			groupCenter = 0.25 * gap + 0.5 * groupWidth + groupIndex * groupSep;
		}
		return this.getCategorySize(windowRect, viewportRect) * groupCenter;
	}
	,
	scrollIntoView: function (item) {
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = this.viewportRect();
		var unitRect = new $.ig.Rect(0, 0, 0, 1, 1);
		var xParams = new $.ig.ScalerParams(unitRect, unitRect, this.isInverted());
		var index = !windowRect.isEmpty() && !viewportRect.isEmpty() && this.fastItemsSource() != null ? this.fastItemsSource().indexOf(item) : -1;
		var cx = index > -1 ? this.getScaledValue(index, xParams) : NaN;
		if (!$.ig.util.isNaN(cx) && this.seriesViewer().isSyncReady()) {
			if (!$.ig.util.isNaN(cx)) {
				if (cx < windowRect.left() + 0.1 * windowRect.width()) {
					cx = cx + 0.4 * windowRect.width();
					windowRect.x(cx - 0.5 * windowRect.width());
				}
				if (cx > windowRect.right() - 0.1 * windowRect.width()) {
					cx = cx - 0.4 * windowRect.width();
					windowRect.x(cx - 0.5 * windowRect.width());
				}
			}
			this.seriesViewer().windowNotify(windowRect, false);
		}
	}
	,
	getScaledValue: function (unscaledValue, p) {
		var itemCount = this.categoryMode() == $.ig.CategoryMode.prototype.mode0 ? this._cachedItemsCount - 1 : this._cachedItemsCount;
		if (itemCount < 0) {
			itemCount = 0;
		}
		var scaledValue = itemCount >= 1 ? (unscaledValue) / (itemCount) : itemCount == 0 ? 0.5 : NaN;
		if (this.isInvertedCached()) {
			scaledValue = 1 - scaledValue;
		}
		return p._viewportRect.left() + p._viewportRect.width() * (scaledValue - p._windowRect.left()) / p._windowRect.width();
	}
	,
	getUnscaledValue: function (scaledValue, p) {
		return this.getUnscaledValue2(scaledValue, p._windowRect, p._viewportRect, this.categoryMode());
	}
	,
	getUnscaledValue2: function (scaledValue, windowRect, viewportRect, categoryMode) {
		var unscaledValue = windowRect.left() + (scaledValue - viewportRect.left()) * windowRect.width() / viewportRect.width();
		if (this.isInvertedCached()) {
			unscaledValue = 1 - unscaledValue;
		}
		var itemCount = categoryMode == $.ig.CategoryMode.prototype.mode0 ? this._cachedItemsCount - 1 : this._cachedItemsCount;
		if (itemCount < 0) {
			itemCount = 0;
		}
		return unscaledValue * itemCount;
	}
	,
	renderAxisOverride: function (animate) {
		$.ig.CategoryAxisBase.prototype.renderAxisOverride.call(this, animate);
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = this.viewportRect();
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, this.isInverted());
		var axisGeometry = this.view().getAxisLinesGeometry();
		var stripsGeometry = this.view().getStripsGeometry();
		var majorGeometry = this.view().getMajorLinesGeometry();
		var minorGeometry = this.view().getMinorLinesGeometry();
		var axisLinesPathInfo = this.view().getAxisLinesPathInfo();
		var majorLinesPathInfo = this.view().getMajorLinesPathInfo();
		var minorLinesPathInfo = this.view().getMinorLinesPathInfo();
		var fastItemsSource = this.fastItemsSource();
		this.updateLineVisibility();
		this.clearMarks(axisGeometry);
		this.clearMarks(stripsGeometry);
		this.clearMarks(majorGeometry);
		this.clearMarks(minorGeometry);
		this.labelDataContext().clear();
		this.labelPositions().clear();
		this.majorLinePositions().clear();
		this.view().updateLabelPanel(this, windowRect, viewportRect);
		if (windowRect.isEmpty() || viewportRect.isEmpty()) {
			this.textBlocks().count(0);
		}
		if (this.textBlocks().count() == 0) {
			this.view().clearLabelPanel();
		}
		if (this.labelSettings() != null) {
			this.labelSettings().registerAxis(this);
		}
		if (this.itemsSource() == null || fastItemsSource == null || fastItemsSource.count() == 0) {
			this.textBlocks().count(0);
			this.view().clearLabelPanel();
			return;
		}
		if (!windowRect.isEmpty() && !viewportRect.isEmpty()) {
			var visibleMinimum = this.getUnscaledValue(viewportRect.left(), xParams);
			var visibleMaximum = this.getUnscaledValue(viewportRect.right(), xParams);
			if (this.isInverted()) {
				visibleMinimum = Math.ceil(visibleMinimum);
				visibleMaximum = Math.floor(visibleMaximum);
			} else {
				visibleMinimum = Math.floor(visibleMinimum);
				visibleMaximum = Math.ceil(visibleMaximum);
			}
			var crossingValue = viewportRect.bottom();
			var relativeCrossingValue = crossingValue - viewportRect.top();
			if (this.crossingAxis() != null) {
				var yAxis = $.ig.util.cast($.ig.NumericYAxis.prototype.$type, this.crossingAxis());
				if (yAxis != null) {
					var yParams = new $.ig.ScalerParams(windowRect, viewportRect, yAxis.isInverted());
					crossingValue = this.crossingValue();
					crossingValue = yAxis.getScaledValue(crossingValue, yParams);
					relativeCrossingValue = crossingValue - viewportRect.top();
					if (crossingValue < viewportRect.top()) {
						crossingValue = viewportRect.top();
					} else if (crossingValue > viewportRect.bottom()) {
						crossingValue = viewportRect.bottom();
					}
					if (relativeCrossingValue < 0) {
						relativeCrossingValue = 0;
					} else if (relativeCrossingValue > viewportRect.height()) {
						relativeCrossingValue = viewportRect.height();
					}
				}
			}
			this.horizontalLine(axisGeometry, crossingValue, viewportRect, axisLinesPathInfo);
			this.view().setLabelPanelCrossingValue(relativeCrossingValue);
			var trueVisibleMinimum = Math.min(visibleMinimum, visibleMaximum);
			var trueVisibleMaximum = Math.max(visibleMinimum, visibleMaximum);
			var snapper = new $.ig.LinearCategorySnapper(1, trueVisibleMinimum, trueVisibleMaximum, viewportRect.width(), this.interval(), this.categoryMode());
			var firstValue = Math.floor((trueVisibleMinimum - 0) / snapper.interval());
			var lastValue = Math.ceil((trueVisibleMaximum - 0) / snapper.interval());
			if (!$.ig.util.isNaN(firstValue) && !$.ig.util.isNaN(lastValue)) {
				var first = $.ig.truncate(firstValue);
				var last = $.ig.truncate(lastValue);
				var majorValue = this.getScaledValue(0 + first * snapper.interval(), xParams);
				this.view().setLabelPanelInterval(this.getScaledValue(snapper.interval(), xParams));
				var viewportPixelRight = $.ig.truncate(Math.ceil(viewportRect.right()));
				var viewportPixelLeft = $.ig.truncate(Math.floor(viewportRect.left()));
				for (var i = first; i <= last; ++i) {
					var nextMajorValue = this.getScaledValue(0 + (i + 1) * snapper.interval(), xParams);
					if (majorValue <= viewportRect.right()) {
						if (i % 2 == 0) {
							this.verticalStrip(stripsGeometry, majorValue, nextMajorValue, viewportRect);
						}
						this.verticalLine(majorGeometry, majorValue, viewportRect, majorLinesPathInfo);
						this.majorLinePositions().add(majorValue);
						if (this.categoryMode() != $.ig.CategoryMode.prototype.mode0 && this.mode2GroupCount() != 0 && this.shouldRenderMinorLines()) {
							for (var categoryNumber = 0; categoryNumber < $.ig.truncate(snapper.interval()); categoryNumber++) {
								for (var groupNumber = 0; groupNumber < this.mode2GroupCount(); groupNumber++) {
									var center = this.getGroupCenter(groupNumber, windowRect, viewportRect);
									if (this.isInverted()) {
										center = -center;
									}
									var minorValue = this.getScaledValue(categoryNumber + i * snapper.interval(), xParams) + center;
									this.verticalLine(minorGeometry, minorValue, viewportRect, minorLinesPathInfo);
								}
							}
						}
					}
					var categoryValue = majorValue;
					if (this.categoryMode() != $.ig.CategoryMode.prototype.mode0) {
						var nextCategoryValue = this.getScaledValue(i * snapper.interval() + 1, xParams);
						categoryValue = (majorValue + nextCategoryValue) / 2;
					}
					var categoryPixelValue = $.ig.truncate(Math.round(categoryValue));
					if (categoryPixelValue >= viewportPixelLeft && categoryPixelValue <= viewportPixelRight) {
						var itemIndex = 0;
						if (snapper.interval() >= 1) {
							itemIndex = i * $.ig.truncate(Math.floor(snapper.interval()));
						} else {
							if ((i * snapper.interval()) * 2 % 2 == 0) {
								itemIndex = $.ig.truncate(Math.floor(i * snapper.interval()));
							} else {
								itemIndex = -1;
							}
						}
						if (fastItemsSource != null && itemIndex < fastItemsSource.count() && itemIndex >= 0) {
							var dataItem = fastItemsSource.item(itemIndex);
							var labelText = this.getLabel(dataItem);
							if (!$.ig.util.isNaN(categoryValue) && !Number.isInfinity(categoryValue) && labelText != null) {
								if ((typeof labelText === 'string') && (labelText).equals("")) {
								} else {
									this.labelDataContext().add1(labelText);
									this.labelPositions().add(new $.ig.LabelPosition(categoryValue));
								}
							}
						}
					}
					majorValue = nextMajorValue;
				}
			}
			if ((this.labelSettings() == null || this.labelSettings().visibility() == $.ig.Visibility.prototype.visible) && this.crossingAxis() != null) {
				if (this.labelSettings() != null && (this.labelSettings().location() == $.ig.AxisLabelsLocation.prototype.insideTop || this.labelSettings().location() == $.ig.AxisLabelsLocation.prototype.insideBottom)) {
					this.seriesViewer().invalidatePanels();
				}
			}
			this.view().updateLabelPanelContent(this.labelDataContext(), this.labelPositions());
			this.renderLabels();
		}
	}
	,
	updateRangeOverride: function () {
		if (this.fastItemsSource() == null) {
			return false;
		}
		var max = this.fastItemsSource().count();
		if (max != this.actualMaximum()) {
			var ea = new $.ig.AxisRangeChangedEventArgs(1, 1, this.actualMaximum(), max);
			this.actualMaximum(max);
			this.raiseRangeChanged(ea);
			return true;
		}
		return false;
	}
	,
	interval: function (value) {
		if (arguments.length === 1) {
			this.setValue($.ig.CategoryXAxis.prototype.intervalProperty, value);
			return value;
		} else {
			return this.getValue($.ig.CategoryXAxis.prototype.intervalProperty);
		}
	}
	,
	shouldShareMode: function (chart) {
		if (chart == null) {
			return false;
		}
		var settings = this.getSyncSettings();
		if (settings == null) {
			return false;
		}
		return settings.synchronizeHorizontally();
	}
	,
	orientation: function () {
		return $.ig.AxisOrientation.prototype.horizontal;
	}
	,
	$type: new $.ig.Type('CategoryXAxis', $.ig.CategoryAxisBase.prototype.$type)
}, true);

$.ig.util.defType('CategoryXAxisView', 'CategoryAxisBaseView', {
	_xModel: null,
	xModel: function (value) {
		if (arguments.length === 1) {
			this._xModel = value;
			return value;
		} else {
			return this._xModel;
		}
	}
	,
	init: function (model) {
		$.ig.CategoryAxisBaseView.prototype.init.call(this, model);
		this.xModel(model);
	},
	$type: new $.ig.Type('CategoryXAxisView', $.ig.CategoryAxisBaseView.prototype.$type)
}, true);

$.ig.util.defType('BarFramePreparer', 'CategoryFramePreparer', {
	init: function (initNumber, host) {
		if (initNumber > 0) {
			switch (initNumber) {
				case 1:
					this.init1.apply(this, arguments);
					break;
			}
			return;
		}
		$.ig.BarFramePreparer.prototype.init1.call(this, 1, host, $.ig.util.cast($.ig.ISupportsMarkers.prototype.$type, host), $.ig.util.cast($.ig.IProvidesViewport.prototype.$type, host), $.ig.util.cast($.ig.ISupportsErrorBars.prototype.$type, host), $.ig.util.cast($.ig.IBucketizer.prototype.$type, host));
	},
	init1: function (initNumber, host, markersHost, viewportHost, errorBarsHost, bucketizingHost) {
		$.ig.CategoryFramePreparer.prototype.init1.call(this, 1, host, markersHost, viewportHost, errorBarsHost, bucketizingHost);
		this.trendlineHost(new $.ig.DefaultCategoryTrendlineHost());
		if ($.ig.util.cast($.ig.IHasCategoryTrendline.prototype.$type, host) !== null) {
			this.trendlineHost($.ig.util.cast($.ig.IHasCategoryTrendline.prototype.$type, host));
		}
		this.valuesProvider(new $.ig.DefaultSingleValueProvider());
		if ($.ig.util.cast($.ig.IHasSingleValueCategory.prototype.$type, host) !== null) {
			this.valuesProvider($.ig.util.cast($.ig.IHasSingleValueCategory.prototype.$type, host));
		}
	},
	prepareMarker: function (frame, bucket, collisionAvoider, itemIndex, markerCount, markerBucket) {
		var x = bucket[1];
		var y = bucket[0];
		var markerRect = new $.ig.Rect(0, x - 5, y - 5, 11, 11);
		if (!$.ig.util.isNaN(x) && !$.ig.util.isNaN(y) && !Number.isInfinity(x) && !Number.isInfinity(y) && collisionAvoider.tryAdd(markerRect)) {
			frame._markers.add({ __x: x, __y: y, $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName });
			this.markersHost().updateMarkerTemplate(markerCount, itemIndex, markerBucket);
			return true;
		}
		return false;
	}
	,
	prepareTrendline: function (p, h, offset) {
		if (this.trendlineHost().trendLineType() == $.ig.TrendLineType.prototype.none || this.trendlineHost().trendlinePreparer() == null || this.trendlineHost().trendLinePeriod() < 1) {
			return;
		}
		var sParams = new $.ig.ScalerParams(p.windowRect(), p.viewportRect(), p.scaler().isInverted());
		var yParams = new $.ig.ScalerParams(p.windowRect(), p.viewportRect(), p.yScaler().isInverted());
		var values = (h).values();
		if (p.sortingScaler() != null && p.sortingScaler().sortedIndices() != null) {
			values = new $.ig.SafeSortedReadOnlyDoubleCollection(0, values, p.sortingScaler().sortedIndices());
		}
		var trendResolutionParams = (function () {
			var $ret = new $.ig.TrendResolutionParams();
			$ret.bucketSize(p.bucketSize());
			$ret.firstBucket(p.firstBucket());
			$ret.lastBucket(p.lastBucket());
			$ret.offset(offset);
			$ret.resolution(p.resolution());
			$ret.viewport(p.viewportRect());
			return $ret;
		}());
		if (this.trendlineHost().trendLineType() != $.ig.TrendLineType.prototype.none) {
			this.trendlineHost().trendlinePreparer().prepareLine(p.frame()._trend, this.trendlineHost().trendLineType(), values, this.trendlineHost().trendLinePeriod(), function (x) { return p.yScaler().getScaledValue(x, yParams); }, function (y) { return p.scaler().getScaledValue(y, sParams); }, trendResolutionParams);
		}
	}
	,
	$type: new $.ig.Type('BarFramePreparer', $.ig.CategoryFramePreparer.prototype.$type)
}, true);

$.ig.util.defType('BarTrendFitCalculator', 'Object', {
	init: function () {
		$.ig.Object.prototype.init.call(this);
	},
	calculateFit: function (trend, trendLineType, trendResolutionParams, trendCoefficients, count, GetUnscaledX, GetUnscaledY, GetScaledXValue, GetScaledYValue, ymin, ymax) {
		if (trendCoefficients == null) {
			switch (trendLineType) {
				case $.ig.TrendLineType.prototype.linearFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.linearFit(count, GetUnscaledY, GetUnscaledX);
					break;
				case $.ig.TrendLineType.prototype.quadraticFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.quadraticFit(count, GetUnscaledY, GetUnscaledX);
					break;
				case $.ig.TrendLineType.prototype.cubicFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.cubicFit(count, GetUnscaledY, GetUnscaledX);
					break;
				case $.ig.TrendLineType.prototype.quarticFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.quarticFit(count, GetUnscaledY, GetUnscaledX);
					break;
				case $.ig.TrendLineType.prototype.quinticFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.quinticFit(count, GetUnscaledY, GetUnscaledX);
					break;
				case $.ig.TrendLineType.prototype.exponentialFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.exponentialFit(count, GetUnscaledY, GetUnscaledX);
					break;
				case $.ig.TrendLineType.prototype.logarithmicFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.logarithmicFit(count, GetUnscaledY, GetUnscaledX);
					break;
				case $.ig.TrendLineType.prototype.powerLawFit:
					trendCoefficients = $.ig.LeastSquaresFit.prototype.powerLawFit(count, GetUnscaledY, GetUnscaledX);
					break;
				default: throw new $.ig.NotImplementedException(0);
			}
		}
		if (trendCoefficients == null) {
			return null;
		}
		for (var i = 0; i < trendResolutionParams.viewport().height(); i += 2) {
			var p = i / (trendResolutionParams.viewport().height() - 1);
			var yi = ymin + p * (ymax - ymin);
			var xi = NaN;
			switch (trendLineType) {
				case $.ig.TrendLineType.prototype.linearFit:
					xi = $.ig.LeastSquaresFit.prototype.linearEvaluate(trendCoefficients, yi);
					break;
				case $.ig.TrendLineType.prototype.quadraticFit:
					xi = $.ig.LeastSquaresFit.prototype.quadraticEvaluate(trendCoefficients, yi);
					break;
				case $.ig.TrendLineType.prototype.cubicFit:
					xi = $.ig.LeastSquaresFit.prototype.cubicEvaluate(trendCoefficients, yi);
					break;
				case $.ig.TrendLineType.prototype.quarticFit:
					xi = $.ig.LeastSquaresFit.prototype.quarticEvaluate(trendCoefficients, yi);
					break;
				case $.ig.TrendLineType.prototype.quinticFit:
					xi = $.ig.LeastSquaresFit.prototype.quinticEvaluate(trendCoefficients, yi);
					break;
				case $.ig.TrendLineType.prototype.exponentialFit:
					xi = $.ig.LeastSquaresFit.prototype.exponentialEvaluate(trendCoefficients, yi);
					break;
				case $.ig.TrendLineType.prototype.logarithmicFit:
					xi = $.ig.LeastSquaresFit.prototype.logarithmicEvaluate(trendCoefficients, yi);
					break;
				case $.ig.TrendLineType.prototype.powerLawFit:
					xi = $.ig.LeastSquaresFit.prototype.powerLawEvaluate(trendCoefficients, yi);
					break;
				default: throw new $.ig.NotImplementedException(0);
			}
			xi = GetScaledXValue(xi);
			yi = GetScaledYValue(yi);
			if (!$.ig.util.isNaN(xi) && !Number.isInfinity(xi)) {
				trend.add({ __x: xi, __y: yi + trendResolutionParams.offset(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName });
			}
		}
		return trendCoefficients;
	}
	,
	$type: new $.ig.Type('BarTrendFitCalculator', $.ig.Object.prototype.$type)
}, true);

$.ig.util.defType('BarTrendLineManager', 'CategoryTrendLineManager', {
	init: function () {
		$.ig.CategoryTrendLineManager.prototype.init.call(this);
	},
	prepareLine: function (flattenedPoints, trendLineType, valueColumn, period, GetScaledXValue, GetScaledYValue, trendResolutionParams) {
		var ymin = trendResolutionParams.firstBucket() * trendResolutionParams.bucketSize();
		var ymax = trendResolutionParams.lastBucket() * trendResolutionParams.bucketSize();
		var trend = new $.ig.List$1($.ig.Point.prototype.$type, 0);
		if (trendLineType == $.ig.TrendLineType.prototype.none) {
			this.trendCoefficients(null);
			this.trendColumn().clear();
			return;
		}
		if (this.isFit(trendLineType)) {
			this.trendColumn().clear();
			this.trendCoefficients($.ig.BarTrendFitCalculator.prototype.calculateFit(trend, trendLineType, trendResolutionParams, this.trendCoefficients(), valueColumn.count(), function (i) { return valueColumn.item(i); }, function (i) { return i + 1; }, GetScaledXValue, function (x) { return GetScaledYValue(x - 1); }, ymin + 1, ymax + 1));
		}
		if (this.isAverage(trendLineType)) {
			this.trendCoefficients(null);
			$.ig.TrendAverageCalculator.prototype.calculateSingleValueAverage(trendLineType, this.trendColumn(), valueColumn, period);
			for (var i = trendResolutionParams.firstBucket(); i <= trendResolutionParams.lastBucket(); i += 1) {
				var itemIndex = i * trendResolutionParams.bucketSize();
				if (itemIndex >= 0 && itemIndex < this.trendColumn().count()) {
					var xi = GetScaledXValue(this.trendColumn().__inner[itemIndex]);
					var yi = GetScaledYValue(itemIndex);
					trend.add({ __x: xi, __y: yi + trendResolutionParams.offset(), $type: $.ig.Point.prototype.$type, getType: $.ig.Object.prototype.getType, getGetHashCode: $.ig.Object.prototype.getGetHashCode, typeName: $.ig.Object.prototype.typeName });
				}
			}
		}
		this.flattenTrendLine(trend, trendResolutionParams, flattenedPoints);
	}
	,
	$type: new $.ig.Type('BarTrendLineManager', $.ig.CategoryTrendLineManager.prototype.$type)
}, true);

$.ig.util.defType('VerticalAnchoredCategorySeries', 'AnchoredCategorySeries', {
	init: function () {
		$.ig.AnchoredCategorySeries.prototype.init.call(this);
	},
	xAxis: function (value) {
		if (arguments.length === 1) {
			this.setValue($.ig.VerticalAnchoredCategorySeries.prototype.xAxisProperty, value);
			return value;
		} else {
			return this.getValue($.ig.VerticalAnchoredCategorySeries.prototype.xAxisProperty);
		}
	}
	,
	yAxis: function (value) {
		if (arguments.length === 1) {
			this.setValue($.ig.VerticalAnchoredCategorySeries.prototype.yAxisProperty, value);
			return value;
		} else {
			return this.getValue($.ig.VerticalAnchoredCategorySeries.prototype.yAxisProperty);
		}
	}
	,
	isVertical: function () {
		return true;
	}
	,
	getCategoryAxis: function () {
		return this.yAxis();
	}
	,
	getOffsetValue: function () {
		return this.framePreparer().getOffset(this.yAxis(), this.view().windowRect(), this.view().viewport());
	}
	,
	getCategoryWidth: function () {
		return this.yAxis().getCategorySize(this.view().windowRect(), this.view().viewport());
	}
	,
	getNextOrExactIndex: function (world, skipUnknowns) {
		return this.getNextOrExactIndexHelper(world, skipUnknowns, this.yAxis(), this.getExactUnsortedItemIndex.runOn(this), this.valueColumn());
	}
	,
	getPreviousOrExactIndex: function (world, skipUnknowns) {
		return this.getPreviousOrExactIndexHelper(world, skipUnknowns, this.yAxis(), this.getExactUnsortedItemIndex.runOn(this), this.valueColumn());
	}
	,
	getDistanceToIndex: function (world, index, axis, p, offset) {
		if (this.valueColumn() == null) {
			return Number.POSITIVE_INFINITY;
		}
		return this.getDistanceToIndexHelper(world, index, this.yAxis(), p, offset, this.valueColumn().count(), this.getExactUnsortedItemIndex.runOn(this));
	}
	,
	getSeriesValue: function (world, useInterpolation, skipUnknowns) {
		if (this.seriesViewer() == null) {
			return NaN;
		}
		var yParams = new $.ig.ScalerParams(this.seriesViewer().actualWindowRect(), this.view().viewport(), this.yAxis().isInverted());
		var offset = this.framePreparer().getOffset(this.yAxis(), this.seriesViewer().actualWindowRect(), this.view().viewport());
		return this.getSeriesValueHelper(this.valueColumn(), world, this.yAxis(), yParams, offset, this.getExactUnsortedItemIndex.runOn(this), useInterpolation, skipUnknowns);
	}
	,
	getSeriesValuePosition: function (world, useInterpolation, skipUnknowns) {
		return this.getSeriesValuePositionHelper(world, useInterpolation, skipUnknowns, this.framePreparer().getOffset(this.yAxis(), this.view().windowRect(), this.view().viewport()), this.xAxis(), this.yAxis(), null, null, null);
	}
	,
	getXAxis: function () {
		return this.xAxis();
	}
	,
	getYAxis: function () {
		return this.yAxis();
	}
	,
	setXAxis: function (xAxis) {
		this.xAxis($.ig.util.cast($.ig.NumericXAxis.prototype.$type, xAxis));
	}
	,
	setYAxis: function (yAxis) {
		this.yAxis($.ig.util.cast($.ig.CategoryYAxis.prototype.$type, yAxis));
	}
	,
	updateNumericAxisRange: function () {
		return this.xAxis() != null && this.xAxis().updateRange();
	}
	,
	getCategoryItems: function (orderedStartIndex, orderedEndIndex) {
		return this.getCategoryItemsHelper(orderedStartIndex, orderedEndIndex, this.yAxis());
	}
	,
	getExactItemIndex: function (world) {
		var windowRect = this.seriesViewer() != null ? this.seriesViewer().actualWindowRect() : $.ig.Rect.prototype.empty();
		var viewportRect = this.view().viewport();
		var rowIndex = -1;
		if (this.yAxis() != null && !windowRect.isEmpty() && !viewportRect.isEmpty()) {
			var top = this.yAxis().getUnscaledValue2(viewportRect.top(), windowRect, viewportRect, this.yAxis().categoryMode());
			var bottom = this.yAxis().getUnscaledValue2(viewportRect.bottom(), windowRect, viewportRect, this.yAxis().categoryMode());
			var windowY = (world.__y - windowRect.top()) / windowRect.height();
			var bucket = top + (windowY * (bottom - top));
			if (this.yAxis().categoryMode() != $.ig.CategoryMode.prototype.mode0) {
				bucket -= 0.5;
			}
			rowIndex = bucket;
		}
		return rowIndex;
	}
	,
	getExactUnsortedItemIndex: function (world) {
		return this.getExactUnsortedItemIndexHelper(world, this.getYAxis());
	}
	,
	getItemIndex: function (world) {
		return $.ig.truncate(Math.round(this.getExactItemIndex(world)));
	}
	,
	getItem: function (world) {
		var index = this.getItemIndex(world);
		return index >= 0 && this.fastItemsSource() != null && index < this.fastItemsSource().count() ? this.fastItemsSource().item(index) : null;
	}
	,
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.AnchoredCategorySeries.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.VerticalAnchoredCategorySeries.prototype.xAxisPropertyName:
				if (oldValue != newValue) {
					this.deregisterForAxis($.ig.util.cast($.ig.Axis.prototype.$type, oldValue));
					this.registerForAxis($.ig.util.cast($.ig.Axis.prototype.$type, newValue));
					this.categoryView().bucketCalculator().calculateBuckets(this.resolution());
					this.renderSeries(false);
					this.notifyThumbnailAppearanceChanged();
				}
				break;
			case $.ig.VerticalAnchoredCategorySeries.prototype.yAxisPropertyName:
				if (oldValue != newValue) {
					this.deregisterForAxis($.ig.util.cast($.ig.Axis.prototype.$type, oldValue));
					this.registerForAxis($.ig.util.cast($.ig.Axis.prototype.$type, newValue));
					this.categoryView().bucketCalculator().calculateBuckets(this.resolution());
					this.updateNumericAxisRange();
					this.renderSeries(false);
					this.notifyThumbnailAppearanceChanged();
				}
				break;
		}
	}
	,
	$type: new $.ig.Type('VerticalAnchoredCategorySeries', $.ig.AnchoredCategorySeries.prototype.$type)
}, true);

$.ig.util.defType('BarSeries', 'VerticalAnchoredCategorySeries', {
	createView: function () {
		return new $.ig.BarSeriesView(this);
	}
	,
	getDefaultTransitionInMode: function () {
		return $.ig.CategoryTransitionInMode.prototype.fromZero;
	}
	,
	onViewCreated: function (view) {
		$.ig.VerticalAnchoredCategorySeries.prototype.onViewCreated.call(this, view);
		this.barView(view);
	}
	,
	_barView: null,
	barView: function (value) {
		if (arguments.length === 1) {
			this._barView = value;
			return value;
		} else {
			return this._barView;
		}
	}
	,
	hasIndividualElements: function () {
		return true;
	}
	,
	init: function () {
		$.ig.VerticalAnchoredCategorySeries.prototype.init.call(this);
		this.defaultStyleKey($.ig.BarSeries.prototype.$type);
		this.framePreparer(new $.ig.BarFramePreparer(1, this, this.barView(), this, this, this.barView().bucketCalculator()));
	},
	getFramePreparer: function (view) {
		var categoryView = $.ig.util.cast($.ig.CategorySeriesView.prototype.$type, view);
		if (categoryView != null && categoryView.isThumbnailView()) {
			if (categoryView.isAlternateView()) {
				return new $.ig.BarFramePreparer(1, this, $.ig.util.cast($.ig.ISupportsMarkers.prototype.$type, categoryView), categoryView, this, categoryView.bucketCalculator());
			} else {
				return new $.ig.BarFramePreparer(1, this, $.ig.util.cast($.ig.ISupportsMarkers.prototype.$type, categoryView), this.seriesViewer().view().overviewPlusDetailViewportHost(), this, categoryView.bucketCalculator());
			}
		} else {
			return this.framePreparer();
		}
	}
	,
	onApplyTemplate: function () {
		$.ig.VerticalAnchoredCategorySeries.prototype.onApplyTemplate.call(this);
	}
	,
	radiusX: function (value) {
		if (arguments.length === 1) {
			this.setValue($.ig.BarSeries.prototype.radiusXProperty, value);
			return value;
		} else {
			return this.getValue($.ig.BarSeries.prototype.radiusXProperty);
		}
	}
	,
	radiusY: function (value) {
		if (arguments.length === 1) {
			this.setValue($.ig.BarSeries.prototype.radiusYProperty, value);
			return value;
		} else {
			return this.getValue($.ig.BarSeries.prototype.radiusYProperty);
		}
	}
	,
	preferredCategoryMode: function (axis) {
		return $.ig.CategoryMode.prototype.mode2;
	}
	,
	clearRendering: function (wipeClean, view) {
		$.ig.VerticalAnchoredCategorySeries.prototype.clearRendering.call(this, wipeClean, view);
		var barView = $.ig.util.cast($.ig.BarSeriesView.prototype.$type, view);
		if (wipeClean && barView != null && barView.columns() != null) {
			barView.columns().count(0);
		}
	}
	,
	getMode2Index: function () {
		var result = 0;
		var en = this.seriesViewer().series().getEnumerator();
		while (en.moveNext()) {
			var currentSeries = en.current();
			if (currentSeries == this) {
				return result;
			}
			var currentCategorySeries = $.ig.util.cast($.ig.IBarSeries.prototype.$type, currentSeries);
			if (currentCategorySeries != null && currentCategorySeries.yAxis() == this.yAxis() && currentCategorySeries.getPreferredCategoryMode() == $.ig.CategoryMode.prototype.mode2) {
				result++;
			}
		}
		$.ig.Debug.prototype.assert1(false, "CategorySeries.GetMode2Index failed to find series");
		return -1;
	}
	,
	getWorldZeroValue: function (view) {
		var value = 0;
		var windowRect = view.windowRect();
		var viewportRect = view.viewport();
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, this.xAxis().isInverted());
		if (!windowRect.isEmpty() && !viewportRect.isEmpty() && this.xAxis() != null) {
			value = this.xAxis().getScaledValue(this.xAxis().referenceValue(), xParams);
		}
		return value;
	}
	,
	getRange: function (axis) {
		if (this.valueColumn() == null || this.valueColumn().count() == 0) {
			return null;
		}
		if (axis == this.yAxis()) {
			return new $.ig.AxisRange(0, this.valueColumn().count() - 1);
		}
		if (axis == this.xAxis()) {
			return new $.ig.AxisRange(this.valueColumn().minimum(), this.valueColumn().maximum());
		}
		return null;
	}
	,
	scrollIntoView: function (item) {
		var windowRect = this.view().windowRect();
		var viewportRect = this.view().viewport();
		var unitRect = new $.ig.Rect(0, 0, 0, 1, 1);
		var index = !windowRect.isEmpty() && !viewportRect.isEmpty() && this.fastItemsSource() != null ? this.fastItemsSource().indexOf(item) : -1;
		var xParams = new $.ig.ScalerParams(unitRect, unitRect, this.xAxis().isInverted());
		var yParams = new $.ig.ScalerParams(unitRect, unitRect, this.yAxis().isInverted());
		var cy = this.yAxis() != null ? this.yAxis().getScaledValue(index, yParams) : NaN;
		var offset = this.yAxis() != null ? this.framePreparer().getOffset(this.yAxis(), unitRect, unitRect) : 0;
		cy += offset;
		var cx = this.xAxis() != null && this.valueColumn() != null && index < this.valueColumn().count() ? this.xAxis().getScaledValue(this.valueColumn().item(index), xParams) : NaN;
		if (!$.ig.util.isNaN(cx)) {
			if (cx < windowRect.left() + 0.1 * windowRect.width()) {
				cx = cx + 0.4 * windowRect.width();
				windowRect.x(cx - 0.5 * windowRect.width());
			}
			if (cx > windowRect.right() - 0.1 * windowRect.width()) {
				cx = cx - 0.4 * windowRect.width();
				windowRect.x(cx - 0.5 * windowRect.width());
			}
		}
		if (!$.ig.util.isNaN(cy)) {
			if (cy < windowRect.top() + 0.1 * windowRect.height()) {
				cy = cy + 0.4 * windowRect.height();
				windowRect.y(cy - 0.5 * windowRect.height());
			}
			if (cy > windowRect.bottom() - 0.1 * windowRect.height()) {
				cy = cy - 0.4 * windowRect.height();
				windowRect.y(cy - 0.5 * windowRect.height());
			}
		}
		if (this.syncLink() != null) {
			this.syncLink().windowNotify(this.seriesViewer(), windowRect);
		}
		return index >= 0;
	}
	,
	getItemSpan: function () {
		return this.yAxis().getGroupSize(this.view().windowRect(), this.view().viewport());
	}
	,
	renderFrame: function (frame, view) {
		$.ig.VerticalAnchoredCategorySeries.prototype.renderFrame.call(this, frame, view);
		var buckets = frame._buckets;
		if (!view.hasSurface()) {
			return;
		}
		var windowRect = view.windowRect();
		var viewportRect = view.viewport();
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, this.xAxis().isInverted());
		var yAxis = this.yAxis();
		var yParams = new $.ig.ScalerParams(windowRect, viewportRect, this.yAxis().isInverted());
		var xscale = this.xAxis();
		var zero = xscale.getScaledValue(xscale.referenceValue(), xParams);
		var groupWidth = this.yAxis().getGroupSize(windowRect, viewportRect);
		var barView = $.ig.util.cast($.ig.BarSeriesView.prototype.$type, view);
		if ($.ig.util.isNaN(groupWidth) || Number.isInfinity(groupWidth) || $.ig.util.isNaN(zero)) {
			barView.columns().count(0);
			return;
		}
		this._renderManager.initCategoryRenderSettings(this, this.shouldOverrideCategoryStyle(), this.yAxis(), this.getCategoryItems.runOn(this), this.getBucketSize(view), this.getFirstBucket(view));
		this._renderManager._initialRenderRadiusX = this.radiusX();
		this._renderManager._initialRenderRadiusY = this.radiusY();
		this._renderManager._actualRenderRadiusX = this.radiusX();
		this._renderManager._actualRenderRadiusY = this.radiusY();
		var areStylesOverriden = false;
		var args = this._renderManager.categoryOverrideArgs();
		if (args != null) {
			areStylesOverriden = true;
		}
		var isSorting = this.xAxis().isSorting();
		var valueCount = this.valueColumn().count();
		for (var i = 0; i < buckets.count(); ++i) {
			var top = buckets.__inner[i][0] - 0.5 * groupWidth;
			var right = buckets.__inner[i][1];
			var left = zero;
			left = Math.max(left, -100);
			right = Math.min(right, viewportRect.right() + 100);
			var column = barView.columns().item(i);
			column.height(groupWidth);
			column.width(Math.abs(right - left));
			if (areStylesOverriden) {
				this.performCategoryStyleOverride(buckets, i, valueCount, yAxis, yParams, view.isThumbnailView());
			}
			this._renderManager.setCategoryShapeAppearance(column, false, false, false, false);
			column.radiusX(this._renderManager._actualRenderRadiusX);
			column.radiusY(this._renderManager._actualRenderRadiusY);
			barView.setColumnPosition(column, Math.min(right, left), top);
		}
		barView.columns().count(buckets.count());
		view.updateFrameVersion(frame);
	}
	,
	dataUpdatedOverride: function (action, position, count, propertyName) {
		switch (action) {
			case $.ig.FastItemsSourceEventAction.prototype.reset:
			case $.ig.FastItemsSourceEventAction.prototype.insert:
			case $.ig.FastItemsSourceEventAction.prototype.remove:
				this.anchoredView().bucketCalculator().calculateBuckets(this.resolution());
				break;
		}
		this.anchoredView().trendLineManager().dataUpdated(action, position, count, propertyName);
		switch (action) {
			case $.ig.FastItemsSourceEventAction.prototype.reset:
				if (this.xAxis() != null && !this.xAxis().updateRange()) {
					this.renderSeries(true);
				}
				break;
			case $.ig.FastItemsSourceEventAction.prototype.insert:
				if (this.xAxis() != null && !this.xAxis().updateRange()) {
					this.renderSeries(true);
				}
				break;
			case $.ig.FastItemsSourceEventAction.prototype.remove:
				if (this.xAxis() != null && !this.xAxis().updateRange()) {
					this.renderSeries(true);
				}
				break;
			case $.ig.FastItemsSourceEventAction.prototype.replace:
				if (this.valueMemberPath() != null && this.anchoredView().bucketCalculator()._bucketSize > 0) {
					this.renderSeries(true);
				}
				break;
			case $.ig.FastItemsSourceEventAction.prototype.change:
				if (propertyName == this.valueMemberPath()) {
					if (this.xAxis() != null && !this.xAxis().updateRange()) {
						this.renderSeries(true);
					}
				}
				break;
		}
	}
	,
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.VerticalAnchoredCategorySeries.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.VerticalAnchoredCategorySeries.prototype.xAxisPropertyName:
				if (oldValue != null) {
					(oldValue).deregisterSeries(this);
				}
				if (newValue != null) {
					(newValue).registerSeries(this);
				}
				this.anchoredView().bucketCalculator().calculateBuckets(this.resolution());
				if (this.xAxis() != null && this.xAxis().updateRange()) {
					this.renderSeries(false);
				}
				break;
			case $.ig.VerticalAnchoredCategorySeries.prototype.yAxisPropertyName:
				if (oldValue != null) {
					(oldValue).deregisterSeries(this);
				}
				if (newValue != null) {
					(newValue).registerSeries(this);
				}
				this.anchoredView().trendLineManager($.ig.CategoryTrendLineManagerBase.prototype.selectManager(this.anchoredView().trendLineManager(), this.yAxis(), this.rootCanvas(), this));
				this.anchoredView().bucketCalculator().calculateBuckets(this.resolution());
				this.renderSeries(false);
				break;
			case $.ig.Series.prototype.fastItemsSourcePropertyName:
				if (this.xAxis() != null && !this.xAxis().updateRange()) {
					this.anchoredView().bucketCalculator().calculateBuckets(this.resolution());
					this.renderSeries(false);
				}
				break;
			case $.ig.AnchoredCategorySeries.prototype.valueColumnPropertyName:
				if (this.xAxis() != null && !this.xAxis().updateRange()) {
					this.anchoredView().bucketCalculator().calculateBuckets(this.resolution());
					this.renderSeries(false);
				}
				break;
			case $.ig.Series.prototype.seriesViewerPropertyName:
				if (oldValue != null && newValue == null) {
					this.deregisterForAxis(this.xAxis());
					this.deregisterForAxis(this.yAxis());
				}
				if (oldValue == null && newValue != null) {
					this.registerForAxis(this.xAxis());
					this.registerForAxis(this.yAxis());
				}
				this.anchoredView().bucketCalculator().calculateBuckets(this.resolution());
				this.renderSeries(false);
				break;
		}
	}
	,
	getPreferredCategoryMode: function () {
		return this.preferredCategoryMode(this.yAxis());
	}
	,
	currentCategoryMode: function () {
		return this.preferredCategoryMode(this.yAxis());
	}
	,
	scaler: function () {
		return this.yAxis();
	}
	,
	yScaler: function () {
		return this.xAxis();
	}
	,
	$type: new $.ig.Type('BarSeries', $.ig.VerticalAnchoredCategorySeries.prototype.$type, [$.ig.IIsCategoryBased.prototype.$type, $.ig.IBarSeries.prototype.$type])
}, true);

$.ig.util.defType('BarSeriesView', 'AnchoredCategorySeriesView', {
	_barModel: null,
	barModel: function (value) {
		if (arguments.length === 1) {
			this._barModel = value;
			return value;
		} else {
			return this._barModel;
		}
	}
	,
	init: function (model) {
		var $self = this;
		this.__hitItem = new $.ig.Rectangle();
		$.ig.AnchoredCategorySeriesView.prototype.init.call(this, model);
		this.barModel(model);
		this.columns((function () {
			var $ret = new $.ig.Pool$1($.ig.Rectangle.prototype.$type);
			$ret.create($self.columnCreate.runOn($self));
			$ret.activate($self.columnActivate.runOn($self));
			$ret.disactivate($self.columnDisactivate.runOn($self));
			$ret.destroy($self.columnDestroy.runOn($self));
			return $ret;
		}()));
		this.trendLineManager(new $.ig.BarTrendLineManager());
	},
	_columns: null,
	columns: function (value) {
		if (arguments.length === 1) {
			this._columns = value;
			return value;
		} else {
			return this._columns;
		}
	}
	,
	onInit: function () {
		$.ig.AnchoredCategorySeriesView.prototype.onInit.call(this);
		this.visibleColumns(new $.ig.List$1($.ig.Rectangle.prototype.$type, 0));
		if (!this.isThumbnailView()) {
			this.model().resolution(4);
			this.model().legendItemBadgeTemplate((function () {
				var $ret = new $.ig.DataTemplate();
				$ret.render($.ig.LegendTemplates.prototype.rectBadgeTemplate);
				$ret.measure($.ig.LegendTemplates.prototype.legendItemBadgeMeasure);
				return $ret;
			}()));
		}
	}
	,
	columnCreate: function () {
		var column = new $.ig.Rectangle();
		this.visibleColumns().add(column);
		column.__visibility = $.ig.Visibility.prototype.collapsed;
		return column;
	}
	,
	_visibleColumns: null,
	visibleColumns: function (value) {
		if (arguments.length === 1) {
			this._visibleColumns = value;
			return value;
		} else {
			return this._visibleColumns;
		}
	}
	,
	columnActivate: function (column) {
		column.__visibility = $.ig.Visibility.prototype.visible;
	}
	,
	columnDisactivate: function (column) {
		column.__visibility = $.ig.Visibility.prototype.collapsed;
	}
	,
	columnDestroy: function (column) {
		this.visibleColumns().remove(column);
	}
	,
	setColumnPosition: function (column, x, y) {
		if (!this.isDirty()) {
			this.makeDirty();
		}
		column.canvasTop(y);
		column.canvasLeft(x);
	}
	,
	createBucketCalculator: function () {
		return new $.ig.BarBucketCalculator(this);
	}
	,
	setupItemHitAppearanceOverride: function (item, index) {
		$.ig.AnchoredCategorySeriesView.prototype.setupItemHitAppearanceOverride.call(this, item, index);
		var rect = item;
		var brush = this.getHitBrush1(index);
		rect.__fill = brush;
		rect.__stroke = brush;
		rect.strokeThickness(this.model().thickness());
	}
	,
	getItem: function (index) {
		return this.visibleColumns().__inner[index];
	}
	,
	__hitItem: null,
	getHitItem: function (index) {
		var item = this.visibleColumns().__inner[index];
		this.__hitItem.canvasLeft(item.canvasLeft());
		this.__hitItem.canvasTop(item.canvasTop());
		this.__hitItem.width(item.width());
		this.__hitItem.height(item.height());
		var hitBrush = this.getHitBrush1(index);
		this.__hitItem.__fill = hitBrush;
		this.__hitItem.__stroke = hitBrush;
		this.__hitItem.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		return this.__hitItem;
	}
	,
	renderOverride: function (context, isHitContext) {
		$.ig.AnchoredCategorySeriesView.prototype.renderOverride.call(this, context, isHitContext);
		if (context.shouldRender()) {
			for (var i = 0; i < this.visibleColumns().count(); i++) {
				var column = this.getCurrentItem(i, isHitContext);
				this.setupItemAppearance(column, i, isHitContext);
				context.renderRectangle(column);
			}
		}
	}
	,
	exportViewShapes: function (svd) {
		$.ig.AnchoredCategorySeriesView.prototype.exportViewShapes.call(this, svd);
		var i = 0;
		var toSort = new $.ig.List$1($.ig.Rectangle.prototype.$type, 0);
		var en = this.columns().active().getEnumerator();
		while (en.moveNext()) {
			var column = en.current();
			toSort.add(column);
		}
		toSort.sort2(function (c1, c2) {
			if (c1.canvasTop() > c2.canvasTop()) {
				return -1;
			} else if (c1.canvasTop() < c2.canvasTop()) {
				return 1;
			} else {
				return 0;
			}
		});
		var en1 = toSort.getEnumerator();
		while (en1.moveNext()) {
			var column1 = en1.current();
			var rvd = new $.ig.RectangleVisualData(1, "column" + i, column1);
			rvd.tags().add("Main");
			rvd.tags().add("Fill");
			svd.shapes().add(rvd);
		}
		i++;
	}
	,
	applyDropShadowDefaultSettings: function () {
		var color = new $.ig.Color();
		color.colorString("rgba(95,95,95,0.5)");
		this.model().shadowColor(color);
		this.model().shadowBlur(5);
		this.model().shadowOffsetX(5);
		this.model().shadowOffsetY(-5);
	}
	,
	$type: new $.ig.Type('BarSeriesView', $.ig.AnchoredCategorySeriesView.prototype.$type)
}, true);

$.ig.util.defType('BarBucketCalculator', 'CategoryBucketCalculator', {
	init: function (view) {
		$.ig.CategoryBucketCalculator.prototype.init.call(this, view);
		this.barView(view);
	},
	_barView: null,
	barView: function (value) {
		if (arguments.length === 1) {
			this._barView = value;
			return value;
		} else {
			return this._barView;
		}
	}
	,
	calculateBuckets: function (resolution) {
		var windowRect = this.view().windowRect();
		var viewportRect = this.view().viewport();
		var fastItemsSource = this.view().categoryModel().fastItemsSource();
		if (windowRect.isEmpty() || viewportRect.isEmpty() || this.barView().barModel().yAxis() == null || fastItemsSource == null || fastItemsSource.count() == 0) {
			this._bucketSize = 0;
			return;
		}
		var barSeries = $.ig.util.cast($.ig.BarSeries.prototype.$type, this.view().categoryModel());
		var y0 = Math.floor(barSeries.yAxis().getUnscaledValue2(viewportRect.top(), windowRect, viewportRect, $.ig.CategoryMode.prototype.mode0));
		var y1 = Math.ceil(barSeries.yAxis().getUnscaledValue2(viewportRect.bottom(), windowRect, viewportRect, $.ig.CategoryMode.prototype.mode0));
		if (!barSeries.yAxis().isInverted()) {
			y1 = Math.ceil(barSeries.yAxis().getUnscaledValue2(viewportRect.top(), windowRect, viewportRect, $.ig.CategoryMode.prototype.mode0));
			y0 = Math.floor(barSeries.yAxis().getUnscaledValue2(viewportRect.bottom(), windowRect, viewportRect, $.ig.CategoryMode.prototype.mode0));
		}
		var c = Math.floor((y1 - y0 + 1) * resolution / viewportRect.height());
		this._bucketSize = $.ig.truncate(Math.max(1, c));
		this._firstBucket = $.ig.truncate(Math.max(0, Math.floor(y0 / this._bucketSize) - 1));
		this._lastBucket = $.ig.truncate(Math.ceil(y1 / this._bucketSize));
	}
	,
	getBucket: function (bucket) {
		var column = this.__values;
		var count = this.__count;
		var i0 = Math.min(bucket * this._bucketSize, count - 1);
		var i1 = Math.min(i0 + this._bucketSize - 1, count - 1);
		var min = NaN;
		var max = NaN;
		for (var i = i0; i <= i1; ++i) {
			var y = column[i];
			if (!$.ig.util.isNaN(min)) {
				if (!$.ig.util.isNaN(y)) {
					min = Math.min(min, y);
					max = Math.max(max, y);
				}
			} else {
				min = y;
				max = y;
			}
		}
		if (!$.ig.util.isNaN(min)) {
			return [ (0.5 * (i0 + i1)), min, max ];
		}
		return [ (0.5 * (i0 + i1)), NaN, NaN ];
	}
	,
	__values: null,
	__count: 0,
	cacheValues: function () {
		this.__count = this.barView().barModel().valueColumn().count();
		this.__values = this.barView().barModel().valueColumn().asArray();
	}
	,
	unCacheValues: function () {
		this.__values = null;
	}
	,
	$type: new $.ig.Type('BarBucketCalculator', $.ig.CategoryBucketCalculator.prototype.$type)
}, true);

$.ig.util.defType('PointSeries', 'HorizontalAnchoredCategorySeries', {
	createView: function () {
		return new $.ig.PointSeriesView(this);
	}
	,
	_pointView: null,
	pointView: function (value) {
		if (arguments.length === 1) {
			this._pointView = value;
			return value;
		} else {
			return this._pointView;
		}
	}
	,
	onViewCreated: function (view) {
		$.ig.HorizontalAnchoredCategorySeries.prototype.onViewCreated.call(this, view);
		this.pointView(view);
	}
	,
	init: function () {
		$.ig.HorizontalAnchoredCategorySeries.prototype.init.call(this);
		this.defaultStyleKey($.ig.PointSeries.prototype.$type);
	},
	renderFrame: function (frame, view) {
		$.ig.HorizontalAnchoredCategorySeries.prototype.renderFrame.call(this, frame, view);
	}
	,
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.HorizontalAnchoredCategorySeries.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
	}
	,
	$type: new $.ig.Type('PointSeries', $.ig.HorizontalAnchoredCategorySeries.prototype.$type)
}, true);

$.ig.util.defType('PointSeriesView', 'AnchoredCategorySeriesView', {
	_pointModel: null,
	pointModel: function (value) {
		if (arguments.length === 1) {
			this._pointModel = value;
			return value;
		} else {
			return this._pointModel;
		}
	}
	,
	init: function (model) {
		$.ig.AnchoredCategorySeriesView.prototype.init.call(this, model);
		this.pointModel(model);
	},
	onInit: function () {
		$.ig.AnchoredCategorySeriesView.prototype.onInit.call(this);
		if (!this.isThumbnailView()) {
			this.markerModel().markerType($.ig.MarkerType.prototype.automatic);
			this.model().legendItemBadgeTemplate((function () {
				var $ret = new $.ig.DataTemplate();
				$ret.render($.ig.LegendTemplates.prototype.pointBadgeTemplate);
				$ret.measure($.ig.LegendTemplates.prototype.legendItemBadgeMeasure);
				return $ret;
			}()));
		}
	}
	,
	applyDropShadowDefaultSettings: function () {
		var color = new $.ig.Color();
		color.colorString("rgba(95,95,95,0.5)");
		this.model().shadowColor(color);
		this.model().shadowBlur(3);
		this.model().shadowOffsetX(2);
		this.model().shadowOffsetY(2);
		this.model().useSingleShadow(false);
	}
	,
	$type: new $.ig.Type('PointSeriesView', $.ig.AnchoredCategorySeriesView.prototype.$type)
}, true);

$.ig.util.defType('SplineAreaSeriesView', 'SplineSeriesBaseView', {
	_splineAreaModel: null,
	splineAreaModel: function (value) {
		if (arguments.length === 1) {
			this._splineAreaModel = value;
			return value;
		} else {
			return this._splineAreaModel;
		}
	}
	,
	init: function (model) {
		this._polygon0 = new $.ig.Path();
		this._polyline0 = new $.ig.Path();
		this._polygon1 = new $.ig.Path();
		this._polyline1 = new $.ig.Path();
		this.__hitPolygon0 = new $.ig.Path();
		this.__hitPolyline0 = new $.ig.Path();
		this.__hitPolygon1 = new $.ig.Path();
		this.__hitPolyline1 = new $.ig.Path();
		$.ig.SplineSeriesBaseView.prototype.init.call(this, model);
		this.splineAreaModel(model);
	},
	onInit: function () {
		$.ig.SplineSeriesBaseView.prototype.onInit.call(this);
		if (!this.isThumbnailView()) {
			this.model().legendItemBadgeTemplate((function () {
				var $ret = new $.ig.DataTemplate();
				$ret.render($.ig.LegendTemplates.prototype.rectBadgeTemplate);
				$ret.measure($.ig.LegendTemplates.prototype.legendItemBadgeMeasure);
				return $ret;
			}()));
		}
	}
	,
	_polygon0: null,
	_polyline0: null,
	_polygon1: null,
	_polyline1: null,
	line0: function () {
		return this._polyline0;
	}
	,
	line1: function () {
		return this._polyline1;
	}
	,
	polygon0: function () {
		return this._polygon0;
	}
	,
	polygon1: function () {
		return this._polygon1;
	}
	,
	clearSplineArea: function () {
		this._polygon0.data(null);
		this._polygon1.data(null);
		this._polyline0.data(null);
		this._polyline1.data(null);
		this.makeDirty();
	}
	,
	rasterizeSplineArea: function (count, buckets, useX0AsX1, bucketSize, resolution, terminatePolygon, unknownValuePlotting) {
		this.anchoredModel().lineRasterizer().isSortingAxis($.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.categoryModel().getXAxis()) !== null ? true : false);
		this.anchoredModel().lineRasterizer().rasterizePolygonPaths(this._polygon0, this._polyline0, this._polygon1, this._polyline1, count, buckets, useX0AsX1, bucketSize, resolution, terminatePolygon, unknownValuePlotting);
		this.makeDirty();
	}
	,
	__hitPolygon0: null,
	__hitPolyline0: null,
	__hitPolygon1: null,
	__hitPolyline1: null,
	setupHitAppearanceOverride: function () {
		$.ig.SplineSeriesBaseView.prototype.setupHitAppearanceOverride.call(this);
		this.__hitPolygon0.data(this._polygon0.data());
		this.__hitPolyline0.data(this._polyline0.data());
		this.__hitPolygon1.data(this._polygon1.data());
		this.__hitPolyline1.data(this._polyline1.data());
		var hitBrush = this.getHitBrush();
		this.__hitPolygon0.__fill = hitBrush;
		this.__hitPolygon0.__opacity = 1;
		this.__hitPolygon1.__fill = hitBrush;
		this.__hitPolygon1.__opacity = 1;
		this.__hitPolyline0.__stroke = hitBrush;
		this.__hitPolyline0.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this.__hitPolyline1.__stroke = hitBrush;
		this.__hitPolyline1.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
	}
	,
	renderOverride: function (context, isHitContext) {
		$.ig.SplineSeriesBaseView.prototype.renderOverride.call(this, context, isHitContext);
		if (isHitContext) {
			context.renderPath(this.__hitPolygon0);
			context.renderPath(this.__hitPolygon1);
			context.renderPath(this.__hitPolyline0);
			context.renderPath(this.__hitPolyline1);
		} else {
			context.renderPath(this._polygon0);
			context.renderPath(this._polygon1);
			context.renderPath(this._polyline0);
			context.renderPath(this._polyline1);
		}
	}
	,
	exportViewShapes: function (svd) {
		$.ig.SplineSeriesBaseView.prototype.exportViewShapes.call(this, svd);
		var lowerShape = new $.ig.PathVisualData(1, "lowerShape", this._polyline0);
		lowerShape.tags().add("Lower");
		var upperShape = new $.ig.PathVisualData(1, "upperShape", this._polyline1);
		upperShape.tags().add("Upper");
		upperShape.tags().add("Main");
		var translucent = new $.ig.PathVisualData(1, "translucentShape", this._polygon1);
		translucent.tags().add("Translucent");
		var fill = new $.ig.PathVisualData(1, "fillShape", this._polygon0);
		fill.tags().add("Fill");
		svd.shapes().add(lowerShape);
		svd.shapes().add(upperShape);
		svd.shapes().add(translucent);
		svd.shapes().add(fill);
	}
	,
	applyDropShadowDefaultSettings: function () {
		var color = new $.ig.Color();
		color.colorString("rgba(95,95,95,0.5)");
		this.model().shadowColor(color);
		this.model().shadowBlur(5);
		this.model().shadowOffsetX(1);
		this.model().shadowOffsetY(-3);
	}
	,
	$type: new $.ig.Type('SplineAreaSeriesView', $.ig.SplineSeriesBaseView.prototype.$type)
}, true);

$.ig.util.defType('AreaSeries', 'HorizontalAnchoredCategorySeries', {
	createView: function () {
		return new $.ig.AreaSeriesView(this);
	}
	,
	getDefaultTransitionInMode: function () {
		return $.ig.CategoryTransitionInMode.prototype.fromZero;
	}
	,
	onViewCreated: function (view) {
		$.ig.HorizontalAnchoredCategorySeries.prototype.onViewCreated.call(this, view);
		this.areaView(view);
	}
	,
	_areaView: null,
	areaView: function (value) {
		if (arguments.length === 1) {
			this._areaView = value;
			return value;
		} else {
			return this._areaView;
		}
	}
	,
	init: function () {
		$.ig.HorizontalAnchoredCategorySeries.prototype.init.call(this);
		this.defaultStyleKey($.ig.AreaSeries.prototype.$type);
	},
	preferredCategoryMode: function (axis) {
		return $.ig.CategoryMode.prototype.mode0;
	}
	,
	clearRendering: function (wipeClean, view) {
		$.ig.HorizontalAnchoredCategorySeries.prototype.clearRendering.call(this, wipeClean, view);
		var areaView = view;
		areaView.clearAreaLines();
	}
	,
	renderFrame: function (frame, view) {
		var $self = this;
		$.ig.HorizontalAnchoredCategorySeries.prototype.renderFrame.call(this, frame, view);
		var bucketSize = view.bucketCalculator()._bucketSize;
		var areaView = $.ig.util.cast($.ig.AreaSeriesView.prototype.$type, view);
		var buckets = frame._buckets;
		this._renderManager.initCategoryRenderSettings(this, this.shouldOverrideCategoryStyle(), this.cachedXAxis(), this.getCategoryItems.runOn(this), this.getBucketSize(view), this.getFirstBucket(view));
		var areStylesOverriden = false;
		var args = this._renderManager.categoryOverrideArgs();
		if (args != null) {
			areStylesOverriden = true;
		}
		if (areStylesOverriden) {
			var xParams = new $.ig.ScalerParams(view.windowRect(), view.viewport(), this.cachedXAxis().isInverted());
			this.performCategoryStyleOverride(buckets, -1, this.valueColumn().count(), this.cachedXAxis(), xParams, view.isThumbnailView());
		}
		var line0 = areaView.line0();
		var line1 = areaView.line1();
		var polygon0 = areaView.polygon0();
		var polygon1 = areaView.polygon1();
		this._renderManager.setCategoryShapeAppearance(line0, true, false, true, true);
		this._renderManager.setCategoryShapeAppearance(line1, true, false, true, true);
		this._renderManager.setCategoryShapeAppearance(polygon0, false, true, false, false);
		this._renderManager.setCategoryShapeAppearance(polygon1, false, true, false, false);
		if (view.checkFrameDirty(frame)) {
			areaView.rasterizeArea(buckets.count(), buckets, true, bucketSize, this.resolution(), function (p0, l0, p01, l1, f) { $self.terminatePolygon(p0, frame._buckets.count(), view); }, this.unknownValuePlotting());
			view.updateFrameVersion(frame);
		}
		var yAxis = this.getYAxis();
		polygon0.__opacity = this._renderManager._actualRenderOpacity * this.actualAreaFillOpacity();
		polygon1.__opacity = 0.5 * this._renderManager._actualRenderOpacity * this.actualAreaFillOpacity();
	}
	,
	unknownValuePlotting: function (value) {
		if (arguments.length === 1) {
			this.setValue($.ig.AreaSeries.prototype.unknownValuePlottingProperty, $.ig.UnknownValuePlotting.prototype.getBox(value));
			return value;
		} else {
			return $.ig.util.getEnumValue(this.getValue($.ig.AreaSeries.prototype.unknownValuePlottingProperty));
		}
	}
	,
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.HorizontalAnchoredCategorySeries.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.AreaSeries.prototype._unknownValuePlottingPropertyName:
				this.framePreparer().skipUnknowns(this.unknownValuePlotting() == $.ig.UnknownValuePlotting.prototype.linearInterpolate);
				this.renderSeries(false);
				this.notifyThumbnailAppearanceChanged();
				break;
		}
	}
	,
	$type: new $.ig.Type('AreaSeries', $.ig.HorizontalAnchoredCategorySeries.prototype.$type)
}, true);

$.ig.util.defType('AreaSeriesView', 'AnchoredCategorySeriesView', {
	_areaModel: null,
	areaModel: function (value) {
		if (arguments.length === 1) {
			this._areaModel = value;
			return value;
		} else {
			return this._areaModel;
		}
	}
	,
	init: function (model) {
		this._polygon0 = new $.ig.Path();
		this._polyline0 = new $.ig.Path();
		this._polygon1 = new $.ig.Path();
		this._polyline1 = new $.ig.Path();
		this.__hitPolygon0 = new $.ig.Path();
		this.__hitPolyline0 = new $.ig.Path();
		this.__hitPolygon1 = new $.ig.Path();
		this.__hitPolyline1 = new $.ig.Path();
		$.ig.AnchoredCategorySeriesView.prototype.init.call(this, model);
		this.areaModel(model);
	},
	onInit: function () {
		$.ig.AnchoredCategorySeriesView.prototype.onInit.call(this);
		if (!this.isThumbnailView()) {
			this.model().legendItemBadgeTemplate((function () {
				var $ret = new $.ig.DataTemplate();
				$ret.render($.ig.LegendTemplates.prototype.rectBadgeTemplate);
				$ret.measure($.ig.LegendTemplates.prototype.legendItemBadgeMeasure);
				return $ret;
			}()));
		}
	}
	,
	line0: function () {
		return this._polyline0;
	}
	,
	line1: function () {
		return this._polyline1;
	}
	,
	polygon0: function () {
		return this._polygon0;
	}
	,
	polygon1: function () {
		return this._polygon1;
	}
	,
	_polygon0: null,
	_polyline0: null,
	_polygon1: null,
	_polyline1: null,
	clearAreaLines: function () {
		this._polygon0.data(null);
		this._polygon1.data(null);
		this._polyline0.data(null);
		this._polyline1.data(null);
		this.makeDirty();
	}
	,
	rasterizeArea: function (count, buckets, useX0AsX1, bucketSize, resolution, terminatePolygon, unknownValuePlotting) {
		this.anchoredModel().lineRasterizer().isSortingAxis($.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.categoryModel().getXAxis()) !== null ? true : false);
		this.anchoredModel().lineRasterizer().rasterizePolygonPaths(this._polygon0, this._polyline0, this._polygon1, this._polyline1, count, buckets, useX0AsX1, bucketSize, resolution, terminatePolygon, unknownValuePlotting);
		this.makeDirty();
	}
	,
	__hitPolygon0: null,
	__hitPolyline0: null,
	__hitPolygon1: null,
	__hitPolyline1: null,
	setupHitAppearanceOverride: function () {
		$.ig.AnchoredCategorySeriesView.prototype.setupHitAppearanceOverride.call(this);
		this.__hitPolygon0.data(this._polygon0.data());
		this.__hitPolyline0.data(this._polyline0.data());
		this.__hitPolygon1.data(this._polygon1.data());
		this.__hitPolyline1.data(this._polyline1.data());
		var hitBrush = this.getHitBrush();
		this.__hitPolygon0.__fill = hitBrush;
		this.__hitPolygon0.__opacity = 1;
		this.__hitPolygon1.__fill = hitBrush;
		this.__hitPolygon1.__opacity = 1;
		this.__hitPolyline0.__stroke = hitBrush;
		this.__hitPolyline0.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this.__hitPolyline1.__stroke = hitBrush;
		this.__hitPolyline1.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
	}
	,
	renderOverride: function (context, isHitContext) {
		$.ig.AnchoredCategorySeriesView.prototype.renderOverride.call(this, context, isHitContext);
		if (isHitContext) {
			context.renderPath(this.__hitPolygon0);
			context.renderPath(this.__hitPolygon1);
			context.renderPath(this.__hitPolyline0);
			context.renderPath(this.__hitPolyline1);
		} else {
			context.renderPath(this._polygon0);
			context.renderPath(this._polygon1);
			context.renderPath(this._polyline0);
			context.renderPath(this._polyline1);
		}
	}
	,
	exportViewShapes: function (svd) {
		$.ig.AnchoredCategorySeriesView.prototype.exportViewShapes.call(this, svd);
		var lowerShape = new $.ig.PathVisualData(1, "lowerShape", this._polyline0);
		lowerShape.tags().add("Lower");
		var upperShape = new $.ig.PathVisualData(1, "upperShape", this._polyline1);
		upperShape.tags().add("Upper");
		upperShape.tags().add("Main");
		var translucent = new $.ig.PathVisualData(1, "translucentShape", this._polygon1);
		translucent.tags().add("Translucent");
		var fill = new $.ig.PathVisualData(1, "fillShape", this._polygon0);
		fill.tags().add("Fill");
		svd.shapes().add(lowerShape);
		svd.shapes().add(upperShape);
		svd.shapes().add(translucent);
		svd.shapes().add(fill);
	}
	,
	applyDropShadowDefaultSettings: function () {
		var color = new $.ig.Color();
		color.colorString("rgba(95,95,95,0.5)");
		this.model().shadowColor(color);
		this.model().shadowBlur(5);
		this.model().shadowOffsetX(1);
		this.model().shadowOffsetY(-3);
	}
	,
	$type: new $.ig.Type('AreaSeriesView', $.ig.AnchoredCategorySeriesView.prototype.$type)
}, true);

$.ig.util.defType('ColumnSeries', 'HorizontalAnchoredCategorySeries', {
	createView: function () {
		return new $.ig.ColumnSeriesView(this);
	}
	,
	_columnView: null,
	columnView: function (value) {
		if (arguments.length === 1) {
			this._columnView = value;
			return value;
		} else {
			return this._columnView;
		}
	}
	,
	onViewCreated: function (view) {
		$.ig.HorizontalAnchoredCategorySeries.prototype.onViewCreated.call(this, view);
		this.columnView(view);
	}
	,
	getDefaultTransitionInMode: function () {
		return $.ig.CategoryTransitionInMode.prototype.fromZero;
	}
	,
	init: function () {
		$.ig.HorizontalAnchoredCategorySeries.prototype.init.call(this);
		this.defaultStyleKey($.ig.ColumnSeries.prototype.$type);
	},
	radiusX: function (value) {
		if (arguments.length === 1) {
			this.setValue($.ig.ColumnSeries.prototype.radiusXProperty, value);
			return value;
		} else {
			return this.getValue($.ig.ColumnSeries.prototype.radiusXProperty);
		}
	}
	,
	radiusY: function (value) {
		if (arguments.length === 1) {
			this.setValue($.ig.ColumnSeries.prototype.radiusYProperty, value);
			return value;
		} else {
			return this.getValue($.ig.ColumnSeries.prototype.radiusYProperty);
		}
	}
	,
	hasIndividualElements: function () {
		return true;
	}
	,
	preferredCategoryMode: function (axis) {
		return $.ig.CategoryMode.prototype.mode2;
	}
	,
	clearRendering: function (wipeClean, view) {
		$.ig.HorizontalAnchoredCategorySeries.prototype.clearRendering.call(this, wipeClean, view);
		var columnView = view;
		if (wipeClean && columnView.columns() != null) {
			columnView.columns().count(0);
		}
	}
	,
	getItemSpan: function () {
		return this.cachedXAxis().getGroupSize(this.view().windowRect(), this.view().viewport());
	}
	,
	renderFrame: function (frame, view) {
		$.ig.HorizontalAnchoredCategorySeries.prototype.renderFrame.call(this, frame, view);
		var buckets = frame._buckets;
		if (!view.ready()) {
			return;
		}
		var windowRect = view.windowRect();
		var viewportRect = view.viewport();
		var yParams = new $.ig.ScalerParams(windowRect, viewportRect, this.cachedYAxis().isInverted());
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, this.cachedXAxis().isInverted());
		var yscale = this.cachedYAxis();
		var zero = yscale.getScaledValue(yscale.referenceValue(), yParams);
		var groupWidth = this.cachedXAxis().getGroupSize(windowRect, viewportRect);
		var xAxis = this.cachedXAxis();
		var columnView = view;
		if ($.ig.util.isNaN(groupWidth) || Number.isInfinity(groupWidth)) {
			columnView.columns().count(0);
			return;
		}
		this._renderManager.initCategoryRenderSettings(this, this.shouldOverrideCategoryStyle(), this.cachedXAxis(), this.getCategoryItems.runOn(this), this.getBucketSize(view), this.getFirstBucket(view));
		this._renderManager._initialRenderRadiusX = this.radiusX();
		this._renderManager._initialRenderRadiusY = this.radiusY();
		this._renderManager._actualRenderRadiusX = this.radiusX();
		this._renderManager._actualRenderRadiusY = this.radiusY();
		var areStylesOverriden = false;
		var args = this._renderManager.categoryOverrideArgs();
		if (args != null) {
			areStylesOverriden = true;
		}
		var isSorting = this.cachedXAxis().isSorting();
		var valueCount = this.valueColumn().count();
		var bucketSize = this.getBucketSize(view);
		var bucketCount = 0;
		for (var i = 0; i < buckets.count(); ++i) {
			var left = buckets.__inner[i][0] - 0.5 * groupWidth;
			var top = buckets.__inner[i][1];
			var bottom = zero;
			top = Math.max(top, -100);
			bottom = Math.min(bottom, viewportRect.bottom() + 100);
			var height = Math.abs(bottom - top);
			if (Number.isInfinity(height)) {
				continue;
			}
			var column = columnView.columns().item(bucketCount);
			bucketCount++;
			column.width(groupWidth);
			column.height(height);
			if (areStylesOverriden) {
				this.performCategoryStyleOverride(buckets, i, valueCount, xAxis, xParams, view.isThumbnailView());
			}
			if (column.dataContext() != null) {
				var dc = column.dataContext();
				if (bucketSize == 1) {
					var columnIndex = this._renderManager.getBucketBounds(valueCount, i)[0];
					if (columnIndex >= 0 && columnIndex < this.fastItemsSource().count()) {
						dc.item(this.fastItemsSource().item(columnIndex));
					}
				} else {
					dc.item(null);
				}
			}
			this._renderManager.setCategoryShapeAppearance(column, false, false, false, false);
			column.radiusX(this._renderManager._actualRenderRadiusX);
			column.radiusY(this._renderManager._actualRenderRadiusY);
			columnView.positionRectangle(column, left, Math.min(bottom, top));
		}
		columnView.columns().count(bucketCount);
		view.updateFrameVersion(frame);
	}
	,
	$type: new $.ig.Type('ColumnSeries', $.ig.HorizontalAnchoredCategorySeries.prototype.$type)
}, true);

$.ig.util.defType('ColumnSeriesView', 'AnchoredCategorySeriesView', {
	onInit: function () {
		$.ig.AnchoredCategorySeriesView.prototype.onInit.call(this);
		this.visibleColumns(new $.ig.List$1($.ig.Rectangle.prototype.$type, 0));
		if (!this.isThumbnailView()) {
			this.model().resolution(4);
			this.model().legendItemBadgeTemplate((function () {
				var $ret = new $.ig.DataTemplate();
				$ret.render($.ig.LegendTemplates.prototype.rectBadgeTemplate);
				$ret.measure($.ig.LegendTemplates.prototype.legendItemBadgeMeasure);
				return $ret;
			}()));
		}
	}
	,
	_columnModel: null,
	columnModel: function (value) {
		if (arguments.length === 1) {
			this._columnModel = value;
			return value;
		} else {
			return this._columnModel;
		}
	}
	,
	init: function (model) {
		var $self = this;
		this.__hitItem = new $.ig.Rectangle();
		$.ig.AnchoredCategorySeriesView.prototype.init.call(this, model);
		this.columnModel(model);
		this.columns((function () {
			var $ret = new $.ig.Pool$1($.ig.Rectangle.prototype.$type);
			$ret.create($self.columnCreate.runOn($self));
			$ret.activate($self.columnActivate.runOn($self));
			$ret.disactivate($self.columnDisactivate.runOn($self));
			$ret.destroy($self.columnDestroy.runOn($self));
			return $ret;
		}()));
	},
	columnCreate: function () {
		var column = new $.ig.Rectangle();
		this.visibleColumns().add(column);
		column.__visibility = $.ig.Visibility.prototype.collapsed;
		return column;
	}
	,
	_visibleColumns: null,
	visibleColumns: function (value) {
		if (arguments.length === 1) {
			this._visibleColumns = value;
			return value;
		} else {
			return this._visibleColumns;
		}
	}
	,
	columnActivate: function (column) {
		column.__visibility = $.ig.Visibility.prototype.visible;
	}
	,
	columnDisactivate: function (column) {
		column.__visibility = $.ig.Visibility.prototype.collapsed;
	}
	,
	columnDestroy: function (column) {
		this.visibleColumns().remove(column);
	}
	,
	positionRectangle: function (column, left, top) {
		if (!this.isDirty()) {
			this.makeDirty();
		}
		column.canvasTop(top);
		column.canvasLeft(left);
	}
	,
	getItem: function (index) {
		return this.visibleColumns().__inner[index];
	}
	,
	__hitItem: null,
	getHitItem: function (index) {
		var item = this.visibleColumns().__inner[index];
		this.__hitItem.__visibility = item.__visibility;
		this.__hitItem.canvasLeft(item.canvasLeft());
		this.__hitItem.canvasTop(item.canvasTop());
		this.__hitItem.width(item.width());
		this.__hitItem.height(item.height());
		var hitBrush = this.getHitBrush1(index);
		this.__hitItem.__fill = hitBrush;
		this.__hitItem.__stroke = hitBrush;
		this.__hitItem.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		return this.__hitItem;
	}
	,
	renderOverride: function (context, isHitContext) {
		$.ig.AnchoredCategorySeriesView.prototype.renderOverride.call(this, context, isHitContext);
		var doGradients = false;
		if (context.shouldRender()) {
			for (var i = 0; i < this.visibleColumns().count(); i++) {
				var column = this.getCurrentItem(i, isHitContext);
				this.setupItemAppearance(column, i, isHitContext);
				context.renderRectangle(column);
			}
		}
	}
	,
	_columns: null,
	columns: function (value) {
		if (arguments.length === 1) {
			this._columns = value;
			return value;
		} else {
			return this._columns;
		}
	}
	,
	exportViewShapes: function (svd) {
		$.ig.AnchoredCategorySeriesView.prototype.exportViewShapes.call(this, svd);
		var i = 0;
		var toSort = new $.ig.List$1($.ig.Rectangle.prototype.$type, 0);
		var en = this.columns().active().getEnumerator();
		while (en.moveNext()) {
			var column = en.current();
			toSort.add(column);
		}
		toSort.sort2(function (c1, c2) {
			if (c1.canvasLeft() < c2.canvasLeft()) {
				return -1;
			} else if (c1.canvasLeft() > c2.canvasLeft()) {
				return 1;
			} else {
				return 0;
			}
		});
		var en1 = toSort.getEnumerator();
		while (en1.moveNext()) {
			var column1 = en1.current();
			var rvd = new $.ig.RectangleVisualData(1, "column" + i, column1);
			rvd.tags().add("Main");
			rvd.tags().add("Fill");
			svd.shapes().add(rvd);
		}
		i++;
	}
	,
	$type: new $.ig.Type('ColumnSeriesView', $.ig.AnchoredCategorySeriesView.prototype.$type)
}, true);

$.ig.util.defType('LineSeries', 'HorizontalAnchoredCategorySeries', {
	createView: function () {
		return new $.ig.LineSeriesView(this);
	}
	,
	_lineView: null,
	lineView: function (value) {
		if (arguments.length === 1) {
			this._lineView = value;
			return value;
		} else {
			return this._lineView;
		}
	}
	,
	onViewCreated: function (view) {
		$.ig.HorizontalAnchoredCategorySeries.prototype.onViewCreated.call(this, view);
		this.lineView(view);
	}
	,
	init: function () {
		$.ig.HorizontalAnchoredCategorySeries.prototype.init.call(this);
		this.defaultStyleKey($.ig.LineSeries.prototype.$type);
	},
	preferredCategoryMode: function (axis) {
		return $.ig.CategoryMode.prototype.mode0;
	}
	,
	clearRendering: function (wipeClean, view) {
		$.ig.HorizontalAnchoredCategorySeries.prototype.clearRendering.call(this, wipeClean, view);
		var lineView = view;
		lineView.clearLine();
	}
	,
	renderFrame: function (frame, view) {
		$.ig.HorizontalAnchoredCategorySeries.prototype.renderFrame.call(this, frame, view);
		var bucketSize = view.bucketCalculator()._bucketSize;
		var lineView = $.ig.util.cast($.ig.LineSeriesView.prototype.$type, view);
		var buckets = frame._buckets;
		this._renderManager.initCategoryRenderSettings(this, this.shouldOverrideCategoryStyle(), this.cachedXAxis(), this.getCategoryItems.runOn(this), this.getBucketSize(view), this.getFirstBucket(view));
		var areStylesOverriden = false;
		var args = this._renderManager.categoryOverrideArgs();
		if (args != null) {
			areStylesOverriden = true;
		}
		if (areStylesOverriden) {
			var xParams = new $.ig.ScalerParams(view.windowRect(), view.viewport(), this.cachedXAxis().isInverted());
			this.performCategoryStyleOverride(buckets, -1, this.valueColumn().count(), this.cachedXAxis(), xParams, view.isThumbnailView());
		}
		var line0 = lineView.line0();
		var line1 = lineView.line1();
		var fillArea = lineView.fillArea();
		this._renderManager.setCategoryShapeAppearance(line0, true, false, true, false);
		this._renderManager.setCategoryShapeAppearance(line1, true, false, true, false);
		this._renderManager.setCategoryShapeAppearance(fillArea, false, true, false, false);
		fillArea.__opacity = 0.75 * this._renderManager._actualRenderOpacity;
		if (view.checkFrameDirty(frame)) {
			lineView.rasterizeLine(buckets.count(), buckets, true, this.unknownValuePlotting(), this.getLineClipper(buckets, buckets.count() - 1, view.viewport(), view.windowRect()), bucketSize, this.resolution());
			view.updateFrameVersion(frame);
		}
	}
	,
	unknownValuePlotting: function (value) {
		if (arguments.length === 1) {
			this.setValue($.ig.LineSeries.prototype.unknownValuePlottingProperty, $.ig.UnknownValuePlotting.prototype.getBox(value));
			return value;
		} else {
			return $.ig.util.getEnumValue(this.getValue($.ig.LineSeries.prototype.unknownValuePlottingProperty));
		}
	}
	,
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.HorizontalAnchoredCategorySeries.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.LineSeries.prototype._unknownValuePlottingPropertyName:
				this.framePreparer().skipUnknowns(this.unknownValuePlotting() == $.ig.UnknownValuePlotting.prototype.linearInterpolate);
				this.renderSeries(false);
				this.notifyThumbnailAppearanceChanged();
				break;
		}
	}
	,
	$type: new $.ig.Type('LineSeries', $.ig.HorizontalAnchoredCategorySeries.prototype.$type)
}, true);

$.ig.util.defType('LineSeriesView', 'AnchoredCategorySeriesView', {
	_lineModel: null,
	lineModel: function (value) {
		if (arguments.length === 1) {
			this._lineModel = value;
			return value;
		} else {
			return this._lineModel;
		}
	}
	,
	init: function (model) {
		this._polyline0 = new $.ig.Path();
		this._polygon01 = new $.ig.Path();
		this._polyline1 = new $.ig.Path();
		this.__hitPolyline1 = new $.ig.Path();
		this.__hitPolyline0 = new $.ig.Path();
		this.__hitPolygon01 = new $.ig.Path();
		$.ig.AnchoredCategorySeriesView.prototype.init.call(this, model);
		this.lineModel(model);
	},
	_polyline0: null,
	_polygon01: null,
	_polyline1: null,
	line0: function () {
		return this._polyline0;
	}
	,
	line1: function () {
		return this._polyline1;
	}
	,
	fillArea: function () {
		return this._polygon01;
	}
	,
	clearLine: function () {
		this._polygon01.data(null);
		this._polyline0.data(null);
		this._polyline1.data(null);
		this.makeDirty();
	}
	,
	rasterizeLine: function (bucketCount, buckets, useX0AsX1, unknownValuePlotting, clipper, bucketSize, resolution) {
		this.lineModel().lineRasterizer().isSortingAxis($.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.categoryModel().getXAxis()) !== null ? true : false);
		this.lineModel().lineRasterizer().rasterizePolylinePaths(this._polyline0, this._polygon01, this._polyline1, bucketCount, buckets, useX0AsX1, unknownValuePlotting, clipper, bucketSize, resolution);
		this.makeDirty();
	}
	,
	setupAppearanceOverride: function () {
		$.ig.AnchoredCategorySeriesView.prototype.setupAppearanceOverride.call(this);
	}
	,
	__hitPolyline1: null,
	__hitPolyline0: null,
	__hitPolygon01: null,
	setupHitAppearanceOverride: function () {
		$.ig.AnchoredCategorySeriesView.prototype.setupHitAppearanceOverride.call(this);
		this.__hitPolyline0.data(this._polyline0.data());
		this.__hitPolyline1.data(this._polyline1.data());
		this.__hitPolygon01.data(this._polygon01.data());
		var hitBrush = this.getHitBrush();
		this.__hitPolyline0.__stroke = hitBrush;
		this.__hitPolyline0.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this.__hitPolyline1.__stroke = hitBrush;
		this.__hitPolyline1.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this.__hitPolygon01.__fill = hitBrush;
		this.__hitPolygon01.__opacity = 1;
	}
	,
	renderOverride: function (context, isHitContext) {
		$.ig.AnchoredCategorySeriesView.prototype.renderOverride.call(this, context, isHitContext);
		if (context.shouldRender()) {
			if (isHitContext) {
				context.renderPath(this.__hitPolygon01);
				context.renderPath(this.__hitPolyline0);
				context.renderPath(this.__hitPolyline1);
			} else {
				context.renderPath(this._polygon01);
				context.renderPath(this._polyline0);
				context.renderPath(this._polyline1);
			}
		}
	}
	,
	exportViewShapes: function (svd) {
		$.ig.AnchoredCategorySeriesView.prototype.exportViewShapes.call(this, svd);
		var lowerShape = new $.ig.PathVisualData(1, "lowerShape", this._polyline0);
		lowerShape.tags().add("Lower");
		lowerShape.tags().add("Main");
		var upperShape = new $.ig.PathVisualData(1, "upperShape", this._polyline1);
		upperShape.tags().add("Upper");
		var translucent = new $.ig.PathVisualData(1, "translucentShape", this._polygon01);
		translucent.tags().add("Translucent");
		svd.shapes().add(lowerShape);
		svd.shapes().add(upperShape);
		svd.shapes().add(translucent);
	}
	,
	applyDropShadowDefaultSettings: function () {
		var color = new $.ig.Color();
		color.colorString("rgba(95,95,95,0.5)");
		this.model().shadowColor(color);
		this.model().shadowBlur(3);
		this.model().shadowOffsetX(1);
		this.model().shadowOffsetY(4);
		this.model().useSingleShadow(false);
	}
	,
	$type: new $.ig.Type('LineSeriesView', $.ig.AnchoredCategorySeriesView.prototype.$type)
}, true);

$.ig.util.defType('SplineAreaSeries', 'SplineSeriesBase', {
	createView: function () {
		return new $.ig.SplineAreaSeriesView(this);
	}
	,
	getDefaultTransitionInMode: function () {
		return $.ig.CategoryTransitionInMode.prototype.fromZero;
	}
	,
	onViewCreated: function (view) {
		$.ig.SplineSeriesBase.prototype.onViewCreated.call(this, view);
		this.splineAreaView(view);
	}
	,
	_splineAreaView: null,
	splineAreaView: function (value) {
		if (arguments.length === 1) {
			this._splineAreaView = value;
			return value;
		} else {
			return this._splineAreaView;
		}
	}
	,
	init: function () {
		$.ig.SplineSeriesBase.prototype.init.call(this);
		this.defaultStyleKey($.ig.SplineAreaSeries.prototype.$type);
	},
	preferredCategoryMode: function (axis) {
		return $.ig.CategoryMode.prototype.mode0;
	}
	,
	clearRendering: function (wipeClean, view) {
		$.ig.SplineSeriesBase.prototype.clearRendering.call(this, wipeClean, view);
		var splineAreaView = view;
		splineAreaView.clearSplineArea();
	}
	,
	renderFrame: function (frame, view) {
		var $self = this;
		$.ig.SplineSeriesBase.prototype.renderFrame.call(this, frame, view);
		var bucketSize = this.categoryView().bucketCalculator()._bucketSize;
		var splineAreaView = $.ig.util.cast($.ig.SplineAreaSeriesView.prototype.$type, view);
		var buckets = frame._buckets;
		this._renderManager.initCategoryRenderSettings(this, this.shouldOverrideCategoryStyle(), this.cachedXAxis(), this.getCategoryItems.runOn(this), this.getBucketSize(view), this.getFirstBucket(view));
		var areStylesOverriden = false;
		var args = this._renderManager.categoryOverrideArgs();
		if (args != null) {
			areStylesOverriden = true;
		}
		if (areStylesOverriden) {
			var xParams = new $.ig.ScalerParams(view.windowRect(), view.viewport(), this.cachedXAxis().isInverted());
			this.performCategoryStyleOverride(buckets, -1, this.valueColumn().count(), this.cachedXAxis(), xParams, view.isThumbnailView());
		}
		var line0 = splineAreaView.line0();
		var line1 = splineAreaView.line1();
		var polygon0 = splineAreaView.polygon0();
		var polygon1 = splineAreaView.polygon1();
		this._renderManager.setCategoryShapeAppearance(line0, true, false, true, true);
		this._renderManager.setCategoryShapeAppearance(line1, true, false, true, true);
		this._renderManager.setCategoryShapeAppearance(polygon0, false, true, false, false);
		this._renderManager.setCategoryShapeAppearance(polygon1, false, true, false, false);
		polygon0.__opacity = this._renderManager._actualRenderOpacity * this.actualAreaFillOpacity();
		polygon1.__opacity = 0.5 * this._renderManager._actualRenderOpacity * this.actualAreaFillOpacity();
		if (view.checkFrameDirty(frame)) {
			splineAreaView.rasterizeSplineArea(frame._buckets.count(), buckets, true, bucketSize, this.resolution(), function (p0, l0, p1, l1, f) { $self.terminatePolygon(p0, frame._buckets.count(), view); }, $.ig.UnknownValuePlotting.prototype.dontPlot);
			view.updateFrameVersion(frame);
		}
		var yAxis = this.getYAxis();
	}
	,
	$type: new $.ig.Type('SplineAreaSeries', $.ig.SplineSeriesBase.prototype.$type)
}, true);

$.ig.util.defType('SplineSeries', 'SplineSeriesBase', {
	createView: function () {
		return new $.ig.SplineSeriesView(this);
	}
	,
	onViewCreated: function (view) {
		$.ig.SplineSeriesBase.prototype.onViewCreated.call(this, view);
		this.splineView(view);
	}
	,
	_splineView: null,
	splineView: function (value) {
		if (arguments.length === 1) {
			this._splineView = value;
			return value;
		} else {
			return this._splineView;
		}
	}
	,
	init: function () {
		$.ig.SplineSeriesBase.prototype.init.call(this);
		this.defaultStyleKey($.ig.SplineSeries.prototype.$type);
	},
	preferredCategoryMode: function (axis) {
		return $.ig.CategoryMode.prototype.mode0;
	}
	,
	clearRendering: function (wipeClean, view) {
		$.ig.SplineSeriesBase.prototype.clearRendering.call(this, wipeClean, view);
		var splineView = view;
		splineView.clearSplineLines();
	}
	,
	renderFrame: function (frame, view) {
		$.ig.SplineSeriesBase.prototype.renderFrame.call(this, frame, view);
		var categoryView = view;
		var bucketSize = categoryView.bucketCalculator()._bucketSize;
		var splineView = $.ig.util.cast($.ig.SplineSeriesView.prototype.$type, view);
		var buckets = frame._buckets;
		this._renderManager.initCategoryRenderSettings(this, this.shouldOverrideCategoryStyle(), this.cachedXAxis(), this.getCategoryItems.runOn(this), this.getBucketSize(view), this.getFirstBucket(view));
		var areStylesOverriden = false;
		var args = this._renderManager.categoryOverrideArgs();
		if (args != null) {
			areStylesOverriden = true;
		}
		if (areStylesOverriden) {
			var xParams = new $.ig.ScalerParams(view.windowRect(), view.viewport(), this.cachedXAxis().isInverted());
			this.performCategoryStyleOverride(buckets, -1, this.valueColumn().count(), this.cachedXAxis(), xParams, view.isThumbnailView());
		}
		var line0 = splineView.line0();
		var line1 = splineView.line1();
		var fillArea = splineView.fillArea();
		this._renderManager.setCategoryShapeAppearance(line0, true, false, true, false);
		this._renderManager.setCategoryShapeAppearance(line1, true, false, true, false);
		this._renderManager.setCategoryShapeAppearance(fillArea, false, true, false, false);
		fillArea.__opacity = 0.75 * this._renderManager._actualRenderOpacity;
		if (view.checkFrameDirty(frame)) {
			splineView.rasterizeSpline(buckets.count(), buckets, true, $.ig.UnknownValuePlotting.prototype.dontPlot, this.getLineClipper(buckets, buckets.count() - 1, view.viewport(), view.windowRect()), bucketSize, this.resolution());
			view.updateFrameVersion(frame);
		}
	}
	,
	$type: new $.ig.Type('SplineSeries', $.ig.SplineSeriesBase.prototype.$type)
}, true);

$.ig.util.defType('SplineSeriesView', 'SplineSeriesBaseView', {
	_splineModel: null,
	splineModel: function (value) {
		if (arguments.length === 1) {
			this._splineModel = value;
			return value;
		} else {
			return this._splineModel;
		}
	}
	,
	init: function (model) {
		this._polyline0 = new $.ig.Path();
		this._polygon01 = new $.ig.Path();
		this._polyline1 = new $.ig.Path();
		this.__hitPolyline1 = new $.ig.Path();
		this.__hitPolyline0 = new $.ig.Path();
		this.__hitPolygon01 = new $.ig.Path();
		$.ig.SplineSeriesBaseView.prototype.init.call(this, model);
		this.splineModel(model);
	},
	_polyline0: null,
	_polygon01: null,
	_polyline1: null,
	line0: function () {
		return this._polyline0;
	}
	,
	line1: function () {
		return this._polyline1;
	}
	,
	fillArea: function () {
		return this._polygon01;
	}
	,
	clearSplineLines: function () {
		this._polygon01.data(null);
		this._polyline0.data(null);
		this._polyline1.data(null);
		this.makeDirty();
	}
	,
	rasterizeSpline: function (count, buckets, useX0AsX1, unknownValuePlotting, clipper, bucketSize, resolution) {
		this.anchoredModel().lineRasterizer().isSortingAxis($.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.categoryModel().getXAxis()) !== null ? true : false);
		this.anchoredModel().lineRasterizer().rasterizePolylinePaths(this._polyline0, this._polygon01, this._polyline1, count, buckets, useX0AsX1, unknownValuePlotting, clipper, bucketSize, resolution);
		this.makeDirty();
	}
	,
	__hitPolyline1: null,
	__hitPolyline0: null,
	__hitPolygon01: null,
	setupHitAppearanceOverride: function () {
		$.ig.SplineSeriesBaseView.prototype.setupHitAppearanceOverride.call(this);
		this.__hitPolyline0.data(this._polyline0.data());
		this.__hitPolyline1.data(this._polyline1.data());
		this.__hitPolygon01.data(this._polygon01.data());
		var hitBrush = this.getHitBrush();
		this.__hitPolyline0.__stroke = hitBrush;
		this.__hitPolyline0.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this.__hitPolyline1.__stroke = hitBrush;
		this.__hitPolyline1.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this.__hitPolygon01.__fill = hitBrush;
		this.__hitPolygon01.__opacity = 1;
	}
	,
	renderOverride: function (context, isHitContext) {
		$.ig.SplineSeriesBaseView.prototype.renderOverride.call(this, context, isHitContext);
		if (context.shouldRender()) {
			if (isHitContext) {
				context.renderPath(this.__hitPolygon01);
				context.renderPath(this.__hitPolyline0);
				context.renderPath(this.__hitPolyline1);
			} else {
				context.renderPath(this._polygon01);
				context.renderPath(this._polyline0);
				context.renderPath(this._polyline1);
			}
		}
	}
	,
	exportViewShapes: function (svd) {
		$.ig.SplineSeriesBaseView.prototype.exportViewShapes.call(this, svd);
		var lowerShape = new $.ig.PathVisualData(1, "lowerShape", this._polyline0);
		lowerShape.tags().add("Lower");
		lowerShape.tags().add("Main");
		var upperShape = new $.ig.PathVisualData(1, "upperShape", this._polyline1);
		upperShape.tags().add("Upper");
		var translucent = new $.ig.PathVisualData(1, "translucentShape", this._polygon01);
		translucent.tags().add("Translucent");
		svd.shapes().add(lowerShape);
		svd.shapes().add(upperShape);
		svd.shapes().add(translucent);
	}
	,
	$type: new $.ig.Type('SplineSeriesView', $.ig.SplineSeriesBaseView.prototype.$type)
}, true);

$.ig.util.defType('StepAreaSeries', 'HorizontalAnchoredCategorySeries', {
	createView: function () {
		return new $.ig.StepAreaSeriesView(this);
	}
	,
	onViewCreated: function (view) {
		$.ig.HorizontalAnchoredCategorySeries.prototype.onViewCreated.call(this, view);
		this.stepAreaView(view);
	}
	,
	_stepAreaView: null,
	stepAreaView: function (value) {
		if (arguments.length === 1) {
			this._stepAreaView = value;
			return value;
		} else {
			return this._stepAreaView;
		}
	}
	,
	init: function () {
		$.ig.HorizontalAnchoredCategorySeries.prototype.init.call(this);
		this.defaultStyleKey($.ig.StepAreaSeries.prototype.$type);
	},
	preferredCategoryMode: function (axis) {
		return $.ig.CategoryMode.prototype.mode1;
	}
	,
	clearRendering: function (wipeClean, view) {
		$.ig.HorizontalAnchoredCategorySeries.prototype.clearRendering.call(this, wipeClean, view);
		var stepAreaView = view;
		stepAreaView.clearStepArea();
	}
	,
	getXValue: function (i, fromEnd, frame, width, isSorting) {
		if (fromEnd) {
			if (isSorting) {
				if ((i & 1) == 0 || (($.ig.intDivide(i, 2)) + 1) >= frame._buckets.count()) {
					return frame._buckets.__inner[($.ig.intDivide(i, 2))][0];
				}
				return frame._buckets.__inner[($.ig.intDivide(i, 2)) + 1][0];
			}
			return frame._buckets.__inner[($.ig.intDivide(i, 2))][0] + ((i & 1) == 1 ? -width : width);
		}
		if (isSorting) {
			if ((i & 1) == 0 || (($.ig.intDivide(i, 2)) + 1) >= frame._buckets.count()) {
				return frame._buckets.__inner[($.ig.intDivide(i, 2))][0];
			}
			return frame._buckets.__inner[($.ig.intDivide(i, 2)) + 1][0];
		}
		return frame._buckets.__inner[($.ig.intDivide(i, 2))][0] + ((i & 1) == 0 ? -width : width);
	}
	,
	getDefaultTransitionInMode: function () {
		return $.ig.CategoryTransitionInMode.prototype.fromZero;
	}
	,
	renderFrame: function (frame, view) {
		var $self = this;
		$.ig.HorizontalAnchoredCategorySeries.prototype.renderFrame.call(this, frame, view);
		var windowRect = view.windowRect();
		var viewportRect = view.viewport();
		var isSorting = $.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.cachedXAxis()) != null;
		var width = this.cachedXAxis() != null ? 0.5 * this.cachedXAxis().getCategorySize(windowRect, viewportRect) : 0;
		if (this.cachedXAxis() != null && this.cachedXAxis().isInverted()) {
			width = -width;
		}
		var count = frame._buckets.count() * 2;
		var buckets = new $.ig.List$1(Array, 2, count);
		this._renderManager.initCategoryRenderSettings(this, this.shouldOverrideCategoryStyle(), this.cachedXAxis(), this.getCategoryItems.runOn(this), this.getBucketSize(view), this.getFirstBucket(view));
		var areStylesOverriden = false;
		var args = this._renderManager.categoryOverrideArgs();
		if (args != null) {
			areStylesOverriden = true;
		}
		for (var i = 0; i < count; i++) {
			var bucket = new Array(4);
			bucket[0] = this.getXValue(i, false, frame, width, isSorting);
			bucket[1] = frame._buckets.__inner[($.ig.intDivide(i, 2))][1];
			bucket[2] = this.getXValue(i, true, frame, width, isSorting);
			bucket[3] = frame._buckets.__inner[($.ig.intDivide(i, 2))][2];
			buckets.add(bucket);
		}
		var bucketSize = this.categoryView().bucketCalculator()._bucketSize;
		if (areStylesOverriden) {
			var xParams = new $.ig.ScalerParams(view.windowRect(), view.viewport(), this.cachedXAxis().isInverted());
			this.performCategoryStyleOverride(buckets, -1, this.valueColumn().count(), this.cachedXAxis(), xParams, view.isThumbnailView());
		}
		var stepAreaView = $.ig.util.cast($.ig.StepAreaSeriesView.prototype.$type, view);
		var line0 = stepAreaView.polyline0();
		var line1 = stepAreaView.polyline1();
		var polygon0 = stepAreaView.polygon0();
		var polygon1 = stepAreaView.polygon1();
		this._renderManager.setCategoryShapeAppearance(line0, true, false, true, true);
		this._renderManager.setCategoryShapeAppearance(line1, true, false, true, true);
		this._renderManager.setCategoryShapeAppearance(polygon0, false, true, false, false);
		this._renderManager.setCategoryShapeAppearance(polygon1, false, true, false, false);
		if (view.checkFrameDirty(frame)) {
			stepAreaView.rasterizeStepArea(count, buckets, false, bucketSize, this.resolution(), function (p0, l0, p01, l1, f) { $self.terminatePolygon(p0, 2 * frame._buckets.count(), view); }, $.ig.UnknownValuePlotting.prototype.dontPlot);
			view.updateFrameVersion(frame);
		}
		var yAxis = this.getYAxis();
		stepAreaView.polygon0().__opacity = this.actualAreaFillOpacity();
		stepAreaView.polygon1().__opacity = 0.5 * this.actualAreaFillOpacity();
	}
	,
	currentCategoryMode: function () {
		if (this.cachedXAxis() != null && $.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.cachedXAxis()) !== null) {
			this.cachedXAxis().categoryMode($.ig.CategoryMode.prototype.mode0);
			return $.ig.CategoryMode.prototype.mode0;
		}
		return $.ig.CategoryMode.prototype.mode1;
	}
	,
	$type: new $.ig.Type('StepAreaSeries', $.ig.HorizontalAnchoredCategorySeries.prototype.$type, [$.ig.IIsCategoryBased.prototype.$type])
}, true);

$.ig.util.defType('StepAreaSeriesView', 'AnchoredCategorySeriesView', {
	_stepAreaModel: null,
	stepAreaModel: function (value) {
		if (arguments.length === 1) {
			this._stepAreaModel = value;
			return value;
		} else {
			return this._stepAreaModel;
		}
	}
	,
	init: function (model) {
		this._polygon0 = new $.ig.Path();
		this._polyline0 = new $.ig.Path();
		this._polygon1 = new $.ig.Path();
		this._polyline1 = new $.ig.Path();
		this.__hitPolygon0 = new $.ig.Path();
		this.__hitPolyline0 = new $.ig.Path();
		this.__hitPolygon1 = new $.ig.Path();
		this.__hitPolyline1 = new $.ig.Path();
		$.ig.AnchoredCategorySeriesView.prototype.init.call(this, model);
		this.stepAreaModel(model);
	},
	onInit: function () {
		$.ig.AnchoredCategorySeriesView.prototype.onInit.call(this);
		if (!this.isThumbnailView()) {
			this.model().legendItemBadgeTemplate((function () {
				var $ret = new $.ig.DataTemplate();
				$ret.render($.ig.LegendTemplates.prototype.rectBadgeTemplate);
				$ret.measure($.ig.LegendTemplates.prototype.legendItemBadgeMeasure);
				return $ret;
			}()));
		}
	}
	,
	_polygon0: null,
	_polyline0: null,
	_polygon1: null,
	_polyline1: null,
	polygon0: function () {
		return this._polygon0;
	}
	,
	polyline0: function () {
		return this._polyline0;
	}
	,
	polygon1: function () {
		return this._polygon1;
	}
	,
	polyline1: function () {
		return this._polyline1;
	}
	,
	clearStepArea: function () {
		this._polygon0.data(null);
		this._polygon1.data(null);
		this._polyline0.data(null);
		this._polyline1.data(null);
		this.makeDirty();
	}
	,
	rasterizeStepArea: function (count, buckets, useX0AsX1, bucketSize, resolution, terminatePolygon, unknownValuePlotting) {
		this.anchoredModel().lineRasterizer().isSortingAxis($.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.categoryModel().getXAxis()) !== null ? true : false);
		this.anchoredModel().lineRasterizer().rasterizePolygonPaths(this._polygon0, this._polyline0, this._polygon1, this._polyline1, count, buckets, useX0AsX1, bucketSize, resolution, terminatePolygon, unknownValuePlotting);
		this.makeDirty();
	}
	,
	__hitPolygon0: null,
	__hitPolyline0: null,
	__hitPolygon1: null,
	__hitPolyline1: null,
	setupHitAppearanceOverride: function () {
		$.ig.AnchoredCategorySeriesView.prototype.setupHitAppearanceOverride.call(this);
		this.__hitPolygon0.data(this._polygon0.data());
		this.__hitPolyline0.data(this._polyline0.data());
		this.__hitPolygon1.data(this._polygon1.data());
		this.__hitPolyline1.data(this._polyline1.data());
		var hitBrush = this.getHitBrush();
		this.__hitPolygon0.__fill = hitBrush;
		this.__hitPolygon0.__opacity = 1;
		this.__hitPolygon1.__fill = hitBrush;
		this.__hitPolygon1.__opacity = 1;
		this.__hitPolyline0.__stroke = hitBrush;
		this.__hitPolyline0.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this.__hitPolyline1.__stroke = hitBrush;
		this.__hitPolyline1.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
	}
	,
	renderOverride: function (context, isHitContext) {
		$.ig.AnchoredCategorySeriesView.prototype.renderOverride.call(this, context, isHitContext);
		if (isHitContext) {
			context.renderPath(this.__hitPolygon0);
			context.renderPath(this.__hitPolygon1);
			context.renderPath(this.__hitPolyline0);
			context.renderPath(this.__hitPolyline1);
		} else {
			context.renderPath(this._polygon0);
			context.renderPath(this._polygon1);
			context.renderPath(this._polyline0);
			context.renderPath(this._polyline1);
		}
	}
	,
	exportViewShapes: function (svd) {
		$.ig.AnchoredCategorySeriesView.prototype.exportViewShapes.call(this, svd);
		var lowerShape = new $.ig.PathVisualData(1, "lowerShape", this._polyline0);
		lowerShape.tags().add("Lower");
		var upperShape = new $.ig.PathVisualData(1, "upperShape", this._polyline1);
		upperShape.tags().add("Upper");
		upperShape.tags().add("Main");
		var translucent = new $.ig.PathVisualData(1, "translucentShape", this._polygon1);
		translucent.tags().add("Translucent");
		var fill = new $.ig.PathVisualData(1, "fillShape", this._polygon0);
		fill.tags().add("Fill");
		svd.shapes().add(lowerShape);
		svd.shapes().add(upperShape);
		svd.shapes().add(translucent);
		svd.shapes().add(fill);
	}
	,
	$type: new $.ig.Type('StepAreaSeriesView', $.ig.AnchoredCategorySeriesView.prototype.$type)
}, true);

$.ig.util.defType('StepLineSeries', 'HorizontalAnchoredCategorySeries', {
	createView: function () {
		return new $.ig.StepLineSeriesView(this);
	}
	,
	onViewCreated: function (view) {
		$.ig.HorizontalAnchoredCategorySeries.prototype.onViewCreated.call(this, view);
		this.stepView(view);
	}
	,
	_stepView: null,
	stepView: function (value) {
		if (arguments.length === 1) {
			this._stepView = value;
			return value;
		} else {
			return this._stepView;
		}
	}
	,
	init: function () {
		$.ig.HorizontalAnchoredCategorySeries.prototype.init.call(this);
		this.defaultStyleKey($.ig.StepLineSeries.prototype.$type);
	},
	onApplyTemplate: function () {
		$.ig.HorizontalAnchoredCategorySeries.prototype.onApplyTemplate.call(this);
	}
	,
	preferredCategoryMode: function (axis) {
		return $.ig.CategoryMode.prototype.mode1;
	}
	,
	clearRendering: function (wipeClean, view) {
		$.ig.HorizontalAnchoredCategorySeries.prototype.clearRendering.call(this, wipeClean, view);
		var stepView = view;
		stepView.clearStepLine();
	}
	,
	getXValue: function (i, fromEnd, frame, width, xInverted, isSorting) {
		var even;
		if (fromEnd) {
			if (isSorting) {
				even = (i & 1) == 0;
				if (even || ($.ig.intDivide(i, 2)) + 1 < 0) {
					return frame._buckets.__inner[($.ig.intDivide(i, 2))][0];
				}
				if (frame._buckets.count() == ($.ig.intDivide(i, 2)) + 1) {
					return frame._buckets.__inner[($.ig.intDivide(i, 2))][0];
				}
				return frame._buckets.__inner[($.ig.intDivide(i, 2)) + 1][0];
			}
			even = (i & 1) == 0;
			return (frame._buckets.__inner[($.ig.intDivide(i, 2))][0] + (even ? width : -width));
		}
		if (isSorting) {
			even = (i & 1) == 0;
			if (even || (($.ig.intDivide(i, 2)) + 1) >= frame._buckets.count()) {
				return frame._buckets.__inner[($.ig.intDivide(i, 2))][0];
			}
			if (frame._buckets.count() == ($.ig.intDivide(i, 2)) + 1) {
				return frame._buckets.__inner[($.ig.intDivide(i, 2))][0];
			}
			return (frame._buckets.__inner[($.ig.intDivide(i, 2)) + 1][0]);
		}
		even = (i & 1) == 0;
		return (frame._buckets.__inner[($.ig.intDivide(i, 2))][0] + (even ? -width : width));
	}
	,
	renderFrame: function (frame, view) {
		$.ig.HorizontalAnchoredCategorySeries.prototype.renderFrame.call(this, frame, view);
		var windowRect = view.windowRect();
		var viewportRect = view.viewport();
		var isSorting = $.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.cachedXAxis()) != null;
		var xIsInverted = this.cachedXAxis().isInverted();
		var width = 0;
		if (this.cachedXAxis() != null) {
			width = 0.5 * this.cachedXAxis().getCategorySize(windowRect, viewportRect);
		}
		var buckets = frame._buckets;
		var count = 2 * buckets.count();
		var procesedBuckets = new $.ig.List$1(Array, 2, count);
		if (!this.cachedXAxis().isInverted()) {
			for (var i = 0; i < count; i++) {
				var values = new Array(4);
				values[0] = this.getXValue(i, false, frame, width, xIsInverted, isSorting);
				values[1] = frame._buckets.__inner[($.ig.intDivide(i, 2))][1];
				values[2] = this.getXValue(i, true, frame, width, xIsInverted, isSorting);
				values[3] = frame._buckets.__inner[($.ig.intDivide(i, 2))][2];
				procesedBuckets.add(values);
			}
		} else {
			for (var i1 = 0; i1 < count; i1++) {
				var values1 = new Array(4);
				values1[0] = this.getXValue(i1, true, frame, width, xIsInverted, isSorting);
				values1[1] = frame._buckets.__inner[($.ig.intDivide(i1, 2))][1];
				values1[2] = this.getXValue(i1, true, frame, width, xIsInverted, isSorting);
				values1[3] = frame._buckets.__inner[($.ig.intDivide(i1, 2))][2];
				procesedBuckets.add(values1);
			}
		}
		var stepLineView = $.ig.util.cast($.ig.StepLineSeriesView.prototype.$type, view);
		var bucketSize = stepLineView.bucketCalculator()._bucketSize;
		this._renderManager.initCategoryRenderSettings(this, this.shouldOverrideCategoryStyle(), this.cachedXAxis(), this.getCategoryItems.runOn(this), this.getBucketSize(view), this.getFirstBucket(view));
		var areStylesOverriden = false;
		var args = this._renderManager.categoryOverrideArgs();
		if (args != null) {
			areStylesOverriden = true;
		}
		if (areStylesOverriden) {
			var xParams = new $.ig.ScalerParams(view.windowRect(), view.viewport(), this.cachedXAxis().isInverted());
			this.performCategoryStyleOverride(buckets, -1, this.valueColumn().count(), this.cachedXAxis(), xParams, view.isThumbnailView());
		}
		var line0 = stepLineView.line0();
		var line1 = stepLineView.line1();
		var fillArea = stepLineView.fillArea();
		this._renderManager.setCategoryShapeAppearance(line0, true, false, true, false);
		this._renderManager.setCategoryShapeAppearance(line1, true, false, true, false);
		this._renderManager.setCategoryShapeAppearance(fillArea, false, true, false, false);
		fillArea.__opacity = 0.75 * this._renderManager._actualRenderOpacity;
		if (view.checkFrameDirty(frame)) {
			stepLineView.rasterizeStepLine(count, procesedBuckets, false, $.ig.UnknownValuePlotting.prototype.dontPlot, this.getLineClipper(procesedBuckets, count - 1, view.viewport(), view.windowRect()), bucketSize, this.resolution());
			view.updateFrameVersion(frame);
		}
	}
	,
	currentCategoryMode: function () {
		if (this.cachedXAxis() != null && $.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.cachedXAxis()) !== null) {
			this.cachedXAxis().categoryMode($.ig.CategoryMode.prototype.mode0);
			return $.ig.CategoryMode.prototype.mode0;
		}
		return $.ig.CategoryMode.prototype.mode1;
	}
	,
	$type: new $.ig.Type('StepLineSeries', $.ig.HorizontalAnchoredCategorySeries.prototype.$type, [$.ig.IIsCategoryBased.prototype.$type])
}, true);

$.ig.util.defType('StepLineSeriesView', 'AnchoredCategorySeriesView', {
	_stepModel: null,
	stepModel: function (value) {
		if (arguments.length === 1) {
			this._stepModel = value;
			return value;
		} else {
			return this._stepModel;
		}
	}
	,
	init: function (model) {
		this._polyline0 = new $.ig.Path();
		this._polygon01 = new $.ig.Path();
		this._polyline1 = new $.ig.Path();
		this.__hitPolyline1 = new $.ig.Path();
		this.__hitPolyline0 = new $.ig.Path();
		this.__hitPolygon01 = new $.ig.Path();
		$.ig.AnchoredCategorySeriesView.prototype.init.call(this, model);
		this.stepModel(model);
	},
	_polyline0: null,
	_polygon01: null,
	_polyline1: null,
	line0: function () {
		return this._polyline0;
	}
	,
	line1: function () {
		return this._polyline1;
	}
	,
	fillArea: function () {
		return this._polygon01;
	}
	,
	clearStepLine: function () {
		this._polygon01.data(null);
		this._polyline0.data(null);
		this._polyline1.data(null);
		this.makeDirty();
	}
	,
	rasterizeStepLine: function (count, buckets, useX0AsX1, unknownValuePlotting, clipper, bucketSize, resolution) {
		this.anchoredModel().lineRasterizer().isSortingAxis($.ig.util.cast($.ig.ISortingAxis.prototype.$type, this.categoryModel().getXAxis()) !== null ? true : false);
		this.anchoredModel().lineRasterizer().rasterizePolylinePaths(this._polyline0, this._polygon01, this._polyline1, count, buckets, useX0AsX1, unknownValuePlotting, clipper, bucketSize, resolution);
		this.makeDirty();
	}
	,
	__hitPolyline1: null,
	__hitPolyline0: null,
	__hitPolygon01: null,
	setupHitAppearanceOverride: function () {
		$.ig.AnchoredCategorySeriesView.prototype.setupHitAppearanceOverride.call(this);
		this.__hitPolyline0.data(this._polyline0.data());
		this.__hitPolyline1.data(this._polyline1.data());
		this.__hitPolygon01.data(this._polygon01.data());
		var hitBrush = this.getHitBrush();
		this.__hitPolyline0.__stroke = hitBrush;
		this.__hitPolyline0.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this.__hitPolyline1.__stroke = hitBrush;
		this.__hitPolyline1.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		this.__hitPolygon01.__fill = hitBrush;
		this.__hitPolygon01.__opacity = 1;
	}
	,
	renderOverride: function (context, isHitContext) {
		$.ig.AnchoredCategorySeriesView.prototype.renderOverride.call(this, context, isHitContext);
		if (context.shouldRender()) {
			if (isHitContext) {
				context.renderPath(this.__hitPolygon01);
				context.renderPath(this.__hitPolyline0);
				context.renderPath(this.__hitPolyline1);
			} else {
				context.renderPath(this._polygon01);
				context.renderPath(this._polyline0);
				context.renderPath(this._polyline1);
			}
		}
	}
	,
	exportViewShapes: function (svd) {
		$.ig.AnchoredCategorySeriesView.prototype.exportViewShapes.call(this, svd);
		var lowerShape = new $.ig.PathVisualData(1, "lowerShape", this._polyline0);
		lowerShape.tags().add("Lower");
		lowerShape.tags().add("Main");
		var upperShape = new $.ig.PathVisualData(1, "upperShape", this._polyline1);
		upperShape.tags().add("Upper");
		var translucent = new $.ig.PathVisualData(1, "translucentShape", this._polygon01);
		translucent.tags().add("Translucent");
		svd.shapes().add(lowerShape);
		svd.shapes().add(upperShape);
		svd.shapes().add(translucent);
	}
	,
	applyDropShadowDefaultSettings: function () {
		var color = new $.ig.Color();
		color.colorString("rgba(95,95,95,0.5)");
		this.model().shadowColor(color);
		this.model().shadowBlur(3);
		this.model().shadowOffsetX(1);
		this.model().shadowOffsetY(4);
		this.model().useSingleShadow(false);
	}
	,
	$type: new $.ig.Type('StepLineSeriesView', $.ig.AnchoredCategorySeriesView.prototype.$type)
}, true);

$.ig.util.defType('WaterfallSeries', 'HorizontalAnchoredCategorySeries', {
	createView: function () {
		return new $.ig.WaterfallSeriesView(this);
	}
	,
	onViewCreated: function (view) {
		$.ig.HorizontalAnchoredCategorySeries.prototype.onViewCreated.call(this, view);
		this.waterfallView(view);
	}
	,
	_waterfallView: null,
	waterfallView: function (value) {
		if (arguments.length === 1) {
			this._waterfallView = value;
			return value;
		} else {
			return this._waterfallView;
		}
	}
	,
	init: function () {
		$.ig.HorizontalAnchoredCategorySeries.prototype.init.call(this);
		this.defaultStyleKey($.ig.WaterfallSeries.prototype.$type);
	},
	preferredCategoryMode: function (axis) {
		return $.ig.CategoryMode.prototype.mode2;
	}
	,
	negativeBrush: function (value) {
		if (arguments.length === 1) {
			this.setValue($.ig.WaterfallSeries.prototype.negativeBrushProperty, value);
			return value;
		} else {
			return this.getValue($.ig.WaterfallSeries.prototype.negativeBrushProperty);
		}
	}
	,
	radiusX: function (value) {
		if (arguments.length === 1) {
			this.setValue($.ig.WaterfallSeries.prototype.radiusXProperty, value);
			return value;
		} else {
			return this.getValue($.ig.WaterfallSeries.prototype.radiusXProperty);
		}
	}
	,
	radiusY: function (value) {
		if (arguments.length === 1) {
			this.setValue($.ig.WaterfallSeries.prototype.radiusYProperty, value);
			return value;
		} else {
			return this.getValue($.ig.WaterfallSeries.prototype.radiusYProperty);
		}
	}
	,
	hasIndividualElements: function () {
		return true;
	}
	,
	propertyUpdatedOverride: function (sender, propertyName, oldValue, newValue) {
		$.ig.HorizontalAnchoredCategorySeries.prototype.propertyUpdatedOverride.call(this, sender, propertyName, oldValue, newValue);
		switch (propertyName) {
			case $.ig.WaterfallSeries.prototype.radiusYPropertyName:
			case $.ig.WaterfallSeries.prototype.radiusXPropertyName:
			case $.ig.WaterfallSeries.prototype.negativeBrushPropertyName:
				this.renderSeries(false);
				break;
		}
	}
	,
	getDefaultTransitionInMode: function () {
		return $.ig.CategoryTransitionInMode.prototype.fromZero;
	}
	,
	clearRendering: function (wipeClean, view) {
		$.ig.HorizontalAnchoredCategorySeries.prototype.clearRendering.call(this, wipeClean, view);
		this.waterfallView().columns().count(0);
	}
	,
	getItemSpan: function () {
		return this.cachedXAxis().getGroupSize(this.view().windowRect(), this.view().viewport());
	}
	,
	renderFrame: function (frame, view) {
		var waterfallView = view;
		$.ig.HorizontalAnchoredCategorySeries.prototype.renderFrame.call(this, frame, view);
		var windowRect = view.windowRect();
		var viewportRect = view.viewport();
		var groupWidth = this.cachedXAxis().getGroupSize(windowRect, viewportRect);
		var radiusX = this.radiusX();
		var radiusY = this.radiusY();
		var rectangleGeometry;
		var rect;
		var left;
		var zeroVal = this.getWorldZeroValue(view);
		var lastKnownValue = NaN;
		var columns = waterfallView.columns();
		var currentRectangle;
		var columnCount = 0;
		this._renderManager.initCategoryRenderSettings(this, this.shouldOverrideCategoryStyle(), this.cachedXAxis(), this.getCategoryItems.runOn(this), this.getBucketSize(view), this.getFirstBucket(view));
		this._renderManager._initialRenderRadiusX = this.radiusX();
		this._renderManager._initialRenderRadiusY = this.radiusY();
		this._renderManager._actualRenderRadiusX = this.radiusX();
		this._renderManager._actualRenderRadiusY = this.radiusY();
		var areStylesOverriden = false;
		var args = this._renderManager.categoryOverrideArgs();
		if (args != null) {
			areStylesOverriden = true;
		}
		var isSorting = this.cachedXAxis().isSorting();
		var valueCount = this.valueColumn().count();
		var buckets = frame._buckets;
		var xAxis = this.cachedXAxis();
		var xParams = new $.ig.ScalerParams(windowRect, viewportRect, this.cachedXAxis().isInverted());
		var positiveBrush = this.actualBrush();
		var negativeBrush = this.negativeBrush();
		if (frame._buckets.count() > 0) {
			left = frame._buckets.__inner[0][0] - 0.5 * groupWidth;
			var currentValue = frame._buckets.__inner[0][1];
			if (!$.ig.util.isNaN(currentValue)) {
				if (currentValue > zeroVal) {
					currentRectangle = columns.item(columnCount);
					columnCount++;
					waterfallView.positionRectangle(currentRectangle, left, zeroVal);
					currentRectangle.width(groupWidth);
					currentRectangle.height(Math.abs(zeroVal - currentValue));
					this._renderManager._initialRenderFill = negativeBrush;
					this._renderManager._actualRenderFill = negativeBrush;
					this._renderManager._actualNegativeShape = true;
					if (areStylesOverriden) {
						this.performCategoryStyleOverride(buckets, 0, valueCount, xAxis, xParams, view.isThumbnailView());
					}
					this._renderManager.setCategoryShapeAppearance(currentRectangle, false, false, false, false);
					currentRectangle.radiusX(this._renderManager._actualRenderRadiusX);
					currentRectangle.radiusY(this._renderManager._actualRenderRadiusY);
				} else {
					currentRectangle = columns.item(columnCount);
					columnCount++;
					waterfallView.positionRectangle(currentRectangle, left, currentValue);
					currentRectangle.width(groupWidth);
					currentRectangle.height(Math.abs(currentValue - zeroVal));
					this._renderManager._initialRenderFill = positiveBrush;
					this._renderManager._actualRenderFill = positiveBrush;
					this._renderManager._actualNegativeShape = false;
					if (areStylesOverriden) {
						this.performCategoryStyleOverride(buckets, 0, valueCount, xAxis, xParams, view.isThumbnailView());
					}
					this._renderManager.setCategoryShapeAppearance(currentRectangle, false, false, false, false);
					currentRectangle.radiusX(this._renderManager._actualRenderRadiusX);
					currentRectangle.radiusY(this._renderManager._actualRenderRadiusY);
				}
				lastKnownValue = currentValue;
			} else {
				lastKnownValue = zeroVal;
			}
		}
		for (var i = 1; i < frame._buckets.count(); ++i) {
			var bucket1 = frame._buckets.__inner[i];
			left = frame._buckets.__inner[i][0] - 0.5 * groupWidth;
			var currentValue1 = bucket1[1];
			if (!$.ig.util.isNaN(currentValue1)) {
				currentRectangle = columns.item(columnCount);
				columnCount++;
				waterfallView.positionRectangle(currentRectangle, left, Math.min(lastKnownValue, currentValue1));
				currentRectangle.width(groupWidth);
				currentRectangle.height(Math.abs(lastKnownValue - currentValue1));
				this._renderManager._initialRenderFill = positiveBrush;
				this._renderManager._actualRenderFill = positiveBrush;
				this._renderManager._actualNegativeShape = false;
				if (lastKnownValue > currentValue1) {
					if (areStylesOverriden) {
						this.performCategoryStyleOverride(buckets, i, valueCount, xAxis, xParams, view.isThumbnailView());
					}
				} else {
					this._renderManager._initialRenderFill = negativeBrush;
					this._renderManager._actualRenderFill = negativeBrush;
					this._renderManager._actualNegativeShape = true;
					if (areStylesOverriden) {
						this.performCategoryStyleOverride(buckets, i, valueCount, xAxis, xParams, view.isThumbnailView());
					}
				}
				this._renderManager.setCategoryShapeAppearance(currentRectangle, false, false, false, false);
				currentRectangle.radiusX(this._renderManager._actualRenderRadiusX);
				currentRectangle.radiusY(this._renderManager._actualRenderRadiusY);
				lastKnownValue = currentValue1;
			}
		}
		columns.count(columnCount);
		view.updateFrameVersion(frame);
	}
	,
	$type: new $.ig.Type('WaterfallSeries', $.ig.HorizontalAnchoredCategorySeries.prototype.$type)
}, true);

$.ig.util.defType('WaterfallSeriesView', 'AnchoredCategorySeriesView', {
	onInit: function () {
		$.ig.AnchoredCategorySeriesView.prototype.onInit.call(this);
		this.visibleColumns(new $.ig.List$1($.ig.Rectangle.prototype.$type, 0));
		if (!this.isThumbnailView()) {
			this.model().resolution(4);
			this.waterfallModel().negativeBrush((function () {
				var $ret = new $.ig.Brush();
				$ret.fill("#415460");
				return $ret;
			}()));
			this.model().legendItemBadgeTemplate((function () {
				var $ret = new $.ig.DataTemplate();
				$ret.render($.ig.LegendTemplates.prototype.positiveNegativeBadgeTemplate);
				$ret.measure($.ig.LegendTemplates.prototype.legendItemBadgeMeasure);
				return $ret;
			}()));
		}
	}
	,
	_waterfallModel: null,
	waterfallModel: function (value) {
		if (arguments.length === 1) {
			this._waterfallModel = value;
			return value;
		} else {
			return this._waterfallModel;
		}
	}
	,
	init: function (model) {
		var $self = this;
		this.__hitItem = new $.ig.Rectangle();
		$.ig.AnchoredCategorySeriesView.prototype.init.call(this, model);
		this.waterfallModel(model);
		this.columns((function () {
			var $ret = new $.ig.Pool$1($.ig.Rectangle.prototype.$type);
			$ret.create($self.columnCreate.runOn($self));
			$ret.activate($self.columnActivate.runOn($self));
			$ret.disactivate($self.columnDisactivate.runOn($self));
			$ret.destroy($self.columnDestroy.runOn($self));
			return $ret;
		}()));
	},
	columnCreate: function () {
		var column = new $.ig.Rectangle();
		this.visibleColumns().add(column);
		column.__visibility = $.ig.Visibility.prototype.collapsed;
		return column;
	}
	,
	_visibleColumns: null,
	visibleColumns: function (value) {
		if (arguments.length === 1) {
			this._visibleColumns = value;
			return value;
		} else {
			return this._visibleColumns;
		}
	}
	,
	columnActivate: function (column) {
		column.__visibility = $.ig.Visibility.prototype.visible;
	}
	,
	columnDisactivate: function (column) {
		column.__visibility = $.ig.Visibility.prototype.collapsed;
	}
	,
	columnDestroy: function (column) {
		this.visibleColumns().remove(column);
	}
	,
	positionRectangle: function (column, left, top) {
		var dirty = false;
		if (column.canvasTop() != top) {
			dirty = true;
			column.canvasTop(top);
		}
		if (column.canvasLeft() != left) {
			dirty = true;
			column.canvasLeft(left);
		}
		if (dirty) {
			this.makeDirty();
		}
	}
	,
	getItem: function (index) {
		return this.visibleColumns().__inner[index];
	}
	,
	__hitItem: null,
	getHitItem: function (index) {
		var item = this.visibleColumns().__inner[index];
		this.__hitItem.__visibility = item.__visibility;
		this.__hitItem.canvasLeft(item.canvasLeft());
		this.__hitItem.canvasTop(item.canvasTop());
		this.__hitItem.width(item.width());
		this.__hitItem.height(item.height());
		var hitBrush = this.getHitBrush1(index);
		this.__hitItem.__fill = hitBrush;
		this.__hitItem.__stroke = hitBrush;
		this.__hitItem.strokeThickness(this.model().thickness() + $.ig.SeriesView.prototype.hIT_THICKNESS_AUGMENT);
		return this.__hitItem;
	}
	,
	renderOverride: function (context, isHitContext) {
		$.ig.AnchoredCategorySeriesView.prototype.renderOverride.call(this, context, isHitContext);
		var doGradients = false;
		if (context.shouldRender()) {
			for (var i = 0; i < this.visibleColumns().count(); i++) {
				var column = this.getCurrentItem(i, isHitContext);
				this.setupItemAppearance(column, i, isHitContext);
				context.renderRectangle(column);
			}
		}
	}
	,
	_columns: null,
	columns: function (value) {
		if (arguments.length === 1) {
			this._columns = value;
			return value;
		} else {
			return this._columns;
		}
	}
	,
	exportViewShapes: function (svd) {
		$.ig.AnchoredCategorySeriesView.prototype.exportViewShapes.call(this, svd);
		var i = 0;
		var toSort = new $.ig.List$1($.ig.Rectangle.prototype.$type, 0);
		var en = this.columns().active().getEnumerator();
		while (en.moveNext()) {
			var column = en.current();
			toSort.add(column);
		}
		toSort.sort2(function (c1, c2) {
			if (c1.canvasLeft() < c2.canvasLeft()) {
				return -1;
			} else if (c1.canvasLeft() > c2.canvasLeft()) {
				return 1;
			} else {
				return 0;
			}
		});
		var en1 = toSort.getEnumerator();
		while (en1.moveNext()) {
			var column1 = en1.current();
			var rvd = new $.ig.RectangleVisualData(1, "column" + i, column1);
			rvd.tags().add("Main");
			svd.shapes().add(rvd);
			if (column1.__fill == this.model().actualBrush()) {
				rvd.tags().add("Positive");
			} else {
				rvd.tags().add("Negative");
			}
		}
		i++;
	}
	,
	$type: new $.ig.Type('WaterfallSeriesView', $.ig.AnchoredCategorySeriesView.prototype.$type)
}, true);

$.ig.CategoryXAxis.prototype._intervalPropertyName = "Interval";
$.ig.CategoryXAxis.prototype.intervalProperty = $.ig.DependencyProperty.prototype.register($.ig.CategoryXAxis.prototype._intervalPropertyName, Number, $.ig.CategoryXAxis.prototype.$type, new $.ig.PropertyMetadata(2, NaN, function (sender, e) {
	(sender).raisePropertyChanged($.ig.CategoryXAxis.prototype._intervalPropertyName, e.oldValue(), e.newValue());
	(sender).renderAxis1(false);
}));

$.ig.VerticalAnchoredCategorySeries.prototype.xAxisPropertyName = "XAxis";
$.ig.VerticalAnchoredCategorySeries.prototype.yAxisPropertyName = "YAxis";
$.ig.VerticalAnchoredCategorySeries.prototype.xAxisProperty = $.ig.DependencyProperty.prototype.register($.ig.VerticalAnchoredCategorySeries.prototype.xAxisPropertyName, $.ig.NumericXAxis.prototype.$type, $.ig.VerticalAnchoredCategorySeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.VerticalAnchoredCategorySeries.prototype.xAxisPropertyName, e.oldValue(), e.newValue());
}));
$.ig.VerticalAnchoredCategorySeries.prototype.yAxisProperty = $.ig.DependencyProperty.prototype.register($.ig.VerticalAnchoredCategorySeries.prototype.yAxisPropertyName, $.ig.CategoryYAxis.prototype.$type, $.ig.VerticalAnchoredCategorySeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.VerticalAnchoredCategorySeries.prototype.yAxisPropertyName, e.oldValue(), e.newValue());
}));

$.ig.BarSeries.prototype.radiusXPropertyName = "RadiusX";
$.ig.BarSeries.prototype.radiusYPropertyName = "RadiusY";
$.ig.BarSeries.prototype.radiusXProperty = $.ig.DependencyProperty.prototype.register($.ig.BarSeries.prototype.radiusXPropertyName, Number, $.ig.BarSeries.prototype.$type, new $.ig.PropertyMetadata(2, 2, function (sender, e) {
	(sender).raisePropertyChanged($.ig.BarSeries.prototype.radiusXPropertyName, e.oldValue(), e.newValue());
}));
$.ig.BarSeries.prototype.radiusYProperty = $.ig.DependencyProperty.prototype.register($.ig.BarSeries.prototype.radiusYPropertyName, Number, $.ig.BarSeries.prototype.$type, new $.ig.PropertyMetadata(2, 2, function (sender, e) {
	(sender).raisePropertyChanged($.ig.BarSeries.prototype.radiusYPropertyName, e.oldValue(), e.newValue());
}));

$.ig.AreaSeries.prototype._unknownValuePlottingPropertyName = "UnknownValuePlotting";
$.ig.AreaSeries.prototype.unknownValuePlottingProperty = $.ig.DependencyProperty.prototype.register($.ig.AreaSeries.prototype._unknownValuePlottingPropertyName, $.ig.UnknownValuePlotting.prototype.$type, $.ig.AreaSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.UnknownValuePlotting.prototype.getBox($.ig.UnknownValuePlotting.prototype.dontPlot), function (sender, e) {
	(sender).raisePropertyChanged($.ig.AreaSeries.prototype._unknownValuePlottingPropertyName, e.oldValue(), e.newValue());
}));

$.ig.ColumnSeries.prototype.radiusXPropertyName = "RadiusX";
$.ig.ColumnSeries.prototype.radiusYPropertyName = "RadiusY";
$.ig.ColumnSeries.prototype.radiusXProperty = $.ig.DependencyProperty.prototype.register($.ig.ColumnSeries.prototype.radiusXPropertyName, Number, $.ig.ColumnSeries.prototype.$type, new $.ig.PropertyMetadata(2, 2, function (sender, e) {
	(sender).raisePropertyChanged($.ig.ColumnSeries.prototype.radiusXPropertyName, e.oldValue(), e.newValue());
}));
$.ig.ColumnSeries.prototype.radiusYProperty = $.ig.DependencyProperty.prototype.register($.ig.ColumnSeries.prototype.radiusYPropertyName, Number, $.ig.ColumnSeries.prototype.$type, new $.ig.PropertyMetadata(2, 2, function (sender, e) {
	(sender).raisePropertyChanged($.ig.ColumnSeries.prototype.radiusYPropertyName, e.oldValue(), e.newValue());
}));

$.ig.LineSeries.prototype._unknownValuePlottingPropertyName = "UnknownValuePlotting";
$.ig.LineSeries.prototype.unknownValuePlottingProperty = $.ig.DependencyProperty.prototype.register($.ig.LineSeries.prototype._unknownValuePlottingPropertyName, $.ig.UnknownValuePlotting.prototype.$type, $.ig.LineSeries.prototype.$type, new $.ig.PropertyMetadata(2, $.ig.UnknownValuePlotting.prototype.getBox($.ig.UnknownValuePlotting.prototype.dontPlot), function (sender, e) {
	(sender).raisePropertyChanged($.ig.LineSeries.prototype._unknownValuePlottingPropertyName, e.oldValue(), e.newValue());
}));

$.ig.WaterfallSeries.prototype.negativeBrushPropertyName = "NegativeBrush";
$.ig.WaterfallSeries.prototype.radiusXPropertyName = "RadiusX";
$.ig.WaterfallSeries.prototype.radiusYPropertyName = "RadiusY";
$.ig.WaterfallSeries.prototype.negativeBrushProperty = $.ig.DependencyProperty.prototype.register($.ig.WaterfallSeries.prototype.negativeBrushPropertyName, $.ig.Brush.prototype.$type, $.ig.WaterfallSeries.prototype.$type, new $.ig.PropertyMetadata(2, null, function (sender, e) {
	(sender).raisePropertyChanged($.ig.WaterfallSeries.prototype.negativeBrushPropertyName, e.oldValue(), e.newValue());
}));
$.ig.WaterfallSeries.prototype.radiusXProperty = $.ig.DependencyProperty.prototype.register($.ig.WaterfallSeries.prototype.radiusXPropertyName, Number, $.ig.WaterfallSeries.prototype.$type, new $.ig.PropertyMetadata(2, 2, function (sender, e) {
	(sender).raisePropertyChanged($.ig.WaterfallSeries.prototype.radiusXPropertyName, e.oldValue(), e.newValue());
}));
$.ig.WaterfallSeries.prototype.radiusYProperty = $.ig.DependencyProperty.prototype.register($.ig.WaterfallSeries.prototype.radiusYPropertyName, Number, $.ig.WaterfallSeries.prototype.$type, new $.ig.PropertyMetadata(2, 2, function (sender, e) {
	(sender).raisePropertyChanged($.ig.WaterfallSeries.prototype.radiusYPropertyName, e.oldValue(), e.newValue());
}));

} (jQuery));


