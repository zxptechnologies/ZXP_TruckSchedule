﻿/*!@license
* Infragistics.Web.MobileUI ListView localization resources 15.1.20151.2352
*
* Copyright (c) 2011-2015 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/

/*global jQuery */
$.ig = $.ig || {};

if (!$.ig.mobileListView) {
	$.ig.mobileListView = {};
	$.ig.mobileListViewFiltering = {};
	$.ig.mobileListViewLoadOnDemand = {};
	$.ig.mobileListViewSorting = {};

	$.ig.mobileListView.locale = {
		noSuchWidget: "No such widget loaded: ",
		optionChangeNotSupported: "Changing the following option after the igListView has been created is not supported:",
		emptyListText: "There are no list items!",
		goBackLabel: "Go back",
		detailsLabel: "Details",
		searchTrayExpandLabel: "Sort/Filter",
		searchTrayCollapseLabel: "Collapse"
	};
	$.ig.mobileListViewFiltering.locale = {
		keywordSearchLabel: "",
		keywordAllStateText: "All Fields",
		filterPresetsLabel: "Filter Presets:",
		searchBarPlaceHolder: "Filter Items...",
		filterAllStateText: "All",
		showLabel: "Show ",
		cancelButtonLabel: "Cancel",
		clearSearchButtonText: "Clear Text"
	};
	$.ig.mobileListViewLoadOnDemand.locale = {
		loadMoreItemsLabel: "Load more items",
		noMoreItemsLabel: "No items left to load"
	};
	$.ig.mobileListViewSorting.locale = {
		sortPresetsLabel: "Sort Presets:",
		sortDefaultStateText: "Default",
		sortByLabel: "Sort by ",
		expandedCueText: "Click to collapse {0}",
		collapsedCueText: "Click to expand {0}"
	};

}


/*!@license
 * Infragistics.Web.MobileUI ListView 15.1.20151.2352
 *
 * Copyright (c) 2011-2015 Infragistics Inc.
 *
 * http://www.infragistics.com/
 *
 * Depends on: 
 *  jquery-1.7.2.js
 *  jquery.mobile-1.2.0.js
 *	infragistics.dataSource.js
 *  infragistics.ui.shared.js
 *	infragistics.util.js
 */

/*global jQuery, define, unescape, document, window*/
(function ($) {
	var _originalBindings = null;

	$.widget("mobile.igList", $.mobile.widget, {
		css: {
			/* Class assigned to the main element indicating its an igList */
			igList: "ig-listview",
			/* Class assigned to the list element holding the items */
			baseList: "ui-listview ui-group-theme-{0}",
			/* Class assigned to the list element when the list is inset */
			insetList: "ui-listview-inset ui-corner-all ui-shadow",
			/* Class assigned to the form element holding the search area.  {0} is replaced by searchTheme */
			searchArea: "ui-listview-filter ui-bar-{0}",
			/* Class assigned to the div in the search area holding presets and input for keyword search */
			searchTray: "ui-iglist-tray",
			/* Class assigned to the search area when it is collapsed */
			searchTrayCollapsed: "ui-iglist-tray-collapsed",
			/* Class assigned to the search area form element when the list is inset */
			insetSearchArea: "ui-listview-filter-inset",
			/* Class assigned to the div holding search options when the list is inset */
			insetSearchTray: "ui-listview-filter-inset",
			/* Class assigned to footer element of the search tray.  Displays text describing search conditions.
				{0} is replaced by searchFooterTheme*/
			searchTrayFooter: "ui-iglist-tray-footer ui-bar-{0}",
			/* Class assigned to footer element of the search tray when the tray is collapsed */
			searchTrayFooterCollapsed: "ui-iglist-tray-footer-collapsed",
			/* Class assigned to the collapse area of the search tray.  Holds a collapse button. */
			searchTrayCollapse: "ui-iglist-tray-collapse ui-bar-{0}",
			/* Class assigned to the collapse area of the search tray when the tray is open */
			searchTrayCollapseOpen: "ui-iglist-tray-collapse-open",
			/* Class assigned to element holding text in the footer that is displayed when no sort/filter conditions are applied */
			searchTrayExpandText: "ui-iglist-tray-footer-empty",
			/* Class assigned to the icon to expand the search tray */
			searchTrayExpandIcon: "ui-icon ui-icon-arrow-d ui-iglist-tray-footer-empty-icon",
			/* Class assigned to the icon to collapse the search tray */
			searchTrayCollapseIcon: "ui-icon ui-icon-arrow-u",
			/* Class assigned to search area footer when the list is inset */
			insetSearchTrayFooter: "ui-iglist-tray-footer-inset",
			/* Class assigned to a list item element */
			baseListItem: "ui-li",		
			/* Class assigned to a list item element when it is read only */
			readOnlyListItem: "ui-li ui-li-static ui-body-{0}",
			/* Class assigned to count bubbles in list items */
			count: "ui-li-count ui-btn-up-{0} ui-btn-corner-all ui-btn",
			/* Class assigned to a list item element when it has an icon to the right (a child or url) */
			liIconRight: "ui-btn-icon-right ui-li-has-arrow ui-icon-carat-r",
			/* Class assigned to a list item element when it has a count bubble */
			liHasCount: "ui-li-has-count",
			/* Class assigned to a list item element when it has a thumbnail image */
			liHasThumb: "ui-li-has-thumb",
			/* Class assigned to a list item element when it has an icon image */
			liHasIcon: "ui-li-has-icon",
			/* Class assigned to image element in a list item when it is an icon */
			imageIcon: "ui-li-icon ui-li-thumb",
			/* Class assigned to image element in a list item when it is a thumbnail */
			imageThumb: "ui-li-thumb",
			/* The class to apply to the container of the item details template*/
			detailsTemplate: "ui-iglist-details",
			/* The classes applied to divider items.  {0} is replaced by listDividerTheme */
			listDivider: "ui-li ui-li-divider ui-bar-{0} ui-li-has-count",
			/* The classes applied to the last li in a non-inset list. */
			lastNonInsetItem: "ui-li-last"
		},
		options: {
			/* type="bool" Whether the list view should appear inset in the page */
			inset: false,
			/* type="bool" indicates if an ol or ul should be used as the main element for a databound list */
			numberedList: false,

			/* type="object" can be any valid data source accepted by $.ig.DataSource, or an instance of an $.ig.DataSource itself */
			dataSource: null,
			/* type="string" specifies a remote URL as a data source, from which data will be retrieved using an AJAX call ($.ajax)*/
			dataSourceUrl: null,
			/* type="string" explicitly set data source type (such as "json"). Please refer to the documentation of $.ig.DataSource and its type property */
			dataSourceType: null,
			/* type="string" see $.ig.DataSource. This is basically the property in the responses where data records are held, if the response is wrapped */
			responseDataKey: null,
			/* type="string" see $.ig.DataSource. property in the response specifying the total number of records on the server */
			responseTotalRecCountKey: null,
			/* type="string" explicitly set response type (such as "json"). Please refer to the documentation of $.ig.DataSource and its type property */
			responseDataType: null,
			/* type="bool" if this option is set to false, the data to which the list is bound will be used "as is" with no additional transformations based on bindings */
			localSchemaTransform: true,

			/* type="string" IG templating style template that will be used to render list items */
			itemTemplate: null,

			/* type="string" IG templating style template that will be used to render details about list items in a sub page */
			itemDetailsTemplate: null,

			/* type="none|icon|thumbnail" Whether to show no image, an icon, or a thumbnail
			none type="string"
			icon type="string"
			thumbnail type="string"
			*/
			imageMode: "thumbnail",
			/* type="bool" Whether to show a count bubble */
			showCount: true,
			/* type="none|h1|h2|h3|h4|h5|h6" Whether to show a heading tag in the LI.  Can be H1 to H6 depending upon value.
			*/
			itemHeaderSize: "h2",
			/* type="object" Specifies the data binding properties and keys. */
			bindings: {
				/* type="string" Specifies the name of the data source property the value of which would be the node text. */
				textKey: 'Text',
				/* type="string" Specifies the XPath to the text attribute/node. Used in client-only binding directly to XML. */
				textXPath: '@Text',
				/* type="string" Specifies the name of the data source property the value of which would be used as a URL 
								for the node image. 
				*/
				imageUrlKey: 'ImageUrl',
				/* type="string" Specifies the XPath to the image URL attribute/node. Used in client-only binding directly to XML. */
				imageUrlXPath: '@ImageUrl',
				/* type="string" Specifies the name of the data source property the value of which would be used as an href 
								attribute for the node anchor. 
				*/
				navigateUrlKey: 'NavigateUrl',
				/* type="string" Specifies the XPath to the navigate URL attribute/node. Used in client-only binding directly to XML. */
				navigateUrlXPath: '@NavigateUrl',
				/* type="string" Specifies the name of the data source property the value of which would be used as a count of the node
				*/
				countKey: 'Count',
				/* type="string" Specifies the XPath to the node count. Used in client-only binding directly to XML. */
				countXPath: '@Count',

				/* type="string" Specifies the name of the data source property the value of which would be used as a count of the node
				*/
				headerKey: 'Header',
				/* type="string" Specifies the XPath to the list item header. Used in client-only binding directly to XML. */
				headerXPath: '@Header',

				/* type="string" Specifies the name of the data source property the value of which would be used as a count of the node
				*/
				descriptionKey: 'Description',
				/* type="string" Specifies the XPath to the list item description Used in client-only binding directly to XML. */
				descriptionXPath: '@Description',

				/* type="string" Specifies the name of the data source property the value of which is the primary key attribute
								for the data. This property is used when load on demand is enabled and if specified the node paths
								would be generated using primary keys instead of indices.
				*/
				primaryKey: null,
				/* type="string" Specifies the name of the data source property which will be used to determine if an item represents a read-only list divider
				*/
				isDividerKey: 'IsDivider',
				/* type="string" Specifies the name of the data source property the value of which would be the Title of a sub page for a node. */
				detailsTitleKey: 'Title',
				/* type="string" Specifies the XPath to the title attribute/node. Used in client-only binding directly to XML. */
				detailsTitleXPath: '@Title',
				/* type="array" A list of objects of custom bindings.  This will bring in extra data to be used in item or details templates.
					Each item should be an object with key/value pairs of 'fieldName', 'dataType', and 'format' */
				customBindings: []
			},

			/* type="string" The swatch to apply to the search (filter/sort) tray. */
			searchTheme: "c",
			/* type="string" The swatch to apply to the search (filter/sort) tray footer. */
			searchFooterTheme: "d",
			/* type="string" The swatch to apply to count bubbles (if present). */
			countTheme: "c",
			/* type="string" The swatch applied to the headers of sub pages */
			subPageHeaderTheme: "b",
			/* type="string" The swatch to apply to list dividers.*/
			listDividerTheme: "b",
			/* type="string" The swatch applied to list items.  If null, it is determined from the parent(s) or defaults to 'c'. */
			itemTheme: null,
			/* type="string" The text displayed in the search tray footer when it is collapsed and all the states are default.  
				If null, uses $.ig.mobileListView.locale.searchTrayExpandLabel	*/
			searchTrayExpandLabel: null,
			/* type="bool" if this option is set to true, sub pages for local data are created the first time the list view is bound */
			createSubPagesOnInit: false,
			/* type="bool" Enables formatting of the dates as UTC. Note that this may be desirable when the dates are coming from a backend, encoded as UTC. Otherwise, if dates are created on the client (in the browser), most probably keeping enableUTCDates to false is the desired behavior */
			enableUtcDates: false,

			/* type="object" a list of list features definitions: sorting, filtering, etc. Each feature goes with its separate options that are documented for the feature accordingly */
			features : [
				{
					/* feature options object */
				}
			]
		},
		events: {
			/* cancel="true" Event fired before data binding takes place.
			Return false in order to cancel data binding.
			Function takes arguments evt and ui.
			Use ui.owner to get reference to igList.
			*/
			dataBinding: "dataBinding",
			/* Event fired after data binding is complete.
			Function takes arguments evt and ui.
			Use ui.owner to get reference to igList.
			*/
			dataBound: "dataBound",
			/* cancel="true" Event fired before cleaning up the UL/OL and rendering new items.
			Use ui.owner to get reference to igList.
			*/
			dataRendering: "dataRendering",
			/* cancel="false" Event fired before after the list is completely rendered.
			Use ui.owner to get reference to igList.
			*/
			dataRendered: "dataRendered",
			/* cancel="true" Event fired before the search tray is rendered for the list.
			Use ui.owner to get reference to igList.
			Use ui.tray to get reference to the actual tray (null initially and needs to be set).
			Use ui.needTray to set whether a tray is needed. 1 for persestent tray.  2 for tray with footer to collapse/expand
			Use ui.css to get/set the reference to the css class that will be assigned to the tray once rendered
			*/
			renderingTray: "renderingTray",
			/* Event fired after the search tray is rendered for the list.
			Use ui.owner to get reference to igList.
			Use ui.tray to get reference to the actual tray .
			Use ui.needTray to set whether a tray is needed. 1 for persestent tray.  2 for tray with footer to collapse/expand
			Use ui.css to get/set the reference to the css class that will be assigned to the tray once rendered
			*/
			renderedTray: "renderedTray",
			/* cancel="true" Event fired before the search tray footer bar is rendered for the list.
			Use ui.owner to get reference to igList.
			Use ui.trayFooter to get reference to the the div that will be the tray footer bar.
			*/
			renderingTrayFooterBar: "renderingTrayFooterBar",
			/* Event fired after the search tray footer bar is rendered for the list.
			Use ui.owner to get reference to igList.
			*/
			renderedTrayFooterBar: "renderedTrayFooterBar",
			/* cancel="true" Event fired before footer is rendered to the list.  Use to add contents to footer.
			Use ui.owner to get reference to igList.
			Use ui.footerContents to get reference to the footerContents (initially empty).
			*/
			footerRendering: "footerRendering",
			/* Event fired after list view footer has been rendered.
			Use ui.owner to get reference to igList.
			*/
			footerRendered: "footerRendered",
			/* cancel="true" Event fired before new list item is rendered.
			Function takes arguments evt and ui.
			Use ui.owner to get reference to igList.
			Use ui.item to get reference to list item defined by dataSource. Members of that object can be modified and rendering will use custom values.
			Use ui.index to get the index of item.
			Use ui.bindings to get reference to bindings used by rendering.
			*/
			itemRendering: "itemRendering",
			/* Event fired after html-string which represents list item was generated.
			Function takes arguments evt and ui.
			Use ui.owner to get reference to igList.
			Use ui.item to get reference to list item defined by dataSource.
			Use ui.index to get the index of item.
			Use ui.bindings to get reference to bindings used by rendering.
			Use ui.html to get the html of list item. That member can be modified and custom value will be used instead of original html.
			*/
			itemRendered: "itemRendered",
			/* cancel="true" Event fired before new list items are rendered.
			Function takes arguments evt and ui.
			Use ui.owner to get reference to igList.
			Use ui.items to get reference to string representing html that will be rendered at end.
			Use ui.index to get/set the index in the data view where rendering should begin.
			Use ui.dataView to get reference to the data view that is being used for rendering.
			*/
			itemsRendering: "itemsRendering",
			/* Event fired after list items have been created and added to the DOM.
			Function takes arguments evt and ui.
			Use ui.owner to get reference to igList.
			Use ui.hasSubPages to get boolean indicating if any list item has sub pages.
			*/
			itemsRendered: "itemsRendered",
			/* cancel="true" Event fired before page for child list and/or details is created.
			Function takes arguments evt and ui.
			Use ui.owner to get reference to igList that is making a sub page.
			Use ui.subPageTitle to get/set the title that will be displayed in the sub page.
			Use ui.extraContents to get/set any extra contents that should be displayed after details and child list.
			*/
			subPageCreating: "subPageCreating",
			/* Event fired after page when child list and/or details is created.
			Function takes arguments evt and ui.
			Use ui.owner to get reference to igList that made a sub page.
			Use ui.subPage to get refrerence to the new 'Page' object that will be navigated to.
			*/
			subPageCreated: "subPageCreated",
			/* Event fired after $.ig.DataSource schema has been generated, in case it needs to be modified.
			Function takes arguments evt and ui.
			Use ui.owner to get reference to igList.
			Use ui.schema to get reference to data source schema.
			Use ui.dataSource to get reference to data source.
			*/
			schemaGenerated: "schemaGenerated",
			/*
				Event fired if there is an error in the request, when the list is doing a remote operation,
				such as data binding, load on demand, sorting, etc. 
				use ui.owner to get a reference to the igList
				use ui.message to get the error message coming from the server 
			*/
			requestError: "requestError"
		},
		_setOption: function (key, value) {
			var o = this.options, css = this.css, oldCss;
			if (o[key] === value) {
				return;
			}
			$.Widget.prototype._setOption.apply(this, arguments);
			if (key === 'numberedList') {
				throw new Error(this._locale('optionChangeNotSupported') + ' ' + key);
			}
			if (key === 'dataSource') {
				o.dataSource = value;
				this.dataBind();
			} else if (key === 'itemTemplate' || key === 'imageMode' || key === 'showCount' || key === 'itemHeaderSize') {
				this._rerenderAllData();
			} else if (key.indexOf('Theme') > -1) {
				oldCss = $.extend(true, {}, this.css);
				o[key] = value;
				this._updateCss();
				if (key === 'searchTheme') {
					this.container().find('form').removeClass(oldCss.searchArea).addClass(this.css.searchArea);
				} else if (key === 'searchFooterTheme') {
					this.container().find('form').find('.' + oldCss.searchTrayFooter.split(' ')[0]).removeClass(oldCss.searchTrayFooter).addClass(this.css.searchTrayFooter).end().find('.' + oldCss.searchTrayCollapse.split(' ')[0]).removeClass(oldCss.searchTrayCollapse).addClass(this.css.searchTrayCollapse);
				} else if (key === 'itemTheme' || (key === 'countTheme' && o.showCount && o.bindings.countKey) || (key === 'listDividerTheme' && o.bindings.isDividerKey)) {
					this._rerenderAllData();
				}
			} else if (key === 'searchTrayExpandLabel') {
				this.container().find('form').find("[data-trayRole='empty']").html(this._locale('searchTrayExpandLabel'));
			} else if (key === 'searchTrayCollapseLabel') {
				this.container().find('form').find('.' + css.searchTrayCollapse.split(' ')[0]).html(this._locale('searchTrayCollapseLabel') + "<span class='" + css.searchTrayCollapseIcon + "'></span>");
			} else if (key === 'inset') {
				if (value) {
					this.listElement.addClass(css.insetList);
					this.container().find('form').addClass(css.insetSearchArea).find('.' + css.searchTrayFooter.split(' ')[0]).addClass(css.insetSearchTrayFooter);
				} else {
					this.listElement.removeClass(css.insetList);
					this.container().find('form').removeClass(css.insetSearchArea).find('.' + css.insetSearchTrayFooter).removeClass(css.insetSearchTrayFooter);
				}
				this._rerenderAllData();
			}
	    },
		_rerenderAllData: function () {
			var oldPageIndex = this.dataSource.settings.paging.pageIndex;
			this.dataSource.settings.paging.pageIndex = 0;
			this._requireRecordsClear = true;
			this._renderData();
			this.dataSource.settings.paging.pageIndex = oldPageIndex;
		},
		_createWidget: function () {
			/* !Strip dummy objects from options, because they are defined for documentation purposes only! */
			this.options.bindings = null;
			$.Widget.prototype._createWidget.apply(this, arguments);
		},
		_create: function () {
			var opts = this.options;
			if (!opts.itemTheme) {
				opts.itemTheme = $.mobile.getInheritedTheme(this.element, "c");
			}
			this._firstBind = true;
			this._updateCss();
			this.dataBind();
		},
		container: function () {
			/* returns the DIV that is the topmost container of the list widget
				returnType="dom"
			*/
			var parent = this.element.parent();
			if (parent && parent.length > 0 && parent[0].id === this.element[0].id + '_container') {
				return parent;
			}
			return $('#' + this.element[0].id + '_container');
		},
		_locale: function (key) {
			var val = this.options[key];
			if (val === undefined || val === null) {
				val = $.ig.mobileListView && $.ig.mobileListView.locale ? $.ig.mobileListView.locale[key] : null;
			}
			return val || '';
		},
		_updateCss: function () {
			var css = $.extend(true, {}, $.mobile.igList.prototype.css), opts = this.options;
			css.baseListItem = css.baseListItem.replace("{0}", opts.itemTheme);		
			css.baseList=css.baseList.replace("{0}", opts.itemTheme);				
			css.readOnlyListItem = css.readOnlyListItem.replace("{0}", opts.itemTheme);
			css.count = css.count.replace("{0}", opts.countTheme);
			css.searchArea = css.searchArea.replace("{0}", opts.searchTheme);
			css.searchTray = css.searchTray.replace("{0}", opts.searchTheme);
			css.searchTrayFooter = css.searchTrayFooter.replace("{0}", opts.searchFooterTheme);
			css.searchTrayCollapse = css.searchTrayCollapse.replace("{0}", opts.searchFooterTheme);
			css.listDivider = css.listDivider.replace("{0}", opts.listDividerTheme);
			this.css = css;
		},
		_itemFromTarget: function (target, tagName, attribute) {
			while (target) {
				if (target.tagName && target.tagName.toLowerCase() === tagName && target.getAttribute(attribute) !== null) {
					break;
				}
				target = target.parentNode;
			}
			return target;
		},
		toggleSearchArea: function () {
			/* This will toggle the visibility of the search tray (if there is one), by triggering a click on it's footer. */
			this.container().find('.' + this.css.searchTrayFooter.split(' ')[0]).trigger('click');
			return this;
		},
		dataBind: function () {
			/* Data binds the list. */
			var dataOptions, i, noCancel = true, listString, hList;
			// fire data binding event
			noCancel = this._trigger(this.events.dataBinding, null, {owner: this});
			if (noCancel) {
				dataOptions = this._generateDataSourceOptions(this.options);
				this._setupDataSource(dataOptions);
				this._dataOptions = dataOptions;
				if (!this._initialized) {
					this._onChangePageHandler = $.proxy(this._onChangePage, this);
					$(document).bind("pagechange", this._onChangePageHandler);
					if (this.element.is("div")) {
						this._isWrapped = true;
						hList = this.options._hParent;
						if ((hList && hList.options.dataSource && parseInt(this.element.attr('data-level'), 10) === 0 && hList.options.dataSource.tagName && (hList.options.dataSource.tagName.toLowerCase() === "ul" || hList.options.dataSource.tagName.toLowerCase() === "ol")) || (dataOptions.dataSource && dataOptions.dataSource.tagName && (dataOptions.dataSource.tagName.toLowerCase() === "ul" || dataOptions.dataSource.tagName.toLowerCase() === "ol"))) {
							this.listElement = hList ? $(hList.options.dataSource) : $(dataOptions.dataSource);
							this.listElement.siblings().remove();
							if (!this.listElement[0].id) {
								this.listElement.attr('id', this.element[0].id + "_list");
							}
						} else {
							if (this.options.numberedList) {
								listString = "<ol></ol>";
							} else {
								listString = "<ul></ul>";
							}
							this.element.empty();
							this.listElement = $(listString).appendTo(this.element).attr('id', this.element[0].id + "_list");
						}
					} else {
						this.listElement = this.element;
					}
					this.element.data('igFlatList', this);
					for (i = 0; i < this.options.features.length; i++) {
						this._initFeature(this.options.features[i], dataOptions);
					}
					this._renderList();
				}
				//$.mobile.loading('show');
				$.mobile.loading('show');
				this._dataBinding = true;
				this._requireRecordsClear = true;
				this.dataSource.dataBind();
			}
		},
		_onChangePage: function () {
			if (this._dataBinding) {
				$.mobile.loading('show');
			}
			$(document).unbind("pagechange", this._onChangePageHandler);
			delete this._onChangePageHandler;
		},
		_renderList: function () {
			var self = this, css = this.css, opts = this.options, listClass = css.baseList, searchClass, trayFooter, containerId, containerDiv, form = $("<form></form>"), args, noCancel;
			containerId =  this.element[0].id + '_container';
			containerDiv = '<div id="' + containerId + '"> </div>';
			this.element.wrap(containerDiv).addClass(css.igList);
			searchClass = css.searchArea;
			trayFooter = css.searchTrayFooter;
			if (opts.inset) {
				listClass += " " + css.insetList;
				searchClass += " " + css.insetSearchArea;
			}
			this.listElement.addClass(listClass);

			if (opts.itemDetailsTemplate !== null && opts.itemDetailsTemplate.length > 0) {
				this.listElement.bind("click", function (evnt) {
					self._listTap(evnt);
				});
			}
			args = {owner: this, tray: null, needTray: 0, css: this.css.searchTray };
			noCancel = this._trigger(this.events.renderingTray, null, args);
			if (noCancel && args.needTray) {
				form.addClass(searchClass).append(args.tray).bind({
					"submit": function () {
						return false;
					}
				});
				this._trigger(this.events.renderedTray, null, args);
				if (args.needTray > 1) {
					args.tray.addClass(css.searchTray).addClass(args.css).addClass(css.searchTrayCollapsed);
					args = {owner: this, trayFooter: $("<div>").addClass(css.searchTrayFooter).addClass(css.searchTrayFooterCollapsed) };
					if (this.options.inset) {
						args.trayFooter.addClass(css.insetSearchTrayFooter);
					}
					noCancel = this._trigger(this.events.renderingTrayFooterBar, null, args);
					if (noCancel) {
						args.trayFooter.append("<span data-trayRole='empty'	class='" + css.searchTrayExpandText + "'>" + this._locale("searchTrayExpandLabel") + "</span><span class='" + css.searchTrayExpandIcon + "'></span>");
						if (args.trayFooter.find('[data-trayRole="keyword"]').text()) {
							args.trayFooter.find('[data-trayRole="empty"]').hide().next().hide();
						}
						form = form.append(args.trayFooter).append($("<div>").addClass(css.searchTrayCollapse).html(this._locale("searchTrayCollapseLabel") + "<span class='" + css.searchTrayCollapseIcon + "'></span>")).wrap("<div>").parent();
						this._trigger(this.events.renderedTrayFooterBar, null, {owner: this});
						this._clickFooter = function () {
							var footer = self.container().find('.ui-iglist-tray-footer');
							footer.toggleClass(css.searchTrayFooterCollapsed).next().toggleClass(css.searchTrayCollapseOpen).end().prev().toggleClass(css.searchTrayCollapsed);

						};
						args.trayFooter.bind("click", this._clickFooter);
						args.trayFooter.next().bind("click", this._clickFooter);
						form.children().insertBefore(this.listElement);
					}
				} else {
					form.insertBefore(this.listElement);
				}
				this.listElement.parent().find("form").find("li:visible").each(function () {
					var $this = $(this);
					$this.width($this.outerWidth());
				});
			}
			args = {owner: this, footerContents: $("<div>") };
			noCancel = this._trigger(this.events.footerRendering, null, args);
			if (noCancel) {
				args.footerContents.children().insertAfter(this.element);
				this._trigger(this.events.footerRendered, null, {owner: this});
			}

			if (this.dataSource.type() !== 'htmlListDom') {
				this.listElement.empty();
			}
		},
		_initFeature: function (featureObject) {
		    if (!featureObject) {
			    return;
            }
		    // construct widget name
			if (featureObject.name === undefined) {
				return;
			}
		    var widget = 'igListView' + featureObject.name;
			// validate widget
			if ($.type($('#' + this.element[0].id)[widget]) !== "function") {
				throw new Error(this._locale('noSuchWidget') + ' ' + widget);
			}
			// instantiate widget
			if (this.element.data(widget) !== undefined) {
				this.element[widget]('destroy');
			}
			this.element[widget](featureObject);
		    this.element.data(widget)._injectList(this);
	    },
		_generateDataSourceOptions: function () {

			var schema, dataOptions;
			// if there is neither options.dataSource specified, nor options.dataSourceUrl, we check if we are binding to an unordered or ordered list and if there is any existing
			// data in it, and then we set the data source to that ul/ol DOM element, so that it can be processed by the data source control
			if (!this.options.dataSource && !this.options.dataSourceUrl && (this.element.is('ul') || this.element.is('ol')) && this.element.children().length > 0) {
				this.options.dataSource = this.element[0];
			}

			dataOptions = {
			    callback : $.proxy(this._onDataBound, this),
			    callee : this,
			    responseDataKey: this.options.responseDataKey,
				localSchemaTransform: this.options.localSchemaTransform,
				dataSource: this.options.dataSource
		    };
			if (this.options.dataSourceType !== null) {
				dataOptions.type = this.options.dataSourceType;
			}
			schema = this._generateDataSourceSchema();
			if (this.options.bindings && this.options.bindings.primaryKey) {
				dataOptions.primaryKey = this.options.bindings.primaryKey;
			}
			if ((this.options.dataSource instanceof $.ig.DataSource && (this.options.dataSource.settings.schema === null
				|| (this.options.dataSource.settings.schema.fields && this.options.dataSource.settings.schema.fields.length >= 0) || !this.options.dataSource.settings.schema.fields))
					|| !(this.options.dataSource instanceof $.ig.DataSource)) {
				dataOptions = $.extend(dataOptions, {schema: schema});
			}
			return dataOptions;
		},
		_generateDataSourceSchema: function () {
			var schema = {}, ds = this.options.dataSource, opt = this.options, bindings = opt.bindings, x, binding, key, field;
			schema.fields = [];
			schema.searchField = this.options.responseDataKey;

			if (bindings === null) {
				return this._generateBindings(ds);
			}
			if (opt.dataSourceType === 'xml') {
				schema.fields = [];
				if (bindings.textKey) {
					schema.fields.push({ name: bindings.textKey, xpath: bindings.textXPath });
					schema.textKey = bindings.textKey;
				}
				if (bindings.navigateUrlKey) {
					schema.fields.push({ name: bindings.navigateUrlKey, xpath: bindings.navigateUrlXPath });
					schema.navigateUrlKey = bindings.navigateUrlKey;
				}
				if (bindings.imageUrlKey) {
					schema.fields.push({ name: bindings.imageUrlKey, xpath: bindings.imageUrlXPath });
					schema.imageUrlKey = bindings.imageUrlKey;
				}
				if (bindings.countKey) {
					schema.fields.push({ name: bindings.countKey, xpath: bindings.countXPath });
					schema.countXPath = bindings.countKey;
				}
				if (bindings.headerKey) {
					schema.fields.push({ name: bindings.headerKey, xpath: bindings.headerXPath });
					schema.headerXPath = bindings.headerKey;
				}
				if (bindings.descriptionKey) {
					schema.fields.push({ name: bindings.descriptionKey, xpath: bindings.descriptionXPath });
					schema.descriptionXPath = bindings.descriptionKey;
				}
				if (bindings.detailsTitleKey) {
					schema.fields.push({ name: bindings.detailsTitleKey, xpath: bindings.detailsTitleXPath });
					schema.detailsTitleXPath = bindings.detailsTitleKey;
				}
				if (bindings.searchFieldXPath) {
					schema.searchField = bindings.searchFieldXPath;
				}
				if (this.options.childLayout) {
					schema.fields.push({ name: this.options.childLayout.key, xpath: this.options.childLayout.key
						});
					schema.childDataProperty = this.options.childLayout.key;
				}
				return schema;
			}

			schema.fields = [];
			if (bindings.primaryKey) {
				schema.fields.push({ name: bindings.primaryKey, type: 'string' });
				schema.primaryKeyKey = bindings.primaryKey;
			}
			if (bindings.textKey) {
				binding = key = bindings.textKey;
				if ($.type(binding) === "object") {
					key = binding.fieldName;
				}
				if (key) {
					field = { name: key, type: 'string' };
					if (binding.dataType) {
						field.type = binding.dataType;
					}
					if (binding.format) {
						field.format = binding.format;
					}
					schema.fields.push(field);
					schema.textKey = key;
				}
			}
			if (bindings.navigateUrlKey) {
				schema.fields.push({ name: bindings.navigateUrlKey, type: 'string' });
				schema.navigateUrlKey = bindings.navigateUrlKey;
			}
			if (bindings.imageUrlKey) {
				schema.fields.push({ name: bindings.imageUrlKey, type: 'string' });
				schema.imageUrlKey = bindings.imageUrlKey;
			}
			if (bindings.countKey) {
				binding = key = bindings.countKey;
				if ($.type(binding) === "object") {
					key = binding.fieldName;
				}
				if (key) {
					field = { name: key, type: 'number' };
					if (binding.format) {
						field.format = binding.format;
					}
					schema.fields.push(field);
					schema.countKey = key;
				}
			}
			if (bindings.headerKey) {
				binding = key = bindings.headerKey;
				if ($.type(binding) === "object") {
					key = binding.fieldName;
				}
				if (key) {
					field = { name: key, type: 'string' };
					if (binding.dataType) {
						field.type = binding.dataType;
					}
					if (binding.format) {
						field.format = binding.format;
					}
					schema.fields.push(field);
					schema.headerKey = key;
				}
			}
			if (bindings.descriptionKey) {
				binding = key = bindings.descriptionKey;
				if ($.type(binding) === "object") {
					key = binding.fieldName;
				}
				if (key) {
					field = { name: key, type: 'string' };
					if (binding.dataType) {
						field.type = binding.dataType;
					}
					if (binding.format) {
						field.format = binding.format;
					}
					schema.fields.push(field);
					schema.descriptionKey = key;
				}
			}
			if (bindings.detailsTitleKey) {
				schema.fields.push({ name: bindings.detailsTitleKey, type: 'string' });
				schema.detailsTitleKey = bindings.detailsTitleKey;
			}
			if (bindings.isDividerKey) {
				schema.fields.push({ name: bindings.isDividerKey, type: 'bool' });
				schema.isDividerKey = bindings.isDividerKey;
			}
			if (bindings.customBindings && bindings.customBindings.length > 0) {
				for (x = 0; x < bindings.customBindings.length; ++x) {
					binding = bindings.customBindings[x];
					schema.fields.push({ name: binding.fieldName, type: binding.dataType, format: binding.format });
					schema[bindings.customBindings[x].fieldName + "Key"] = bindings.customBindings[x].fieldName;
				}
			}
			opt.schema = schema;
			opt.schema.searchField = opt.responseDataKey;
			if (this.options.childLayout) {
				schema.fields.push({ name: this.options.childLayout.childrenDataProperty === undefined ?
						this.options.childLayout.key : this.options.childLayout.childrenDataProperty
					});
			}

			// used in special cases where the schema needs to be additionally modified ( as it is the case with hGrid, so that all complex objects
			// are also added to the schema whenever autoGenerateColumns === false (only in that case) 
			this._trigger(this.events.schemaGenerated, null, {owner: this, schema: schema, dataSource: ds});
			return schema;
		},
		_generateBindings: function (ds, addAll) {
			var opt = this.options, schema, x, rec, prop, name, camelCase, bindingName, fieldType, guess, allFields = [
				'Text',
				'NavigateUrl',
				'ImageUrl',
				'Count',
				'Description',
				'Header',
				'DetailsTitle',
				'IsDivider'
			];
			if ((opt.bindings === null || opt.bindings === undefined) && ds && ds.length && ds.length > 0 && $.type(ds) === "array") {
				opt.bindings = {};
				schema = {};
				schema.fields = [];
				schema.searchField = this.options.responseDataKey;
				for (x = 0; x < ds.length; ++x) {
					rec = ds[x];
					for (prop in rec) {
						if (rec.hasOwnProperty(prop)) {
							guess = this._guessBindingName(rec, prop);
							if (guess && !this._fieldExists(prop, schema) && allFields.indexOf(guess) > -1) {
								camelCase = this._toCamelCase(guess);
								bindingName = this._getBindingName(guess);
								fieldType = this._calcFieldType(guess);
								schema.fields.push({name: prop, type: fieldType});
								schema[bindingName] = {name: prop, type: fieldType};
								schema[camelCase] = {name: prop, type: fieldType};
								opt.bindings[bindingName] = prop;
								allFields.removeAt(allFields.indexOf(guess));
							}
						}
					}
				}
				if (addAll) {
					for (x = 0; x < allFields.length; ++x) {
						name = allFields[x];
						if (!this._fieldExists(name, schema)) {
							camelCase = this._toCamelCase(name);
							bindingName = this._getBindingName(name);
							fieldType = this._calcFieldType(name);
							schema.fields.push({name: name, type: fieldType});
							schema[bindingName] = {name: name, type: fieldType};
							opt.bindings[bindingName] = name;
						}
					}
				}
				this._trigger(this.events.schemaGenerated, null, { owner: this, schema: schema, dataSource: ds });
			}
			return schema;
		},
		_toCamelCase: function (val) {
			return val.substr(0, 1).toLowerCase() + val.substr(1, val.length - 1);
		},
		_calcFieldType: function (name) {
			if (name === "Count") {
				return "number";
			}
			if (name === "IsDivider") {
				return "bool";
			}
			return "string";
		},
		_getBindingName: function (name) {
			name = this._toCamelCase(name);
			if (name.indexOf("Key") !== -1) {
				return name;
			}
			return name + "Key";
		},
		_guessBindingName: function (rec, prop) {
			var val = rec[prop];
			if (prop === "Text") {
				return "Text";
			}
			if (prop === "NavigateUrl") {
				return "NavigateUrl";
			}
			if (prop === "ImageUrl") {
				return "ImageUrl";
			}
			if (prop === "Count") {
				return "Count";
			}
			if (prop === "Description") {
				return "Description";
			}
			if (prop === "Header") {
				return "Header";
			}
			if (prop === "DetailsTitle") {
				return "DetailsTitle";
			}
			if (prop === "IsDivider") {
				return "IsDivider";
			}
			if (prop === "PrimaryKey") {
				return "PrimaryKey";
			}
			if ($.type(val) === "string") {
				if (val.indexOf(".gif") > -1 || val.indexOf(".png") > -1 || val.indexOf(".jpg") > -1) {
					return "ImageUrl";
				}
				if (val.indexOf("http://") === 0 || val.indexOf(".htm") > -1 || val.indexOf(".aspx") > -1) {
					return "NavigateUrl";
				}
				return "Text";
			}
			if ($.type(val) === "number") {
				return "Count";
			}
			if ($.type(val) === "boolean") {
				return "IsDivider";
			}
			return null;
		},
		_fieldExists: function (prop, schema) {
			var i;
			for (i = 0; i < schema.fields.length; i++) {
				if (schema.fields[i].name === prop) {
					return true;
				}
			}
			return false;
		},
		_onDataBound: function (success, errmsg) {
			var o = this.options,
				ds = o.dataSource,
				listElement = this.element,
				noCancel = true,
				isUlOl = false,
				noCancelError = true;
			if (success === false) {
				// check if there is an event requestError defined
				noCancelError = this._trigger(this.events.requestError, null, {owner: this, message: errmsg});
				// if the handler returns false or doesn't return anything, the error will be propagated to the list and an Error object will be returned
				if (noCancelError) {
					throw new Error(errmsg);
				}
			}
			this._trigger(this.events.dataBound, null, { owner: this });
			noCancel = this._trigger(this.events.dataRendering, null, { owner: this, listElement: listElement });
			if (noCancel) {
				if (this._requireRecordsClear && !(ds && ds.tagName && ($(ds).is('ul') || $(ds).is('0l')))) {
					listElement = this._cleanupList();
				} else {
					isUlOl = true;
				}
				delete this._requireRecordsClear;

				if (!this._initialized) {
					if (!o.bindings) {
						o.schema = this._generateBindings(this.dataSource.dataView(), this.dataSource.type() !== "remoteUrl");
					}
					if (isUlOl) {
						// now clean up the UL/OL
						listElement.empty();
					}
				}
				delete this._dataBinding;
				this._renderData();
				this.dataSource.settings.paging.appendPage = true;
				$.mobile.loading('hide');
				this._trigger(this.events.dataRendered, null, { owner: this });
			}
			// scenarios where the first load is sending JSON, but the second time we are actually making an AJAX request (MVC for example)
			if (o.dataSourceUrl && this._firstBind) {
				ds = this.dataSource;
				ds.settings.dataSource = o.dataSource = o.dataSourceUrl;
				ds.settings.type = "remoteUrl";
				ds._runtimeType = ds.analyzeDataSource();
				this._firstBind = false;
			}
			this._initialized = true;
		},
		_cleanupList: function () {
			var list = this.listElement.attr('data-empty', null), noCancel;
			noCancel = this._trigger("_cleanuplist", null, { owner: this, listElement: list });
			if (noCancel) {
				if ($.mobile.igListView && $.mobile.igListView.speedupDOMCleanup === false) {
					list.empty();
				} else {
					if (list.children().length > 0) {
						this.listElement[0].innerHTML = "";
					}
				}
			}
			return this.listElement;
		},
		_renderData: function () {	
			var args, val, liAtts, hasSubPage, liClass, hyperLink, wrapperDivStart, wrapperDivEnd, arrow,
				startIndex, key, href, pk, title, bKey,
				i = 0,
				hasSubPages = false,
				listElement = this.listElement,
				ds = this.dataSource.dataView(),
				dsCount = ds ? ds.length : 0,
				items = '',
				opts = this.options,
				// VS 02/26/2013 protect from possible exception if bindings is null
				bindings = opts.bindings || {},
				css = this.css,
				dns = "data-" + $.mobile.ns,
				titleKey = bindings.detailsTitleKey;
			if (this._requireRecordsClear) {
				listElement = this._cleanupList();
				delete this._requireRecordsClear;
			}
			args = {owner: this, items: items, index: i, listElement: listElement, dataView: ds};
			if (!this._trigger(this.events.itemsRendering, null, args)) {
				return;
			}
			pk = bindings.primaryKey = bindings.primaryKey || "ig_pk";
			items = args.items;
			startIndex = args.index;
			ds = this.dataSource.dataView();
			dsCount = ds.length;
			for (i = args.index; i < dsCount; ++i) {
				args = {owner: this, item: $.extend({}, ds[i]), index: i, bindings: bindings};
				this._trigger("itemRendering", null, args);
				val = args.item;
				// VS 02/26/2013 title is not rendered
				title = titleKey ? val[titleKey] : null;
				if (opts.itemTemplate) {
					liAtts = dns + "idx='" + i + "'";
					if (title) {
						liAtts += " title='" + title + "'";
					}
					liAtts += " " + dns + "id='" + (pk === "ig_pk" ? this._getVal(val, ds[i]) : val[pk]) + "'";
					hasSubPage = this._hasSubPage(val);
					hasSubPages = hasSubPages || hasSubPage;
					if (hasSubPage) {
						liAtts += " subPage=\"false\"";
					}
					args.html = "<li class='" + css.baseListItem + "{EXTRACSS}' " + liAtts + ">" +  $.ig.tmpl(opts.itemTemplate, this._prepareValue(val), {}) + "</li>";
				} else {
					liClass = css.baseListItem;
					if (val[bindings.isDividerKey] === true) {
						hyperLink = "{TEXT}{COUNT}";
						liAtts = wrapperDivStart = wrapperDivEnd = arrow = "";
						liClass = css.listDivider;
						if (i === dsCount - 1 || ds[i + 1][bindings.isDividerKey] === true) {
							continue;
						}
						bKey = bindings.textKey;
						key = bKey && bKey.fieldName ? bKey.fieldName : bKey;
						if (bKey && val[key] !== null && val[key] !== undefined) {
							key = bKey.format ? $.ig.formatter(val[key], bKey.dataType || "string", bKey.format) : val[key];
						} else {
							key = "";
						}
						hyperLink = hyperLink.replace("{TEXT}", key);
						//
						bKey = bindings.countKey;
						key = bKey && bKey.fieldName ? bKey.fieldName : bKey;
						if (bKey && val[key] !== null && val[key] !== undefined) {
							liClass += " " + css.liHasCount;
							key = "<span class='" + css.count + "'>" + val[key] + "</span>";
						} else {
							key = "";
						}
						hyperLink = hyperLink.replace("{COUNT}", key);
					} else {
						hyperLink = "<a{HREF} class='ui-link-inherit ui-btn'>{IMG}{HEAD}{DESC}{TEXT}{COUNT}</a>";
						liAtts = dns + "idx='" + i + "' " + dns + "theme='" + opts.itemTheme + "'";
						hasSubPage = this._hasSubPage(val);
						hasSubPages = hasSubPages || hasSubPage;
						liAtts += " " + dns + "id='" + (pk === "ig_pk" ? this._getVal(val, ds[i]) : val[pk]) + "'";
						href = val[bindings.navigateUrlKey];
						if (href || hasSubPage) {
							liClass += " " + css.liIconRight;
							if (hasSubPage) {
								liAtts += " subPage=\"false\"";
								key = "";
							} else {
								// VS 02/25/2013 Bug 134145. For external a-link, jquery mobile framework checks for 'rel=external' flag. Fix: set that flag
								key = " href='" + href + (href.indexOf(".htm") > 0 || href.indexOf(".aspx") > 0 ? "' rel='external'" : "'");
							}
							hyperLink = hyperLink.replace("{HREF}", key);
							arrow = "<span class='ui-icon ui-icon-arrow-r ui-icon-shadow'></span>";
							wrapperDivStart = "<div class='ui-li ui-btn-inner'>";
							wrapperDivEnd = "</div>";
						} else {
							liClass = css.readOnlyListItem;
							hyperLink = "{IMG}{HEAD}{DESC}{TEXT}{COUNT}";
							arrow = wrapperDivStart = wrapperDivEnd = "";
						}
						bKey = bindings.descriptionKey;
						key = bKey && bKey.fieldName ? bKey.fieldName : bKey;
						if (bKey && val[key] !== null && val[key] !== undefined) {
							key = "<p class='ui-li-desc'>" + (bKey.format ? $.ig.formatter(val[key], bKey.dataType || "string", bKey.format) : val[key]) + "</p>";
						} else {
							key = "";
						}
						hyperLink = hyperLink.replace("{DESC}", key);
						//
						bKey = bindings.headerKey;
						key = bKey && bKey.fieldName ? bKey.fieldName : bKey;
						if (opts.itemHeaderSize !== "none" && bKey && val[key] !== null && val[key] !== undefined) {
							key = bKey.format ? $.ig.formatter(val[key], bKey.dataType || "string", bKey.format) : val[key];
							key = "<" + opts.itemHeaderSize + " class='ui-li-heading'>" + key + "</" + opts.itemHeaderSize + ">";
						} else {
							key = "";
						}
						hyperLink = hyperLink.replace("{HEAD}", key);
						//
						bKey = bindings.textKey;
						key = bKey && bKey.fieldName ? bKey.fieldName : bKey;
						if (bKey && val[key] !== null && val[key] !== undefined) {
							key = bKey.format ? $.ig.formatter(val[key], bKey.dataType || "string", bKey.format) : val[key];
						} else {
							key = "";
						}
						hyperLink = hyperLink.replace("{TEXT}", key);
						//
						bKey = bindings.countKey;
						key = bKey && bKey.fieldName ? bKey.fieldName : bKey;
						if (bKey && opts.showCount && val[key] !== null && val[key] !== undefined) {
							liClass += " " + css.liHasCount;
							key = bKey.format ? $.ig.formatter(val[key], "number", bKey.format) : val[key];
							key = "<span class='" + css.count + "'>" + key + "</span>";
						} else {
							key = "";
						}
						hyperLink = hyperLink.replace("{COUNT}", key);
						//
						bKey = bindings.imageUrlKey;
						if (opts.imageMode !== "none" && bKey) {
							if (opts.imageMode === "thumbnail") {
								liClass += " " + css.liHasThumb;
								key = css.imageThumb;
							} else {
								liClass += " " + css.liHasIcon;
								key = css.imageIcon;
							}
							key = (val[bKey] ? "<img src='" + val[bKey] + "'" : "<div") + " class='" + key + "' />";
						} else {
							key = "";
						}
						hyperLink = hyperLink.replace("{IMG}", key);
					}
					if (title) {
						liAtts += " title='" + title + "'";
					}
					args.html = "<li class='" + liClass + "{EXTRACSS}' " + liAtts + ">" + hyperLink + arrow + "</li>";
				}
				this._trigger("itemRendered", null, args);
				items += args.html;
				args = {owner: this, items: items, index: i, listElement: listElement, dataView: ds, value: val};
				this._trigger("_itemRendered", null, args);
				items = args.items;
				items = items.replace("{EXTRACSS}", "");
			}
			if (items.length === 0 && listElement.html() === "") {
				items = "<li class='" + css.readOnlyListItem + "'>" + this._locale('emptyListText') + "</li>";
				listElement.attr('data-empty', 'true');
			}
			if (items && items.length > 0) {
				if (this._loadOnDemand) {
					listElement.append(items);
				} else {
					listElement.html(items);
				}
			}
			if (opts.itemTemplate) {
				listElement.trigger('create', {target: listElement});
			}
			//
			val = listElement.children();
			if (opts.inset) {
				this._addCorners(val.first(), "top");
				this._addCorners(val.last(), "bottom");
			} else {
				val.last().addClass(css.lastNonInsetItem);
			}
			this._trigger(this.events.itemsRendered, null, {owner: this, hasSubPages: hasSubPages });
			if (!this._initialized && opts.createSubPagesOnInit && pk !== "ig_pk") {
				ds = this.dataSource._data;
				dsCount = ds ? ds.length : 0;
				bKey = bindings.isDividerKey;
				for (i = startIndex; i < dsCount; ++i) {
					val = ds[i];
					if (val && (!bKey || val[bKey] !== true)) {
						this._createSubPage(val, listElement.children().eq(i), i);
					}
				}
			}
		},
		_addCorners: function (li, which) {
			if (which === "both" || which === "top") {
				li.addClass("ui-corner-top")
					.find(".ui-btn-inner").not(".ui-li-link-alt span:first-child").addClass("ui-corner-top").end().end()
					.find(".ui-li-thumb").not(".ui-li-icon").addClass("ui-corner-tl");
			}
			if (which === "both" || which === "bottom") {
				li.addClass("ui-corner-bottom")
					.find(".ui-btn-inner").not(".ui-li-link-alt span:first-child").addClass("ui-corner-bottom").end().end()
					.find(".ui-li-thumb").not(".ui-li-icon").addClass("ui-corner-bl");
			}
		},
		_prepareValue: function (val, binding) {
			var fields = this.dataSource.schema() ? this.dataSource.schema().fields() : [], field, x, newObj = $.extend({}, val);
			if (binding) {
				if ($.type(binding) === "object") {
					if (binding.format || binding.dataType === "date") {
						return $.ig.formatter(val[binding.fieldName], binding.dataType, binding.format, true, this.options.enableUtcDates);
					}
					return newObj[binding.fieldName];
				}
				return val[binding];
			}
			for (x = 0; x < fields.length; ++x) {
				field = fields[x];
				if (field.format || field.type === "date") {
					newObj[field.name] = $.ig.formatter(newObj[field.name], field.type, field.format, true, this.options.enableUtcDates);
				}
			}
			return newObj;
		},
		_hasSubPage: function () {
			return this.options.itemDetailsTemplate !== undefined && this.options.itemDetailsTemplate !== null && this.options.itemDetailsTemplate.length > 0;
		},
		_listTap: function (evnt) {
			var li = evnt.target, $li, index, flatDataSource = this.dataSource.dataView(), dataItem, newPage;
			while (li && (li.tagName !== "LI" || li.className.indexOf("ui-li-divider") !== -1)) {
				li = li.parentNode;
			}
			if (li === null) {
				return;
			}
			$li = $(li);
			index = parseInt($li.jqmData("idx"), 10);
			dataItem = flatDataSource[index];

			if (li.getAttribute("subPage") === "false") {
				newPage = this._createSubPage(dataItem, $li, index);
				if (newPage) {
					$.mobile.changePage(newPage, {transition: "slide"});
					if ($li.find("a").length === 0  || !$.mobile.ajaxEnabled) {
						$li.attr('subPage', "noLink").data("newPage", newPage);
					} else {
						$li.attr('subPage', "true").find("a").first().attr('href', newPage.jqmData('url'));
					}
				}
			} else if (li && (li.getAttribute("subPage") === "noLink")) {
				$.mobile.changePage($(li).data("newPage"), {transition: "slide"});
			}
		},
		_createSubPageContent: function (dataItem) {
			var items = $(null);
			if (this.options.itemDetailsTemplate) {
				items[0] = $("<div class='" + this.css.detailsTemplate + "'></div>").append($.ig.tmpl(this.options.itemDetailsTemplate, this._prepareValue(dataItem), {}))[0];
				items.length = 1;
			}
			return items;
		},
		_createSubPage: function (dataItem, listItem) {
			var parentPage = this.element.closest(".ui-page"),
				parentUrl = parentPage.jqmData("url"),
				//parentId = parentUrl || parentPage[0][$.expando],
				parentListId = $(this.element).attr("id"),
				dns = "data-" + $.mobile.ns,
				persistentFooterID = parentPage.find(":jqmData(role='footer')").jqmData("id"),
				title = this._locale('detailsLabel'),
				subItems,
				id = (parentUrl || "") + "&" + $.mobile.subPageUrlKey + "=" + parentListId + "-" + this.options.bindings.primaryKey + '/' + dataItem[this.options.bindings.primaryKey],
				newPage,
				opts = this.options,
				backBtn,
				args,
				noCancel;
			if ((newPage = $(":jqmData(url='" + id + "')")).length > 0) {
				return newPage;
			}
			if (this.options.bindings && this.options.bindings.detailsTitleKey && dataItem[this.options.bindings.detailsTitleKey]) {
				title = dataItem[this.options.bindings.detailsTitleKey];
			}
			newPage = null;
			args = {owner: this, subPageTitle: title, extraContents: $("<div>") };
			noCancel = this._trigger(this.events.subPageCreating, null, args);
			if (noCancel) {
				title = args.subPageTitle;
				subItems = this._createSubPageContent(dataItem, listItem);
				backBtn = $("<a>").css("zIndex", 1).text(this._locale('goBackLabel')).bind("click", function () {
					/* DAY 7/30/12 117843- active button class not getting removed in JQM 1.1.0 */
					var parentListItem = listItem;
					parentListItem.removeClass($.mobile.activeBtnClass);
					window.history.back();
				}).buttonMarkup({ inline: true, theme: opts.subPageHeaderTheme });
				newPage = $("<div " + dns + "role='content'></div>")
					.wrap("<div " + dns + "role='page' " + dns + "url='" + id + "' " + dns + "theme='" + opts.itemTheme + "' " + dns + "count-theme='" + opts.countTheme + "'></div>")
					.append(subItems)
					.append(args.extraContents.children())
					.before($("<div " + dns + "role='header' " + dns + "theme='" + opts.subPageHeaderTheme + "'><div class='ui-title'>" + title + "</div></div>").prepend(backBtn))
					.after(persistentFooterID ? $("<div " + dns + "role='footer' " + dns + "id='" + persistentFooterID + "'>") : "")
					.parent()
					.appendTo($.mobile.pageContainer);

				// trigger sub page created event to add child list views if necessary
				newPage.page();
				args = {owner: this, subPage: newPage };
				this._trigger(this.events.subPageCreated, null, args);
			}
			return newPage;
		},
		_setupDataSource: function (dataOptions) {
			var dsSet, o = this.options, ds = o.dataSource;
			if (!(ds instanceof $.ig.DataSource)) {
				// fix for JSONP
				if ($.type(dataOptions.dataSource) === "string" && dataOptions.dataSource.indexOf("$callback=?") !== -1) {
					this.dataSource = new $.ig.JSONPDataSource(dataOptions);
				} else {
					this.dataSource = new $.ig.DataSource(dataOptions);
				}
			} else {
				this.dataSource = ds;
				dsSet = ds.settings;
				if (dsSet.responseDataKey !== null) {
					delete dataOptions.responseDataKey;
					if (dataOptions.schema) {
						dataOptions.schema.searchField = dsSet.responseDataKey;
					}
				}
				this._tds = dsSet.dataSource;
				dsSet.dataSource = null;
				ds.settings = dsSet = $.extend(true, {}, dsSet, dataOptions);
				dsSet.dataSource = this._tds;
				dsSet.responseDataType = o.responseDataType || dsSet.responseDataType;
				this._tds = null;
				if (dataOptions.schema) {
					ds._initSchema();
				}
			}
		},
		_getVal: function (data, ds) {
		    var val;
		    /*jshint -W106*/
			if (data.ig_pk) {
				val = data.ig_pk;
			} else {
				val = $.ig.uid();
				ds.ig_pk = data.ig_pk = val;
			}
		    /*jshint +W106*/
			return val;
		},
		_inferOpType: function () {
			// infer the default feature operation type, if it is not explicitly specified by the developer
			// that will be done based on the data source type after it's analyzed
			if (this.options.dataSourceUrl || this.dataSource.type() === "remoteUrl") {
				return "remote";
			}
			return "local";
		},
		destroy: function () {
			/* destroys the list by removing attributes and css class from the element, destroying features, and emptying the list element */
			var prev = this.container().prev(), i, css = this.css;
			for (i = 0; i < this.options.features.length; i++) {
				if (this.options.features[i].name && this.element.data('igListView' + this.options.features[i].name)) {
					$('#' + this.element[0].id)['igListView' + this.options.features[i].name]('destroy');
				}
			}
			if (prev.length === 0) {
				prev = this.container().parent();
			}
			this.listElement.empty().removeClass(css.baseList);
			this.element.find("form").remove();
			prev.append(this.element);
			this.element.attr('data-level', null).removeClass(css.igList + ' ' + css.baseList + ' ' + css.insetList);
			$.Widget.prototype.destroy.call(this);
			this.container().remove();
			this.element.children().remove();
			this.element.removeData('igFlatList');
			
		}
	});
	// Expose List as an AMD module, but only for AMD loaders that
	// understand the issues with loading multiple versions of jQuery
	// in a page that all might call define(). The loader will indicate
	// they have special allowances for multiple jQuery versions by
	// specifying define.amd.jQuery = true. Register as a named module,
	// since jQuery can be concatenated with other files that may use define,
	// but not use a proper concatenation script that understands anonymous
	// AMD modules. A named AMD is safest and most robust way to register.
	// Lowercase ig.mobileui.flatlist is used because AMD module names are derived from
	// file names, and jQuery is normally delivered in a lowercase file name.
	// Do this after creating the global so that if an AMD module wants to call
	// noConflict to hide this version of jQuery, it will work.
	if (typeof define === "function" && define.amd && define.amd.jQuery) {
		define("ig.mobileui.flatlist", ["ig.util", "ig.datasource"], function () { return $.mobile.igList; });
	}

	$.widget("mobile.igListView", $.mobile.widget, {
		css: {
		},
		// the options listed here are only specific to the hierarchical list. All other options that are exposed by the flat list, will be copied automatically
		// such as bindings, showCount, features, etc. 
		options: {
			// specific hierarchical list options go here. everything else gets merged with the flat list CSS (meaning root level)
			// even though this widget *does not extend* the flat list
			/* type="number" Only the first level will be data-bound initially. Also serves as "render" depth, meaning that depending on this prop, the list will */
			initialDataBindDepth: -1,
			/* type="bool" If true, encodes all requests using OData conventions and the $expand syntax */
			odata: false,
			/* type="string" Specifies the default property in the response where children will be located */
			defaultChildrenDataProperty: "Children",
			/* type="string" Specifies the delimiter for constructing paths , for hierarchical lookup of data */
			pathSeparator: "/",
			/* type="bool" if true, will autogenerate all layouts assuming default values for "key" 
			*/
			autoGenerateLayouts: false,
			/* type="object" Object defning the options for a child list. All options that are applicable to a flat list are also applicable here */
			childLayout:
				{
					/* type="string" Specifies the columnLayout key. This can be the property that holds the data records for the child layout. */
					key: null
				},
			/* type="string" The selector to use by default to find html elements that should be transformed into this widget. */
			initSelector: ":jqmData(role='iglistview')"
			// all options for the flat list are also applicable here
		},
		events: {
			/* cancel="true" Event which is fired when children are about to be populated (Load on demand)
				use args.owner to access the hierarchical list object
				use args.parentitem to access the li element for the item that's about to be populated
				use args.id to get the data ID of the list item 
			*/
			childrenPopulating: "childrenPopulating",
			/* Event which is fired when children have been populated (Load on demand) 
				use args.owner to access the hierarchical list object
				use args.parentitem to access the li element for the item that was populated
				use args.id to get the data ID of the list item 
			*/
			childrenPopulated: "childrenPopulated"
		},
		_create: function () {
			var tmpSource;
			this._regevents(this.element, this);
			this.options = $.extend(true, {}, $.mobile.igList.prototype.options, this.options);
			if (this.options._fromHtml && this.options.dataSource) {
				try {
				    tmpSource = this.options.dataSource;
				    /*jshint -W061*/
				    this.options.dataSource = eval(this.options.dataSource);
				    /*jshint +W061*/
				} catch (exc) {
					this.options.dataSource = tmpSource;
				}
				if (this.options.dataSource === undefined && tmpSource) {
					this.options.dataSource = tmpSource;
				}
			}
			if (this.tmpDataSource !== null && this.tmpDataSource !== undefined) {
				this.options.dataSource = this.tmpDataSource;
				this._originalOptions.dataSource = this.tmpDataSource;
			}
			// we need to data-bind the hierarchical data source, and then create recursively child lists where appropriate, 
			// and bind the child data to them 
			$("<div>").buttonMarkup();
			this.dataBind();
		},
		_createWidget: function (options) {
			/* !Strip dummy objects from options, because they are defined for documentation purposes only! */
			this.options.features = [];
			this.options.childLayout = null;
			if ($.mobile.igList.prototype.options.bindings !== null && $.mobile.igList.prototype.options.bindings !== undefined) {
				_originalBindings = $.mobile.igList.prototype.options.bindings;
			}
			$.mobile.igList.prototype.options.bindings = null;
			if (options && options.dataSource && ($.type(options.dataSource) === "array" || $.type(options.dataSource) === "object")) {
				this.tmpDataSource = options.dataSource;
				options.dataSource = null;
				// later we would need to restore the data source to the original external options object
				this._originalOptions = options;
			}
			$.Widget.prototype._createWidget.apply(this, arguments);
		},
		dataBind: function () {
			/* Data binds the hierarchical list. No child lists will be created or rendered by default, unless there is initialExpandDepth >= 0 set. 
			*/
			var hds, hdsoptions, rootds, opts;
			// auto generate layouts
			if (this.options.autoGenerateLayouts) {
				this._generateLayouts();
			}
			hdsoptions = this._hdsoptions();
			hds = new $.ig.HierarchicalDataSource(hdsoptions);
			// do not data-bind the hierarchical data source. Instead "ask" it to generate options for the respective sources
			// such as the root one
			//hds.dataBind();
			this._hds = hds;
			// create the root level list
			// two ways, pass the root ds instance, or the dynamically generated options object 
			rootds = this._hds.root();
			this._tmpds = this.options.dataSource;
			this.options.dataSource = null;
			opts = $.extend(true, {}, this.options);
			this.options.dataSource = this._tmpds;
			this._tmpds = null;
			opts.dataSource = rootds;
			if ($.type(hdsoptions.dataSource) === "string") {
				opts.dataSourceUrl = hdsoptions.dataSource;
			}

			this.element.attr("data-level", 0);
			if (this._root) {
				this._root.igList('option', 'dataSource', opts.dataSource);
			} else {
				opts._hParent = this;
				this._root = this.element.igList(opts);
			}
		},
		root: function () {
			/* returns the element of the root list (igList)
			returnType="object" jquery wrapped element of the root list
			*/
			return this._root;
		},
		rootWidget: function () {
			/* returns the widget object of the root list (igList)
			returnType="object" widget object of the root igList (not igListView)
			*/
			return this.root().data('igFlatList');
		},

		// parse the hierarchical layout definitions
		_layouts: function () {
			// traverse the DS and generate the layouts. 
			// does autoGenerateLayouts make any sense at all ? 
			// traverses the existing data source and auto generates the layouts
			this.element.unbind('ig_flatlistdatarendering', this._databoundHandler);
		},

		_hdsoptions: function () {
			var opts,
				o = this.options,
				ds = o.dataSource,
				url = o.dataSourceUrl;
			if (!ds) {
				if (url) {
					ds = url;
				} else {
					ds = this.element;
					if (!ds.is('ul') && !ds.is('ol')) {
						ds = ds.children('ul,ol');
					}
					ds = ds[0];
				}
				o.dataSource = ds;
			}
			opts = {
				responseDataKey: o.responseDataKey,
				responseTotalRecCountKey: o.responseTotalRecCountKey,
				dataSource: ds,
				localSchemaTransform: o.localSchemaTransform,
				odata: o.odata,
				initialDataBindDepth: o.initialDataBindDepth
			};
			if (o.bindings && o.bindings.primaryKey) {
				opts.primaryKey = o.bindings.primaryKey;
			}
			if (o.dataSourceType) {
				opts.type = o.dataSourceType;
			}
			if (ds instanceof $.ig.HierarchicalDataSource && ds.settings.schema) {
				return opts;
			}
			return $.extend(opts, { schema: this._hschema() });
		},
		_hschema: function () {
			var schema = {},  ds = this.options.dataSource, opt = this.options, bindings = opt.bindings, /*encodedLayouts = [],*/ guess, x, prop, rec, name, camelCase, bindingName, fieldType, allFields = [
				'Text',
				'NavigateUrl',
				'ImageUrl',
				'Count',
				'Description',
				'Header',
				'DetailsTitle',
				'IsDivider'
			];
			schema.fields = [];
			schema.searchField = this.options.responseDataKey;

			if (bindings === null) {
				if (ds && ((ds.length && ds.length > 0 && $.type(ds) === "array") || (ds.tagName && (ds.tagName.toLowerCase() === "ul" || ds.tagName.toLowerCase() === "ol")))) {
					opt.bindings = {};
					for (x = 0; x < ds.length; ++x) {
						rec = ds[x];
						for (prop in rec) {
							if (rec.hasOwnProperty(prop)) {
								guess = this._guessBindingName(rec, prop);
								if (guess && !this._fieldExists(prop, schema) && allFields.indexOf(guess) > -1) {
									camelCase = this._toCamelCase(guess);
									bindingName = this._getBindingName(guess);
									fieldType = this._calcFieldType(guess);
									schema.fields.push({name: prop, type: fieldType});
									schema[bindingName] = {name: prop, type: fieldType};
									schema[camelCase] = {name: prop, type: fieldType};
									opt.bindings[bindingName] = prop;
									allFields.removeAt(allFields.indexOf(guess));
								}
							}
						}
					}
					for (x = 0; x < allFields.length; ++x) {
						name = allFields[x];
						if (!this._fieldExists(name, schema)) {
							camelCase = this._toCamelCase(name);
							bindingName = this._getBindingName(name);
							fieldType = this._calcFieldType(name);
							schema.fields.push({name: name, type: fieldType});
							schema[bindingName] = {name: name, type: fieldType};
							schema[camelCase] = {name: name, type: fieldType};
							opt.bindings[bindingName] = name;
						}
					}
					// generate top level schema
					if (this.options.childLayout) {
						schema.childDataProperty = { name: this.options.childLayout.key, type: 'object' };
						schema.childData = { name: this.options.childLayout.key, type: 'object' };
					} else if (ds && ds.tagName && (ds.tagName.toLowerCase() === "ul" || ds.tagName.toLowerCase() === "ol")) {
						schema.childDataProperty = { name: 'Children', type: 'object' };
						schema.childData = { name: 'Children', type: 'object' };
					}
					//return schema;
				}
				//return null;
				return schema;
			}
			if (opt.dataSourceType === 'xml') {
				schema.fields = [];
				if (bindings.textKey) {
					schema.fields.push({ name: bindings.textKey, xpath: bindings.textXPath });
					schema.textKey = bindings.textKey;
				}
				if (bindings.navigateUrlKey) {
					schema.fields.push({ name: bindings.navigateUrlKey, xpath: bindings.navigateUrlXPath });
					schema.navigateUrlKey = bindings.navigateUrlKey;
				}
				if (bindings.imageUrlKey) {
					schema.fields.push({ name: bindings.imageUrlKey, xpath: bindings.imageUrlXPath });
					schema.imageUrlKey = bindings.imageUrlKey;
				}
				if (bindings.countKey) {
					schema.fields.push({ name: bindings.countKey, xpath: bindings.countXPath });
					schema.countXPath = bindings.countKey;
				}
				if (bindings.headerKey) {
					schema.fields.push({ name: bindings.headerKey, xpath: bindings.headerXPath });
					schema.headerXPath = bindings.headerKey;
				}
				if (bindings.descriptionKey) {
					schema.fields.push({ name: bindings.descriptionKey, xpath: bindings.descriptionXPath });
					schema.descriptionXPath = bindings.descriptionKey;
				}
				if (bindings.searchFieldXPath) {
					schema.searchField = bindings.searchFieldXPath;
				}
				// generate top level schema
				if (this.options.childLayout) {
					schema.childDataProperty = { name: this.options.childLayout.key, type: 'object' };
					schema.childData = { name: this.options.childLayout.key, type: 'object' };
				}
				return schema;
			}

			schema.fields = [];
			if (bindings.primaryKey) {
				schema.fields.push({ name: bindings.primaryKey, type: 'string' });
				schema.primaryKeyKey = bindings.primaryKey;
			}
			if (bindings.textKey) {
				schema.fields.push({ name: bindings.textKey, type: 'string' });
				schema.textKey = bindings.textKey;
			}
			if (bindings.navigateUrlKey) {
				schema.fields.push({ name: bindings.navigateUrlKey, type: 'string' });
				schema.navigateUrlKey = bindings.navigateUrlKey;
			}
			if (bindings.imageUrlKey) {
				schema.fields.push({ name: bindings.imageUrlKey, type: 'string' });
				schema.imageUrlKey = bindings.imageUrlKey;
			}
			if (bindings.countKey) {
				schema.fields.push({ name: bindings.countKey, type: 'number' });
				schema.countKey = bindings.countKey;
			}
			if (bindings.headerKey) {
				schema.fields.push({ name: bindings.headerKey, type: 'string' });
				schema.headerKey = bindings.headerKey;
			}
			if (bindings.descriptionKey) {
				schema.fields.push({ name: bindings.descriptionKey, type: 'string' });
				schema.descriptionKey = bindings.descriptionKey;
			}
			if (bindings.isDividerKey) {
				schema.fields.push({ name: bindings.isDividerKey, type: 'bool' });
				schema.isDividerKey = bindings.isDividerKey;
			}
			if (this.options.childLayout) {
				schema.childDataProperty = { name: this.options.childLayout.key, type: 'object' };
				schema.childData = { name: this.options.childLayout.key, type: 'object' };
			}
			return schema;
		},
		_toCamelCase: function (val) {
			return val.substr(0, 1).toLowerCase() + val.substr(1, val.length - 1);
		},
		_calcFieldType: function (name) {
			if (name === "Count") {
				return "number";
			}
			if (name === "IsDivider") {
				return "bool";
			}
			return "string";
		},
		_getBindingName: function (name) {
			name = this._toCamelCase(name);
			if (name.indexOf("Key") !== -1) {
				return name;
			}
			return name + "Key";
		},
		_guessBindingName: function (rec, prop) {
			var val = rec[prop];
			if (prop === "Text") {
				return "Text";
			}
			if (prop === "NavigateUrl") {
				return "NavigateUrl";
			}
			if (prop === "ImageUrl") {
				return "ImageUrl";
			}
			if (prop === "Count") {
				return "Count";
			}
			if (prop === "Description") {
				return "Description";
			}
			if (prop === "Header") {
				return "Header";
			}
			if (prop === "DetailsTitle") {
				return "DetailsTitle";
			}
			if (prop === "IsDivider") {
				return "IsDivider";
			}
			if (prop === "PrimaryKey") {
				return "PrimaryKey";
			}
			if ($.type(val) === "string") {
				if (val.indexOf(".gif") > -1 || val.indexOf(".png") > -1 || val.indexOf(".jpg") > -1) {
					return "ImageUrl";
				}
				if (val.indexOf("http://") === 0 || val.indexOf(".htm") > -1 || val.indexOf(".aspx") > -1) {
					return "NavigateUrl";
				}
				return "Text";
			}
			if ($.type(val) === "number") {
				return "Count";
			}
			if ($.type(val) === "boolean") {
				return "IsDivider";
			}
			return null;
		},
		_fieldExists: function (prop, schema) {
			var i;
			for (i = 0; i < schema.fields.length; i++) {
				if (schema.fields[i].name === prop) {
					return true;
				}
			}
			return false;
		},
		_parseLayouts: function (layouts, cpath, options) {
			var layout, p, cdp = null;
			if (options.childLayout) {
				layout = options.childLayout;
				cdp = layout.key;
				if (!cdp) {
					cdp = this.options.defaultChildrenDataProperty;
				}
				//p = cpath + this.options.pathSeparator + cdp + ":" + layout.bindings.primaryKey;
				p = cpath + this.options.pathSeparator + cdp + ":";
				if (layout.bindings && layout.bindings.primaryKey) {
					p += layout.bindings.primaryKey;
				} else {
					p += "ig_pk";
				}
				layouts[p] = layout;
				this._parseLayouts(layouts, p, layout);
			}
		},

		// returns child options given parent options
		_optsFor: function (popts) {
			var i, o = [], layout;
			if (popts.childLayout) {
				layout = popts.childLayout;
					// handle features inheritance. Parameters passed - parent options and child options
				this._inherit(popts, layout);
				o.push($.extend(true, {}, $.mobile.igList.prototype.options, layout));
			}
			if (popts.dataSourceUrl) {
				for (i = 0; i < o.length; i++) {
					if (!o[i].dataSource) {
						o[i].dataSourceUrl = popts.dataSourceUrl;
					} else {
						o[i].dataSourceUrl = o[i].dataSource;
					}
				}
			}
			return o[0];
		},
		_inherit: function (parent, child) {
			if (parent.dataSourceType && !child.dataSourceType) {
				child.dataSourceType = parent.dataSourceType;
			}

		},
		_schemaGenerated: function (evnt, args) {
			// check the initialDataBindDepth of the root list, if it is greater than -1 (load on demand), do nothing
			// since we have load on demand and we don't care (on the client), if parent items have children or not, at this very moment
			var hList, i, rec, schema = args.schema, ds = args.dataSource, $this = args.owner, prop, child;
			hList = $this.options._hParent;
			if (this.options.dataSource && this.options.dataSource.tagName && (this.options.dataSource.tagName.toLowerCase() === "ul" || this.options.dataSource.tagName.toLowerCase() === "ol")) {
				if (($this.options.childLayout === null || $this.options.childLayout === undefined)) {
					child = $this.options.childLayout = {};
					child.key = "Children";
				}
				if ($this.options.bindings && !$this.options.bindings.primaryKey) {
					$this.options.bindings.primaryKey = "ig_hpk";
					schema.fields.push({ name: "ig_hpk", type: "number" });
					schema.primaryKey = { name: "ig_hpk", type: "number" };
				}
			}
			if (!hList || hList.options.initialDataBindDepth > -1) {
				return;
			}
			// add fields which are complex objects (or arrays)
			for (i = 0; ds && ds.length && $.type(ds) === "array" && i < ds.length; i++) {
				rec = ds[i];
				for (prop in rec) {
					if (rec.hasOwnProperty(prop)) {
						if (!$this._fieldExists(prop, schema) && ($.type(rec[prop]) === "array" || $.type(rec[prop]) === "object")) {
							schema.fields.push({ name: prop, type: $.ig.getColType(rec[prop]) });
						}
					}
				}
			}
		},
		_hierarchicalHasSubPage: function (val) {
			var opts = this.options, hList = opts._hParent, hasSubPage, childprop, layout, lod;
			hasSubPage = opts.itemDetailsTemplate !== null && opts.itemDetailsTemplate.length > 0;
			if (!hasSubPage && opts.childLayout !== null && opts.childLayout !== undefined) {
				lod = hList.options.initialDataBindDepth > -1;
				if (!lod) {
					if (val[opts.childLayout.key]) {
						childprop = opts.childLayout.key;
						layout = opts.childLayout;
					}
					childprop = childprop || opts.defaultChildrenDataProperty;
					if (childprop) {
						if (layout && layout.responseDataKey) {
							if (val[childprop] && val[childprop][layout.responseDataKey] &&
									val[childprop][layout.responseDataKey].length !== undefined &&
									val[childprop][layout.responseDataKey].length > 0) {
								hasSubPage = true;
							}
						} else {
							// make sure the case where the children also have response key is also considered: || $.type(data[childprop]) === "object" 
							if (val[childprop] &&
									val[childprop].length !== undefined &&
									val[childprop].length > 0) {
								hasSubPage = true;
							}
						}
					}
				} else {
					hasSubPage = true;
				}
			}
			return hasSubPage;
		},
		_hierarchicalCreateSubPageContent: function (dataItem, listItem) {
			var items = this._flatCreateSubPageContent(dataItem, listItem), parent = listItem.closest('.ig-listview').data('igFlatList'), parentOptions = parent.options, hList = this, cOpts, keyspath = "", itemId = "", parentListItem = parentOptions._parent, ds, childds, sp, childList, parentLevel, level, keyspathvar, isHierarchical, tmplist, tmpkey, pki, rootId, aList, noCancel, result;
			if (hList.root() && hList.root().length > 0) {
				rootId = hList.root()[0].id;
			}

			if (parentOptions.childLayout !== undefined && parentOptions.childLayout !== null) {
				cOpts = hList._optsFor(parentOptions);
				result = hList._getChildDataSource(parentOptions, cOpts, listItem, parentListItem, aList);
				itemId = result.itemId;
				keyspathvar = result.keyspathvar;
				keyspath = result.keyspath;
				if (!rootId && aList) {
					rootId = aList.element.id;
				} else if (!rootId) {
					rootId = parent.element.id;
				}
				childList = $("<div></div>").attr("id", rootId + '_' +
					listItem.attr('data-id') + '_' + cOpts.key + '_child');
				parentLevel = parseInt(parent.element.attr('data-level'), 10);
				childList.attr('id', childList.attr('id').replace(",", "-")).attr('data-level', parentLevel + 1);

				childds = hList._hds.dataAt(itemId, keyspath + keyspathvar);

				if ($.type(childds) !== "array" && !cOpts.responseDataKey && childds !== undefined) {
					childds = [childds];
				} else if (childds === null || childds === undefined) {
					childds = [];
				}

				isHierarchical = false;
				if (cOpts.childLayout) {
					isHierarchical = true;
				}
				if (hList._hds.settings.dataSource.tagName && (hList._hds.settings.dataSource.tagName.toLowerCase() === "ul" || hList._hds.settings.dataSource.tagName.toLowerCase() === "ol")) {
					isHierarchical = true;
				}
				if (isHierarchical) {
					hList._regevents(childList, hList);
				}
				cOpts._parent = listItem;
				cOpts._hParent = hList;

				level = itemId.split(parentOptions.pathSeparator).length;
				if (level > this.options.initialDataBindDepth && this.options.initialDataBindDepth !== -1) {
					sp = true;
				}
				ds = hList._hdsoptions().dataSource;

				if (!sp) {
					// pass layout / level info 
					cOpts.dataSource = childds;
					if ($.type(ds) === "string") {
						cOpts.dataSourceUrl = ds;
					}
					// if a dataSourceUrl is set, we need to ensure that we pass the path to the child list
					// so that it can be later bound from the server-side code 
					if (cOpts.dataSourceUrl && $.type(cOpts.dataSourceUrl) === 'string') {
						if (cOpts.dataSourceUrl.indexOf("?") !== -1) {
							cOpts.dataSourceUrl += "&" + hList._hds._encodeUrlPath(itemId, cOpts.key); //itemId + "/[" + cOpts.key + "]";
						} else {
							cOpts.dataSourceUrl += "?" + hList._hds._encodeUrlPath(itemId, cOpts.key);
						}
					}
					// we need to copy the ig_pk col, if present (that's given there are no primary keys defined). 
					// in that case the list is generating the primary keys itself, so that auto generation of layouts
					// works fine

					childList.igList(cOpts);
				    /*jshint -W106*/
					if (cOpts.bindings === null || cOpts.bindings === undefined || cOpts.bindings.primaryKey === null || cOpts.bindings.primaryKey === undefined) {
						tmplist = childList.data("igFlatList");
						tmpkey = tmplist.dataSource.schema() ? tmplist.dataSource.schema().schema.searchField : null;
						if (tmpkey !== null) {
							for (pki = 0; pki < cOpts.dataSource[tmpkey].length; pki++) {
								cOpts.dataSource[tmpkey][pki].ig_pk = tmplist.dataSource.data()[pki].ig_pk;
							}
						} else {
							for (pki = 0; pki < cOpts.dataSource.length; pki++) {
								if (cOpts.dataSource[pki]) {
									cOpts.dataSource[pki].ig_pk = tmplist.dataSource.data()[pki].ig_pk;
								}
							}
						}
					}
				    /*jshint +W106*/
				} else {
					// can child layouts have dataSource themselves ? i.e. sth like mashup data source?
					if (ds instanceof $.ig.DataSource) {
						if (this.options.odata) {
							childds = hList._hds.dataAt(itemId, keyspath + keyspathvar);
							// the OData spec specifies that all deferred content which hasn't been initially retrieved using $expand
							// should be contained in a __deferred object.
							if (childds.__deferred && childds.__deferred.uri) {
								cOpts.dataSource = childds.__deferred.uri;
								// we need to handle the special case when JSONP protocol is used. For that a callback=? is necessary in the URL
								// if the original data source contains this fragment, we need to ensure we add it for all dynamically constructed URLs
								// for child data sources. The OData spec doesn't say anything about $expand and __deferred syntax having callback
								// i.e. it's not inherited from parent URLs.
								if (ds.settings.dataSource.indexOf("$callback=?") !== -1) {
									cOpts.dataSource += "?$callback=?";
								}
								// copy $format
								if (ds.settings.dataSource.indexOf("$format=") !== -1) {
									if (ds.settings.dataSource.indexOf("$format=json") !== -1) {
										cOpts.dataSource += "&$format=json";
									} else {
										cOpts.dataSource += "&$format=atom";
									}
								}
							}
						} else {
							cOpts.dataSource = ds.settings.dataSource + '?' + hList._hds._encodeUrlPath(itemId, cOpts.key);
						}
					} else {
						// check for  the existence of dataSourceUrl (MVC scenario)
						if (cOpts.dataSourceUrl) {
							if (cOpts.dataSourceUrl.indexOf("?") !== -1) {
								cOpts.dataSourceUrl += '&' + hList._hds._encodeUrlPath(itemId, cOpts.key);
							} else {
								cOpts.dataSourceUrl += '?' + hList._hds._encodeUrlPath(itemId, cOpts.key);
							}
							cOpts.dataSource = cOpts.dataSourceUrl;
							cOpts.dataSourceType = "remoteUrl";
						} else {
							// 10 Oct. 2011 - Fix for bug #91254 
							if ($.type(cOpts.dataSource) === "string" && $.type(ds) !== "string") {
								/* DAY 4/11/12 106993- Exception is thrown when clicking on a category in Load On Demand sample */
								if (cOpts.dataSource.indexOf("?") === -1) {
									cOpts.dataSource += '?' + hList._hds._encodeUrlPath(itemId, cOpts.key);
								} else {
									cOpts.dataSource += '&' + hList._hds._encodeUrlPath(itemId, cOpts.key);
								}
								cOpts.dataSourceType = "remoteUrl";
							} else if ($.type(ds) === "string") {
								if (cOpts.dataSource.indexOf("?") === -1) {
									cOpts.dataSource += '?' + hList._hds._encodeUrlPath(itemId, cOpts.key);
								} else {
									cOpts.dataSource += '&' + hList._hds._encodeUrlPath(itemId, cOpts.key);
								}
								//hList._hds.populate(itemId, $.proxy(this._populateComplete, this), params);
							} else {//added by dave 
								cOpts.dataSource = childds;
							}
						}
					}
				}
				if (sp) {
					// fire children populating
					noCancel = this._trigger(this.events.childrenPopulating, null, {owner: this, parentitem: listItem, id: itemId});
					if (noCancel) {
						childList.igList(cOpts);
						// fire childrenPopulated event
						this._trigger(this.events.childrenPopulated, null, {owner: this, parentitem: listItem, id: itemId});
					}
				}
				items[items.length++] = childList.parent()[0];
			}
			return items;
		},
		/* DAY 3/30/12 107422- When child layout has remote loadOnDemand and after loading item children are not correct */
		_getChildDataSource: function (parentOptions, cOpts, listItem, parentListItem, aList) {
			var itemId = "", keyspath = "", keyspathvar = "", o, k, curpath = 0, hOpts = this.options;
			if (parentOptions.key) {
				keyspath = parentOptions.key;
			}
			while (parentListItem) {
				if (curpath !== 0) {
					itemId += hOpts.pathSeparator;
				}
				aList = parentListItem.closest('.ig-listview').data('igFlatList');
				o = parentListItem.closest('.ig-listview').data('igFlatList').options;
				k = o.bindings.primaryKey;
				itemId += k + ':' + parentListItem.attr('data-id');
				if (o.key) {
					keyspath += hOpts.pathSeparator + o.key;
				}
				parentListItem = o._parent;
				curpath++;
			}
			// reverse keyspath and itemId
			keyspath = keyspath.split(hOpts.pathSeparator).reverse().join(hOpts.pathSeparator);
			itemId = itemId.split(hOpts.pathSeparator).reverse().join(hOpts.pathSeparator);

			k = parentOptions.bindings.primaryKey;
			if (itemId === "") {
				itemId = k + ':' + listItem.attr('data-id');
			} else {
				itemId += hOpts.pathSeparator + k + ':' + listItem.attr('data-id');
			}

			if (keyspath === "") {
				keyspathvar = cOpts.key;
			} else {
				keyspathvar = hOpts.pathSeparator + cOpts.key;
			}
			return {"itemId": itemId, "keyspath": keyspath, "keyspathvar": keyspathvar};
		},
		_listInitialized: function (event, args) {
			args.owner._hasSubPage = $.proxy(this._hierarchicalHasSubPage, args.owner);
			this._flatCreateSubPageContent = $.proxy(args.owner._createSubPageContent, args.owner);
			args.owner._createSubPageContent = $.proxy(this._hierarchicalCreateSubPageContent, this);
		},
		_itemsRendered: function (evnt, args) {
			var list = args.owner, hasSubPages = args.hasSubPages;
			if (hasSubPages && !(list.options.itemDetailsTemplate !== undefined && list.options.itemDetailsTemplate !== null && list.options.itemDetailsTemplate.length > 0)) {
				list.element.bind("click", function (evnt) {
					list._listTap(evnt);
				});
			}
		},
		// decorates the flat list with hierarchical functionality 
		_regevents: function (e, context) {
			var schemaGenerated, cancelEvent, listInitialized, itemsRendered;
			schemaGenerated = $.proxy(this._schemaGenerated, context);
			e.bind("iglistschemagenerated", schemaGenerated);
			listInitialized = $.proxy(this._listInitialized, context);
			e.bind("iglistrenderingtray", listInitialized);
			itemsRendered = $.proxy(this._itemsRendered, context);
			e.bind("iglistitemsrendered", itemsRendered);
			cancelEvent = function (e) {
				e.stopPropagation();
				e.preventDefault();
				return false;
			};
		},
		// auto generation of layouts
		_generateLayouts: function () {
			var rec, i, ds = this.options.dataSource;
			if (($.type(ds) !== "array" && $.type(ds) !== "object") || ds.length === 0) {
				return;
			}
			if ($.type(ds) === "object" && this.options.responseDataKey) {
				ds = ds[this.options.responseDataKey] || ds;
			}
			for (i = 0; i < ds.length; i++) {
				rec = ds[i];
				this._generateLayout(rec, this.options);
			}
		},
		_generateLayout: function (record, options) {
			var name, layout, tmpLayout, i, rec, hasRespKey = false;
			for (name in record) {
				if (record.hasOwnProperty(name) && ($.type(record[name]) === "array" ||
					($.type(record[name]) === "object" && options.responseDataKey && $.type(record[name][options.responseDataKey]) === "array"))) {
					rec = record[name];
					if (options.responseDataKey && $.type(rec) === "object") {
						if (rec[options.responseDataKey] && $.type(rec[options.responseDataKey]) === "array") {
							rec = rec[options.responseDataKey];
							hasRespKey = true;
						} else {
							continue;
						}
					}
					layout = {key: name};
					if (hasRespKey) {
						layout.responseDataKey = options.responseDataKey;
					}
					// check if the layout exists. Needs to be recursive. 
					tmpLayout = this._layoutExistsRecursive(this.options, name);
					if (!tmpLayout) {
						if (options.childLayout === undefined || options.childLayout === null) {
							options.childLayout = layout;
						}
					} else {
						layout = tmpLayout;
					}
					if (rec.length > 0) {
						for (i = 0; i < rec.length; i++) {
							this._generateLayout(rec[i], layout);
						}
					}
				}
			}
		},
		_layoutExistsRecursive: function (options, key) {
			var tmpLayout = null;
			tmpLayout = options.key === key ? options : tmpLayout;
			if (!tmpLayout && options.childLayout) {
				tmpLayout = this._layoutExistsRecursive(options.childLayout, key);
			}
			return tmpLayout;
		},
		destroy: function () {
			/* destroys the hierarchical list by recursively destroying all child lists */
			this.tmpDataSource = null;
			this.rootWidget().destroy();
			$.Widget.prototype.destroy.call(this);
		}
	});
	function _addDash(c) {
		return "-" + c.toLowerCase();
	}
	function parseBindings(element, options) {
		var added = false, nullAtStart = false, binding, value, bindingsPrototype = $.mobile.igList.prototype.options.bindings;
		if (!options.bindings) {
			nullAtStart = true;
			options.bindings = {};
		}
		if (!bindingsPrototype) {
			bindingsPrototype = _originalBindings;
		}
		for (binding in bindingsPrototype) {
			if (bindingsPrototype.hasOwnProperty(binding)) {
				value = element.jqmData("bindings-" + binding.replace(/[A-Z]/g, _addDash));
				if (value !== undefined) {
					added = true;
					options.bindings[binding] = value;
				}
			}
		}
		if (!added && nullAtStart) {
			options.bindings = null;
		}
	}
	function parseSimpleProps(element, options, type) {
		var option, value;
		for (option in type.prototype.options) {
			if (type.prototype.options.hasOwnProperty(option)) {
				value = element.jqmData(option.replace(/[A-Z]/g, _addDash));
				if (value !== undefined) {
					options[option] = value;
				}
			}
		}
	}
	function parseSimpleFlatListProps(element, options) {
		var value;
		parseSimpleProps(element, options, $.mobile.igList);
		value = element.jqmData("key");
		if (value !== undefined) {
			options.key = value;
		}
	}
	function parseLevel(list, options, parse) {
		var items, args, subList;
		if (parse === undefined) {
			parse = true;
		}
		items = list.children(":jqmData(role='itemTemplate')");
		if (items.length > 0) {
			options.itemTemplate = unescape(items.first().html());
		}
		items = list.children(":jqmData(role='detailsTemplate')");
		if (items.length > 0) {
			options.itemDetailsTemplate = unescape(items.first().html());
		}
		if (parse) {
			parseSimpleFlatListProps(list, options);
			parseBindings(list, options);
			args = {element: list, options: options};
			$(document).trigger("_igListViewHtmlOptions", args);
			$(document).trigger("_igListViewHtmlEvents", args);
			options = args.options;
		}
		subList = list.children("li").children("ul:jqmData(role='childLayout'), ol:jqmData(role='childLayout')");
		if (subList.length > 0) {
			options.childLayout = {};
			parseLevel(subList, options.childLayout);
		}
	}
	//auto self-init widgets
	function _igmListAutoInit(e) {
		var target = document;
		if (e) {
			target = e.target;
		}
		$($.mobile.igListView.prototype.options.initSelector, target).each(function () {
			var $this = $(this), optObj = {_fromHtml: true}, options = $this.jqmData('options'), list = $this, args, parseLevelOne = true;
			if ($this.data('igListView')) {
				return;
			}
			if (options) {
			    try {
			        /*jshint -W061*/
			        optObj = eval(options);
			        /*jshint +W061*/
				} catch (exc) {
					try {
						optObj = $.parseJSON(options);
					} catch (exc2) {
						optObj = {};
					}
				}
			}
			if (!(list.is("ul") || list.is("ol"))) {
				parseSimpleFlatListProps($this, optObj);
				parseBindings($this, optObj);
				args = {element: list, options: optObj, listElement: list.children("ul,ol")};
				$(document).trigger("_igListViewHtmlOptions", args);
				$(document).trigger("_igListViewHtmlEvents", args);
				parseLevelOne = false;
				list = list.children("ul,ol");
			}
			parseSimpleProps(list, optObj, $.mobile.igListView);
			parseLevel(list, optObj, parseLevelOne);
			$this.igListView(optObj);
		});
	}

	if ($.ig && $.ig.loader) {
		$.ig.loader().preinit(_igmListAutoInit);
	}

	$(document).bind("pagecreate create", _igmListAutoInit);

	// Expose igListView as an AMD module, but only for AMD loaders that
	// understand the issues with loading multiple versions of jQuery
	// in a page that all might call define(). The loader will indicate
	// they have special allowances for multiple jQuery versions by
	// specifying define.amd.jQuery = true. Register as a named module,
	// since jQuery can be concatenated with other files that may use define,
	// but not use a proper concatenation script that understands anonymous
	// AMD modules. A named AMD is safest and most robust way to register.
	// Lowercase ig.mobileui.list is used because AMD module names are derived from
	// file names, and jQuery is normally delivered in a lowercase file name.
	// Do this after creating the global so that if an AMD module wants to call
	// noConflict to hide this version of jQuery, it will work.
	if (typeof define === "function" && define.amd && define.amd.jQuery) {
		define("ig.mobileui.list", ["ig.util", "ig.datasource", "ig.mobileui.flatlist"], function () { return $.mobile.igListView; });
	}

	$.extend($.mobile.igListView, { version: '15.1.20151.2352' });
}(jQuery));



